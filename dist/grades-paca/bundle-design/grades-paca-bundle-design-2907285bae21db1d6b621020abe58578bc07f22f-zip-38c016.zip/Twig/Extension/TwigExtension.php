<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 10/06/14
 */

namespace Oru\Bundle\DesignBundle\Twig\Extension;


class TwigExtension extends \Twig_Extension
{
    /**
     * @var \Twig_Environment
     */
    private $environment;

    function __construct(\Twig_Environment $environment)
    {
        $this->environment = $environment;
    }

    /**
     * Return the functions registered as twig extensions
     *
     * @return array
     */
    public function getFunctions()
    {
        return array(
            'file_exists' => new \Twig_Function_Function('file_exists'),
            'html_entity_decode'    => new \Twig_Function_Function('html_entity_decode')
        );
    }

    /**
     * Return the filters registered as twig extensions
     *
     * @return array
     */
    public function getFilters()
    {
        return array(
            new \Twig_SimpleFilter('slice_tooltip', array($this, 'sliceTooltip'), array('is_safe'=>array('html'))),
        );
    }

    public function sliceTooltip($item, $start = 0, $length = 20, $preserveKeys = false) {
        $newItem = twig_slice($this->environment, $item, $start, $length, $preserveKeys);

        if(!is_array($newItem) && strlen($item) > strlen($newItem))
        {
            return '<span data-toggle="tooltip" title="'.twig_escape_filter($this->environment,$item).'">'.twig_escape_filter($this->environment,$newItem).'...</span>';
        }

        return twig_escape_filter($this->environment,$newItem);
    }

    public function getName()
    {
        return 'twig_extension';
    }
}
