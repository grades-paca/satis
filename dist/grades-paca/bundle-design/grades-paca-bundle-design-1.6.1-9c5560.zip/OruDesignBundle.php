<?php

namespace Oru\Bundle\DesignBundle;

use Oru\Bundle\SettingBundle\Bundle\OruBundle;

class OruDesignBundle extends OruBundle
{
    public static function getFriendlyName()
    {
        return 'Maquette globale';
    }

    public static function getDescription()
    {
        return 'Gestion des éléments de la maquette graphique globale';
    }
}
