jQuery(document).ready(function(){
    jQuery('ul.flash').each(function(){
        var bg_color = jQuery(this).css('background-color');
        $(this).animate({ backgroundColor: 'white' }, 300);
        $(this).animate({ backgroundColor: bg_color }, 1000);
    });
});
