function ajaxBegin()
{
    jQuery('body').prepend('<div class="ajax-loading"><img src="/bundles/orudesign/images/ajax-loader.gif" /></div>');
}
function ajaxStop()
{
    jQuery('div.ajax-loading').remove();
}
jQuery('a').click(function(e){
    var aElement = jQuery(this);
    var match,
        pl     = /\+/g,  // Regex for replacing addition symbol with a space
        search = /([^&=]+)=?([^&]*)/g,
        decode = function (s) { return decodeURIComponent(s.replace(pl, " ")); },
        query  = jQuery(aElement).get(0).search.substring(1);

    urlParams = {};
    while (match = search.exec(query))
        urlParams[decode(match[1])] = decode(match[2]);

    if(urlParams['_method'] != undefined)
    {
        if(urlParams['_method'] == 'DELETE' && !confirm('Êtes-vous sûr de vouloir supprimer cet élément ?'))
        {
            e.preventDefault();
            return;
        }
        e.preventDefault();
        ajaxBegin();
        jQuery.post(jQuery(aElement).get(0).pathname, urlParams).done(
            function(data){
                if (data.redirect) {
                    window.location.href = data.redirect;
                }
                else {
                    ajaxStop();
                    alert('Une erreur est survenue.');
                }
            }).fail(
            function(xhr)
            {
                ajaxStop();
                if(xhr.status == '403')
                    alert('Vous n\'avez pas les droits suffisants.');
                else
                    alert('Une erreur est survenue.');
            }
        );
    }
});