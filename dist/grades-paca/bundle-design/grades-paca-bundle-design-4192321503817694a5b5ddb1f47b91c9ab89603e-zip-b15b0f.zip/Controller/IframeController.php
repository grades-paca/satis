<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 10/07/14
 */

namespace Oru\Bundle\DesignBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class IframeController extends Controller
{
    /**
     * @param Request $request
     */
    public function indexAction(Request $request)
    {
        if (!$request->get('url')) {
            throw new NotFoundHttpException('Aucune url trouvée pour cette iframe.');
        }
        return $this->render(
            '@OruDesign/Default/iframe.html.twig',
            array(
                'url' => $request->get('url'),
            )
        );
    }
}
