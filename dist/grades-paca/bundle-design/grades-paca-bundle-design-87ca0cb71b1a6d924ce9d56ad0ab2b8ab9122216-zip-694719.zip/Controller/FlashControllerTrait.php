<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 24/02/14
 * Time: 10:41
 */

namespace Oru\Bundle\DesignBundle\Controller;

/**
 * Class FlashControllerTrait
 * @package Oru\Bundle\DesignBundle\Controller
 * @author Michaël VEROUX
 */
trait FlashControllerTrait
{
    /**
     * @param $message
     * @param string $type debug|notice|warning|error
     * @author Michaël VEROUX
     */
    public function addSessionMessage($message, $type = 'notice')
    {
        if('debug' === $type && 'dev' !== $this->container->getParameter('kernel.environment'))
            return;

        $this->get('session')->getFlashBag()->add(
            $type,
            $message
        );
    }

} 