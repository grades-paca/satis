function select2ror() {
    $("select[class!='no-select2']").each(function() {
        oneSelect2ror($(this));
    });
}

function oneSelect2ror(field) {
    if(!field.next().is('.select2')) {

        var $options = [];

        // empty selected value
        if (field.attr('required')) {
            $options['allowClear'] = false;
        } else {
            $options['allowClear'] = true;
        }

        // placeholder if no placeholder and no empty value option
        placeholder = field.attr('placeholder');
        emptyValue = field.children('option').filter(function() { return !this.value || $.trim(this.value).length == 0; });
        if((placeholder === undefined || placeholder === false)) {
            if(emptyValue.length && $.trim(emptyValue.html()) != '' && $.trim(emptyValue.html()) != '&nbsp;') {
                $options['placeholder'] = emptyValue.html();
            } else {
                $options['placeholder'] = 'Choisissez une option';
            }
        } else {
            $options['placeholder'] = placeholder;
        }

        // close on select
        if (field.attr('multiple') && !field.hasClass('closeOnSelect')) {
            $options['closeOnSelect'] = false;
        } else {
            $options['closeOnSelect'] = true;
        }

        var $flag = false;
        if ($('#s2id_' + $(this).attr('id')).length) {
            vals = field.val();
            $('#s2id_' + field.attr('id')).remove();
            var $flag = true;
        }

        field.select2($options);

        if ($flag) {
            field.val(vals);
        }
    }
}

$.ui.dialog.prototype._allowInteraction = function(e) {
    return !!$(e.target).closest('.ui-dialog, .ui-datepicker, .select2-drop').length;
};

function tooltips() {
    // jQuery UI
    $('.tooltip').tooltip();

    // Bootstrap
    $('[data-toggle="tooltip"]').tooltip();
}

$(document).ready(function() {
    // surcharge des champs html select
    select2ror();

    // ajout des tooltips
    tooltips();

    // surcharge des champs html de type time
    if (!Modernizr.inputtypes.time) {
        $("input[type=time]").clockpicker({
            autoclose:true
        });
    }

    // Bootstrap button drop-down inside responsive table not visible because of scroll
    $('.table-responsive').on('show.bs.dropdown', function () {
        $('.table-responsive').css( "overflow", "inherit" );
    });

    $('.table-responsive').on('hide.bs.dropdown', function () {
        $('.table-responsive').css( "overflow", "auto" );
    });

    $("body").find("a[target=_blank]:not(.without-external-icon)").each(function () {
        var glyfClass = "glyphicon glyphicon-new-window"; //Links
        if($(this).parent().hasClass("attachment_filename")){
            glyfClass = "glyphicon glyphicon-save"; //Files
        }
        $(this)
            .contents()
            .filter(function() {
                return this.nodeType === 3; //Node.TEXT_NODE
            })
            .before($('<i class="externalLink '+glyfClass+'">'));

        if(!$(this).attr('title')){
            $(this).attr('title','Lien externe');
        }
        if(!$(this).find('img').attr('alt')){
            $(this).find('img').attr('alt','Lien externe');
        }
    });
});