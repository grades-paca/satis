jQuery(document).ready(function(){
    jQuery('ul.flash').each(function(){
        var bg_color = jQuery(this).css('background-color');
        $(this).animate({ backgroundColor: 'white' }, 300);
        $(this).animate({ backgroundColor: bg_color }, 1000);
    });
});

PNotify.prototype.options.styling = "bootstrap3";

function show_notif(text, type) {
    var opts = {
        title: "Information.",
        text: text,
        type: "info",
        nonblock: {
            nonblock: true
        }
    };
    switch (type) {
        case 'error':
            opts.title = "Erreur !";
            opts.type = "error";
            break;
        case 'info':
            opts.type = "info";
            break;
        case 'warning':
            opts.title = "Attention...";
            opts.type = "notice";
            break;
        case 'success':
            opts.title = "Succès.";
            opts.type = "success";
            break;
    }
    new PNotify(opts);
}

/**
 * Display current notifications using show_notif function
 *
 * @using show_notif
 */
function show_notifs()
{
    $.ajax(Routing.generate('oru_design_flash')).success(function(data) { 
        if(data) {
            if(data.notice && data.notice.length) {
                for (i = 0; i < data.notice.length; i++) {
                    show_notif(data.notice[i], 'info');
                }
            }
            if(data.error && data.error.length) {
                for (i = 0; i < data.error.length; i++) {
                    show_notif(data.error[i], 'error');
                }
            }
            if(data.info && data.info.length) {
                for (i = 0; i < data.info.length; i++) {
                    show_notif(data.info[i], 'info');
                }
            }
            if(data.warning && data.warning.length) {
                for (i = 0; i < data.warning.length; i++) {
                    show_notif(data.warning[i], 'warning');
                }
            }
            if(data.success && data.success.length) {
                for (i = 0; i < data.success.length; i++) {
                    show_notif(data.success[i], 'success');
                }
            }
        }
    });
}