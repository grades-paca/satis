<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\DesignBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;

class FlashController extends Controller
{
    public function indexAction()
    {
        return new JsonResponse($this->get('session')->getFlashBag()->all());
    }
}
