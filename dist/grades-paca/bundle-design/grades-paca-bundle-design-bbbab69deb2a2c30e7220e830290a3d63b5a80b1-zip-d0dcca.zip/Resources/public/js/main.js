function select2ror() {
    $("select[class!='no-select2']").each(function() {
        if ($('#s2id_' + $(this).attr('id')).length)
        {
            vals = $(this).select2('val');
            $('#s2id_' + $(this).attr('id')).remove();
            $(this).select2({ allowClear: true, dropdownAutoWidth: true });
            $(this).select2('val', vals);
        }
        else $(this).select2({ allowClear: true, dropdownAutoWidth: true });
    });
}

function oneSelect2ror(field) {
    $(field).select2({ allowClear: true, dropdownAutoWidth: true });
}

$.ui.dialog.prototype._allowInteraction = function(e) {
    return !!$(e.target).closest('.ui-dialog, .ui-datepicker, .select2-drop').length;
};

function tooltips() {
    // jQuery UI
    $('.tooltip').tooltip();

    // Bootstrap
    $('[data-toggle="tooltip"]').tooltip();
}

$(document).ready(function() {
    // surcharge des champs html select
    select2ror();

    // ajout des tooltips
    tooltips();

    // surcharge des champs html de type time
    if (!Modernizr.inputtypes.time) {
        $("input[type=time]").timepicker({
            showPeriodLabels: false,
            showNowButton: true,
            showCloseButton: true,
            showDeselectButton: true
        });
    }

    // Bootstrap button drop-down inside responsive table not visible because of scroll
    $('.table-responsive').on('show.bs.dropdown', function () {
        $('.table-responsive').css( "overflow", "inherit" );
    });

    $('.table-responsive').on('hide.bs.dropdown', function () {
        $('.table-responsive').css( "overflow", "auto" );
    });

    $("body").find("a[target=_blank]").each(function () {
        var glyfClass = "glyphicon glyphicon-new-window"; //Links
        if($(this).parent().hasClass("attachment_filename")){
            glyfClass = "glyphicon glyphicon-save"; //Files
        }
        $(this)
            .contents()
            .filter(function() {
                return this.nodeType === 3; //Node.TEXT_NODE
            })
            .before($('<i class="externalLink '+glyfClass+'">'));

            $(this)
            .find('img').attr('alt','Lien externe')
            .parent()
            .find(':not(img)').attr('title','Lien externe');
    });
});