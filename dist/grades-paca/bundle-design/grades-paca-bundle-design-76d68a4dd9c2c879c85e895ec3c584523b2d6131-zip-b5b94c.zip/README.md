Bundle OruDesignBundle
======================

Description
-----------

Ce bundle regroupe des fonctionnalités utiles à toute l'application. Le but de celui-ci est de regrouper toutes les surcharges de champs, tant au niveau fonctionnalités que affichage, de manière à avoir un comportement uniforme sur différentes plateformes tout en gardant la possibilité de remplacer ou retirer facilement un comportement.

Voici quelques unes des fonctionnalités disponibles dans ce bundle :
* un template par défaut avec l'inclusion de librairies comme jQuery, jQuery UI, Modernizer, Normalize...,
* les js (main.js) et css (main.css) par défaut de l'application,
* les surcharges des champs de formulaires comme les listes de sélection, datetime, éditeurs de texte avancé...

Ce bundle surcharge automatiquement les champs html de type 'date' et 'time' pour les navigateurs qui ne supportent pas encore ces types de champ.
Les librairies ajoutées dans le template par défaut sont celles qui doivent être disponibles sur toutes les pages.

A terme, il faudra surement séparer la partie formulaire (guessers, nouveaux champs de formulaires...) et affichage (templates, plugins jquery...). Les fichiers main.css et main.js devront surement être séparés, le but actuel étant de fournir un support à toute la partie esthétique du ROR.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/design":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oryzone\Bundle\BoilerplateBundle\OryzoneBoilerplateBundle();
$bundles[] = new FM\ElfinderBundle\FMElfinderBundle();
$bundles[] = new Pinano\Select2Bundle\PinanoSelect2Bundle();
$bundles[] = new Oru\Bundle\DesignBundle\OruDesignBundle();
$bundles[] = new FOS\JsRoutingBundle\FOSJsRoutingBundle();
$bundles[] = new SunCat\MobileDetectBundle\MobileDetectBundle();
```

Suivre la documentation d'installation du bundle OruFormBundle.

Dans le config.yml, ajouter ce bundle aux paramètres imports :

```
imports:
    ...
    - { resource: @OruDesignBundle/Resources/config/config.yml }
```

Dans le routing.yml, ajouter la nouvelle route :

```
oru_design:
    resource: "@OruDesignBundle/Resources/config/routing.yml"
```

Suivre la documentation d'installation du bundle OruFormBundle.

Vider le cache de Symfony2

Utilisation
-----------

Toutes les listes déroulantes sont surchargées sauf celles ayant la classe css *no-select2*.
Pour surcharger les feuilles de styles disponibles dans les headers, il faut utiliser le bloc twig *head_css*.
Le contenu des pages doit être ajouté au bloc twig *body_container_main*.
Pour surcharger les fichiers et le code javascript disponibles en fin de page, il faut utiliser le bloc twig *body_js_jquery*.

### Utilisation des flashes

Utiliser le trait FlashControllerTrait dans le controller pour bénéficier d'une méthode "addSessionMessage($message, $type = 'notice')"

```php
use Oru\Bundle\DesignBundle\Controller\FlashControllerTrait;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class ExtendedController extends Controller
{
    use FlashControllerTrait;
}
```

Utiliser la fonction javascript show_notifs pour récupérer et afficher les notifications en ajax.

### Utilisation des macros

Ce bundle fournit un ensemble de macros twig pour afficher certains types de champs :

#### une collection

```twig
{{ macros.collection(collection) }}
```

Affichage d'une collection sous forme de liste non ordonnée.

#### un booléen

```twig
{{ macros.boolean(booleen) }}
```

Cette macro gère la valeur null et renvoie une chaîne traduite.

#### une entité

```twig
{{ macros.entity(entite) }}
```

Utilisation de la fonction toString pour afficher l'entité. Cette macro gère les entités archivées.

#### un numéro de téléphone

```twig
{{ macros.phone(telephone, format) }}
```

Le format par défaut est 'NATIONAL'. Plus d'informations sur https://github.com/misd-service-development/phone-number-bundle.


### Utilisation des iframes

```twig
{{ render(controller('OruDesignBundle:Iframe:index', {'url': url})) }}
```