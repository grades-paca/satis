<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 10/06/14
 */

namespace Oru\Bundle\DesignBundle\Twig\Extension;


class TwigExtension extends \Twig_Extension implements \Twig_Extension_InitRuntimeInterface
{
    /**
     * @var \Twig_Environment
     */
    protected $environment;

    /**
     * {@inheritDoc}
     */
    public function initRuntime(\Twig_Environment $environment)
    {
        $this->environment = $environment;
    }

    /**
     * Return the functions registered as twig extensions
     *
     * @return array
     */
    public function getFunctions()
    {
        return array(
            new \Twig_SimpleFunction('file_exists', array('file_exists')),
            new \Twig_SimpleFunction('html_entity_decode', array($this, 'unescape'))
        );
    }

    /**
     * Return the filters registered as twig extensions
     *
     * @return array
     */
    public function getFilters()
    {
        return array(
            new \Twig_SimpleFilter('slice_tooltip', array($this, 'sliceTooltip'), array('is_safe'=>array('html'))),
        );
    }

    public function sliceTooltip($item, $start = 0, $length = 20, $preserveKeys = false) {
        $newItem = twig_slice($this->environment, $item, $start, $length, $preserveKeys);

        if(!is_array($newItem) && strlen($item) > strlen($newItem))
        {
            return '<span data-toggle="tooltip" title="'.twig_escape_filter($this->environment,$item).'">'.twig_escape_filter($this->environment,$newItem).'...</span>';
        }

        return twig_escape_filter($this->environment,$newItem);
    }

    /**
     * @param $data
     * @return string
     */
    function unescape($data)
    {
        return html_entity_decode($data);
    }

    public function getName()
    {
        return 'twig_extension';
    }
}
