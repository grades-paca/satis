<?php

namespace Oru\Bundle\DesignBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruDesignBundle extends Bundle
{
}
