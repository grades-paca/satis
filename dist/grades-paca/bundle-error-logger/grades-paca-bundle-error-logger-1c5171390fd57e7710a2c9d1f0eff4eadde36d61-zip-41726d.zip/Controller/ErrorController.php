<?php
/**
 * Author: Michaël VEROUX
 * Date: 29/10/14
 * Time: 16:18
 */

namespace Oru\Bundle\ErrorLoggerBundle\Controller;

use Oru\Bundle\ErrorLoggerBundle\Entity\Error;
use Oru\Bundle\ErrorLoggerBundle\Form\Filter\ErrorFilterType;
use Oru\Bundle\ErrorLoggerBundle\Listing\ErrorListingType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class ErrorController extends Controller
{
    /**
     * @var array
     */
    private $filterDefault = array('info' => '0', 'session' => null);

    /**
     * @param Request $request
     * @param null    $form
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function indexAction(Request $request, $form = null)
    {
        $this->credentialCheck();
        if (null === $form) {
            $form = $this->createForm(ErrorFilterType::class)->submit($this->getFilterDefault($request));
        }

        $entities = $this->getDoctrine()->getRepository('OruErrorLoggerBundle:Error')->queryList($form->getData());

        $listing = $this->container->get('paginator.factory')->create(
            new ErrorListingType(),
            $entities,
            $request->query->get('page', 1)
        );

        return $this->render('@OruErrorLogger/Error/index.html.twig',
            array(
                'listing' => $listing,
                'form' => $form->createView(),
            )
        );
    }

    public function filterAction(Request $request)
    {
        $this->credentialCheck();
        $form = $this->createForm(ErrorFilterType::class)->handleRequest($request);

        if ($form->get('reset')->isClicked()) {
            $request->getSession()->set('oru_error_logger.filter', $this->filterDefault);

            return $this->redirect($this->generateUrl('oru_error'));
        }

        if ($form->isValid()) {
            $request->getSession()->set('oru_error_logger.filter', $request->get($form->getName()));

            return $this->redirect($this->generateUrl('oru_error'));
        }

        return $this->indexAction($request, $form);
    }

    public function showAction(Error $entity)
    {
        $this->credentialCheck();

        return $this->render('@OruErrorLogger/Error/show.html.twig',
            array(
                'entity' => $entity,
            )
        );
    }

    /**
     * @param Error $error
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     *
     * @author Michaël VEROUX
     */
    public function stopAction(Error $error)
    {
        $this->credentialCheck();

        $e = $this->get('oru_error_logger.duplicate')->convertErrorEntityToException($error);
        $this->get('oru_error_logger.duplicate')->stop($e);
        $this->get('session')->getFlashBag()->add(
            'notice',
            sprintf('Les erreurs identiques à l\'erreur %d ne sont plus logguées.', $error->getId())
        );

        return $this->redirectToRoute('oru_error');
    }

    public function notFoundAction()
    {
        $response = $this->render('@OruErrorLogger/Error/notfound.html.twig', array()
        );

        $response->setStatusCode('404');

        return $response;
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    private function credentialCheck()
    {
        if ($this->has('oru_ror_credentials.credentials_checker')) {
            if ($this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ROR_ADMIN')) {
                return true;
            }
        }

        throw new AccessDeniedHttpException();
    }

    /**
     * @param Request $request
     *
     * @return mixed
     *
     * @author Michaël VEROUX
     */
    private function getFilterDefault(Request $request)
    {
        $defaultFilter = $request->getSession()->get('oru_error_logger.filter', array('info' => $request->query->get('session', '0'), 'session' => $request->query->get('session', null)));

        return $defaultFilter;
    }
}
