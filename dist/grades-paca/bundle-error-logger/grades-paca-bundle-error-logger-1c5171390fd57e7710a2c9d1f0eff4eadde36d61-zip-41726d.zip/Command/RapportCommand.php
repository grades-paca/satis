<?php

namespace Oru\Bundle\ErrorLoggerBundle\Command;

use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class RapportCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    /**
     * Doit renvoyer le nombre de secondes d'exécution acceptable avant que le gestionnaire de taches ne tue le processus
     * 0 si pas de limite.
     *
     * @return int
     **/
    public function getMaxRunningTimeSec()
    {
        return 30;
    }

    /**
     * Doit renvoyer un booleen signalant si la tache accepte d'être exécutée en parallèle avec d'autres taches issus de la même commande.
     *
     * @return bool
     */
    public function isConcurentAllowed()
    {
        return false;
    }

    /**
     * Cette methode fait le lien entre un nom de parametre ou d'option, et le type de champ au sens "formulaire symfony"
     * Si elle est implémentée vide, tout sera considéré comme du texte.
     *
     * Fonctionnement:
     * En fonction du nom de l'argument ou de l'option spécifié par $name
     * il faut affecter les variables passées en référence $type et $options
     * Ces variables seront utilisées lors de la génération du formulaire symfony d'interface graphique pour gêrer l'exécution du script
     * et seront passées à la commande FormBuilder::add (voir options de cette commande pour plus de détail sur le contenu éventuel de $options)
     *
     * @param mixed $name
     *
     * @return mixed
     */
    public function getTypeFieldFromArgumentName($name, &$type = 'text', &$options = array())
    {
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this
            ->setName('oru:error:rapport')
            ->setDescription('Envoi des rapports d\'erreur par mail.');
    }

    /**
     * {@inheritdoc}
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $em = $this->getContainer()->get('doctrine')->getManager();

        try {
            $version = $em->getRepository('OruVersionBundle:Version')->findLastVersion();
            if ($version) {
                $lastInstallDate = $version->getCreatedAt();
                $this->getContainer()->get('oru_error_logger.rapport')->setSince($lastInstallDate);
            }
        } catch (\Exception $e) {
            // Tant pis ! :-)
        }

        $nb = $this->getContainer()->get('oru_error_logger.rapport')->sendAll();
        if (1 < $nb) {
            $output->writeln(sprintf('Envoi de %d rapports.', $nb));
        } else {
            $output->writeln(sprintf('Envoi de %d rapport.', $nb));
        }
    }
}
