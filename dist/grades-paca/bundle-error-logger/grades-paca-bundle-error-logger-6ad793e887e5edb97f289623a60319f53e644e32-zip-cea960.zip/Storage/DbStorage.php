<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 12/12/13
 * Time: 16:47
 */

namespace Oru\Bundle\ErrorLoggerBundle\Storage;

use Doctrine\ORM\EntityManager;
use Monolog\Formatter\FormatterInterface;
use Monolog\Handler\AbstractProcessingHandler;
use Monolog\Logger;
use Oru\Bundle\ErrorLoggerBundle\Entity\Error;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;

class DbStorage extends AbstractProcessingHandler
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    protected $entityManager = null;

    /**
     * @var \Symfony\Component\DependencyInjection\Container
     */
    protected $container = null;

    protected $record = array();

    /**
     * @param \Doctrine\ORM\EntityManager $entityManager
     */
    public function setEntityManager(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    public function setContainer(Container $container)
    {
        $this->container = $container;
    }


    /**
     * Writes the record down to the log of the implementing handler
     *
     * @param  array $record
     * @return void
     */
    protected function write(array $record)
    {
        $this->record = $record;

        /** @var \Symfony\Component\HttpFoundation\Request|null $request */
        $request = $this->container->isScopeActive('request') ? $this->container->get('request') : null;

        $error = new Error();
        $error->setMessage($this->getFromRecord('message'));
        $error->setFile($this->getFile());
        $error->setLine($this->getLine());
        $error->setTrace($this->getTrace());
        $error->setType($this->getType());
        $error->setCode($this->getCode());
        if($request)
        {
            $error->setUri($request->getRequestUri());
            $error->setRoute($request->get('_route'));
            $error->setController($request->get('_controller'));
            $error->setUserAgent($request->headers->get('User-Agent'));
        }

        if($this->container->get('security.token_storage')->getToken() instanceof TokenInterface)
        {
            $error->setUserContext($this->container->get('security.token_storage')->getToken());
            $error->setUser($this->container->get('security.token_storage')->getToken()->getUsername());
        }

        if (!$this->entityManager->isOpen()) {
            $this->entityManager = $this->entityManager->create(
                $this->entityManager->getConnection(),
                $this->entityManager->getConfiguration()
            );
        }

        $this->entityManager->persist($error);
        $this->entityManager->flush($error);

//        if('dev' === $this->container->getParameter("kernel.environment"))
//            file_put_contents('/tmp/error.log', (string) $record['formatted']);
    }

    private function getFromRecord($name)
    {
        if(isset($this->record[$name]))
            return $this->record[$name];
        else
            return '';
    }

    private function getFromRecordContext($name)
    {
        $context = $this->getFromRecord('context');
        if('' !== $context && isset($context[$name]))
            return $context[$name];
        else
            return '';
    }

    private function getException()
    {
        if($exception = $this->getFromRecordContext('exception'))
        {
            if($exception instanceof \Exception)
            {
                return $exception;
            }
        }
        return null;
    }

    private function getLine()
    {
        if($this->getFromRecordContext('line'))
            return $this->getFromRecordContext('line');

        if($this->getException())
            return $this->getException()->getLine();

        return 0;
    }

    private function getFile()
    {
        if($this->getFromRecordContext('file'))
            return $this->getFromRecordContext('file');

        if($this->getException())
            return $this->getException()->getFile();

        return '';
    }

    private function getTrace()
    {
        if($this->getException())
            return $this->getException()->getTraceAsString();

        return '';
    }

    private function getType()
    {
        if($this->getException())
            return get_class($this->getException());
        return 'unknown';
    }

    private function getCode()
    {
        if($this->getException())
            return $this->getException()->getCode();

        return null;
    }
}