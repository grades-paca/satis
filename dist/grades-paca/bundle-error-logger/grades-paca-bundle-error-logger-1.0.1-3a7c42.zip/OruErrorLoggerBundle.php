<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 12/12/13
 * Time: 09:35
 */
namespace Oru\Bundle\ErrorLoggerBundle;

use Monolog\ErrorHandler;
use Symfony\Component\Debug\ExceptionHandler;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruErrorLoggerBundle extends Bundle
{

    public function boot()
    {
        $logger = $this->container->get('oru_error_logger.error_log_manager')->getLogger();

        $handler = new ErrorHandler($logger);
        $handler->registerErrorHandler();
        $handler->registerExceptionHandler();
        $handler->registerFatalHandler();

        if('prod' !== $this->container->getParameter("kernel.environment"))
            ExceptionHandler::register();
    }
}