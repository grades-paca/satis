<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 12/12/13
 * Time: 15:42
 */

namespace Oru\Bundle\ErrorLoggerBundle\Error;

use Symfony\Bridge\Monolog\Logger;

class LogManager
{
    protected $logger;

    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
    }

    /**
     * @return \Psr\Log\LoggerInterface
     */
    public function getLogger()
    {
        return $this->logger;
    }
}