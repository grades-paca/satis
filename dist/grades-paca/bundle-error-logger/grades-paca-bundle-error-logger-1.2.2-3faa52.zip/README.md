Bundle ErrorLoggerBundle
========================

Installation
------------

Dans le AppKernel.php, activer ce bundle

    $bundles[] = new Oru\Bundle\ErrorLoggerBundle\OruErrorLoggerBundle();

Dans le routing.yml, ajouter les routes :

    oru_error:
        resource: "@OruErrorLoggerBundle/Resources/config/routing.xml"
        prefix: /error

Dans le config.yml, ajouter ce bundle aux paramètres imports :

    imports:
    ...
    - { resource: @OruErrorLoggerBundle/Resources/config/config.yml }

Vider le cache de Symfony

Description
-----------

Ce bundle écrit toutes les erreurs en base de données. Les erreurs rencontrées par les utilisateurs sont consultabes via l'application.

Utilisation
-----------

Pour tracer des erreurs qui ne sont pas critiques :

```php
$e = new \Exception('Cette action inattendue est à tracer...');
$this->getContainer()->get('oru_error_logger.storage_db_storage')->errorLog($e);
```

Les exceptions lancées sinon, sont automatiquement tracées comme critiques.
