<?php

namespace Oru\Bundle\ErrorLoggerBundle\Entity;

use Monolog\Logger;

/**
 * Error.
 */
class Error
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var string
     */
    private $message = '';

    /**
     * @var string
     */
    private $type = 'unknown';

    /**
     * @var string
     */
    private $file = '';

    /**
     * @var int
     */
    private $line;

    /**
     * @var string
     */
    private $trace;

    /**
     * @var int
     */
    private $code;

    /**
     * @var string
     */
    private $controller;

    /**
     * @var string
     */
    private $uri;

    /**
     * @var string
     */
    private $user;

    /**
     * @var string
     */
    private $user_agent;

    /**
     * @var \DateTime
     */
    private $createdAt;

    /**
     * @var string
     */
    private $route;

    /**
     * @var string
     */
    private $userContext;

    /**
     * @var string
     */
    private $session;

    /**
     * @var int
     */
    private $level = Logger::ERROR;

    public function __construct()
    {
        $this->createdAt = new \DateTime();
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set message.
     *
     * @param string $message
     *
     * @return Error
     */
    public function setMessage($message)
    {
        $this->message = $message;

        return $this;
    }

    /**
     * Get message.
     *
     * @return string
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * Get message.
     *
     * @return string
     */
    public function getMessageShort()
    {
        if (strlen($this->message) < 25) {
            return $this->message;
        }

        return substr($this->message, 0, 24).'...';
    }

    /**
     * Set type.
     *
     * @param string $type
     *
     * @return Error
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type.
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set file.
     *
     * @param string $file
     *
     * @return Error
     */
    public function setFile($file)
    {
        $this->file = $file;

        return $this;
    }

    /**
     * Get file.
     *
     * @return string
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * Set line.
     *
     * @param int $line
     *
     * @return Error
     */
    public function setLine($line)
    {
        $this->line = $line;

        return $this;
    }

    /**
     * Get line.
     *
     * @return int
     */
    public function getLine()
    {
        return $this->line;
    }

    /**
     * Set trace.
     *
     * @param string $trace
     *
     * @return Error
     */
    public function setTrace($trace)
    {
        $this->trace = $trace;

        return $this;
    }

    /**
     * Get trace.
     *
     * @return string
     */
    public function getTrace()
    {
        return $this->trace;
    }

    /**
     * Set code.
     *
     * @param int $code
     *
     * @return Error
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code.
     *
     * @return int
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set controller.
     *
     * @param string $controller
     *
     * @return Error
     */
    public function setController($controller)
    {
        $this->controller = $controller;

        return $this;
    }

    /**
     * Get controller.
     *
     * @return string
     */
    public function getController()
    {
        return $this->controller;
    }

    /**
     * Set uri.
     *
     * @param string $uri
     *
     * @return Error
     */
    public function setUri($uri)
    {
        $this->uri = $uri;

        return $this;
    }

    /**
     * Get uri.
     *
     * @return string
     */
    public function getUri()
    {
        return $this->uri;
    }

    /**
     * Get uri.
     *
     * @return string
     */
    public function getUriShort()
    {
        if (strlen($this->uri) < 20) {
            return $this->uri;
        }

        return substr($this->uri, 0, 19);
    }

    /**
     * Set user.
     *
     * @param string $user
     *
     * @return Error
     */
    public function setUser($user)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user.
     *
     * @return string
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set user_agent.
     *
     * @param string $userAgent
     *
     * @return Error
     */
    public function setUserAgent($userAgent)
    {
        $this->user_agent = $userAgent;

        return $this;
    }

    /**
     * Get user_agent.
     *
     * @return string
     */
    public function getUserAgent()
    {
        return $this->user_agent;
    }

    /**
     * Set createdAt.
     *
     * @param \DateTime $createdAt
     *
     * @return Error
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt.
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set route.
     *
     * @param string $route
     *
     * @return Error
     */
    public function setRoute($route)
    {
        $this->route = $route;

        return $this;
    }

    /**
     * Get route.
     *
     * @return string
     */
    public function getRoute()
    {
        return $this->route;
    }

    /**
     * Set userContext.
     *
     * @param string $userContext
     *
     * @return Error
     */
    public function setUserContext($userContext)
    {
        $this->userContext = $userContext;

        return $this;
    }

    /**
     * Get userContext.
     *
     * @return string
     */
    public function getUserContext()
    {
        return $this->userContext;
    }

    /**
     * @return string
     */
    public function getSession()
    {
        return $this->session;
    }

    /**
     * @param string $session
     */
    public function setSession($session)
    {
        $this->session = $session;
    }

    /**
     * @return int
     */
    public function getLevel()
    {
        return $this->level;
    }

    /**
     * @param int $level
     *
     * @return $this
     */
    public function setLevel($level)
    {
        $this->level = $level;

        return $this;
    }
}
