<?php
/**
 * Author: Michaël VEROUX
 * Date: 29/10/14
 * Time: 16:31
 */

namespace Oru\Bundle\ErrorLoggerBundle\Entity;

use Doctrine\ORM\EntityRepository;
use Oru\Bundle\ErrorLoggerBundle\Filter\ErrorFilter;

class ErrorRepository extends EntityRepository
{
    public function queryAll()
    {
        return $this->createQueryBuilder('e')->orderBy('e.id', 'DESC');
    }

    public function queryList(ErrorFilter $errorFilter)
    {
        $query = $this->queryAll();

        if(null !== $errorFilter->getDateBegin())
        {
            $query
                ->andWhere('e.createdAt >= :dateBegin')
                ->setParameter('dateBegin', $errorFilter->getDateBegin()->format('Y-m-d H:i:s'))
            ;
        }

        if(null !== $errorFilter->getDateEnd())
        {
            $query
                ->andWhere('e.createdAt <= :dateEnd')
                ->setParameter('dateEnd', $errorFilter->getDateEnd()->format('Y-m-d H:i:s'))
            ;
        }

        if(null !== $errorFilter->getRoute())
        {
            $query
                ->andWhere('e.route LIKE :route')
                ->setParameter('route', sprintf('%%%s%%', $errorFilter->getRoute()))
            ;
        }

        if(null !== $errorFilter->getUri())
        {
            $query
                ->andWhere('e.uri LIKE :uri')
                ->setParameter('uri', sprintf('%%%s%%', $errorFilter->getUri()))
            ;
        }

        if(null !== $errorFilter->getUser())
        {
            $query
                ->andWhere('e.user LIKE :user')
                ->setParameter('user', sprintf('%%%s%%', $errorFilter->getUser()))
            ;
        }

        if(null !== $errorFilter->getMessage())
        {
            $query
                ->andWhere('e.message LIKE :message')
                ->setParameter('message', sprintf('%%%s%%', $errorFilter->getMessage()))
            ;
        }

        return $query;
    }
} 