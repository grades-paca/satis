<?php
/**
 * Author: Michaël VEROUX
 * Date: 29/10/14
 * Time: 16:27
 */

namespace Oru\Bundle\ErrorLoggerBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ErrorListingType extends AbstractListingType
{
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('id', null, array(
                  'sort'      => 'e.id'
                )
            )
            ->add('createdAt', null, array(
                    'sort'      => 'e.createdAt',
                    'label'     => 'oru_error_listing.createdAt',
                    'translation_domain' => 'OruErrorLoggerBundle',
                )
            )
            ->add('type', null, array(
                    'sort'      => 'e.type',
                    'label'     => 'oru_error_listing.type',
                    'translation_domain' => 'OruErrorLoggerBundle',
                )
            )
            ->add('message', null, array(
                    'label'     => 'oru_error_listing.message',
                    'translation_domain' => 'OruErrorLoggerBundle',
                )
            )
            ->add('uri', null, array(
                    'sort'      => 'e.uri',
                    'label'     => 'oru_error_listing.uri',
                    'translation_domain' => 'OruErrorLoggerBundle',
                )
            )
            ->add('show', 'object_action', array(
                    'route'     => 'oru_error_show',
                    'label'     => 'listing.action.show',
                )
            )
        ;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'oru_error_listing';
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\ErrorLoggerBundle\Entity\Error',
        ));
    }
}