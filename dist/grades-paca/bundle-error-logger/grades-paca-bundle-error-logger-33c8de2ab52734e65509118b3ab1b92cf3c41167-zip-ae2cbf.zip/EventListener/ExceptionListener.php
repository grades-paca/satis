<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 12/12/13
 * Time: 11:35
 */

namespace Oru\Bundle\ErrorLoggerBundle\EventListener;

use Lexik\Bundle\MaintenanceBundle\Drivers\DriverFactory;
use Oru\Bundle\ErrorLoggerBundle\Manager\Duplicate;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Session\Flash\FlashBagInterface;
use Symfony\Component\HttpKernel\Event\GetResponseForExceptionEvent;
use Symfony\Component\HttpKernel\EventListener\ExceptionListener as BaseExceptionListener;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\Routing\Router;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class ExceptionListener extends BaseExceptionListener
{
    /**
     * @var LoggerInterface
     */
    protected $dbLogger;

    /**
     * @var Router
     */
    protected $router;

    /**
     * @var FlashBagInterface
     */
    protected $flashBag;

    /**
     * @var string
     */
    protected $mode;

    /**
     * @var DriverFactory|null
     */
    protected $maintenanceFactory;

    /**
     * @var Duplicate
     */
    protected $duplicate;

    /**
     * ExceptionListener constructor.
     *
     * @param string                 $controller
     * @param LoggerInterface        $logger
     * @param Router                 $router
     * @param FlashBagInterface|null $flashBag
     * @param string                 $mode
     * @param DriverFactory|null     $driverFactory
     */
    public function __construct($controller, LoggerInterface $logger, Router $router, FlashBagInterface $flashBag = null, $mode = 'dev', DriverFactory $driverFactory = null, Duplicate $duplicate)
    {
        $this->dbLogger = $logger;
        $this->router = $router;
        $this->flashBag = $flashBag;
        $this->mode = $mode;
        $this->maintenanceFactory = $driverFactory;
        $this->duplicate = $duplicate;

        parent::__construct($controller, null);
    }

    public function onKernelException(GetResponseForExceptionEvent $event)
    {
        // On ne loggue pas quand une maintenance est en cours
        if (null !== $this->maintenanceFactory && $this->maintenanceFactory->getDriver()->isExists()) {
            return;
        }
        
        if (!$event->getException() instanceof AccessDeniedException) {
            $exception = null;
            try {
                parent::onKernelException($event);
            } catch (\Exception $e) {
                $exception = $e;
            }

            if(
                !$exception instanceof HttpExceptionInterface
                && !$event->getException() instanceof HttpExceptionInterface
                && 'prod' === $this->mode
            )
            {
                if (!$this->duplicate->isStopped($event->getException())) {
                    $this->dbLogger->error($event->getException()->getMessage(), array('exception' => $event->getException()));
                }

                if($this->flashBag)
                {
                    $this->flashBag->add('error', 'Une erreur est survenue');
                }

                $response = new RedirectResponse($this->router->generate('ror_contact', array('custom_message' => 'error')));

                $event->setResponse($response);
            }

            if($event->getException() instanceof NotFoundHttpException || $exception instanceof NotFoundHttpException)
            {
                $matcher = $this->router->getMatcher();

                try
                {
                    $matcher->match($event->getRequest()->getPathInfo());
                }
                catch(\RuntimeException $e)
                {
                    $response = new RedirectResponse($this->router->generate('oru_notfound'));

                    $event->setResponse($response);
                }
            }
        }
    }
}