<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 12/12/13
 * Time: 16:47
 */

namespace Oru\Bundle\ErrorLoggerBundle\Storage;

use Doctrine\ORM\EntityManager;
use Monolog\Handler\AbstractProcessingHandler;
use Monolog\Logger;
use Oru\Bundle\ErrorLoggerBundle\Entity\Error;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;

/**
 * Class DbStorage.
 *
 * @author Michaël VEROUX
 */
class DbStorage extends AbstractProcessingHandler
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    protected $entityManager = null;

    /**
     * @var \Symfony\Component\DependencyInjection\Container
     */
    protected $container = null;

    /**
     * @var array
     */
    protected $record = array();

    /**
     * @param \Doctrine\ORM\EntityManager $entityManager
     */
    public function setEntityManager(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param Container $container
     *
     * @author Michaël VEROUX
     */
    public function setContainer(Container $container)
    {
        $this->container = $container;
    }

    /**
     * @param \Exception $e
     * @param array      $extra
     *
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function errorLog(\Exception $e, array $extra = array())
    {
        return $this->handle(array(
                          'context' => array(
                              'exception' => $e,
                              'line' => $e->getLine(),
                              'file' => $e->getFile(),
                          ),
                          'message' => $e->getMessage(),
                          'level' => Logger::INFO,
                          'extra' => array(),
                      ));
    }

    /**
     * Writes the record down to the log of the implementing handler.
     *
     * @param array $record
     */
    protected function write(array $record)
    {
        $this->record = $record;

        /** @var \Symfony\Component\HttpFoundation\RequestStack|null $request */
        $requestStack = $this->container->get('request_stack');

        $error = new Error();
        $error->setMessage($this->getFromRecord('message'));
        $error->setFile($this->getFile());
        $error->setLine($this->getLine());
        $error->setTrace($this->getTrace());
        $error->setType($this->getType());
        $error->setCode($this->getCode());
        $error->setLevel($this->getRecordLevel());
        if ($requestStack and $requestStack->getCurrentRequest()) {
            $request = $requestStack->getCurrentRequest();
            $error->setUri($request->getRequestUri());
            $error->setRoute($request->get('_route'));
            $error->setController($request->get('_controller'));
            $error->setUserAgent($request->headers->get('User-Agent'));
        }

        $session = $this->container->get('session');
        if ($session) {
            $error->setSession($session->getId());
        }

        if ($this->container->get('security.token_storage')->getToken() instanceof TokenInterface) {
            $error->setUserContext($this->container->get('security.token_storage')->getToken());
            $error->setUser($this->container->get('security.token_storage')->getToken()->getUsername());
        }

        if (!$this->entityManager->isOpen()) {
            $this->entityManager = $this->entityManager->create(
                $this->entityManager->getConnection(),
                $this->entityManager->getConfiguration()
            );
        }

        $this->entityManager->persist($error);
        $this->entityManager->flush($error);
    }

    /**
     * @param string $name
     *
     * @return mixed|string
     *
     * @author Michaël VEROUX
     */
    private function getFromRecord($name)
    {
        if (isset($this->record[$name])) {
            return $this->record[$name];
        }

        return '';
    }

    /**
     * @param string $name
     *
     * @return string
     *
     * @author Michaël VEROUX
     */
    private function getFromRecordContext($name)
    {
        $context = $this->getFromRecord('context');
        if ('' !== $context && isset($context[$name])) {
            return $context[$name];
        }

        return '';
    }

    /**
     * @return null|\Exception
     *
     * @author Michaël VEROUX
     */
    private function getException()
    {
        if ($exception = $this->getFromRecordContext('exception')) {
            if ($exception instanceof \Exception) {
                return $exception;
            }
        }

        return null;
    }

    /**
     * @return int|string
     *
     * @author Michaël VEROUX
     */
    private function getLine()
    {
        if ($this->getFromRecordContext('line')) {
            return $this->getFromRecordContext('line');
        }

        if ($this->getException()) {
            return $this->getException()->getLine();
        }

        return 0;
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    private function getFile()
    {
        if ($this->getFromRecordContext('file')) {
            return $this->getFromRecordContext('file');
        }

        if ($this->getException()) {
            return $this->getException()->getFile();
        }

        return '';
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    private function getTrace()
    {
        if ($this->getException()) {
            return $this->getException()->getTraceAsString();
        }

        return '';
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    private function getType()
    {
        if ($this->getException()) {
            return get_class($this->getException());
        }

        return 'unknown';
    }

    /**
     * @author Michaël VEROUX
     */
    private function getCode()
    {
        if ($this->getException()) {
            return $this->getException()->getCode();
        }

        return null;
    }

    /**
     * @return int
     *
     * @author Michaël VEROUX
     */
    private function getRecordLevel()
    {
        $level = $this->getFromRecord('level');
        if ($level) {
            return $level;
        }

        return Logger::ERROR;
    }
}
