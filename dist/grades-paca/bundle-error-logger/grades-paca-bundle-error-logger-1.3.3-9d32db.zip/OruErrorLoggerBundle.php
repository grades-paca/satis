<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 12/12/13
 * Time: 09:35
 */

namespace Oru\Bundle\ErrorLoggerBundle;

use Monolog\Logger;
use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Symfony\Component\Debug\ErrorHandler;
use Symfony\Component\Debug\ExceptionHandler;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class OruErrorLoggerBundle extends OruBundle
{
    public function boot()
    {
        if ('prod' !== $this->container->getParameter('kernel.environment')) {
            $handler = ExceptionHandler::register();
            $handler->setHandler(array($this, 'handle'));
        } else {
            $handler = ErrorHandler::register();
            $handler->setExceptionHandler(array($this, 'handle'));
        }
    }

    public function handle(\Exception $exception)
    {
        if (
            !$exception instanceof HttpExceptionInterface
            && !$exception instanceof AccessDeniedException
        ) {
            $logger = $this->container->get('oru_error_logger.storage_db_storage');
            $logger->handle(array(
                                'context' => array(
                                    'exception' => $exception,
                                    'line' => $exception->getLine(),
                                    'file' => $exception->getFile(),
                                ),
                                'message' => $exception->getMessage(),
                                'level' => Logger::ERROR,
                                'extra' => array(),
                            ));
        }

        throw $exception;
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public static function getFriendlyName()
    {
        return 'Gestionnaire d\'erreur';
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public static function getDescription()
    {
        return 'Module qui consigne les erreurs de l\'application';
    }
}
