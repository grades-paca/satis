<?php

namespace Oru\Bundle\ErrorLoggerBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class DuplicateCommand extends ContainerAwareCommand
{
    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this
            ->setName('oru:error:duplicate-purge')
            ->setDescription('Les erreurs qui ne sont plus écoutées doivent avoir une occurrence dans les logs.')
            ->addOption('all', null, InputOption::VALUE_NONE, 'Purge tout');
    }

    /**
     * {@inheritdoc}
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        if ($input->getOption('all')) {
            $this->getContainer()->get('oru_error_logger.duplicate')->reset();

            $output->writeln('All errors will be logged now.');

            return;
        }

        $deleted = $this->getContainer()->get('oru_error_logger.duplicate')->purge($this->getContainer()->get('doctrine.orm.default_entity_manager')->getRepository('OruErrorLoggerBundle:Error'));

        while ($removed = array_shift($deleted)) {
            $output->writeln(sprintf('Removed: %s', $removed));
        }

        $output->writeln('Done.');
    }
}
