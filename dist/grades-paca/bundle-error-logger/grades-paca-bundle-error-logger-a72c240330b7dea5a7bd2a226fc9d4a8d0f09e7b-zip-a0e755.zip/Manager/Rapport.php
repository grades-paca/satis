<?php

namespace Oru\Bundle\ErrorLoggerBundle\Manager;

use Oru\Bundle\AppBundle\Cache\CacheManager;
use Oru\Bundle\ErrorLoggerBundle\Entity\Error;
use Oru\Bundle\ErrorLoggerBundle\Entity\ErrorRepository;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Validator\ValidatorInterface;

/**
 * Class Rapport
 *
 * @package Oru\Bundle\ErrorLoggerBundle\Manager
 * @author Michaël VEROUX
 */
class Rapport
{
    const FILE_CACHE_ID = 'rapport-routes';

    /**
     * @var ErrorRepository
     */
    protected $errorRepository;

    /**
     * @var \Swift_Mailer
     */
    protected $mailer;

    /**
     * @var Setting
     */
    protected $setting;

    /**
     * @var ValidatorInterface
     */
    protected $validator;

    /**
     * @var \Twig_Environment
     */
    protected $twig;

    /**
     * @var CacheManager
     */
    protected $cacheManager;

    /**
     * @var \DateTime|null
     */
    protected $since = null;

    /**
     * Rapport constructor.
     *
     * @param ErrorRepository    $errorRepository
     * @param \Swift_Mailer      $mailer
     * @param Setting            $setting
     * @param ValidatorInterface $validator
     * @param \Twig_Environment  $twig
     */
    public function __construct(ErrorRepository $errorRepository, \Swift_Mailer $mailer, Setting $setting, ValidatorInterface $validator, \Twig_Environment $twig, CacheManager $cacheManager)
    {
        $this->errorRepository = $errorRepository;
        $this->mailer = $mailer;
        $this->setting = $setting;
        $this->validator = $validator;
        $this->twig = $twig;
        $this->cacheManager = $cacheManager;
        $this->cacheManager->setId(self::FILE_CACHE_ID);
    }

    /**
     * @return \DateTime|null
     */
    public function getSince()
    {
        return $this->since;
    }

    /**
     * @param \DateTime|null $since
     *
     * @return $this
     */
    public function setSince($since)
    {
        $this->since = $since;

        return $this;
    }

    /**
     * @return \Oru\Bundle\ErrorLoggerBundle\Entity\Error[]
     * @author Michaël VEROUX
     */
    public function getUniqueErrorsRequestContext()
    {
        $errors = $this->errorRepository->findAllCriticalGroupByFileAndLine($this->getSince());

        return $errors;
    }

    /**
     * @return integer
     * @author Michaël VEROUX
     */
    public function sendAll()
    {
        $nb = 0;
        $errors = $this->getUniqueErrorsRequestContext();
        $batchMax = $this->setting->setting('batch_max', 'OruErrorLoggerBundle');
        if ($batchMax < count($errors)) {
            if ($this->sendLight()) {
                $nb++;
            }

            return $nb;
        }
        $routes = $this->getRoutesFromCache();
        foreach ($errors as $error) {
            if (!in_array($error->getRoute(), $routes)) {
                if ($this->send($error)) {
                    $nb++;
                }
                $routes[] = $error->getRoute();
            }
        }

        $this->setRoutesInCache($routes);

        return $nb;
    }

    /**
     * @param Error $error
     *
     * @return bool
     * @author Michaël VEROUX
     */
    public function send(Error $error)
    {
        $to = $this->getReceiver();
        if (!$to) {
            return false;
        }

        $params = array(
            'entity' => $error,
        );

        $template = $this->twig->loadTemplate('@OruErrorLogger/Mail/rapport.html.twig');
        $subject = $template->renderBlock('subject', $params);
        $bodyText = $template->renderBlock('body_text', $params);
        $bodyHtml = $template->renderBlock('body_html', $params);

        $message = \Swift_Message::newInstance($subject)
            ->setFrom($this->setting->setting('mail_from', 'OruMailBundle'))
            ->setSender($this->setting->setting('mail_sender', 'OruMailBundle'))
            ->setTo($to)
            ->setBody($bodyText, 'text/plain');

        $message->addPart($bodyHtml, 'text/html');

        $sent = $this->mailer->send($message);

        return (bool)$sent;
    }

    /**
     * @return bool
     * @author Michaël VEROUX
     */
    public function sendLight()
    {
        $to = $this->getReceiver();
        if (!$to) {
            return false;
        }

        $template = $this->twig->loadTemplate('@OruErrorLogger/Mail/rapport-light.html.twig');
        $subject = $template->renderBlock('subject', array());
        $bodyText = $template->renderBlock('body_text', array());
        $bodyHtml = $template->renderBlock('body_html', array());

        $message = \Swift_Message::newInstance($subject)
            ->setFrom($this->setting->setting('mail_from', 'OruMailBundle'))
            ->setSender($this->setting->setting('mail_sender', 'OruMailBundle'))
            ->setTo($to)
            ->setBody($bodyText, 'text/plain');

        $message->addPart($bodyHtml, 'text/html');

        $sent = $this->mailer->send($message);

        return (bool)$sent;
    }

    /**
     * @return string|null
     * @author Michaël VEROUX
     */
    private function getReceiver()
    {
        $to = $this->setting->setting('send_to', 'OruErrorLoggerBundle');
        if (0 !== count($this->validator->validateValue($to, array(new Email())))) {
            return null;
        }

        return $to;
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    private function getRoutesFromCache()
    {
        $routes = $this->cacheManager->read();

        if (!$routes) {
            $routes = array();
        }

        return $routes;
    }

    /**
     * @param $routes
     *
     * @return void
     * @author Michaël VEROUX
     */
    private function setRoutesInCache($routes)
    {
        $this->cacheManager->write($routes);
    }
}
