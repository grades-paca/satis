<?php
/**
 * Author: Michaël VEROUX
 * Date: 29/10/14
 * Time: 17:14
 */

namespace Oru\Bundle\ErrorLoggerBundle\Form\Filter;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ErrorFilterType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('dateBegin', 'datetime', array(
                    'required'      =>  false,
                    'date_widget'   => 'single_text',
                    'time_widget'   => 'single_text',
                )
            )
            ->add('dateEnd', 'datetime', array(
                    'required'      =>  false,
                    'date_widget'   => 'single_text',
                    'time_widget'   => 'single_text',
                )
            )
            ->add('route', 'search', array(
                    'required'      =>  false,
                    'label'         =>  'oru_error_listing.route',
                )
            )
            ->add('uri', 'search', array(
                    'required'      =>  false,
                    'label'         =>  'oru_error_listing.uri',
                )
            )
            ->add('user', 'search', array(
                    'required'      =>  false,
                    'label'         =>  'oru_error_listing.user',
                )
            )
            ->add('message', 'search', array(
                    'required'      =>  false,
                    'label'         =>  'oru_error_listing.message',
                )
            )
            ->add('filter', 'submit', array(
                    'label'                 => 'listing.action.filter',
                    'translation_domain'    => 'messages',
                )
            )
            ->add('reset', 'submit', array(
                    'label'                 => 'listing.action.reset',
                    'translation_domain'    => 'messages',
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\ErrorLoggerBundle\Filter\ErrorFilter',
            'csrf_protection' => false,
            'validation_groups' => false,
            'translation_domain'    => 'OruErrorLoggerBundle',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_error_form_filter';
    }
}