<?php
/**
 * Author: Michaël VEROUX
 * Date: 29/10/14
 * Time: 16:18
 */

namespace Oru\Bundle\ErrorLoggerBundle\Controller;

use Oru\Bundle\ErrorLoggerBundle\Entity\Error;
use Oru\Bundle\ErrorLoggerBundle\Form\Filter\ErrorFilterType;
use Oru\Bundle\ErrorLoggerBundle\Listing\ErrorListingType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class ErrorController extends Controller
{
    public function indexAction(Request $request, $form = null)
    {
        $this->credentialCheck();
        if(null === $form)
        {
            $form = $this->createForm(new ErrorFilterType())->submit($request->getSession()->get('oru_error_logger.filter', array('session' => $request->query->get('session', null))));
        }

        $entities = $this->getDoctrine()->getRepository('OruErrorLoggerBundle:Error')->queryList($form->getData());

        $listing = $this->container->get('paginator.factory')->create(
            new ErrorListingType(),
            $entities,
            $request->query->get('page', 1)
        );

        return $this->render('OruErrorLoggerBundle:Error:index.html.twig',
            array(
                'listing'       => $listing,
                'form'          => $form->createView(),
            )
        );
    }

    public function filterAction(Request $request)
    {
        $this->credentialCheck();
        $form = $this->createForm(new ErrorFilterType())->handleRequest($request);

        if ($form->get('reset')->isClicked())
        {
            $request->getSession()->set('oru_error_logger.filter', array());

            return $this->redirect($this->generateUrl('oru_error'));
        }

        if($form->isValid()) {
            $request->getSession()->set('oru_error_logger.filter', $request->get($form->getName()));

            return $this->redirect($this->generateUrl('oru_error'));
        }

        return $this->indexAction($request, $form);
    }

    public function showAction(Error $entity)
    {
        $this->credentialCheck();

        return $this->render('OruErrorLoggerBundle:Error:show.html.twig',
            array(
                'entity'       => $entity,
            )
        );
    }

    public function notFoundAction()
    {
        $response = $this->render('OruErrorLoggerBundle:Error:notfound.html.twig', array()
        );

        $response->setStatusCode('404');

        return $response;
    }

    /**
     * @return bool
     * @author Michaël VEROUX
     */
    private function credentialCheck()
    {
        if ($this->has('oru_ror_credentials.credentials_checker')) {
            if ($this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ROR_ADMIN')) {
                return true;
            }
        }

        throw new AccessDeniedHttpException();
    }
} 