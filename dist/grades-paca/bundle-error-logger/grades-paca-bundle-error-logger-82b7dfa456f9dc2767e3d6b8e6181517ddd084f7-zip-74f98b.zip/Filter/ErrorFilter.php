<?php
/**
 * Author: Michaël VEROUX
 * Date: 29/10/14
 * Time: 17:13
 */

namespace Oru\Bundle\ErrorLoggerBundle\Filter;

class ErrorFilter
{
    /**
     * @var \DateTime
     */
    protected $dateBegin;

    /**
     * @var \DateTime
     */
    protected $dateEnd;

    /**
     * @var string
     */
    protected $route;

    /**
     * @var string
     */
    protected $uri;

    /**
     * @var string
     */
    protected $user;

    /**
     * @var string
     */
    protected $message;

    /**
     * @param \DateTime $dateBegin
     */
    public function setDateBegin($dateBegin)
    {
        $this->dateBegin = $dateBegin;
    }

    /**
     * @return \DateTime
     */
    public function getDateBegin()
    {
        return $this->dateBegin;
    }

    /**
     * @param \DateTime $dateEnd
     */
    public function setDateEnd($dateEnd)
    {
        $this->dateEnd = $dateEnd;
    }

    /**
     * @return \DateTime
     */
    public function getDateEnd()
    {
        return $this->dateEnd;
    }

    /**
     * @param string $route
     */
    public function setRoute($route)
    {
        $this->route = $route;
    }

    /**
     * @return string
     */
    public function getRoute()
    {
        return $this->route;
    }

    /**
     * @param string $uri
     */
    public function setUri($uri)
    {
        $this->uri = $uri;
    }

    /**
     * @return string
     */
    public function getUri()
    {
        return $this->uri;
    }

    /**
     * @param string $user
     */
    public function setUser($user)
    {
        $this->user = $user;
    }

    /**
     * @return string
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * @param string $message
     */
    public function setMessage($message)
    {
        $this->message = $message;
    }

    /**
     * @return string
     */
    public function getMessage()
    {
        return $this->message;
    }
} 