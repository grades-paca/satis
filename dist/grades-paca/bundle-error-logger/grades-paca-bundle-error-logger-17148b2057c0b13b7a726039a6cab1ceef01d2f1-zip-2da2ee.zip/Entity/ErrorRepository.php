<?php
/**
 * Author: Michaël VEROUX
 * Date: 29/10/14
 * Time: 16:31
 */

namespace Oru\Bundle\ErrorLoggerBundle\Entity;

use Doctrine\ORM\EntityRepository;
use Monolog\Logger;
use Oru\Bundle\ErrorLoggerBundle\Filter\ErrorFilter;

/**
 * Class ErrorRepository
 *
 * @package Oru\Bundle\ErrorLoggerBundle\Entity
 * @author Michaël VEROUX
 */
class ErrorRepository extends EntityRepository
{
    /**
     * @return \Doctrine\ORM\QueryBuilder
     * @author Michaël VEROUX
     */
    public function queryAll()
    {
        return $this->createQueryBuilder('e')->orderBy('e.id', 'DESC');
    }

    /**
     * @param ErrorFilter $errorFilter
     *
     * @return \Doctrine\ORM\QueryBuilder
     * @author Michaël VEROUX
     */
    public function queryList(ErrorFilter $errorFilter)
    {
        $query = $this->queryAll();

        if (null !== $errorFilter->getDateBegin()) {
            $query
                ->andWhere('e.createdAt >= :dateBegin')
                ->setParameter('dateBegin', $errorFilter->getDateBegin()->format('Y-m-d H:i:s'));
        }

        if (null !== $errorFilter->getDateEnd()) {
            $query
                ->andWhere('e.createdAt <= :dateEnd')
                ->setParameter('dateEnd', $errorFilter->getDateEnd()->format('Y-m-d H:i:s'));
        }

        if (null !== $errorFilter->getRoute()) {
            $query
                ->andWhere('e.route LIKE :route')
                ->setParameter('route', sprintf('%%%s%%', $errorFilter->getRoute()));
        }

        if (null !== $errorFilter->getUri()) {
            $query
                ->andWhere('e.uri LIKE :uri')
                ->setParameter('uri', sprintf('%%%s%%', $errorFilter->getUri()));
        }

        if (null !== $errorFilter->getUser()) {
            $query
                ->andWhere('e.user LIKE :user')
                ->setParameter('user', sprintf('%%%s%%', $errorFilter->getUser()));
        }

        if (null !== $errorFilter->getMessage()) {
            $query
                ->andWhere('e.message LIKE :message')
                ->setParameter('message', sprintf('%%%s%%', $errorFilter->getMessage()));
        }

        if (null !== $errorFilter->getSession()) {
            $query
                ->andWhere('e.session LIKE :session')
                ->setParameter('session', $errorFilter->getSession());
        }

        if ($errorFilter->isInfo()) {
            $query
                ->andWhere('e.level <= :level')
                ->setParameter('level', Logger::NOTICE);
        } else {
            $query
                ->andWhere('e.level > :level')
                ->setParameter('level', Logger::NOTICE);
        }

        return $query;
    }

    /**
     * @return Error[]
     * @author Michaël VEROUX
     */
    public function findAllGroupByRoute()
    {
        $query = $this->createQueryBuilder('e');
        $query->select('MAX(e.id) AS id');
        $query->where('e.route IS NOT NULL');
        $query->groupBy('e.route');

        $result = $query->getQuery()->getScalarResult();
        $ids = array_map('current', $result);

        $query = $this->createQueryBuilder('e');
        $query
            ->where('e.id IN (:ids)')
            ->setParameter('ids', $ids);

        $errors = $query->getQuery()->execute();

        return $errors;
    }
} 