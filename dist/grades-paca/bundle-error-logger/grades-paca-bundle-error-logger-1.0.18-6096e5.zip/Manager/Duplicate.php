<?php

namespace Oru\Bundle\ErrorLoggerBundle\Manager;

use Oru\Bundle\ErrorLoggerBundle\Entity\Error;
use Oru\Bundle\ErrorLoggerBundle\Entity\ErrorRepository;
use Oru\Bundle\ErrorLoggerBundle\Exception\ErrorException;
use Symfony\Component\Filesystem\Filesystem;
use \Exception;

/**
 * Class Duplicate
 *
 * @package Oru\Bundle\ErrorLoggerBundle\Manager
 * @author Michaël VEROUX
 */
class Duplicate
{
    const CACHE_DATA = 'duplicate-data.txt';

    /**
     * @var string
     */
    protected $cacheDirectory;

    /**
     * Duplicate constructor.
     *
     * @param string $cacheDirectory
     */
    public function __construct($cacheDirectory)
    {
        $this->cacheDirectory = sprintf('%s/error-logger', $cacheDirectory);
    }

    /**
     * @param Error $error
     *
     * @return ErrorException
     * @author Michaël VEROUX
     */
    public function convertErrorEntityToException(Error $error)
    {
        $e = new ErrorException($error->getMessage());
        $e->setLine($error->getLine());
        $e->setFile($error->getFile());

        return $e;
    }

    /**
     * @param Exception $e
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function stop(Exception $e)
    {
        if ($this->isStopped($e)) {
            return;
        }

        $string = $this->getUniqueString($e);
        $file = new \SplFileObject($this->getPath(), 'a');
        $file->fwrite(sprintf('%s%s', $string, PHP_EOL));
        unset($file);
    }

    /**
     * @param Exception $e
     *
     * @return bool
     * @author Michaël VEROUX
     */
    public function isStopped(Exception $e)
    {
        $string = $this->getUniqueString($e);
        $data = $this->getData();

        return in_array($string, $data);
    }

    /**
     * @return void
     * @author Michaël VEROUX
     */
    public function reset()
    {
        $filesystem = new Filesystem();
        if (!$filesystem->exists($this->getPath())) {
            return;
        }

        $filesystem->remove($this->getPath());
    }

    /**
     * @param ErrorRepository $errorRepository
     *
     * @return array
     * @author Michaël VEROUX
     */
    public function purge(ErrorRepository $errorRepository)
    {
        $purged = array();
        $data = $this->getData();
        foreach ($data as $uniqueString) {
            $erreur = $this->extractFromUniqueString($uniqueString);
            $error = $errorRepository->findOneBy(array(
                'line'      => $erreur['line'],
                'file'      => $erreur['file'],
                                        ));
            if ($error) {
                $purged[] = $uniqueString;
            }
        }

        file_put_contents($this->getPath(), implode(PHP_EOL, $purged).PHP_EOL);

        return array_diff($data, $purged);
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    private function getData()
    {
        $filesystem = new Filesystem();
        if (!$filesystem->exists($this->getPath())) {
            return array();
        }

        $data = file($this->getPath());
        $data = array_map('trim', $data);
        $data = array_unique($data);

        return $data;
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    private function getPath()
    {
        $path = sprintf('%s/%s', $this->cacheDirectory, static::CACHE_DATA);
        $fileSystem = new Filesystem();
        if (!$fileSystem->exists($this->cacheDirectory)) {
            $fileSystem->mkdir($this->cacheDirectory, 0777);
        }

        return $path;
    }

    /**
     * @param Exception $e
     *
     * @return string
     * @author Michaël VEROUX
     */
    private function getUniqueString(Exception $e)
    {
        $string = sprintf('%d:%s', $e->getLine(), $e->getFile());

        return $string;
    }

    /**
     * @param string $string
     *
     * @return array
     * @author Michaël VEROUX
     */
    private function extractFromUniqueString($string)
    {
        $info = explode(':', $string);
        $erreur = array(
            'line'      =>  0,
            'file'      =>  '',
        );
        if (2 === count($info)) {
            $erreur['line'] = $info[0];
            $erreur['file'] = $info[1];
        }

        return $erreur;
    }
}
