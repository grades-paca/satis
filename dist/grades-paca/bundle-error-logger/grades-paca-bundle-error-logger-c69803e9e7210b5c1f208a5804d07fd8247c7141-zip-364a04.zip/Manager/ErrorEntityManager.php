<?php

namespace Oru\Bundle\ErrorLoggerBundle\Manager;

use Doctrine\ORM\EntityManager;

/**
 * Class ErrorEntityManager.
 *
 * @author Michaël VEROUX
 */
class ErrorEntityManager
{
    /**
     * @var EntityManager
     */
    protected $em;

    /**
     * @var EntityManager|null
     */
    protected $singleEm;

    /**
     * SingleEntityManager constructor.
     *
     * @param EntityManager $em
     */
    public function __construct(EntityManager $em)
    {
        $this->em = $em;
    }

    /**
     * @return EntityManager
     *
     * @author Michaël VEROUX
     */
    public function getManager()
    {
        if (null === $this->singleEm) {
            $enabledFilters = $this->em->getFilters()->getEnabledFilters();

            $this->singleEm = EntityManager::create(
                clone $this->em->getConnection(),
                $this->em->getConfiguration()
            );

            if (is_array($enabledFilters)) {
                foreach ($enabledFilters as $name => $filter) {
                    $this->singleEm->getFilters()->enable($name);
                }
            }
        }

        return $this->singleEm;
    }
}
