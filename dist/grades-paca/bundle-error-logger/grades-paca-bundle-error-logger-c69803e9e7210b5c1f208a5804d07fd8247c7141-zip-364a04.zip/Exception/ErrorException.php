<?php

namespace Oru\Bundle\ErrorLoggerBundle\Exception;

/**
 * Class ErrorException
 *
 * @package Oru\Bundle\ErrorLoggerBundle\Exception
 * @author Michaël VEROUX
 */
class ErrorException extends \Exception
{
    /**
     * @param int $line
     *
     * @return $this
     */
    public function setLine($line)
    {
        $this->line = $line;

        return $this;
    }

    /**
     * @param string $file
     *
     * @return $this
     */
    public function setFile($file)
    {
        $this->file = $file;

        return $this;
    }
}
