<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\CrudBundle\Command;

use Doctrine\ORM\Mapping\ClassMetadataInfo;
use Oru\Bundle\CrudBundle\Generator\OruCrudGenerator;
use Oru\Bundle\CrudBundle\Generator\OruFilterGenerator;
use Oru\Bundle\CrudBundle\Generator\OruFilterTypeGenerator;
use Oru\Bundle\CrudBundle\Generator\OruListingGenerator;
use Sensio\Bundle\GeneratorBundle\Command\GenerateDoctrineCrudCommand;
use Sensio\Bundle\GeneratorBundle\Command\Validators;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\HttpKernel\Bundle\BundleInterface;

class GenerateOruCrudCommand extends GenerateDoctrineCrudCommand
{
    protected $generator;
    protected $listingGenerator;
    protected $filterGenerator;
    protected $filterTypeGenerator;

    public function setListingGenerator(OruListingGenerator $listingGenerator)
    {
        $this->listingGenerator = $listingGenerator;
    }

    public function setFilterGenerator(OruFilterGenerator $formGenerator)
    {
        $this->filterGenerator = filterGenerator;
    }

    public function setFilterTypeGenerator(OruFilterTypeGenerator $formGenerator)
    {
        $this->filterTypeGenerator = filterTypeGenerator;
    }

    protected function configure()
    {
        parent::configure();

        $this->setName('generate:oru:crud');
        $this->setAliases(array('oru:generate:crud'));
        $this->setDescription('Oru crud generator.');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        parent::execute($input, $output);

        $entity = Validators::validateEntityName($input->getOption('entity'));
        list($bundle, $entity) = $this->parseShortcutNotation($entity);
        $entityClass = $this->getContainer()->get('doctrine')->getAliasNamespace($bundle).'\\'.$entity;
        $metadata = $this->getEntityMetadata($entityClass);
        $bundle = $this->getContainer()->get('kernel')->getBundle($bundle);
        $prefix = $this->getRoutePrefix($input, $entity);
        $withWrite = $input->getOption('with-write');
        $format = Validators::validateFormat($input->getOption('format'));

        // listing
        $this->generateListing($bundle, $entity, $metadata, $prefix, $withWrite);
        $output->writeln('Generating the Listing code: <info>OK</info>');

        // filter
        $this->generateFilter($bundle, $entity, $metadata);
        $output->writeln('Generating the Filter code: <info>OK</info>');

        // filter type
        $this->generateFilterType($bundle, $entity, $metadata);
        $output->writeln('Generating the Filter Type code: <info>OK</info>');

        $dialog = $this->getQuestionHelper();
        $errors = array();
        $runner = $dialog->getRunner($output, $errors);
        $runner($this->updateRepository($bundle, $entity, $metadata[0]));
        $dialog->writeGeneratorSummary($output, $errors);
    }

    protected function getSkeletonDirs(BundleInterface $bundle = null)
    {
        $defaultSkeletonDirs = parent::getSkeletonDirs($bundle);

        if (isset($bundle) && is_dir($dir = $bundle->getPath().'/Resources/SensioGeneratorBundle/skeleton')) {
            $skeletonDirs[] = $dir;
        }

        if (is_dir($dir = $this->getContainer()->get('kernel')->getRootdir().'/Resources/SensioGeneratorBundle/skeleton')) {
            $skeletonDirs[] = $dir;
        }

        $skeletonDirs[] = __DIR__.'/../Resources/overload';
        $skeletonDirs[] = __DIR__.'/../Resources';

        return array_merge($skeletonDirs, $defaultSkeletonDirs);
    }

    protected function createGenerator($bundle = null)
    {
        return new OruCrudGenerator($this->getContainer()->get('filesystem'));
    }

    /**
     * Tries to generate listing if they don't exist yet and if we need write operations on entities.
     *
     * @param mixed $bundle
     * @param mixed $entity
     * @param mixed $metadata
     * @param mixed $routePrefix
     * @param mixed $withWrite
     */
    protected function generateListing($bundle, $entity, $metadata, $routePrefix, $withWrite)
    {
        try {
            $this->getListingGenerator($bundle)->generate($bundle, $entity, $metadata[0], $routePrefix, $withWrite);
        } catch (\RuntimeException $e) {
            // form already exists
        }
    }

    /**
     * Tries to generate listing if they don't exist yet and if we need write operations on entities.
     *
     * @param mixed $bundle
     * @param mixed $entity
     * @param mixed $metadata
     */
    protected function generateFilter($bundle, $entity, $metadata)
    {
        try {
            $this->getFilterGenerator($bundle)->generate($bundle, $entity, $metadata[0]);
        } catch (\RuntimeException $e) {
            // form already exists
        }
    }

    /**
     * Tries to generate listing if they don't exist yet and if we need write operations on entities.
     *
     * @param mixed $bundle
     * @param mixed $entity
     * @param mixed $metadata
     */
    protected function generateFilterType($bundle, $entity, $metadata)
    {
        try {
            $this->getFilterTypeGenerator($bundle)->generate($bundle, $entity, $metadata[0]);
        } catch (\RuntimeException $e) {
            // form already exists
        }
    }

    protected function getListingGenerator($bundle = null)
    {
        if (null === $this->listingGenerator) {
            $this->listingGenerator = new OruListingGenerator($this->getContainer()->get('filesystem'));
            $this->listingGenerator->setSkeletonDirs($this->getSkeletonDirs($bundle));
        }

        return $this->listingGenerator;
    }

    protected function getFilterGenerator($bundle = null)
    {
        if (null === $this->filterGenerator) {
            $this->filterGenerator = new OruFilterGenerator($this->getContainer()->get('filesystem'));
            $this->filterGenerator->setSkeletonDirs($this->getSkeletonDirs($bundle));
        }

        return $this->filterGenerator;
    }

    protected function getFilterTypeGenerator($bundle = null)
    {
        if (null === $this->filterTypeGenerator) {
            $this->filterTypeGenerator = new OruFilterTypeGenerator($this->getContainer()->get('filesystem'));
            $this->filterTypeGenerator->setSkeletonDirs($this->getSkeletonDirs($bundle));
        }

        return $this->filterTypeGenerator;
    }

    protected function updateRepository($bundle, $entity, ClassMetadataInfo $metadata)
    {
        $fields = $this->getFieldsFromMetadata($metadata);

        $help = sprintf("        <comment>public function findList(\\{$bundle->getNamespace()}\\Filter\\%sFilter \$filter)</comment>"."\n", $entity);
        $help .= sprintf("        <comment>{</comment>\n");
        $help .= sprintf('        <comment>     $builder = $this->createQueryBuilder("u");</comment>'."\n\n");
        foreach ($fields as $field) {
            $help .= sprintf("        <comment>     if(\$filter->get%s())</comment>\n", Container::camelize($field));
            $help .= sprintf("        <comment>     {</comment>\n");
            $help .= sprintf('        <comment>         $builder->andWhere("u.%s like :%s")->setParameter("%s","%s{$filter->get%s()}%s");</comment>'."\n", $field, $field, $field, '%', Container::camelize($field), '%');
            $help .= sprintf("        <comment>     }</comment>\n");
        }
        $help .= sprintf('        <comment>     return $builder;</comment>'."\n");
        $help .= sprintf("        <comment>}</comment>\n");

        return array(
            "- Import the findList function in the bundle $entity repository file.",
            sprintf('  (%s).', $bundle->getPath().'/Entity/'.$entity.'Repository.php'),
            '',
            $help,
            '',
        );
    }

    /**
     * Returns an array of fields. Fields can be both column fields and
     * association fields.
     *
     * @param ClassMetadataInfo $metadata
     *
     * @return array $fields
     */
    private function getFieldsFromMetadata(ClassMetadataInfo $metadata)
    {
        $fields = (array) $metadata->fieldNames;

        // Remove the primary key field if it's not managed manually
        if (!$metadata->isIdentifierNatural()) {
            $fields = array_diff($fields, $metadata->identifier);
        }

        foreach ($metadata->associationMappings as $fieldName => $relation) {
            if ($relation['type'] !== ClassMetadataInfo::ONE_TO_MANY) {
                $fields[] = $fieldName;
            }
        }

        return $fields;
    }
}
