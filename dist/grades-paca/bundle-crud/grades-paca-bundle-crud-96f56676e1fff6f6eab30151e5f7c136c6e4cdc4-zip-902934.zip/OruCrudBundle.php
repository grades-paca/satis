<?php

namespace Oru\Bundle\CrudBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruCrudBundle extends Bundle
{
    public function getParent()
    {
        return 'SensioGeneratorBundle';
    }
}
