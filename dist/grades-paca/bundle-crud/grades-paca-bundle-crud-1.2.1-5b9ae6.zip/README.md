Bundle OruCrudBundle
====================

Description
-----------

Ce bundle fournit des commandes permettant de générer un CRUD utilisant les bundles OruListingBundle et OruPaginatorBundle. 
Il ajoute aussi au CRUD par défaut des classes permettant de filtrer les éléments d'un tableau.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/crud":dev-master
</pre>

Dans le AppKernel.php, activer ce bundle dans la section 'dev' et 'test' :
<pre>
if (in_array($this->getEnvironment(), array('dev', 'test'))) {
  ...
  $bundles[] = new Oru\Bundle\CrudBundle\OruCrudBundle();
}
```

Vider le cache de Symfony2

Utilisation
-----------

Ce bundle fournit 4 nouvelles commandes dans la section "oru" avec des alias dans la section "generate" : 

```
$ app/console
...
generate
  generate:bundle                       Generates a bundle
  generate:controller                   Generates a controller
  generate:doctrine:crud                Generates a CRUD based on a Doctrine entity
  generate:doctrine:entities            Generates entity classes and method stubs from your mapping information
  generate:doctrine:entity              Generates a new Doctrine entity inside a bundle
  generate:doctrine:form                Generates a form type class based on a Doctrine entity
  generate:oru:crud                     Oru crud generator.
  generate:oru:filter                   Generates a filter class based on a Doctrine entity
  generate:oru:filter_type              Generates a filter type class based on a Doctrine entity
  generate:oru:listing                  Generates a listing type class based on a Doctrine entity
init
  init:acl                              Mounts ACL tables in the database
oru
  oru:generate:crud                     Oru crud generator.
  oru:generate:filter                   Generates a filter class based on a Doctrine entity
  oru:generate:filter_type              Generates a filter type class based on a Doctrine entity
  oru:generate:listing                  Generates a listing type class based on a Doctrine entity
...
```

Les 2 commandes "oru:generate:filter" et "oru:generate:filter_type" génèrent des classes permettant de gérer des filtres sur les tableaux d'éléments.
La commande "oru:generate:listing" génère la classe Listing de base (cf bundle OruListingBundle).
Ces 3 commandes sont utilisées dans la commande "oru:generate:crud" qui génère un CRUD de base en ajoutant le listing et les filtres et en faisant le lien avec le bundle OruPaginatorBundle.

C'est ce bundle qu'il faudra modifier si nous souhaitons surcharger les templates et contrôleurs de base du CRUD. Il hérite d'ailleurs directement du SensioGeneratorBundle.
