Bundle WebClientBundle
======================
========================

Installation
------------

Dans le AppKernel.php, activer ce bundle

    $bundles[] = new Oru\Bundle\WebClientBundle\OruWebClientBundle();

Vider le cache de Symfony

Description
-----------

Ce bundle permet d'interroger des ressources externes en passant par un proxy éventuel.
Lorsqu'il n'y a pas de proxy configuré, l'interrogation de la ressource se fait de manière directe.
Le proxy doit être défini dans parameters.yml dans la variable proxy.

Utilisation
-----------

**Utilisation du client générique :**
```php
$client = $this->get('oru_webclient.client');

$response = $client->get('http://url-de-la-ressource');

// OU

$data = array('key' => 'value');
$client->post('http://url-de-la-ressource', $data);

// OU encore

$client->put('http://url-de-la-ressource', $data);

// OU encore

$client->delete('http://url-de-la-ressource', $data);
```
