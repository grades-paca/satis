<?php

namespace Oru\Bundle\WebClientBundle\Client;

use Oru\Bundle\WebClientBundle\Exception\RuntimeException;
use Oru\Bundle\WebClientBundle\Factory\ClientProxyFactory;
use Oru\Bundle\WebClientBundle\Request\Header;

/**
 * Class CurlResource.
 *
 * @author Michaël VEROUX
 */
class CurlResource
{
    /**
     * @var resource
     */
    protected $curlResource;

    /**
     * @var Header
     */
    protected $header;

    /**
     * @var Options
     */
    protected $options;

    /**
     * @var int
     */
    protected $timeoutMs = ClientProxyFactory::TIMEOUT_MS;

    /**
     * CurlResource constructor.
     *
     * @param resource $curlResource
     */
    public function __construct($curlResource)
    {
        $this->curlResource = $curlResource;
        $this->header = new Header();
        $this->options = new Options();
        $this->options->set(CURLOPT_RETURNTRANSFER, true);
    }

    /**
     * PHP 5 introduces a destructor concept similar to that of other object-oriented languages, such as C++.
     * The destructor method will be called as soon as all references to a particular object are removed or
     * when the object is explicitly destroyed or in any order in shutdown sequence.
     *
     * Like constructors, parent destructors will not be called implicitly by the engine.
     * In order to run a parent destructor, one would have to explicitly call parent::__destruct() in the destructor body.
     *
     * Note: Destructors called during the script shutdown have HTTP headers already sent.
     * The working directory in the script shutdown phase can be different with some SAPIs (e.g. Apache).
     *
     * Note: Attempting to throw an exception from a destructor (called in the time of script termination) causes a fatal error.
     *
     * @see http://php.net/manual/en/language.oop5.decon.php
     */
    public function __destruct()
    {
        curl_close($this->curlResource);
    }

    /**
     * @return Header
     */
    public function getHeader()
    {
        return $this->header;
    }

    /**
     * @return Options
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * @param string $url
     *
     * @return mixed
     *
     * @author Michaël VEROUX
     */
    public function curlExec($url)
    {
        $this->options->set(CURLOPT_URL, $url);
        $this->options->toResource($this->curlResource);
        $this->header->toResource($this->curlResource);

        $curlReturn = curl_exec($this->curlResource);

        if (!$curlReturn) {
            $err = curl_error($this->curlResource);

            throw new RuntimeException("Error accessing {$url} : {$err}");
        }

        return $curlReturn;
    }

    /**
     * @param null|int $option
     *
     * @return array|string
     *
     * @author Michaël VEROUX
     */
    public function curlInfo($option = null)
    {
        $info = curl_getinfo($this->curlResource, $option);

        return $info;
    }
}
