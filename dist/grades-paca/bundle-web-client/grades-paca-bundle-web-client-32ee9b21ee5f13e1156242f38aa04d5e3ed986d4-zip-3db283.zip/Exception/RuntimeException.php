<?php

namespace Oru\Bundle\WebClientBundle\Exception;

/**
 * Class RuntimeException.
 *
 * @author Michaël VEROUX
 */
class RuntimeException extends \RuntimeException
{
}
