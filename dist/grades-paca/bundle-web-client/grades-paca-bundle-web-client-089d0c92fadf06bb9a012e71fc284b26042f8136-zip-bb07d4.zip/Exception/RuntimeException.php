<?php

namespace Oru\Bundle\WebClientBundle\Exception;

/**
 * Class RuntimeException
 *
 * @package Oru\Bundle\WebClientBundle\Exception
 * @author Michaël VEROUX
 */
class RuntimeException extends \RuntimeException
{

}
