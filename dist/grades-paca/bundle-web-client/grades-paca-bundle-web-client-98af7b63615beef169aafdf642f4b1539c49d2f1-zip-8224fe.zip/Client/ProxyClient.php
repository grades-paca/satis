<?php

namespace Oru\Bundle\WebClientBundle\Client;

use Oru\Bundle\WebClientBundle\Exception\RuntimeException;
use Oru\Bundle\WebClientBundle\Factory\ClientProxyFactory;
use Oru\Bundle\WebClientBundle\Request\Header;

/**
 * Class ProxyClient
 *
 * @package Oru\Bundle\WebClientBundle\Client
 * @author Michaël VEROUX
 */
class ProxyClient
{
    /**
     * @var resource
     */
    protected $curlResource;

    /**
     * @var Header
     */
    protected $header;

    /**
     * @var Options
     */
    protected $options;

    /**
     * @var int
     */
    protected $timeoutMs = ClientProxyFactory::TIMEOUT_MS;

    /**
     * ProxyClient constructor.
     *
     * @param resource $curlResource
     */
    public function __construct($curlResource)
    {
        $this->curlResource = $curlResource;
        $this->header = new Header();
        $this->options = new Options();
        $this->options->set(CURLOPT_RETURNTRANSFER, true);
    }

    /**
     * PHP 5 introduces a destructor concept similar to that of other object-oriented languages, such as C++.
     * The destructor method will be called as soon as all references to a particular object are removed or
     * when the object is explicitly destroyed or in any order in shutdown sequence.
     *
     * Like constructors, parent destructors will not be called implicitly by the engine.
     * In order to run a parent destructor, one would have to explicitly call parent::__destruct() in the destructor body.
     *
     * Note: Destructors called during the script shutdown have HTTP headers already sent.
     * The working directory in the script shutdown phase can be different with some SAPIs (e.g. Apache).
     *
     * Note: Attempting to throw an exception from a destructor (called in the time of script termination) causes a fatal error.
     *
     * @return void
     * @link http://php.net/manual/en/language.oop5.decon.php
     */
    public function __destruct()
    {
        curl_close($this->curlResource);
    }

    /**
     * @return Header
     */
    public function getHeader()
    {
        return $this->header;
    }

    /**
     * @return Options
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * @return int
     */
    public function getTimeoutMs()
    {
        return $this->timeoutMs;
    }

    /**
     * @param int $timeoutMs
     *
     * @return $this
     */
    public function setTimeoutMs($timeoutMs)
    {
        $this->timeoutMs = $timeoutMs;

        return $this;
    }

    /**
     * @param string $url
     *
     * @return mixed
     * @author Michaël VEROUX
     */
    public function get($url)
    {
        $response = $this->request($url);

        return $response['data'];
    }

    /**
     * @param string $url
     * @param string $data
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function post($url, $data)
    {
        $this->options->set(CURLOPT_CUSTOMREQUEST, 'POST');
        $this->options->set(CURLOPT_POST, true);
        $this->header->setContent($data);
        $response = $this->request($url);

        return $response['data'];
    }

    /**
     * @param string $url
     * @param string $data
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function put($url, $data)
    {
        $this->options->set(CURLOPT_CUSTOMREQUEST, 'PUT');
        $this->options->set(CURLOPT_PUT, true);
        $this->header->setContent($data);
        $response = $this->request($url);

        return $response['data'];
    }

    /**
     * @param string $url
     * @param string $data
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function delete($url, $data)
    {
        $this->options->set(CURLOPT_CUSTOMREQUEST, 'DELETE');
        $this->options->set(CURLOPT_POST, true);
        $this->header->setContent($data);
        $response = $this->request($url);

        return $response['data'];
    }

    /**
     * @param string   $url
     *
     * @return array
     * @author Michaël VEROUX
     */
    private function request($url)
    {
        $response = $this->requestExec($url, $this->curlResource);

        if (false == $response['httpStatus']) {
            throw new RuntimeException($response['message']);
        }

        return $response;
    }

    /**
     * @param string   $url
     * @param resource $resource
     *
     * @return array
     * @author Michaël VEROUX
     */
    private function requestExec($url, $resource)
    {
        $response = array();
        $this->options->set(CURLOPT_URL, $url);
        $this->options->toResource($resource);
        $this->header->toResource($resource);
        $response['data'] = curl_exec($resource);
        $response['message'] = curl_error($resource);
        $response['httpStatus'] = curl_getinfo($resource, CURLINFO_HTTP_CODE);
        if (28 === curl_errno($resource) && ClientProxyFactory::TIMEOUT_MS >= $this->timeoutMs) {
            $this->timeoutMs = $this->timeoutMs << 2;
            $this->options->set(CURLOPT_TIMEOUT_MS, $this->timeoutMs);

            return $this->requestExec($url, $resource);
        }

        return $response;
    }
}
