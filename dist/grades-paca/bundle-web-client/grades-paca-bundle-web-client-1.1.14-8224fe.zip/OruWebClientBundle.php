<?php
namespace Oru\Bundle\WebClientBundle ;
use Symfony\Component\HttpKernel\Bundle\Bundle ;


class OruWebClientBundle extends Bundle
{

    public function boot() {

    }


    public function __toString() {
        return "OruWebClientBundle" ;
    }




}
