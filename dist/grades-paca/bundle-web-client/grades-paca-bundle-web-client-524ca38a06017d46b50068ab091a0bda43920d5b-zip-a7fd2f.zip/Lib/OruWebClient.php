<?php
/**
 * Created by PhpStorm.
 * User: ecervetti
 * Date: 09/06/15
 * Time: 16:34
 */

namespace Oru\Bundle\WebClientBundle\Lib;


class OruWebClient {

    private $strProxy ;

    function __construct($strProxy)
    {
        $this->strProxy = $strProxy ;
    }

    /**
     * Get a Curl ressource eventually preformated with proxy support
     * @param $headers array of optionnal headers to put in the curl ressource with the CURLOPT_HTTPHEADER option
     * @return resource
     */
    public function getCurlRessource($headers = array())
    {
        $ch = curl_init();
        if ($this->strProxy) {
            $this->getProxyParams($proxy_host, $proxy_port, $proxy_login, $proxy_pass);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_PROXY, "$proxy_host:$proxy_port");
            if ($proxy_login) {
                curl_setopt($ch, CURLOPT_PROXYUSERPWD, "$proxy_login:$proxy_pass");
            }
        }
        return $ch ;
    }

    /**
     * Get the content of a page returned by a url as a string
     * @param $url
     * @param $headers array of optionnal headers to put in the curl ressource with the CURLOPT_HTTPHEADER option
     * @return mixed
     * @throws \Exception
     */
    public function  getSimpleContents($url, $headers = array()){
        $ch = $this->getCurlRessource();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $data = curl_exec($ch);
        $message = curl_error($ch);
        $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ( $httpStatus == 0 ) {
            throw new \Exception($message);
        }
        return $data;
    }

    /**
     * Extract a standard proxy url (login:pass@proxydns:8080 or proxydns:8080 ) to atomic values
     * @param $proxy_host
     * @param $proxy_port
     * @param $proxy_login
     * @param $proxy_pass
     */
    public function getProxyParams(&$proxy_host, &$proxy_port, &$proxy_login, &$proxy_pass) {
        if($this->strProxy) {
            if (preg_match('/([^:]+):(.+)@([^:]+):([^:]+)/', $this->strProxy, $tabMatch)) {
                $proxy_login = $tabMatch[1];
                $proxy_pass = $tabMatch[2];
                $proxy_host = $tabMatch[3];
                $proxy_port = $tabMatch[4];
            } else {
                list($proxy_host, $proxy_port) = explode(':', $this->strProxy);
                $proxy_login = '';
                $proxy_pass = '';
            }
        }
    }



}