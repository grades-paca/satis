<?php

namespace Oru\Bundle\WebClientBundle\Factory;

use Oru\Bundle\WebClientBundle\Client\ProxyClient;
use Oru\Bundle\WebClientBundle\Exception\RuntimeException;
use Redmine\Client;

/**
 * Class ClientProxyFactory
 *
 * @package Oru\Bundle\WebClientBundle\Factory
 * @author Michaël VEROUX
 */
class ClientProxyFactory
{
    const TIMEOUT_MS = 500;

    /**
     * @var string
     */
    protected $proxyUrl;

    /**
     * @var string
     */
    protected $proxyHost;

    /**
     * @var string
     */
    protected $proxyPort;

    /**
     * @var string|null
     */
    protected $proxyLogin;

    /**
     * @var string|null
     */
    protected $proxyPass;

    /**
     * @var bool
     */
    protected $hasProxy = false;

    /**
     * @param string $proxyUrl
     * @param array  $headers
     *
     * @return ProxyClient
     * @author Michaël VEROUX
     */
    public function getClient($proxyUrl, $headers = array())
    {
        $this->proxyUrl = $proxyUrl;
        $ch = $this->getCurlRessource($headers);
        $client = new ProxyClient($ch, !$this->hasProxy);

        return $client;
    }

    /**
     * @param string      $proxyUrl
     * @param string      $url
     * @param string      $apiKey
     * @param string|null $urlLocal
     *
     * @return Client
     * @author Michaël VEROUX
     */
    public function getRedmineClient($proxyUrl, $url, $apiKey, $urlLocal = null)
    {
        $this->proxyUrl = $proxyUrl;
        $this->init();

        $proxyUrl = null;
        $proxyAuth = null;
        if (!$urlLocal && $this->proxyHost) {
            $proxyUrl = sprintf('%s:%s', $this->proxyHost, $this->proxyPort);
            if ($this->proxyLogin) {
                $proxyAuth = sprintf('%s:%s', $this->proxyLogin, $this->proxyPass);
            }
        }
        if ($urlLocal) {
            $url = $urlLocal;
        }
        $client = new Client(
            $url,
            $apiKey,
            null,
            $proxyUrl,
            $proxyAuth
        );

        return $client;
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getHost()
    {
        $this->init();
        $host = sprintf('%s:%s', $this->proxyHost, $this->proxyPort);

        return $host;
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getAuthentication()
    {
        $this->init();
        if (!$this->proxyLogin) {
            return '';
        }
        $auth = sprintf('%s:%s', $this->proxyLogin, $this->proxyPass);

        return $auth;
    }

    /**
     * @return void
     * @author Michaël VEROUX
     */
    private function init()
    {
        if ($this->proxyUrl && !$this->proxyHost) {
            if (preg_match('/([^:]+):(.+)@([^:]+):([^:]+)/', $this->proxyUrl, $tabMatch)) {
                $this->proxyLogin = $tabMatch[1];
                $this->proxyPass = $tabMatch[2];
                $this->proxyHost = $tabMatch[3];
                $this->proxyPort = $tabMatch[4];
            } else {
                list($this->proxyHost, $this->proxyPort) = explode(':', $this->proxyUrl);
                $this->proxyLogin = '';
                $this->proxyPass = '';
            }
            if (!$this->proxyHost) {
                throw new RuntimeException('Failed to retrieve proxy host.');
            }
        }
    }

    /**
     * @param array $headers
     *
     * @return resource
     * @author Michaël VEROUX
     */
    private function getCurlRessource($headers = array())
    {
        $this->init();
        $ch = curl_init();

        if ($this->proxyHost) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            $this->hasProxy = curl_setopt($ch, CURLOPT_PROXY, sprintf('%s:%s', $this->proxyHost, $this->proxyPort));
            if ($this->proxyLogin) {
                curl_setopt($ch, CURLOPT_PROXYUSERPWD, sprintf('%s:%s', $this->proxyLogin, $this->proxyPass));
            }
        }
        curl_setopt($ch, CURLOPT_FAILONERROR, true);
        curl_setopt($ch, CURLOPT_NOSIGNAL, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT_MS, static::TIMEOUT_MS);

        return $ch;
    }
}
