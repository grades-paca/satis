<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\PatientBundle\Controller;

use Oru\Bundle\PatientBundle\Entity\Patient;
use Oru\Bundle\PatientBundle\Exception\NotImplementedException;
use Oru\Bundle\PatientBundle\Form\PatientType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\DependencyInjection\Exception\ParameterNotFoundException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class PatientController extends Controller
{
    /**
     * Search for patient by his name.
     *
     * @param string $_format
     * @param string search : the term to search
     * @param integer structure : the id of the structure to search in
     * @return JsonResponse
     */
    public function searchPatientsAction(Request $request, $_format)
    {
        if ($this->get('security.authorization_checker')->isGranted('view', new Patient()) === false) {
            throw new AccessDeniedException('Unauthorized access!');
        }

        $patients = array();
        if ($request->get('search') == '') {
            throw new ParameterNotFoundException("Parameter 'search' not found.");
        }

        $page_limit = $request->get('page_limit', 10);
        if (!is_numeric($request->get('page_limit')) || $request->get('page_limit') > 100) {
            $page_limit = 10;
        }

        $first = 0;
        if ($request->get('first')) {
            $first = $request->get('first');
        }

        $total = 0;
        if ($request->get('infinite_scroll')) {
            $total = $this->getDoctrine()->getRepository('OruPatientBundle:Patient')->countSearchByName($request->get('search'));
        }

        $str_entities = $this->getDoctrine()->getRepository('OruPatientBundle:Patient')->searchByName($request->get('search'), $page_limit, $first);

        if (count($str_entities)) {
            $i = 0;
            foreach ($str_entities as $str_entitie) {
                $patients[] = array(
                    'id' => $str_entitie->getId(),
                    'nom' => $str_entitie->__toString(),
                );
            }
        }

        if ($_format == 'json') {
            return new JsonResponse(array('total' => $total, 'patients' => $patients));
        }
    }

    /**
     * Get a patient by identifier.
     *
     * @param id $_id
     * @param string $_format
     *
     * @return JsonResponse
     */
    public function getPatientsByIdsAction(Request $request, $_ids, $_format)
    {
        $ids = explode(',', $_ids);
        $patients = array();
        $entities = $this->getDoctrine()->getRepository('OruPatientBundle:Patient')->findById($ids);

        foreach ($entities as $entity) {
            if ($entity) {
                $patients[] = array('id' => $entity->getId(), 'nom' => $entity->__toString());
            }
        }

        if ($_format == 'json') {
            return new JsonResponse($patients);
        }
    }

    /**
     * Creates a new Patient entity.
     *
     */
    public function createAction(Request $request)
    {
        //$form = $this->createCreateForm();
    }

    /**
     * Creates a form to create a Patient entity.
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createCreateForm($entity)
    {
        $form = $this->createForm(new PatientType(), $entity, array(
            'action' => $this->generateUrl('patient_create'),
            'method' => 'POST',
            'attr' => array('id' => 'patient_form')
        ));

        return $form;
    }

    /**
     * Displays a form to create a new Patient entity.
     *
     */
    public function newAction(Request $request)
    {
        if (!$request->isXmlHttpRequest()) {
            throw new NotImplementedException();
        }

        $entity = new Patient();
        $form   = $this->createCreateForm($entity);

        if ($this->get('security.authorization_checker')->isGranted('create', $entity) === false) {
            throw new AccessDeniedException('Unauthorized access!');
        }

        if ($request->isMethod('POST')) {
            $response = new JsonResponse();
            $form->handleRequest($request);
            if ($form->isValid()) {
                $this->getDoctrine()->getManager()->persist($entity);
                $this->getDoctrine()->getManager()->flush();
                $response->setData(array('id' => $entity->getId(), 'name' => (string) $entity));
            } else {
                $response->setData($this->getErrorMessages($form), true);
            }
            return $response;
        }

        return $this->render('@OruPatient/Form/new.html.twig', array(
            'entity' => $entity,
            'form'   => $form->createView(),
            'field'  => $request->get('field', null)
        ));
    }

    private function getErrorMessages(\Symfony\Component\Form\Form $form)
    {
        $errors = array();

        foreach ($form->getErrors() as $key => $error) {
            if ($form->isRoot()) {
                $errors['#'][] = $error->getMessage();
            } else {
                $errors[] = $error->getMessage();
            }
        }

        foreach ($form->all() as $child) {
            if (!$child->isValid()) {
                $errors[$child->getName()] = $this->getErrorMessages($child);
            }
        }

        return $errors;
    }
}
