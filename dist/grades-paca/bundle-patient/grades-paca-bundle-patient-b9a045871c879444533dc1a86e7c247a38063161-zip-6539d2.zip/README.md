Bundle OruPatientBundle
=======================

Description
-----------

Ce bundle met à disposition une gestion de patients.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/patient":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\PatientBundle\OruPatientBundle();
```

Vider le cache de Symfony2

Utilisation
-----------

Le service 'oru_patient.factory' permet de rechercher ou créer un patient.

@todo : Prévoir la possibilité de fusionner plusieurs patients.

@todo : Prévoir un filtre d'anonymisation.

### Widgets

#### - oru\_patient\_autocomplete

Widget pour afficher un champ autocomplété de patients. Ce widget hérite du type texte et de ces options : (exemple : label, read_only, required...).

L'option 'multiple' permet de bénéficier d'un champ à choix multiples. Par défaut, cette option est désactivé.

L'option 'results' correspond au nombre d'éléments de résultats affichés, par défaut 10.

L'option 'infinite_scroll' permet d'ajouter un scroll infini sur les résultat, activé par défaut.

L'option 'minimun' permet de définir le nombre minimum de caractères à saisir avant que se lance la recherche, par défaut 3.

@todo : implémenter l'option create pour créer et séléctionner un patient à la volée.

Exemple d'utilisation :

```php
$builder
    ->add('patient', 'oru_patient_autocomplete')
```
