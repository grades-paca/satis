<?php
namespace Oru\Bundle\PatientBundle\Exception;

class NotImplementedException extends \Exception
{
}
