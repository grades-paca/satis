<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\PatientBundle\Form\Type;

use Oru\Bundle\FormBundle\Form\Type\AutocompleteType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

class PatientAutocompleteType extends AutocompleteType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array('class' => 'OruPatientBundle:Patient', 'placeholder' => 'Chercher un patient', 'create' => false));
        $resolver->setDefined(array('route'));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        $view->vars['create'] = $options['create'];
        $view->vars['route'] = (isset($options['route'])) ? $options['route'] : 'patient_search_by_nom';
    }

    public function getBlockPrefix()
    {
        return 'oru_patient_autocomplete';
    }
}
