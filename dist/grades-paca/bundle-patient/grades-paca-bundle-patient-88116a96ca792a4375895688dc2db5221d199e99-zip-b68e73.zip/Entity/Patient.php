<?php

namespace Oru\Bundle\PatientBundle\Entity;

/**
 * Patient.
 */
class Patient
{
    /**
     * @var string
     */
    private $nom;

    /**
     * @var string
     */
    private $nomPatronymique;

    /**
     * @var string
     */
    private $prenom;

    /**
     * @var \DateTime
     */
    private $dateNaissance;

    /**
     * @var string
     */
    private $sexe;

    /**
     * @var int
     */
    private $id;

    /**
     * @var bool
     */
    private $anonymised;

    public function __toString()
    {
        if ($this->isAnonymised()) {
            return 'Anonymisé '.$this->getId();
        }

        return $this->getPrenom().' '.$this->getNom().(($this->getNomPatronymique() !== '') ? ' né'.(($this->getSexe() === 'H') ? ' ' : 'e ')."{$this->getNomPatronymique()}" : '').' ('.$this->getDateNaissance()->format('d/m/Y').')';
    }

    /**
     * Set nom.
     *
     * @param string $nom
     *
     * @return Patient
     */
    public function setNom($nom)
    {
        $this->nom = strtoupper($nom);

        return $this;
    }

    /**
     * Get nom.
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * @param string $nomPatronymique
     */
    public function setNomPatronymique($nomPatronymique)
    {
        $this->nomPatronymique = strtoupper($nomPatronymique);
    }

    /**
     * @return string
     */
    public function getNomPatronymique()
    {
        return $this->nomPatronymique;
    }

    /**
     * Set prenom.
     *
     * @param string $prenom
     *
     * @return Patient
     */
    public function setPrenom($prenom)
    {
        $this->prenom = ucwords(strtolower($prenom));

        return $this;
    }

    /**
     * Get prenom.
     *
     * @return string
     */
    public function getPrenom()
    {
        return $this->prenom;
    }

    /**
     * Set dateNaissance.
     *
     * @param \DateTime $dateNaissance
     *
     * @return Patient
     */
    public function setDateNaissance($dateNaissance)
    {
        $this->dateNaissance = $dateNaissance;

        return $this;
    }

    /**
     * Get dateNaissance.
     *
     * @return \DateTime
     */
    public function getDateNaissance()
    {
        return $this->dateNaissance;
    }

    /**
     * Set sexe.
     *
     * @param string $sexe
     *
     * @return Patient
     */
    public function setSexe($sexe)
    {
        $this->sexe = $sexe;

        return $this;
    }

    /**
     * Get sexe.
     *
     * @return string
     */
    public function getSexe()
    {
        return $this->sexe;
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return bool
     */
    public function isAnonymised()
    {
        return $this->anonymised;
    }

    /**
     * @param bool $anonymised
     */
    public function setAnonymised($anonymised)
    {
        $this->anonymised = $anonymised;
    }
}
