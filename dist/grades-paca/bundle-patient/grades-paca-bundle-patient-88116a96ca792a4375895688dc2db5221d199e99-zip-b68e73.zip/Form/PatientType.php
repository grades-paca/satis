<?php

namespace Oru\Bundle\PatientBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class PatientType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom', null, array('label' => 'Patient.nom', 'translation_domain' => 'OruPatientBundle'))
            ->add('nomPatronymique', null, array('label' => 'Patient.nomPatronymique', 'translation_domain' => 'OruPatientBundle'))
            ->add('prenom', null, array('label' => 'Patient.prenom', 'translation_domain' => 'OruPatientBundle'))
            ->add('dateNaissance', null, array('label' => 'Patient.dateNaissance', 'translation_domain' => 'OruPatientBundle'))
            ->add('sexe', ChoiceType::class, array('choices_as_values' => true, 'label' => 'Patient.sexe', 'translation_domain' => 'OruPatientBundle', 'choices' => array_flip(array('H' => 'Homme', 'F' => 'Femme'))))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\PatientBundle\Entity\Patient',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_patientbundle_patient';
    }
}
