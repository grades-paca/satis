<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\PatientBundle\Factory;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\PatientBundle\Entity\Patient;

class PatientFactory
{
    protected $entityManager;

    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    public function get($nom, $prenom, \DateTime $dateNaissance, $sexe = null, $nomPatronymique = null)
    {
        $patient = $this->entityManager->getRepository('OruPatientBundle:Patient')->searchPatient($nom, $prenom, $dateNaissance, $sexe);

        switch (count($patient)) {
            case 1:
                return reset($patient);
            default:
                $patient = new Patient();
                $patient->setNom($nom);
                if ($nomPatronymique) {
                    $patient->setNomPatronymique($nomPatronymique);
                }
                $patient->setPrenom($prenom);
                if ($sexe === 'H' || $sexe === 'F') {
                    $patient->setSexe($sexe);
                }
                $patient->setDateNaissance($dateNaissance);

                return $patient;
        }
    }
}
