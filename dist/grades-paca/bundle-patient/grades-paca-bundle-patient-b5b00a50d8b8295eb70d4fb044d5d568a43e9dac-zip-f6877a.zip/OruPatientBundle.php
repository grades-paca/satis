<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\PatientBundle;

use Oru\Bundle\PatientBundle\DependencyInjection\Compiler\FormPass;
use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruPatientBundle extends Bundle
{
    public function boot()
    {
        DynamicLoader::addXml('@OruPatientBundle/Resources/config/routing.xml');
    }

    public function build(ContainerBuilder $container)
    {
        parent::build($container);
        $container->addCompilerPass(new FormPass());
    }
}
