Bundle OruPaginatorBundle
=========================

Description
-----------

Ce bundle est un pont entre le Bundle OruListingBundle et "KnpPaginatorBundle":https://github.com/KnpLabs/KnpPaginatorBundle. 
Il permet l'ajout du système de pagination et de tri d'éléments disponible dans "KnpPaginatorBundle":https://github.com/KnpLabs/KnpPaginatorBundle à la gestion de listes du Bundle OruListingBundle.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/paginator":dev-master
```

Dans le AppKernel.php, activer ce bundle :

```
$bundles[] = new Knp\Bundle\PaginatorBundle\KnpPaginatorBundle();
$bundles[] = new Oru\Bundle\PaginatorBundle\OruPaginatorBundle();
```

Vider le cache de Symfony2

Utilisation
-----------

Ce bundle sert essentiellement à faire le lien entre les bundles Bundle OruListingBundle et "KnpPaginatorBundle":https://github.com/KnpLabs/KnpPaginatorBundle. Il y a donc très peu de choses à changer pour passer d'un contrôleur utilisant le Bundle OruListingBundle à un controleur utilisant celui-ci.
L'objet paginator est disponible via le service 'paginator.factory'. L'appel à la fonction create en fournissant :
- un objet de type "ListingTypeInterface"
- la requête permettant de récupérer les éléments
- la page en cours en fonction des informations disponibles dans la requête en cours
renvoie un object implémentant 'ListingInterface' qui s'affiche via la fonction Twig "listing" (cf [[ Bundle OruListingBundle #Le-contrôleur]]).
L'objet paginator s'occupe de surcharger les templates Twig pour afficher un listing avec la pagination et le tri par colonnes.

Voici un exemple d'utilisation :

```
$listing = $this->container->get('paginator.factory')->create(
    new DepartementListingType(),
    $this->getDoctrine()->getManager()->getRepository('OruRepertoireBundle:Departement')->findList($filter),
    $request->query->get('page', 1)
);
```

Par défaut, le tri sur les colonnes ne s'affiche pas. Il faut au préalable ajouter l'option "sort" lors de la construction de l'object ListingTypeInterface.
Voici comment ajouter le tri sur la colonne libelle d'une entité département :

```
public function buildListing(ListingBuilderInterface $builder)
{
    $builder
        ->add('no')
        ->add('libelle', null, array('sort' => 'u.libelle'))
        ->add('mail')
        ->add('datetime')
        ->add('date')
        ->add('time')
        ->add('edit', 'object_action', array('route' => 'departement_edit'))
        ->add('show', 'object_action', array('route' => 'departement_show'))
        ->add('new', 'list_action', array('route' => 'departement_new'))
    ;
}
```
