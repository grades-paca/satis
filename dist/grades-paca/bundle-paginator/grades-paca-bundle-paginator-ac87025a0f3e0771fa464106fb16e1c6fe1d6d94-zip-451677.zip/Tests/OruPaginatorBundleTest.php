<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 02/01/14
 * Time: 12:16
 */

namespace Oru\Bundle\PaginatorBundle\Tests;


class OruPaginatorBundleTest extends TestCase
{
    /**
     * @test
     */
    public function serviceFactory()
    {
        $paginator = $this->getMockBuilder('Oru\Bundle\PaginatorBundle\Paginator\Paginator')
            ->disableOriginalConstructor()
            ->getMock()
        ;

        $container = $this->getMock('Symfony\Component\DependencyInjection\ContainerInterface');

        $container
            ->expects($this->once())
            ->method('get')
            ->with('paginator.factory')
            ->will($this->returnValue($paginator))
        ;

        $container->get('paginator.factory');
    }
} 