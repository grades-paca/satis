<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\PaginatorBundle\Paginator;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingFactoryInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class Paginator
{
    public $listingFactory = null;
    public $paginator = null;
    public $elements_page;
    public $filter = null;

    /**
     * @param ListingFactoryInterface $listingFactory
     * @param mixed                   $elements_page
     */
    public function __construct(ListingFactoryInterface $listingFactory, \Knp\Component\Pager\Paginator $paginator, $elements_page)
    {
        $this->listingFactory = $listingFactory;
        $this->paginator = $paginator;
        $this->elements_page = $elements_page;
    }

    public function create(AbstractListingType $type, $query, $page, $nb_page = null, $options = array())
    {
        $pageInt = (int) $page;
        if ((string) $pageInt !== (string) $page) {
            throw new NotFoundHttpException('Page must be integer.');
        }

        try {
            $pagination = $this->paginator->paginate(
                $query,
                $page,
                ($nb_page) ? $nb_page : $this->elements_page,
                $options
            );

            $listing = $this->listingFactory->create($type, $pagination->getItems());
        } catch (\UnexpectedValueException $e) {
            throw new NotFoundHttpException($e->getMessage());
        }

        $listing->setPaginator($pagination);
        $listing->setTemplate('defaultListingTableHeaderTemplate', '@OruPaginator/listing_table_header.html.twig');
        $listing->setTemplate('defaultListingCoreFooterTemplate', '@OruPaginator/listing_core_footer.html.twig');
        $listing->setTemplate('defaultListingFooterTemplate', '@OruPaginator/listing_footer.html.twig');

        return $listing;
    }
}
