<?php

namespace Oru\Bundle\PaginatorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruPaginatorBundle extends Bundle
{
}
