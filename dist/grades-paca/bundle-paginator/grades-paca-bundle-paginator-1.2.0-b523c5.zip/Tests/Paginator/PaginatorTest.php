<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 31/12/13
 * Time: 15:58
 */

namespace Oru\Bundle\PaginatorBundle\Tests\Paginator;

use Oru\Bundle\PaginatorBundle\Tests\TestCase;
use Oru\Bundle\TestBundle\Listing\ModelObjectListingType;

class PaginatorTest extends TestCase
{
    /**
     * @test
     */
    public function getCreatePaginator()
    {
        $listingFactory = $this->container->get('paginator.factory');

        $repository = $this->entityManager->getRepository('Oru\Bundle\TestBundle\Entity\ModelObject');

        $queryBuilder = $repository->createQueryBuilder('model');
        $queryBuilder->select('model');

        $paginatorListing = $listingFactory->create(
            new ModelObjectListingType(),
            $queryBuilder,
            1
        );

        // L'objet retourné doit implémenter ListingInterface
        $this->assertInstanceOf(
            'Oru\Bundle\ListingBundle\Listing\ListingInterface',
            $paginatorListing
        );

        // L'objet retourné doit être un AbstractPagination KNP
        $this->assertInstanceOf(
            'Knp\Component\Pager\Pagination\AbstractPagination',
            $paginatorListing->getPaginator()
        );
    }
}
