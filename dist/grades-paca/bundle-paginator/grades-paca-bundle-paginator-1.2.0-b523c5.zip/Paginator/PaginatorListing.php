<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\PaginatorBundle\Paginator;

use Knp\Component\Pager\Pagination\PaginationInterface;
use Oru\Bundle\ListingBundle\Listing\Listing;

class PaginatorListing extends Listing
{
    private $paginator;

    public function setPaginator(PaginationInterface $paginator)
    {
        $this->paginator = $paginator;
    }

    public function getPaginator()
    {
        return $this->paginator;
    }
}
