<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\PaginatorBundle\Paginator;

use Doctrine\ORM\AbstractQuery;
use Doctrine\ORM\Query;
use Doctrine\ORM\QueryBuilder;
use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingFactoryInterface;

class Paginator
{
    public $listingFactory = null;
    public $paginator = null;
    public $elements_page = null;
    public $filter = null;

    /**
     * @param ListingFactoryInterface $listingFactory
     */
    public function __construct(ListingFactoryInterface $listingFactory,\Knp\Component\Pager\Paginator $paginator, $elements_page)
    {
        $this->listingFactory = $listingFactory;
        $this->paginator = $paginator;
        $this->elements_page = $elements_page;
    }

    public function create(AbstractListingType $type, $query, $page, $nb_page = 10, $options = array())
    {
        $pagination = $this->paginator->paginate(
            $query,
            $page,
            ($nb_page != 10) ? $nb_page : $this->elements_page,
            $options
        );


        $listing = $this->listingFactory->create($type, $pagination->getItems());
        $listing->setPaginator($pagination);
        $listing->setTemplate('defaultListingTableHeaderTemplate', 'OruPaginatorBundle::listing_table_header.html.twig');
        $listing->setTemplate('defaultListingFooterTemplate', 'OruPaginatorBundle::listing_footer.html.twig');

        return $listing;
    }
}