<?php

namespace Oru\Bundle\KeyStoreBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class CertificateListingType.
 *
 * @author Michaël VEROUX
 */
class CertificateListingType extends AbstractListingType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('name', null, array('sort' => 'c.name', 'label' => 'Certificate.name',
                                      'translation_domain' => 'OruKeyStoreBundle',
            ))
            ->add('fingerPrintHumanReadable', null, array('label' => 'Certificate.fingerPrint',
                                                          'translation_domain' => 'OruKeyStoreBundle',
            ))
            ->add('show', 'object_action', array('route' => 'certificate_show', 'label' => 'listing.action.show'))
            ->add('edit', 'object_action', array('route' => 'certificate_edit', 'label' => 'listing.action.edit',
                                                 'role' => 'ORU_ROR_POLE_EDIT', 'deleted' => 'deleted',
            ));
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
                                   'data_class' => 'Oru\Bundle\KeyStoreBundle\Entity\Certificate',
                               ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_keystorebundle_certificatelisting';
    }
}
