<?php

namespace Oru\Bundle\KeyStoreBundle\Filter;

/**
 * Class CertificateFilter.
 *
 * @author Michaël VEROUX
 */
class CertificateFilter
{
    /**
     * @var string|null
     */
    protected $name;

    /**
     * @var string|null
     */
    protected $fingerPrint;

    /**
     * @var bool
     */
    protected $deleted = false;

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     *
     * @return $this
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * @return null|string
     */
    public function getFingerPrint()
    {
        return $this->fingerPrint;
    }

    /**
     * @param null|string $fingerPrint
     *
     * @return $this
     */
    public function setFingerPrint($fingerPrint)
    {
        $fingerPrint = str_replace(' ', '', $fingerPrint);
        $fingerPrint = strtolower($fingerPrint);

        $this->fingerPrint = $fingerPrint;

        return $this;
    }

    /**
     * @return bool
     */
    public function getDeleted()
    {
        return $this->deleted;
    }

    /**
     * @param bool $deleted
     *
     * @return $this
     */
    public function setDeleted($deleted)
    {
        $this->deleted = $deleted;

        return $this;
    }
}
