<?php

namespace Oru\Bundle\KeyStoreBundle\Controller;

use Oru\Bundle\KeyStoreBundle\Entity\Certificate;
use Oru\Bundle\KeyStoreBundle\Form\CertificateFilterType;
use Oru\Bundle\KeyStoreBundle\Form\CertificateType;
use Oru\Bundle\KeyStoreBundle\Listing\CertificateListingType;
use Oru\Bundle\RorCredentialsBundle\Controller\CredentialControllerTrait;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

/**
 * Class CertificateController.
 *
 * @author Michaël VEROUX
 */
class CertificateController extends Controller
{
    use CredentialControllerTrait;
    const FILTER_DEFAULT = array('deleted' => '0');

    /**
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function filterAction(Request $request)
    {
        $this->checkCanAdmin();

        $form = $this->createForm(CertificateFilterType::class)->handleRequest($request);

        if ($form->get('reset')->isClicked()) {
            $request->getSession()->set(CertificateFilterType::class, self::FILTER_DEFAULT);

            return $this->redirect($this->generateUrl('certificate'));
        }

        if ($form->isValid()) {
            $request->getSession()->set(CertificateFilterType::class, $request->get($form->getName()));

            return $this->redirect($this->generateUrl('certificate'));
        }

        return $this->indexAction($request, $form);
    }

    /**
     * @param Request $request
     * @param null    $form
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function indexAction(Request $request, $form = null)
    {
        $this->checkCanAdmin();

        if (null === $form) {
            $form = $this->createForm(CertificateFilterType::class)->submit($request->getSession()->get('oru_keystore_certificate.filter', self::FILTER_DEFAULT));
        }

        $entities = $this->getDoctrine()->getRepository('OruKeyStoreBundle:Certificate')->findList($form->getData());

        $listing = $this->container->get('paginator.factory')->create(
            new CertificateListingType(),
            $entities,
            $request->query->get('page', 1)
        );

        return $this->render('@OruKeyStore/Certificate/index.html.twig',
            array(
                'listing' => $listing,
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function newAction()
    {
        $this->checkCanAdmin();

        $form = $this->form();

        return $this->render('@OruKeyStore/Certificate/edit.html.twig', array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function createAction(Request $request)
    {
        $this->checkCanAdmin();

        $form = $this->form();

        $form->handleRequest($request);

        if ($form->isValid()) {
            $entity = $form->getData();

            $this->getDoctrine()->getManager()->persist($entity);
            $this->getDoctrine()->getManager()->flush();

            return $this->redirect($this->generateUrl('certificate'));
        }

        return $this->render('@OruKeyStore/Certificate/edit.html.twig', array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Certificate $certificate
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function editAction(Certificate $certificate)
    {
        $this->checkCanAdmin();

        $form = $this->form($certificate);

        return $this->render('@OruKeyStore/Certificate/edit.html.twig', array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request     $request
     * @param Certificate $certificate
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function updateAction(Request $request, Certificate $certificate)
    {
        $this->checkCanAdmin();

        $form = $this->form($certificate);

        $form->handleRequest($request);

        if ($form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirect($this->generateUrl('certificate'));
        }

        return $this->render('@OruKeyStore/Certificate/edit.html.twig', array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param $id
     *
     * @throws \Symfony\Component\HttpKernel\Exception\NotFoundHttpException
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function showAction($id)
    {
        $this->checkCanAdmin();

        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruKeyStoreBundle:Certificate')->find($id);

        if (!$entity) {
            try {
                $em->getFilters()->disable('softdeleteable');
            } catch (\InvalidArgumentException $e) {
            }

            $entity = $em->getRepository('OruKeyStoreBundle:Certificate')->find($id);
        }

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Certificate entity.');
        }

        return $this->render('@OruKeyStore/Certificate/show.html.twig', array(
            'entity' => $entity,
        ));
    }

    /**
     * @throws AccessDeniedException
     *
     * @author Michaël VEROUX
     */
    protected function checkCanAdmin()
    {
        $this->grantAccess('ORU_ROR_CERTIFICAT');
    }

    /**
     * @param null $entity
     *
     * @return \Symfony\Component\Form\Form
     *
     * @author Michaël VEROUX
     */
    protected function form($entity = null)
    {
        if (null === $entity) {
            $entity = new Certificate();
            $action = $this->generateUrl('certificate_create');
            $method = 'POST';
        } else {
            $action = $this->generateUrl('certificate_update', array('id' => $entity->getId()));
            $method = 'PUT';
        }

        return $this->createForm(
            CertificateType::class,
            $entity,
            array(
                'action' => $action,
                'method' => $method,
            )
        );
    }
}
