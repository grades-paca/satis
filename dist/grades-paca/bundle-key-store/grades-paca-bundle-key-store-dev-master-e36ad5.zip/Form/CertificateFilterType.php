<?php

namespace Oru\Bundle\KeyStoreBundle\Form;

use Oru\Bundle\FormBundle\Form\Type\OuiNonType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class CertificateFilterType.
 *
 * @author Michaël VEROUX
 */
class CertificateFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', TextType::class, array('required' => false, 'label' => 'Certificate.name',
                                        'translation_domain' => 'OruKeyStoreBundle',
            ))
            ->add('fingerPrint', TextType::class, array('required' => false, 'label' => 'Certificate.fingerPrint',
                                        'translation_domain' => 'OruKeyStoreBundle',
            ))
            ->add('deleted', ChoiceType::class, array('choices_as_values' => true, 'choices' => OuiNonType::CHOICES, 'empty_data' => 0,
                                             'required' => false, 'label' => 'entity.deleted',
            ))
            ->add('filter', SubmitType::class, array('label' => 'listing.action.filter', 'translation_domain' => 'messages',
                                            'attr' => array('class' => 'btn btn-primary'),
            ))
            ->add('reset', SubmitType::class, array('label' => 'listing.action.reset', 'translation_domain' => 'messages',
                                           'attr' => array('class' => 'btn btn-default'),
            ));
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
                                   'data_class' => 'Oru\Bundle\KeyStoreBundle\Filter\CertificateFilter',
                                   'csrf_protection' => false,
                               ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_keystore_certificate_filter';
    }
}
