Bundle OruKeyStoreBundle
========================

Description
-----------

Ce bundle permet de stocker des certificats clients et d'authentifier les utilisateurs à l'aide de ces certificats.

Configuration
-------------

Pour que le mécanisme d'authentification par ce mécanisme fonctionne, il faut ajouter dans le security.yml de l'application la configuration suivante :

```yml
        wsse_secure:
            pattern:    ^/path/to/secure/by/certificate
            stateless:  true
            wsse:       true
```

Il faut également paramétrer le serveur de façon à ce qu'il fournisse à PHP le certificat client que le client lui a présenté dans l'une des variables SERVER suivantes :

```
SSL_CLIENT_CERT
REDIRECT_SSL_CLIENT_CERT
HTTP_X_SSL_CERT
REDIRECT_HTTP_X_SSL_CERT
```

Pour que le client puisse être authentifié, il faut ajouter son certificat dans le magasin en se rendant à l'adresse /keystore par exemple (URI configurée dans le ROR à titre d'exemple).

Si l'on veut limiter la route à ce mode d'authentification, il suffit d'ajouter dans le firewall de security.yml :

```yml
        - { path: ^/path/to/secure/by/certificate, role: ROLE_WSSE }
```
