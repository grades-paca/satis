<?php

namespace Oru\Bundle\KeyStoreBundle\Entity;

use Doctrine\ORM\EntityRepository;
use Oru\Bundle\KeyStoreBundle\Filter\CertificateFilter;

/**
 * Class CertificateRepository.
 *
 * @author Michaël VEROUX
 */
class CertificateRepository extends EntityRepository
{
    /**
     * @param CertificateFilter $certificateFilter
     *
     * @return \Doctrine\ORM\QueryBuilder
     *
     * @author Michaël VEROUX
     */
    public function findList(CertificateFilter $certificateFilter)
    {
        $builder = $this->createQueryBuilder('c');

        if ($certificateFilter->getName()) {
            $builder->andWhere('c.name LIKE :name')
                ->setParameter('name', sprintf('%%%s%%', $certificateFilter->getName()));
        }

        if ($certificateFilter->getFingerPrint()) {
            $builder->andWhere('c.fingerPrint LIKE :finger');
            $builder->setParameter('finger', $certificateFilter->getFingerPrint());
        }

        if ($certificateFilter->getDeleted()) {
            $builder->andWhere('c.deleted IS NOT NULL');
        }

        return $builder;
    }
}
