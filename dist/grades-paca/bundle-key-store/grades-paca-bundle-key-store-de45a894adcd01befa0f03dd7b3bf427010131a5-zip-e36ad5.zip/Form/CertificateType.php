<?php

namespace Oru\Bundle\KeyStoreBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class CertificateType.
 *
 * @author Michaël VEROUX
 */
class CertificateType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', null, array(
                            'label' => 'Certificate.name',
                        )
            )
            ->add('certFile', FileType::class, array(
                                'label' => 'Certificate.raw',
                            )
            );
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
                                   'data_class' => 'Oru\Bundle\KeyStoreBundle\Entity\Certificate',
                                   'translation_domain' => 'OruKeyStoreBundle',
                               ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_certificate_form';
    }
}
