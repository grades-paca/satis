<?php

namespace Oru\Bundle\KeyStoreBundle\Entity;

use Oru\Bundle\KeyStoreBundle\Tool\CertificateTool;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * Class Certificate.
 *
 *
 * @author Michaël VEROUX
 */
class Certificate
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var string
     */
    protected $name;

    /**
     * @var string
     */
    protected $raw;

    /**
     * @var string
     */
    protected $fingerPrint;
    /**
     * @var \DateTime
     */
    protected $created;
    /**
     * @var \DateTime
     */
    protected $updated;
    /**
     * @var \DateTime
     */
    protected $deleted;
    /**
     * @var UploadedFile|null
     */
    private $certFile;

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     *
     * @return $this
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * @return null|UploadedFile
     *
     * @author Michaël VEROUX
     */
    public function getCertFile()
    {
        return $this->certFile;
    }

    /**
     * @param UploadedFile $file
     *
     * @author Michaël VEROUX
     */
    public function setCertFile(UploadedFile $file)
    {
        $this->certFile = $file;

        if ($file->isValid()) {
            $content = file_get_contents(sprintf('%s/%s',
                                                 $file->getPath(),
                                                 $file->getFilename()
                                         )
            );

            $this->setRaw($content);
        }
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getFingerPrintHumanReadable()
    {
        return trim(chunk_split(strtoupper($this->getFingerPrint()), 2, ' '));
    }

    /**
     * @return string
     */
    public function getFingerPrint()
    {
        return $this->fingerPrint;
    }

    /**
     * @param string $fingerPrint
     *
     * @return $this
     */
    public function setFingerPrint($fingerPrint)
    {
        $this->fingerPrint = $fingerPrint;

        return $this;
    }

    /**
     * @return string
     */
    public function getRaw()
    {
        return $this->raw;
    }

    /**
     * @param string $raw
     *
     * @return $this
     */
    public function setRaw($raw)
    {
        $this->raw = $raw;

        $fingerPrint = CertificateTool::calcFingerPrint($raw);

        $this->setFingerPrint($fingerPrint);

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param \DateTime $created
     *
     * @return $this
     */
    public function setCreated($created)
    {
        $this->created = $created;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getDeleted()
    {
        return $this->deleted;
    }

    /**
     * @param \DateTime $deleted
     *
     * @return $this
     */
    public function setDeleted($deleted)
    {
        $this->deleted = $deleted;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * @param \DateTime $updated
     *
     * @return $this
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;

        return $this;
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function __toString()
    {
        $str = 'Certificat';

        if ($this->getId()) {
            $str .= ' #'.$this->getId();
        }

        return $str;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }
}
