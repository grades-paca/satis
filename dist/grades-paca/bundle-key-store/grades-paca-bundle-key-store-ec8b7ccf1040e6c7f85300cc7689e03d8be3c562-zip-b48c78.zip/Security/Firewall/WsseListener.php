<?php

namespace Oru\Bundle\KeyStoreBundle\Security\Firewall;

use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Oru\Bundle\KeyStoreBundle\Security\Authentication\WsseUserToken;
use Oru\Bundle\KeyStoreBundle\Tool\CertificateTool;
use Symfony\Component\HttpFoundation\ServerBag;
use Symfony\Component\HttpKernel\Event\GetResponseEvent;
use Symfony\Component\Security\Core\Authentication\AuthenticationManagerInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Security\Http\Firewall\ListenerInterface;
use Symfony\Component\HttpFoundation\Response;

/**
 * Class WsseListener.
 *
 * @author Michaël VEROUX
 */
class WsseListener implements ListenerInterface
{
    const RESOLVABLE_CLIENT = array(
        'SSL_CLIENT_CERT',
        'REDIRECT_SSL_CLIENT_CERT',
        'HTTP_X_SSL_CERT',
        'REDIRECT_HTTP_X_SSL_CERT',
    );

    /**
     * @var TokenStorageInterface
     */
    protected $tokenStorage;

    /**
     * @var AuthenticationManagerInterface
     */
    protected $authenticationManager;

    /**
     * @var CertificateTool
     */
    protected $certificateTool;

    /**
     * WsseListener constructor.
     *
     * @param TokenStorageInterface          $tokenStorage
     * @param AuthenticationManagerInterface $authenticationManager
     * @param CertificateTool                $certificateTool
     */
    public function __construct(TokenStorageInterface $tokenStorage, AuthenticationManagerInterface $authenticationManager, CertificateTool $certificateTool)
    {
        $this->tokenStorage = $tokenStorage;
        $this->authenticationManager = $authenticationManager;
        $this->certificateTool = $certificateTool;
    }

    /**
     * @param GetResponseEvent $event
     *
     * @author Michaël VEROUX
     */
    public function handle(GetResponseEvent $event)
    {
        $request = $event->getRequest();
        $server = $request->server;
        $certClient = $this->getCertClient($server);

        try {
            if (!$certClient) {
                throw new AuthenticationException();
            }

            $fingerPrint = $this->certificateTool->getFingerPrint($certClient);

            $token = new WsseUserToken();
            $token->setUser($fingerPrint);

            $authToken = $this->authenticationManager->authenticate($token);
            $this->tokenStorage->setToken($authToken);
            
            return;
        } catch (AuthenticationException $e) {

        }

        $response = new Response();
        $response->setStatusCode(Response::HTTP_FORBIDDEN);
        $event->setResponse($response);
    }

    /**
     * @param ServerBag $server
     *
     * @return string|null
     *
     * @author Michaël VEROUX
     */
    private function getCertClient(ServerBag $server)
    {
        $resolvable = self::RESOLVABLE_CLIENT;
        foreach ($resolvable as $item) {
            if ($server->has($item)) {
                return $server->get($item);
            }
        }

        return null;
    }
}
