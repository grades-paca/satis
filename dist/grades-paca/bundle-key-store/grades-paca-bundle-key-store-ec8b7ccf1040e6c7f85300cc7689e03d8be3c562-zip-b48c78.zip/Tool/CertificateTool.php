<?php

namespace Oru\Bundle\KeyStoreBundle\Tool;

/**
 * Class CertificateTool.
 *
 * @author Michaël VEROUX
 */
class CertificateTool
{
    /**
     * @param string $rawCert
     *
     * @return string
     *
     * @author Michaël VEROUX
     */
    public static function calcFingerPrint($rawCert)
    {
        $content = trim(
            str_replace(
                array('-----BEGIN CERTIFICATE-----', '-----END CERTIFICATE-----', "\n"),
                array('', '', ''),
                $rawCert
            )
        );

        $fingerPrint = hash('sha1', base64_decode($content));

        return $fingerPrint;
    }

    /**
     * @param string $rawCert
     *
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getFingerPrint($rawCert)
    {
        return self::calcFingerPrint($rawCert);
    }
}
