<?php

namespace Oru\Bundle\KeyStoreBundle\Security\Authentication;

use Symfony\Component\Security\Core\Authentication\Token\AbstractToken;

/**
 * Class WsseUserToken.
 *
 * @author Michaël VEROUX
 */
class WsseUserToken extends AbstractToken
{
    const USERNAME_PREFIX = 'certificat:';

    /**
     * @var array
     */
    protected $credentials;

    /**
     * Returns the user credentials.
     *
     * @return mixed The user credentials
     */
    public function getCredentials()
    {
        return $this->credentials;
    }
}
