<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Manager;


use Doctrine\ORM\EntityManager;
use Oru\Bundle\LogBundle\Entity\LogNew;
use Oru\Bundle\LogBundle\Entity\LogProfiler;
use Oru\Bundle\LogBundle\Entity\LogRequest;
use Oru\Bundle\LogBundle\Entity\LogSession;
use Oru\Bundle\LogBundle\Entity\LogTmp;
use Oru\Bundle\LogBundle\Entity\LogUrl;
use Oru\Bundle\LogBundle\Entity\LogUserAgent;

class ProcessManager
{
    /**
     * @var EntityManager
     */
    private $em;

    /**
     * @var int
     */
    private $limit;

    /**
     * ProcessManager constructor.
     */
    public function __construct(EntityManager $em)
    {
        $this->em = $em;
        $this->limit = 100;
    }

    /**
     * @return int
     */
    public function nbLogs()
    {
        return $this->em->getRepository('OruLogBundle:LogTmp')->count();
    }

    /**
     * Traitement et purge de tous les logs
     */
    public function processAll()
    {
        while ( $this->nbLogs() ) {
            $this->process($this->limit);
        }
    }

    /**
     * Traitement et purge des logs de oru_log_tmp selon limit et offset
     *
     * @param int $limit
     * @param int $offset
     */
    public function process($limit = 100)
    {
        $logs = $this->em->getRepository('OruLogBundle:LogTmp')->findBy(array(), null, $limit);
        foreach($logs as $log) {
            /** @var $log LogTmp */
            $url = $this->em->getRepository('OruLogBundle:LogUrl')->findOneByUrl($log->getUrl());
            if(!$url) {
                $url = new LogUrl();
                $url->setUrl($log->getUrl());
                $this->em->persist($url);
                $this->em->flush($url);
            }

            $newLog = new LogNew();
            $newLog->setUrl($url);
            $newLog->setUsername($log->getUsername());
            $newLog->setCreated($log->getCreated());
            $newLog->setAjax($log->getAjax());

            if($log->getSession()) {
                $session = $this->em->getRepository('OruLogBundle:LogSession')->findOneBySession($log->getSession());
                if(!$session) {
                    $session = new LogSession();
                    $session->setSession($log->getSession());
                    $this->em->persist($session);
                    $this->em->flush($session);
                }
                $newLog->setSession($session);
            }

            $agent = $this->em->getRepository('OruLogBundle:LogUserAgent')->findOneByAgent($log->getAgent());
            if (!$agent) {
                $agent = new LogUserAgent();
                $agent->setAgent($log->getAgent());
                $this->em->persist($agent);
                $this->em->flush($agent);
            }
            $newLog->setUserAgent($agent);

            $logRequest = new LogRequest();
            $logRequest->setHttps($log->getHttps());
            $logRequest->setHttpMethod($log->getHttpMethod());
            $logRequest->setRemoteAddr($log->getRemoteAddr());

            $logProfiler = new LogProfiler();
            $logProfiler->setMemory($log->getMemory());
            $logProfiler->setQueries($log->getQueries());
            $logProfiler->setTime($log->getTime());

            $newLog->setRequest($logRequest);
            $newLog->setProfiler($logProfiler);
            $this->em->persist($newLog);
            $this->em->remove($log);
        }
        $this->em->flush();
        $this->em->clear();
    }

}