Bundle OruLogBundle
===================

Description
-----------

Ce bundle loggue les informations suivantes pour toutes les requêtes :
- username : identifiant de l'utilisateur connecté sinon "anon."
- created : date de création
- ajax : requête ajax
- time : durée
- memory : mémoire utilisée
- queries : nombre de requêtes
- https : requête sécurisée
- httpMethod : méthode HTTP
- remoteAddr : adresse du l'utilisateur
- url : adresse interrogée
- agent : navigateur utilisé par l'utilisateur 
- session : identifiant de la session

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/log":dev-master
```

Dans le AppKernel.php, activer ce bundle

```
$bundles[] = new Oru\Bundle\LogBundle\OruLogBundle();
```

Dans le routing.yml, ajouter cette route :

```
oru_log:
    resource: "@OruLogBundle/Resources/config/routing/log.yml"
    prefix:   /log
```

Dans le config.yml, ajouter ceci à la section imports :

```
imports:
...
    - { resource: @OruLogBundle/Resources/config/config.yml }
```

Vider le cache de Symfony2.
Configurer les droits et pages.

### Liste des pages 

[Pages](./oru_log_bundle/revisions/master/entry/Resources/config/pages.xml)

### Liste des droits 

[Droits](./oru_log_bundle/revisions/master/entry/Resources/config/credentials.yml)

### Liste des paramètres

Un seul paramètre purgePeriod permettant de définir la période de conservation de logs. 

[Paramètres](./oru_log_bundle/revisions/master/entry/Resources/settings/OruLogBundle.generic.orm)

Utilisation
-----------

Rien à faire par défaut. Une interface simpliste de consultation des logs est disponible à l'adresse /log.