<?php

namespace Oru\Bundle\LogBundle\Form;

use Oru\Bundle\FormBundle\Form\Type\OuiNonType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class LogNewFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('username', SearchType::class, array('required' => false, 'label' => 'LogNew.username', 'translation_domain' => 'OruLogBundle'))
            ->add('searchUrl', SearchType::class, array('required' => false, 'label' => 'LogNew.url', 'translation_domain' => 'OruLogBundle'))
            ->add('exactUrl', OuiNonType::class, array('required' => false, 'label' => 'LogNew.exactUrl', 'translation_domain' => 'OruLogBundle', 'expanded' => false))
            ->add('createdAfter', DateTimeType::class, array('required' => false, 'label' => 'LogNew.createdAfter', 'translation_domain' => 'OruLogBundle', 'date_widget' => 'single_text', 'time_widget' => 'single_text'))
            ->add('createdBefore', DateTimeType::class, array('required' => false, 'label' => 'LogNew.createdBefore', 'translation_domain' => 'OruLogBundle', 'date_widget' => 'single_text', 'time_widget' => 'single_text'))
            ->add('sessionId', SearchType::class, array('required' => false, 'label' => 'LogNew.session', 'translation_domain' => 'OruLogBundle'))
            ->add('ajax', OuiNonType::class, array('required' => false, 'label' => 'LogNew.ajax', 'translation_domain' => 'OruLogBundle', 'expanded' => false))
            ->add('filter', SubmitType::class, array('label' => 'listing.action.filter', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-primary')))
            ->add('reset', SubmitType::class, array('label' => 'listing.action.reset', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-default')))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\LogBundle\Filter\LogNewFilter',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_logbundle_lognewfilter';
    }
}
