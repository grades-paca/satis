<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 12/12/13
 * Time: 16:47
 */

namespace Oru\Bundle\LogBundle\Storage;

use Doctrine\ORM\EntityManager;
use Monolog\Formatter\FormatterInterface;
use Monolog\Handler\AbstractProcessingHandler;
use Monolog\Logger;
use Oru\Bundle\LogBundle\Entity\Log;

class LogStorage extends AbstractProcessingHandler
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    protected $entityManager = null;

    /**
     * @param \Doctrine\ORM\EntityManager $entityManager
     */
    public function setEntityManager(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    protected function write(array $record)
    {
        if (!isset($record['extra']['url'])) {
            return $record;
        }

        $log = new Log();
        $log->setBrowser($record['extra']['browser']);
        $log->setCreatedAt(new \Datetime());
        $log->setHttpMethod((isset($record['extra']['http_method'])) ? $record['extra']['http_method'] : '');
        $log->setHttps($record['extra']['https']);
        $log->setMemory(memory_get_peak_usage());
        $log->setMessage($record['message']);
        $log->setPlatform($record['extra']['platform']);
        $log->setQueries($record['extra']['queries']);
        $log->setReferrer((isset($record['extra']['referrer'])) ? $record['extra']['referrer'] : '');
        $log->setRemoteAddr($record['extra']['remote_addr']);
        $log->setServer((isset($record['extra']['server'])) ? $record['extra']['server'] : '');
        $log->setSession($record['extra']['session_id']);
        $log->setTime($record['extra']['duration']);
        $log->setUrl((isset($record['extra']['url'])) ? $record['extra']['url'] : '');
        $log->setUsername($record['extra']['username']);
        $log->setVersion($record['extra']['browser_version']);
        $log->setAjax($record['extra']['ajax']);
        $log->setMaster(($record['level'] == 200) ? 1 : 0);

        if (!$this->entityManager->isOpen()) {
            $this->entityManager = $this->entityManager->create(
                $this->entityManager->getConnection(),
                $this->entityManager->getConfiguration()
            );
        }
        $this->entityManager->clear();
        $this->entityManager->persist($log);
        $this->entityManager->flush($log);

    }

}