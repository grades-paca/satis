<?php

namespace Oru\Bundle\LogBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class LogNewListingType extends AbstractListingType
{
    /**
     * @param ListingBuilderInterface $builder
     * @param array $options
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('username', null, array('label' => 'listing.username', 'translation_domain' => 'OruLogBundle'))
            ->add('searchUrl', null, array('label' => 'listing.url', 'translation_domain' => 'OruLogBundle', 'template' => 'OruLogBundle:Log:listing.url.html.twig'))
            ->add('created', null, array('label' => 'listing.created', 'translation_domain' => 'OruLogBundle'))
            ->add('ajax', 'checkbox', array('label' => 'listing.ajax', 'translation_domain' => 'OruLogBundle'))
            ->add('show', 'object_action', array('route' => 'log_show', 'label' => 'listing.action.show'))
            ->add('follow', 'object_action', array('route' => 'log_follow_session', 'label' => 'listing.action.follow_session', 'translation_domain' => 'OruLogBundle'))
            ->add('error', 'object_action', array('route' => 'log_error_session', 'label' => 'listing.action.error_session', 'translation_domain' => 'OruLogBundle'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\LogBundle\Entity\LogNew'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_logbundle_lognewlisting';
    }
}
