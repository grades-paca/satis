<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Entity;


class LogUrl
{

    /**
     * @var string
     */
    private $url;

    /**
     * @var integer
     */
    private $id;

    /**
     * @var \Oru\Bundle\LogBundle\Entity\LogNew
     */
    private $log;

    /**
     * @var string
     */
    private $route;

    /**
     * @var array
     */
    private $params;

    /**
     * @return string
     */
    function __toString()
    {
        return $this->url;
    }

    /**
     * Set url
     *
     * @param string $url
     *
     * @return LogUrl
     */
    public function setUrl($url)
    {
        $this->url = $url;

        return $this;
    }

    /**
     * Get url
     *
     * @return string
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set log
     *
     * @param \Oru\Bundle\LogBundle\Entity\LogNew $log
     *
     * @return LogUrl
     */
    public function setLog(\Oru\Bundle\LogBundle\Entity\LogNew $log = null)
    {
        $log->setUrl($this);
        $this->log = $log;

        return $this;
    }

    /**
     * Get log
     *
     * @return \Oru\Bundle\LogBundle\Entity\LogNew
     */
    public function getLog()
    {
        return $this->log;
    }

    /**
     * @return string
     */
    public function getRoute()
    {
        return $this->route;
    }

    /**
     * @param string $route
     */
    public function setRoute($route)
    {
        $this->route = $route;
    }

    /**
     * @return array
     */
    public function getParams()
    {
        return $this->params;
    }

    /**
     * @param array $params
     */
    public function setParams($params)
    {
        $this->params = $params;
    }
}
