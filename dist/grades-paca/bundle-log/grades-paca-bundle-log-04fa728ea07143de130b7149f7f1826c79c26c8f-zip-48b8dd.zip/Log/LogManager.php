<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 26/12/13
 */

namespace Oru\Bundle\LogBundle\Log;

use Symfony\Bridge\Monolog\Logger;

class LogManager
{
    /**
     * @var Logger
     */
    protected $logger;

    /**
     * LogManager constructor.
     * @param Logger $logger
     */
    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
    }

    /**
     * @return \Psr\Log\LoggerInterface
     */
    public function getLogger()
    {
        return $this->logger;
    }
}