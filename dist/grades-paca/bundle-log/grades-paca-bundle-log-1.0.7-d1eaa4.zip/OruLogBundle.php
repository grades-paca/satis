<?php

namespace Oru\Bundle\LogBundle;

use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruLogBundle extends Bundle
{
    /**
     * OruLogBundle constructor.
     */
    public function __construct()
    {
        DynamicLoader::addYaml('@OruLogBundle/Resources/config/routing/log.yml');
    }

    public function boot()
    {
        if(php_sapi_name() != 'cli' && $this->container->hasParameter('sql_counter_enabled') && true == $this->container->getParameter('sql_counter_enabled')) {
            $doctrine = $this->container->get('doctrine');
            $logger = new \Doctrine\DBAL\Logging\DebugStack();
            $logProcessor = $this->container->get('oru_log.log_processor');
            if (null !== $doctrine->getConnection()->getConfiguration()->getSQLLogger()) {
                $doctrine
                    ->getConnection()
                    ->getConfiguration()
                    ->getSQLLogger()
                    ->addLogger($logger);
            } else {
                $doctrine
                    ->getConnection()
                    ->getConfiguration()
                    ->setSQLLogger($logger);
            }
            $logProcessor->setLogger($logger);
        }
    }
}
