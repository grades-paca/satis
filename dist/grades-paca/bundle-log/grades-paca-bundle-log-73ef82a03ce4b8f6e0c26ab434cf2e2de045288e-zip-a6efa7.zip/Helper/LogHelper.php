<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Helper;

use Symfony\Component\HttpFoundation\RequestStack;

class LogHelper
{
    /**
     * @var RequestStack
     */
    protected $requestStack;

    /**
     * LogHelper constructor.
     *
     * @param null $serverData
     */
    public function __construct($serverData = null)
    {
        if (null === $serverData) {
            $this->serverData = &$_SERVER;
        } elseif (is_array($serverData) || $serverData instanceof \ArrayAccess) {
            $this->serverData = $serverData;
        } else {
            throw new \UnexpectedValueException('$serverData must be an array or object implementing ArrayAccess.');
        }
    }

    /**
     * @return array
     */
    public function getBrowser()
    {
        return $this->findBrowser((isset($this->serverData['HTTP_USER_AGENT'])) ? $this->serverData['HTTP_USER_AGENT'] : null);
    }

    /**
     * @return string
     */
    public function getUserAgent()
    {
        return (isset($this->serverData['HTTP_USER_AGENT'])) ? $this->serverData['HTTP_USER_AGENT'] : null;
    }

    /**
     * @return string|null
     */
    public function getRemoteAddr()
    {
        if (isset($this->serverData['HTTP_X_REAL_IP'])) {
            return $this->serverData['HTTP_X_REAL_IP'];
        } elseif (isset($this->serverData['HTTP_X_FORWARDED_FOR'])) {
            $IParray = array_values(array_filter(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])));

            return reset($IParray);
        } elseif (isset($this->serverData['REMOTE_ADDR'])) {
            return $this->serverData['REMOTE_ADDR'];
        }

        return null;
    }

    /**
     * @return bool
     */
    public function getHttps()
    {
        return (isset($this->serverData['HTTPS'])) ? $this->serverData['HTTPS'] : 0;
    }

    /**
     * @return bool
     */
    public function getAjax()
    {
        return (!empty($this->serverData['HTTP_X_REQUESTED_WITH']) && strtolower($this->serverData['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ? true : false;
    }

    /**
     * Traiter les urls pour retirer les préfixes.
     *
     * @param $url
     *
     * @return string
     */
    public function processUrl($url)
    {
        $url = preg_replace('/^\/oru.debug/', '', $url);
        $url = preg_replace('/^\/app\.php/', '', $url);
        $url = preg_replace('/^\/app_dev\.php/', '', $url);

        return substr($url, 0, 254);
    }

    /**
     * @param string $u_agent
     *
     * @return array
     */
    private function findBrowser($u_agent = '')
    {
        $bname = 'Unknown';
        $platform = 'Unknown';
        $version = '';
        $ub = '';

        //First get the platform?
        if (preg_match('/linux/i', $u_agent)) {
            $platform = 'linux';
        } elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
            $platform = 'mac';
        } elseif (preg_match('/windows|win32/i', $u_agent)) {
            $platform = 'windows';
        }

        // Next get the name of the useragent yes seperately and for good reason
        if (preg_match('/MSIE/i', $u_agent) && !preg_match('/Opera/i', $u_agent)) {
            $bname = 'Internet Explorer';
            $ub = 'MSIE';
        } elseif (preg_match('/Firefox/i', $u_agent)) {
            $bname = 'Mozilla Firefox';
            $ub = 'Firefox';
        } elseif (preg_match('/Chrome/i', $u_agent)) {
            $bname = 'Google Chrome';
            $ub = 'Chrome';
        } elseif (preg_match('/Safari/i', $u_agent)) {
            $bname = 'Apple Safari';
            $ub = 'Safari';
        } elseif (preg_match('/Opera/i', $u_agent)) {
            $bname = 'Opera';
            $ub = 'Opera';
        } elseif (preg_match('/Netscape/i', $u_agent)) {
            $bname = 'Netscape';
            $ub = 'Netscape';
        }

        // finally get the correct version number
        $known = array('Version', $ub, 'other');
        $pattern = '#(?<browser>'.implode('|', $known).
            ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
        if (!preg_match_all($pattern, $u_agent, $matches)) {
            // we have no matching number just continue
        }

        // see how many we have
        $i = count($matches['browser']);
        if ($i !== 1) {
            //we will have two since we are not using 'other' argument yet
            //see if version is before or after the name
            if (strripos($u_agent, 'Version') < strripos($u_agent, $ub)) {
                $version = $matches['version'][0];
            } elseif (isset($matches['version'][1])) {
                $version = $matches['version'][1];
            }
        } else {
            $version = $matches['version'][0];
        }

        // check if we have a number
        if ($version === null || $version === '') {
            $version = '?';
        }

        return array(
            'userAgent' => $u_agent,
            'name' => $bname,
            'version' => $version,
            'platform' => $platform,
            'pattern' => $pattern,
        );
    }
}
