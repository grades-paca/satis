<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Entity;

class LogProfiler
{
    /**
     * @var string
     */
    private $time;

    /**
     * @var int
     */
    private $memory;

    /**
     * @var int
     */
    private $queries;

    /**
     * @var int
     */
    private $id;

    /**
     * @var \Oru\Bundle\LogBundle\Entity\LogNew
     */
    private $log;

    /**
     * Set time.
     *
     * @param string $time
     *
     * @return LogProfiler
     */
    public function setTime($time)
    {
        $this->time = $time;

        return $this;
    }

    /**
     * Get time.
     *
     * @return string
     */
    public function getTime()
    {
        return $this->time;
    }

    /**
     * Set memory.
     *
     * @param int $memory
     *
     * @return LogProfiler
     */
    public function setMemory($memory)
    {
        $this->memory = $memory;

        return $this;
    }

    /**
     * Get memory.
     *
     * @return int
     */
    public function getMemory()
    {
        return $this->memory;
    }

    /**
     * Set queries.
     *
     * @param int $queries
     *
     * @return LogProfiler
     */
    public function setQueries($queries)
    {
        $this->queries = $queries;

        return $this;
    }

    /**
     * Get queries.
     *
     * @return int
     */
    public function getQueries()
    {
        return $this->queries;
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set log.
     *
     * @param \Oru\Bundle\LogBundle\Entity\LogNew $log
     *
     * @return LogProfiler
     */
    public function setLog(\Oru\Bundle\LogBundle\Entity\LogNew $log = null)
    {
        $this->log = $log;

        return $this;
    }

    /**
     * Get log.
     *
     * @return \Oru\Bundle\LogBundle\Entity\LogNew
     */
    public function getLog()
    {
        return $this->log;
    }
}
