<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Entity;

class LogTmp
{
    /**
     * @var string
     */
    private $username;

    /**
     * @var \DateTime
     */
    private $created;

    /**
     * @var bool
     */
    private $ajax;

    /**
     * @var string
     */
    private $time;

    /**
     * @var int
     */
    private $memory;

    /**
     * @var int
     */
    private $queries;

    /**
     * @var bool
     */
    private $https;

    /**
     * @var string
     */
    private $httpMethod;

    /**
     * @var string
     */
    private $remoteAddr;

    /**
     * @var string
     */
    private $url;

    /**
     * @var string
     */
    private $agent;

    /**
     * @var string
     */
    private $session;

    /**
     * @var int
     */
    private $id;

    /**
     * Set username.
     *
     * @param string $username
     *
     * @return LogTmp
     */
    public function setUsername($username)
    {
        $this->username = $username;

        return $this;
    }

    /**
     * Get username.
     *
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Set created.
     *
     * @param \DateTime $created
     *
     * @return LogTmp
     */
    public function setCreated($created)
    {
        $this->created = $created;

        return $this;
    }

    /**
     * Get created.
     *
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Set ajax.
     *
     * @param bool $ajax
     *
     * @return LogTmp
     */
    public function setAjax($ajax)
    {
        $this->ajax = $ajax;

        return $this;
    }

    /**
     * Get ajax.
     *
     * @return bool
     */
    public function getAjax()
    {
        return $this->ajax;
    }

    /**
     * Set time.
     *
     * @param string $time
     *
     * @return LogTmp
     */
    public function setTime($time)
    {
        $this->time = $time;

        return $this;
    }

    /**
     * Get time.
     *
     * @return string
     */
    public function getTime()
    {
        return $this->time;
    }

    /**
     * Set memory.
     *
     * @param int $memory
     *
     * @return LogTmp
     */
    public function setMemory($memory)
    {
        $this->memory = $memory;

        return $this;
    }

    /**
     * Get memory.
     *
     * @return int
     */
    public function getMemory()
    {
        return $this->memory;
    }

    /**
     * Set queries.
     *
     * @param int $queries
     *
     * @return LogTmp
     */
    public function setQueries($queries)
    {
        $this->queries = $queries;

        return $this;
    }

    /**
     * Get queries.
     *
     * @return int
     */
    public function getQueries()
    {
        return $this->queries;
    }

    /**
     * Set https.
     *
     * @param bool $https
     *
     * @return LogTmp
     */
    public function setHttps($https)
    {
        $this->https = $https;

        return $this;
    }

    /**
     * Get https.
     *
     * @return bool
     */
    public function getHttps()
    {
        return $this->https;
    }

    /**
     * Set httpMethod.
     *
     * @param string $httpMethod
     *
     * @return LogTmp
     */
    public function setHttpMethod($httpMethod)
    {
        $this->httpMethod = $httpMethod;

        return $this;
    }

    /**
     * Get httpMethod.
     *
     * @return string
     */
    public function getHttpMethod()
    {
        return $this->httpMethod;
    }

    /**
     * Set remoteAddr.
     *
     * @param string $remoteAddr
     *
     * @return LogTmp
     */
    public function setRemoteAddr($remoteAddr)
    {
        $this->remoteAddr = $remoteAddr;

        return $this;
    }

    /**
     * Get remoteAddr.
     *
     * @return string
     */
    public function getRemoteAddr()
    {
        return $this->remoteAddr;
    }

    /**
     * Set url.
     *
     * @param string $url
     *
     * @return LogTmp
     */
    public function setUrl($url)
    {
        $this->url = $url;

        return $this;
    }

    /**
     * Get url.
     *
     * @return string
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * Set agent.
     *
     * @param string $agent
     *
     * @return LogTmp
     */
    public function setAgent($agent)
    {
        $this->agent = $agent;

        return $this;
    }

    /**
     * Get agent.
     *
     * @return string
     */
    public function getAgent()
    {
        return $this->agent;
    }

    /**
     * Set session.
     *
     * @param string $session
     *
     * @return LogTmp
     */
    public function setSession($session)
    {
        $this->session = $session;

        return $this;
    }

    /**
     * Get session.
     *
     * @return string
     */
    public function getSession()
    {
        return $this->session;
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }
}
