<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Entity;

class LogSession
{
    /**
     * @var string
     */
    private $session;

    /**
     * @var int
     */
    private $id;

    /**
     * @var \Doctrine\Common\Collections\Collection
     */
    private $log;

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->log = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->session;
    }

    /**
     * Set session.
     *
     * @param string $session
     *
     * @return LogSession
     */
    public function setSession($session)
    {
        $this->session = $session;

        return $this;
    }

    /**
     * Get session.
     *
     * @return string
     */
    public function getSession()
    {
        return $this->session;
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Add log.
     *
     * @param \Oru\Bundle\LogBundle\Entity\LogNew $log
     *
     * @return LogSession
     */
    public function addLog(\Oru\Bundle\LogBundle\Entity\LogNew $log)
    {
        $this->log[] = $log;

        return $this;
    }

    /**
     * Remove log.
     *
     * @param \Oru\Bundle\LogBundle\Entity\LogNew $log
     */
    public function removeLog(\Oru\Bundle\LogBundle\Entity\LogNew $log)
    {
        $this->log->removeElement($log);
    }

    /**
     * Get log.
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLog()
    {
        return $this->log;
    }
}
