<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 26/12/13
 */

namespace Oru\Bundle\LogBundle\Log;

use Psr\Log\LoggerInterface;

class LogManager
{
    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * LogManager constructor.
     *
     * @param LoggerInterface $logger
     */
    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    /**
     * @return LoggerInterface
     */
    public function getLogger()
    {
        return $this->logger;
    }
}
