<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Command;

use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class ProcessCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    public function configure()
    {
        $this
            ->setName('oru:log:process')
            ->setDescription('Traitement et purge des logs de la table oru_log_tmp')
        ;
    }

    public function getMaxRunningTimeSec()
    {
        return 300;
    }

    public function isConcurentAllowed()
    {
        return false;
    }

    public function getTypeFieldFromArgumentName($name, &$type = TextType::class, &$options = array())
    {
        // TODO: Implement getTypeFieldFromArgumentName() method.
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        // Process LOG TMP
        $manager = $this->getContainer()->get('oru_log.process_manager');
        $nbLogs = $manager->nbLogs();
        $limit = 100;

        if (!$nbLogs) {
            return $output->writeln('Aucun log à traiter.');
        }

        $progress = new ProgressBar($output, $nbLogs);
        $progress->start();
        while ($manager->nbLogs()) {
            $manager->process($limit);
            $progress->advance($limit);
        }
        $progress->finish();
        $output->writeln('');
    }
}
