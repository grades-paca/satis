<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Command;

use Oru\Bundle\LogBundle\Entity\LogNew;
use Oru\Bundle\LogBundle\Entity\LogProfiler;
use Oru\Bundle\LogBundle\Entity\LogRequest;
use Oru\Bundle\LogBundle\Entity\LogSession;
use Oru\Bundle\LogBundle\Entity\LogUrl;
use Oru\Bundle\LogBundle\Entity\LogUserAgent;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class MigrateCommand extends ContainerAwareCommand
{
    public function configure()
    {
        $this
            ->setName('oru:log:migrate')
            ->setDescription('Migration des données de la table oru_log vers les nouvelles tables')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $em = $this->getContainer()->get('doctrine.orm.default_entity_manager');
        $con = $em->getConnection();
        $nbLogs = $con->query('SELECT count(*) as nb FROM oru_log')->fetch();
        $nbLogs = (int) ($nbLogs['nb']);
        $limit = 100;
        $offset = 0;

        $progress = new ProgressBar($output, $nbLogs);
        $progress->start();
        while ($offset < $nbLogs) {
            $logs = $con->query("SELECT * FROM oru_log LIMIT $limit");
            while ($log = $logs->fetch()) {
                $log['url'] = preg_replace('/^\/oru.debug/', '', $log['url']);
                $url = $em->getRepository('OruLogBundle:LogUrl')->findOneByUrl($log['url']);
                if (!$url) {
                    $url = new LogUrl();
                    $url->setUrl($log['url']);
                    $em->persist($url);
                    $em->flush($url);
                }

                $newLog = new LogNew();
                $newLog->setUrl($url);
                $newLog->setUsername($log['username']);
                $newLog->setCreated(new \DateTime($log['created_at']));
                $newLog->setAjax(($log['ajax']) ? true : false);

                if ($log['session']) {
                    $session = $em->getRepository('OruLogBundle:LogSession')->findOneBySession($log['session']);
                    if (!$session) {
                        $session = new LogSession();
                        $session->setSession($log['session']);
                        $em->persist($session);
                        $em->flush($session);
                    }
                    $newLog->setSession($session);
                }

                $userAgent = $log['platform'].' '.$log['browser'].' '.$log['version'];
                $agent = $em->getRepository('OruLogBundle:LogUserAgent')->findOneByAgent($userAgent);
                if (!$agent) {
                    $agent = new LogUserAgent();
                    $agent->setAgent($userAgent);
                    $em->persist($agent);
                    $em->flush($agent);
                }
                $newLog->setUserAgent($agent);

                $logRequest = new LogRequest();
                $logRequest->setHttps($log['https']);
                $logRequest->setHttpMethod($log['http_method']);
                $logRequest->setRemoteAddr($log['remote_addr']);

                $logProfiler = new LogProfiler();
                $logProfiler->setMemory($log['memory']);
                $logProfiler->setQueries($log['queries']);
                $logProfiler->setTime($log['time']);

                $newLog->setRequest($logRequest);
                $newLog->setProfiler($logProfiler);
                $em->persist($newLog);
            }
            $em->flush();
            $em->clear();
            $logs = $con->query("DELETE FROM oru_log LIMIT $limit");

            $offset += $limit;
            $progress->advance($limit);
        }
        $progress->finish();
        $output->writeln('');
    }
}
