<?php

namespace Oru\Bundle\LogBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruLogBundle extends Bundle
{
    public function boot()
    {
        $collection = $this
            ->container
            ->get('routing.loader')
            ->load(__DIR__.'/Resources/config/routing/log.yml')
        ;

        $this
            ->container
            ->get('router')
            ->getRouteCollection()
            ->addCollection($collection)
        ;
    }
}
