<?php

namespace Oru\Bundle\LogBundle\Filter;

use Oru\Bundle\LogBundle\Entity\LogNew;


class LogNewFilter extends LogNew
{
    /**
     * @var \DateTime
     */
    private $createdAfter;

    /**
     * @var \DateTime
     */
    private $createdBefore;

    /**
     * @var string
     */
    private $sessionId;

    /**
     * @var string
     */
    private $searchUrl;

    /**
     * @var boolean
     */
    private $exactUrl;

    /**
     * @return \DateTime
     */
    public function getCreatedAfter()
    {
        return $this->createdAfter;
    }

    /**
     * @param \DateTime $createdAfter
     */
    public function setCreatedAfter($createdAfter)
    {
        $this->createdAfter = $createdAfter;
    }

    /**
     * @return \DateTime
     */
    public function getCreatedBefore()
    {
        return $this->createdBefore;
    }

    /**
     * @param \DateTime $createdBefore
     */
    public function setCreatedBefore($createdBefore)
    {
        $this->createdBefore = $createdBefore;
    }

    /**
     * @return string
     */
    public function getSessionId()
    {
        return $this->sessionId;
    }

    /**
     * @param string $sessionId
     */
    public function setSessionId($sessionId)
    {
        $this->sessionId = $sessionId;
    }

    /**
     * @return string
     */
    public function getSearchUrl()
    {
        return $this->searchUrl;
    }

    /**
     * @param string $searchUrl
     */
    public function setSearchUrl($searchUrl)
    {
        $this->searchUrl = $searchUrl;
    }

    /**
     * @return boolean
     */
    public function getExactUrl()
    {
        return $this->exactUrl;
    }

    /**
     * @param boolean $exactUrl
     */
    public function setExactUrl($exactUrl)
    {
        $this->exactUrl = $exactUrl;
    }
}