<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 12/12/13
 * Time: 11:35
 */

namespace Oru\Bundle\LogBundle\EventListener;

use Oru\Bundle\LogBundle\Log\LogManager;
use Symfony\Component\HttpKernel\Event\PostResponseEvent;
use Symfony\Component\HttpKernel\EventListener\ExceptionListener as BaseExceptionListener;
use Symfony\Component\HttpKernel\KernelEvents;

class LogListener extends BaseExceptionListener
{
    protected $logger;
    protected $container;

    public function __construct(LogManager $logManager)
    {
        $this->logger = $logManager->getLogger();
    }

    public function onKernelTerminate(PostResponseEvent $event)
    {
        $this->logger->debug('End of request');
    }
}