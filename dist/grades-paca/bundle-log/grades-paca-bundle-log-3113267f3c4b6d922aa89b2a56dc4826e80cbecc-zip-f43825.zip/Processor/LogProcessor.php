<?php

namespace Oru\Bundle\LogBundle\Processor;

use Oru\Bundle\LogBundle\Helper\LogHelper;
use Symfony\Component\HttpKernel\KernelInterface;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Component\HttpKernel\Event\PostResponseEvent;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class LogProcessor
{
    /**
     * @var KernelInterface
     */
    protected $kernel;

    protected $session;

    protected $security_context;

    protected $logger;

    private $logHelper;

    public function __construct()
    {
    }

    public function setKernel(KernelInterface $kernel = null)
    {
        $this->kernel = $kernel;
    }

    public function setSession(SessionInterface $session = null)
    {
        $this->session = $session;
    }

    public function setSecurityContext(TokenStorageInterface $security_context = null)
    {
        $this->security_context = $security_context;
    }

    public function setLogger(RegistryInterface $doctrine = null)
    {
        if(php_sapi_name() != 'cli') {
            $this->logger = new \Doctrine\DBAL\Logging\DebugStack();
            if (null !== $doctrine->getConnection()->getConfiguration()->getSQLLogger())
                $doctrine
                    ->getConnection()
                    ->getConfiguration()
                    ->getSQLLogger()
                    ->addLogger($this->logger);
            else
                $doctrine
                    ->getConnection()
                    ->getConfiguration()
                    ->setSQLLogger($this->logger);
        }
    }

    public function setHelper(LogHelper $logHelper) {
        $this->logHelper = $logHelper;
    }

    public function onKernelTerminate(PostResponseEvent $event)
    {
        $this->serverData = $event->getRequest()->server->all();
    }

    /**
     * @param  array $record
     * @return array
     */
    public function __invoke(array $record)
    {
        $browser = $this->logHelper->getBrowser();
        $record['extra'] = array_merge(
            $record['extra'],
            array(
                'duration'          => $this->getDuration(),
                'https'             => (isset($this->serverData['HTTPS']) && $this->serverData['HTTPS'] == 'on') ? true : false,
                'platform'          => $browser['platform'],
                'browser'           => $browser['name'],
                'browser_version'   => $browser['version'],
                'remote_addr'       => (isset($this->serverData['REMOTE_ADDR'])) ? $this->serverData['REMOTE_ADDR'] : "",
                'session_id'        => $this->session->getId(),
                'username'          => ($this->security_context->getToken() !== null) ? $this->security_context->getToken()->getUserName() : '',
                'queries'           => ($this->logger) ? count($this->logger->queries) : null,
                'ajax'              => (!empty($this->serverData['HTTP_X_REQUESTED_WITH']) && strtolower($this->serverData['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') ? true : false
            )
        );

        return $record;
    }


    private function getDuration()
    {
        return microtime(true)*1000 - $this->kernel->getStartTime()*1000;
    }
}
