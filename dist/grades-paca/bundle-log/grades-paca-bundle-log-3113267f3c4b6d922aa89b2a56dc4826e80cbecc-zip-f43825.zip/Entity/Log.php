<?php

namespace Oru\Bundle\LogBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use APY\DataGridBundle\Grid\Mapping as GRID;

/**
 * Log
 *
 * @GRID\Source(columns="id, url, browser, version, time, memory, queries, username, createdAt, ajax")
 *
 */
class Log
{
    /**
     * @var integer
     *
     * @GRID\Column(title="Id", filterable=false, sortable=false)
     */
    private $id;

    /**
     * @var string
     */
    private $server;

    /**
     * @var string
     *
     * @GRID\Column(title="Url", filterable=false, sortable=false)
     */
    private $url;

    /**
     * @var string
     */
    private $httpMethod;

    /**
     * @var string
     */
    private $referrer;

    /**
     * @var boolean
     */
    private $https;

    /**
     * @var string
     */
    private $platform;

    /**
     * @var string
     *
     * @GRID\Column(title="Navigateur", filterable=false, sortable=false)
     */
    private $browser;

    /**
     * @var string
     *
     * @GRID\Column(title="Version", filterable=false, sortable=false)
     */
    private $version;

    /**
     * @var string
     */
    private $remoteAddr;

    /**
     * @var float
     *
     * @GRID\Column(title="Durée", size="50",filterable=true, sortable=true)
     */
    private $time;

    /**
     * @var float
     *
     * @GRID\Column(title="Mémoire", size="50", filterable=true, sortable=true)
     */
    private $memory;

    /**
     * @var string
     */
    private $session;

    /**
     * @var integer
     *
     * @GRID\Column(title="Requêtes", size="50", filterable=true, sortable=true)
     */
    private $queries;

    /**
     * @var string
     *
     * @GRID\Column(title="Identifiant", filterable=true, sortable=false)
     */
    private $username;

    /**
     * @var string
     */
    private $message;

    /**
     * @var \DateTime
     *
     * @GRID\Column(title="Date", filterable=true, sortable=true)
     */
    private $createdAt;

    /**
     * @var boolean
     *
     * @GRID\Column(title="Ajax", filterable=true, sortable=false)
     */
    private $ajax;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set server
     *
     * @param string $server
     * @return Log
     */
    public function setServer($server)
    {
        $this->server = $server;
    
        return $this;
    }

    /**
     * Get server
     *
     * @return string 
     */
    public function getServer()
    {
        return $this->server;
    }

    /**
     * Set url
     *
     * @param string $url
     * @return Log
     */
    public function setUrl($url)
    {
        $this->url = $url;
    
        return $this;
    }

    /**
     * Get url
     *
     * @return string 
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * Set httpMethod
     *
     * @param string $httpMethod
     * @return Log
     */
    public function setHttpMethod($httpMethod)
    {
        $this->httpMethod = $httpMethod;
    
        return $this;
    }

    /**
     * Get httpMethod
     *
     * @return string 
     */
    public function getHttpMethod()
    {
        return $this->httpMethod;
    }

    /**
     * Set referrer
     *
     * @param string $referrer
     * @return Log
     */
    public function setReferrer($referrer)
    {
        $this->referrer = $referrer;
    
        return $this;
    }

    /**
     * Get referrer
     *
     * @return string 
     */
    public function getReferrer()
    {
        return $this->referrer;
    }

    /**
     * Set https
     *
     * @param boolean $https
     * @return Log
     */
    public function setHttps($https)
    {
        $this->https = $https;
    
        return $this;
    }

    /**
     * Get https
     *
     * @return boolean 
     */
    public function getHttps()
    {
        return $this->https;
    }

    /**
     * Set platform
     *
     * @param string $platform
     * @return Log
     */
    public function setPlatform($platform)
    {
        $this->platform = $platform;
    
        return $this;
    }

    /**
     * Get platform
     *
     * @return string 
     */
    public function getPlatform()
    {
        return $this->platform;
    }

    /**
     * Set browser
     *
     * @param string $browser
     * @return Log
     */
    public function setBrowser($browser)
    {
        $this->browser = $browser;
    
        return $this;
    }

    /**
     * Get browser
     *
     * @return string 
     */
    public function getBrowser()
    {
        return $this->browser;
    }

    /**
     * Set version
     *
     * @param string $version
     * @return Log
     */
    public function setVersion($version)
    {
        $this->version = $version;
    
        return $this;
    }

    /**
     * Get version
     *
     * @return string 
     */
    public function getVersion()
    {
        return $this->version;
    }

    /**
     * Set remoteAddr
     *
     * @param string $remoteAddr
     * @return Log
     */
    public function setRemoteAddr($remoteAddr)
    {
        $this->remoteAddr = $remoteAddr;
    
        return $this;
    }

    /**
     * Get remoteAddr
     *
     * @return string 
     */
    public function getRemoteAddr()
    {
        return $this->remoteAddr;
    }

    /**
     * Set time
     *
     * @param float $time
     * @return Log
     */
    public function setTime($time)
    {
        $this->time = $time;
    
        return $this;
    }

    /**
     * Get time
     *
     * @return float 
     */
    public function getTime()
    {
        return $this->time;
    }

    /**
     * Set memory
     *
     * @param float $memory
     * @return Log
     */
    public function setMemory($memory)
    {
        $this->memory = $memory;
    
        return $this;
    }

    /**
     * Get memory
     *
     * @return float 
     */
    public function getMemory()
    {
        return $this->memory;
    }

    /**
     * Set session
     *
     * @param string $session
     * @return Log
     */
    public function setSession($session)
    {
        $this->session = $session;
    
        return $this;
    }

    /**
     * Get session
     *
     * @return string 
     */
    public function getSession()
    {
        return $this->session;
    }

    /**
     * Set queries
     *
     * @param integer $queries
     * @return Log
     */
    public function setQueries($queries)
    {
        $this->queries = $queries;
    
        return $this;
    }

    /**
     * Get queries
     *
     * @return integer 
     */
    public function getQueries()
    {
        return $this->queries;
    }

    /**
     * Set username
     *
     * @param string $username
     * @return Log
     */
    public function setUsername($username)
    {
        $this->username = $username;
    
        return $this;
    }

    /**
     * Get username
     *
     * @return string 
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Set message
     *
     * @param string $message
     * @return Log
     */
    public function setMessage($message)
    {
        $this->message = $message;
    
        return $this;
    }

    /**
     * Get message
     *
     * @return string 
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     * @return Log
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime 
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set ajax
     *
     * @param boolean $ajax
     * @return Log
     */
    public function setAjax($ajax)
    {
        $this->ajax = $ajax;
    
        return $this;
    }

    /**
     * Get ajax
     *
     * @return boolean 
     */
    public function getAjax()
    {
        return $this->ajax;
    }
}
