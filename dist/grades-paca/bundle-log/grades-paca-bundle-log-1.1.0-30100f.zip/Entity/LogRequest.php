<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Entity;


class LogRequest
{

    /**
     * @var boolean
     */
    private $https;
    /**
     * @var string
     */
    private $httpMethod;

    /**
     * @var string
     */
    private $remoteAddr;

    /**
     * @var integer
     */
    private $id;

    /**
     * @var \Oru\Bundle\LogBundle\Entity\LogNew
     */
    private $log;


    /**
     * Set https
     *
     * @param boolean $https
     *
     * @return LogRequest
     */
    public function setHttps($https)
    {
        $this->https = $https;

        return $this;
    }

    /**
     * Get https
     *
     * @return boolean
     */
    public function getHttps()
    {
        return $this->https;
    }

    /**
     * Set httpMethod
     *
     * @param string $httpMethod
     *
     * @return LogRequest
     */
    public function setHttpMethod($httpMethod)
    {
        $this->httpMethod = $httpMethod;

        return $this;
    }

    /**
     * Get httpMethod
     *
     * @return string
     */
    public function getHttpMethod()
    {
        return $this->httpMethod;
    }

    /**
     * Set remoteAddr
     *
     * @param string $remoteAddr
     *
     * @return LogRequest
     */
    public function setRemoteAddr($remoteAddr)
    {
        $this->remoteAddr = $remoteAddr;

        return $this;
    }

    /**
     * Get remoteAddr
     *
     * @return string
     */
    public function getRemoteAddr()
    {
        return $this->remoteAddr;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set log
     *
     * @param \Oru\Bundle\LogBundle\Entity\LogNew $log
     *
     * @return LogRequest
     */
    public function setLog(\Oru\Bundle\LogBundle\Entity\LogNew $log = null)
    {
        $this->log = $log;

        return $this;
    }

    /**
     * Get log
     *
     * @return \Oru\Bundle\LogBundle\Entity\LogNew
     */
    public function getLog()
    {
        return $this->log;
    }
}
