<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Manager;


use Oru\Bundle\LogBundle\Helper\LogHelper;

class FilterFormManager
{
    /**
     * @var LogHelper
     */
    protected $helper;

    /**
     * FilterFormManager constructor.
     */
    public function __construct(LogHelper $helper)
    {
        $this->helper = $helper;
    }

    /**
     * Process data to filter
     *
     * @param $filter
     * @return mixed
     */
    public function processData($filter) {
        return $filter;
    }
}