<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Manager;


use Doctrine\ORM\EntityManager;
use Oru\Bundle\LogBundle\Entity\LogNew;
use Oru\Bundle\LogBundle\Entity\LogProfiler;
use Oru\Bundle\LogBundle\Entity\LogRequest;
use Oru\Bundle\LogBundle\Entity\LogSession;
use Oru\Bundle\LogBundle\Entity\LogTmp;
use Oru\Bundle\LogBundle\Entity\LogUrl;
use Oru\Bundle\LogBundle\Entity\LogUserAgent;
use Symfony\Bundle\FrameworkBundle\Routing\Router;
use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;

class ProcessManager
{
    /**
     * @var EntityManager
     */
    private $em;

    /**
     * @var Router
     */
    private $router;

    /**
     * @var int
     */
    private $limit;

    /**
     * ProcessManager constructor.
     */
    public function __construct(EntityManager $em, Router $router)
    {
        $this->em = $em;
        $this->router = $router;
        $this->limit = 100;
    }

    /**
     * Traitement et purge de tous les logs
     */
    public function processAll()
    {
        while ($this->nbLogs()) {
            $this->process($this->limit);
        }
    }

    /**
     * @return int
     */
    public function nbLogs()
    {
        return $this->em->getRepository('OruLogBundle:LogTmp')->count();
    }

    /**
     * Traitement et purge des logs de oru_log_tmp selon limit et offset
     *
     * @param int $limit
     * @param int $offset
     */
    public function process($limit = 100)
    {
        if (function_exists('sem_get')) {
            $semId = sem_get(123456789);
            $sem = sem_acquire($semId);
        }

        $logs = $this->em->getRepository('OruLogBundle:LogTmp')->findBy(array(), null, $limit);
        foreach ($logs as $log) {
            /** @var $log LogTmp */
            $parsedUrl = parse_url($log->getUrl());

            $route = null;
            $params = null;
            if (is_array($parsedUrl) && isset($parsedUrl['path'])) {
                try {
                    $route = $this->router->match($parsedUrl['path'])['_route'];
                } catch (ResourceNotFoundException $e) {

                } catch (MethodNotAllowedException $e) {

                }

                if (isset($parsedUrl['query'])) {
                    parse_str($parsedUrl['query'], $params);
                }
            }

            $url = $this->em->getRepository('OruLogBundle:LogUrl')->findOneByUrl($log->getUrl());

            if (!$url) {
                $url = new LogUrl();
                $url->setUrl($log->getUrl());
                $url->setRoute($route);
                $url->setParams($params);
                $this->em->persist($url);
                $this->em->flush($url);
            } else if (!$url->getRoute() && $route) {
                $url->setRoute($route);
                $url->setParams($params);
                $this->em->flush($url);
            }

            $newLog = new LogNew();
            $newLog->setUrl($url);
            $newLog->setUsername($log->getUsername());
            $newLog->setCreated($log->getCreated());
            $newLog->setAjax($log->getAjax());

            if ($log->getSession()) {
                $session = $this->em->getRepository('OruLogBundle:LogSession')->findOneBySession($log->getSession());
                if (!$session) {
                    $session = new LogSession();
                    $session->setSession($log->getSession());
                    $this->em->persist($session);
                    $this->em->flush($session);
                }
                $newLog->setSession($session);
            }

            if ($log->getAgent()) {
                $agent = $this->em->getRepository('OruLogBundle:LogUserAgent')->findOneByAgent($log->getAgent());
                if (!$agent) {
                    $agent = new LogUserAgent();
                    $agent->setAgent($log->getAgent());
                    $this->em->persist($agent);
                    $this->em->flush($agent);
                }
                $newLog->setUserAgent($agent);
            }

            $logRequest = new LogRequest();
            $logRequest->setHttps($log->getHttps());
            $logRequest->setHttpMethod($log->getHttpMethod());
            $logRequest->setRemoteAddr($log->getRemoteAddr());

            $logProfiler = new LogProfiler();
            $logProfiler->setMemory($log->getMemory());
            $logProfiler->setQueries($log->getQueries());
            $logProfiler->setTime($log->getTime());

            $newLog->setRequest($logRequest);
            $newLog->setProfiler($logProfiler);
            $this->em->persist($newLog);
            $this->em->remove($log);
        }
        $this->em->flush();
        $this->em->clear();

        if (function_exists('sem_get')) {
            sem_release($semId);
        }
    }

    /**
     * Fonction de purge des logs.
     *
     * @param $days Logs à purger inférieur à $days jours
     */
    public function purge($days)
    {
        $date = new \DateTime('- '.abs($days).'days');
        $qb = $this->em->createQueryBuilder();
        $qb->delete('OruLogBundle:LogNew', 'l')->andWhere("l.created < :dateLimit ");
        $qb->setParameter('dateLimit', $date->format('Y-m-d H:i:s'));
        $qb->getQuery()->execute();

        $this->em->getConnection()->query("DELETE FROM `oru_log_session` WHERE `id` IN (SELECT * FROM (SELECT a.id FROM oru_log_session a LEFT JOIN oru_log_new AS b ON a.id = b.session_id WHERE b.id IS NULL) AS t);")->execute();
        $this->em->getConnection()->query("DELETE FROM `oru_log_url` WHERE `id` IN (SELECT * FROM (SELECT a.id FROM oru_log_url a LEFT JOIN oru_log_new AS b ON a.id = b.url_id WHERE b.id IS NULL) AS t);")->execute();
        $this->em->getConnection()->query("DELETE FROM `oru_log_user_agent` WHERE `id` IN (SELECT * FROM (SELECT a.id FROM oru_log_user_agent a LEFT JOIN oru_log_new AS b ON a.id = b.user_agent_id WHERE b.id IS NULL) AS t);")->execute();
    }

}