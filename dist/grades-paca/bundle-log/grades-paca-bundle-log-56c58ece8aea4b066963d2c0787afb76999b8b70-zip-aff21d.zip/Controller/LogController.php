<?php

namespace Oru\Bundle\LogBundle\Controller;

use Doctrine\ORM\Query;
use Oru\Bundle\DesignBundle\Controller\FlashControllerTrait;
use Oru\Bundle\LogBundle\Filter\LogNewFilter;
use Oru\Bundle\LogBundle\Form\LogNewFilterType;
use Oru\Bundle\RorCredentialsBundle\Controller\CredentialControllerTrait;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Oru\Bundle\LogBundle\Entity\LogNew;
use Oru\Bundle\LogBundle\Listing\LogNewListingType;

/**
 * LogNew controller.
 *
 */
class LogController extends Controller
{

    use FlashControllerTrait;
    use CredentialControllerTrait;

    /**
     * Lists all LogNew entities.
     *
     */
    public function indexAction(Request $request)
    {
        $this->grantAccess('ORU_LOG');

        $lastDay = new \DateTime('-1 day');
        $defaultFilters = array('ajax' => 0, 'createdAfter' => array('date' => $lastDay->format('Y-m-d'), 'time' => $lastDay->format('H:i')));
        if($request->query->get('force', null)) {
            $this->get('oru_log.process_manager')->processAll();
        }
        $lastLog = $this->getDoctrine()->getManager()->getRepository('OruLogBundle:LogNew')->findOneBy(array(), array('created' => 'DESC'));
        $submit = ($request->query->get('session', null)) ? array('sessionId' => $request->query->get('session', $defaultFilters)) : $request->getSession()->get('log.filter', $defaultFilters);
        $form = $this->createForm($this->get('oru_log.filter.form'))->submit($submit);
        $data = $this->get('oru_log.filter.form_manager')->processData($form->getData());
        $listing = $this->container->get('paginator.factory')->create(
            new LogNewListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruLogBundle:LogNew')->findList($data)->getQuery(),
            $request->query->get('page', 1)
        );

        return $this->render('@OruLog/Log/index.html.twig', array(
            'listing' => $listing,
            'form' => $this->createForm($this->get('oru_log.filter.form'), $data)->createView(),
            'lastLog' => $lastLog
        ));
    }
    /**
     * Filters LogNew entities.
     *
     */
    public function filterAction(Request $request)
    {
        $this->grantAccess('ORU_LOG');

        $form = $this->createForm($this->get('oru_log.filter.form'))->handleRequest($request);
        $lastLog = $this->getDoctrine()->getManager()->getRepository('OruLogBundle:LogNew')->findOneBy(array(), array('created' => 'DESC'));

        if ($form->get('reset')->isClicked() || !$form->getData() instanceof LogNewFilter) {
            $request->getSession()->remove('log.filter');
            return $this->redirect($this->generateUrl('log'));
        }

        if($form->isValid()) {
            $request->getSession()->set('log.filter', $request->get($form->getName()));
            return $this->redirect($this->generateUrl('log'));
        }

        $data = $this->get('oru_log.filter.form_manager')->processData($form->getData());
        $listing = $this->container->get('paginator.factory')->create(
            new LogNewListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruLogBundle:LogNew')->findList($data)->getQuery(),
            $request->query->get('page', 1)
        );

        return $this->render('@OruLog/Log/index.html.twig', array(
            'listing' => $listing,
            'form' => $form->createView(),
            'lastLog' => $lastLog
        ));
    }

    /**
     * Finds and displays a LogNew entity.
     *
     */
    public function showAction($id)
    {
        $this->grantAccess('ORU_LOG');

        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruLogBundle:LogNew')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find LogNew entity.');
        }

        return $this->render('@OruLog/Log/show.html.twig', array(
            'entity'      => $entity,
        ));
    }

    /**
     * Follow session logs
     *
     * @param $id integer LogNew id
     */
    public function followAction($id)
    {
        $this->grantAccess('ORU_LOG');

        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruLogBundle:LogNew')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find LogNew entity.');
        }

        return $this->redirect($this->generateUrl('log', array('session' => $entity->getSession()->getSession())));
    }

    /**
     * Follow errors for session
     *
     * @param $id integer LogNew id
     */
    public function errorAction($id)
    {
        $this->grantAccess('ORU_LOG');

        $param = $this->getParameter('disabled_bundles');
        if($param && array_search('OruErrorLoggerBundle', $param) !== FALSE) {
            $this->addSessionMessage("Le bundle de gestion des erreurs n'est pas activé.", 'error');
            return $this->redirect($this->generateUrl('log'));
        }

        $em = $this->getDoctrine()->getManager();
        $entity = $em->getRepository('OruLogBundle:LogNew')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find LogNew entity.');
        }

        return $this->redirect($this->generateUrl('oru_error', array('session' => $entity->getSession()->getSession())));
    }
}
