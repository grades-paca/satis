<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 26/12/13
 */
namespace Oru\Bundle\LogBundle\Processor;

use Doctrine\DBAL\Logging\DebugStack;
use Oru\Bundle\LogBundle\Helper\LogHelper;
use Symfony\Component\HttpKernel\KernelInterface;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Security\Core\User\UserInterface;

class LogProcessor
{
    /**
     * @var KernelInterface
     */
    protected $kernel;

    /**
     * @var SessionInterface
     */
    protected $session;

    /**
     * @var TokenStorageInterface
     */
    protected $securityContext;

    /**
     * @var DebugStack
     */
    protected $logger;

    /**
     * @var LogHelper
     */
    private $logHelper;

    /**
     * @param KernelInterface|null $kernel
     */
    public function setKernel(KernelInterface $kernel = null)
    {
        $this->kernel = $kernel;
    }

    /**
     * @param SessionInterface|null $session
     */
    public function setSession(SessionInterface $session = null)
    {
        $this->session = $session;
    }

    /**
     * @param TokenStorageInterface|null $securityContext
     */
    public function setSecurityContext(TokenStorageInterface $securityContext = null)
    {
        $this->securityContext = $securityContext;
    }

    /**
     * @param DebugStack $logger
     */
    public function setLogger(DebugStack $logger)
    {
        $this->logger = $logger;
    }

    /**
     * @param LogHelper $logHelper
     */
    public function setHelper(LogHelper $logHelper) {
        $this->logHelper = $logHelper;
    }

    /**
     * @param  array $record
     * @return array
     */
    public function __invoke(array $record)
    {
        $record['extra'] = array_merge(
            $record['extra'],
            array(
                'duration'          => $this->getDuration(),
                'https'             => $this->logHelper->getHttps(),
                'user_agent'        => $this->logHelper->getUserAgent(),
                'remote_addr'       => $this->logHelper->getRemoteAddr(),
                'session_id'        => $this->session->getId(),
                'username'          => ($this->securityContext->getToken() !== null && $this->securityContext->getToken()->getUser() instanceof UserInterface) ? $this->securityContext->getToken()->getUserName().' ('.$this->securityContext->getToken()->getUser()->getId().')' : null,
                'queries'           => ($this->logger) ? count($this->logger->queries) : 0,
                'ajax'              => ($this->logHelper->getAjax()) ? true : false
            )
        );

        return $record;
    }

    /**
     * Get duration of current request
     *
     * @return mixed
     */
    private function getDuration()
    {
        return microtime(true)*1000 - $this->kernel->getStartTime()*1000;
    }
}
