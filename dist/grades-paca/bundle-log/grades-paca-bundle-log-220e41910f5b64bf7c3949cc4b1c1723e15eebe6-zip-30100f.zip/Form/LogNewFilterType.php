<?php

namespace Oru\Bundle\LogBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class LogNewFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('username', 'search', array('required' => false, 'label' => 'LogNew.username', 'translation_domain' => 'OruLogBundle'))
            ->add('searchUrl', 'search', array('required' => false, 'label' => 'LogNew.url', 'translation_domain' => 'OruLogBundle'))
            ->add('exactUrl', 'oru_oui_non', array('required' => false, 'label' => 'LogNew.exactUrl', 'translation_domain' => 'OruLogBundle', 'expanded' => false))
            ->add('createdAfter', 'datetime', array('required' => false, 'label' => 'LogNew.createdAfter', 'translation_domain' => 'OruLogBundle', 'date_widget' => 'single_text', 'time_widget' => 'single_text'))
            ->add('createdBefore', 'datetime', array('required' => false, 'label' => 'LogNew.createdBefore', 'translation_domain' => 'OruLogBundle', 'date_widget' => 'single_text', 'time_widget' => 'single_text'))
            ->add('sessionId', 'search', array('required' => false, 'label' => 'LogNew.session', 'translation_domain' => 'OruLogBundle'))
            ->add('ajax', 'oru_oui_non', array('required' => false, 'label' => 'LogNew.ajax', 'translation_domain' => 'OruLogBundle', 'expanded' => false))
            ->add('filter', 'submit', array('label' => 'listing.action.filter', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-primary')))
            ->add('reset', 'submit', array('label' => 'listing.action.reset', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-default')))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\LogBundle\Filter\LogNewFilter'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_logbundle_lognewfilter';
    }
}
