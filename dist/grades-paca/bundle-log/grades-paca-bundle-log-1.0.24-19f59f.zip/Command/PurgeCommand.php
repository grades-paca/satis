<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Command;


use Oru\Bundle\LogBundle\Entity\LogMessage;
use Oru\Bundle\LogBundle\Entity\LogNew;
use Oru\Bundle\LogBundle\Entity\LogProfiler;
use Oru\Bundle\LogBundle\Entity\LogRequest;
use Oru\Bundle\LogBundle\Entity\LogSession;
use Oru\Bundle\LogBundle\Entity\LogTmp;
use Oru\Bundle\LogBundle\Entity\LogUrl;
use Oru\Bundle\LogBundle\Entity\LogUser;
use Oru\Bundle\LogBundle\Entity\LogUserAgent;
use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class PurgeCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    public function configure()
    {
        $this
            ->setName('oru:log:purge')
            ->setDescription("Purge des anciens logs (paramètre par défaut à plus d'un an).")
            ->addOption('force', 'f', InputOption::VALUE_NONE, "Permet l'écriture en base")
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $em = $this->getContainer()->get('doctrine.orm.default_entity_manager');

        // Purge LOG NEW
        $param = $this->getContainer()->get('oru_setting')->setting('purgePeriod', 'OruLogBundle');
        if($param) {
            try {
                $period = new \DateTime($param);
            } catch (\Exception $e) {
                $param = '-1 year';
                $period = new \DateTime($param);
            }
        }

        $nbLogs = $em->getRepository('OruLogBundle:LogNew')->countLogs($period);
        if ($input->getOption('force')) {
            // purge oru_log_new
            $qb = $em->createQueryBuilder();
            $qb->delete('OruLogBundle:LogNew', 'l')->andWhere("l.created < :dateLimit ");
            $qb->setParameter('dateLimit', $period->format('Y-m-d H:i:s'));
            $qb->getQuery()->execute();
            $output->writeln("$nbLogs logs datant d'avant le " . $period->format('d/m/Y H:i:s') . " ont été purgés.");

            // purge oru_log_session
            $nbSessions = $em->getRepository('OruLogBundle:LogSession')->countEmptySessions();
            $limit = 1000;
            if(!$nbSessions) {
                return $output->writeln('Aucune session orpheline à purger.');
            }
            $output->writeln("Purge de $nbSessions sessions orphelines : ");
            $progress = new ProgressBar($output, $nbSessions);
            $progress->start();
            while ( $em->getRepository('OruLogBundle:LogSession')->countEmptySessions() ) {
                $results = $em->getRepository('OruLogBundle:LogSession')->findEmptySessions($limit);
                foreach ($results as $result) {
                    $em->remove($result);
                }
                $em->flush();
                $em->clear();
                $progress->advance($limit);
            }
            $progress->finish();
            $output->writeln('');
        } else {
            $output->writeln("$nbLogs logs datant d'avant le " . $period->format('d/m/Y H:i:s') . " à purger. Utilisez l'option --force pour forcer l'écriture en base.");
        }


    }

    public function getMaxRunningTimeSec()
    {
        return 500;
    }

    public function isConcurentAllowed()
    {
        return false;
    }

    public function getTypeFieldFromArgumentName($name, & $type = "text", & $options = [])
    {
    }


}