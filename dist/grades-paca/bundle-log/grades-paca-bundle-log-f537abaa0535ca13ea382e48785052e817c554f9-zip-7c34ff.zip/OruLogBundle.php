<?php

namespace Oru\Bundle\LogBundle;

use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Oru\Bundle\SettingBundle\Bundle\OruBundle;

class OruLogBundle extends OruBundle
{
    /**
     * OruLogBundle constructor.
     */
    public function __construct()
    {
        DynamicLoader::addYaml('@OruLogBundle/Resources/config/routing.yml');
    }

    /**
     * {@inheritdoc}
     */
    public static function getFriendlyName()
    {
        return 'Traçabilité';
    }

    /**
     * {@inheritdoc}
     */
    public static function getDescription()
    {
        return 'Bundle de gestion de la tracabilité';
    }
}
