<?php

namespace Oru\Bundle\LogBundle\Subscriber;

use Doctrine\Bundle\DoctrineBundle\Registry;
use Doctrine\DBAL\Logging\DebugStack;
use Doctrine\DBAL\Logging\LoggerChain;
use Oru\Bundle\LogBundle\Processor\LogProcessor;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\GetResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * Class RequestSubscriber
 *
 * @package Oru\Bundle\LogBundle\Subscriber
 * @author Michaël VEROUX
 */
class RequestSubscriber implements EventSubscriberInterface
{
    /**
     * @var bool
     */
    static protected $done = false;

    /**
     * @var Registry
     */
    protected $registry;

    /**
     * @var LogProcessor
     */
    protected $logProcessor;

    /**
     * @var bool
     */
    protected $sqlCounterEnabled;

    /**
     * RequestSubscriber constructor.
     *
     * @param Registry     $registry
     * @param LogProcessor $logProcessor
     * @param bool         $sqlCounterEnabled
     */
    public function __construct(Registry $registry, LogProcessor $logProcessor, $sqlCounterEnabled)
    {
        $this->registry = $registry;
        $this->logProcessor = $logProcessor;
        $this->sqlCounterEnabled = $sqlCounterEnabled;
    }

    /**
     * Returns an array of event names this subscriber wants to listen to.
     *
     * The array keys are event names and the value can be:
     *
     *  * The method name to call (priority defaults to 0)
     *  * An array composed of the method name to call and the priority
     *  * An array of arrays composed of the method names to call and respective
     *    priorities, or 0 if unset
     *
     * For instance:
     *
     *  * array('eventName' => 'methodName')
     *  * array('eventName' => array('methodName', $priority))
     *  * array('eventName' => array(array('methodName1', $priority), array('methodName2')))
     *
     * @return array The event names to listen to
     */
    public static function getSubscribedEvents()
    {
        return array(
            KernelEvents::REQUEST   => array('onRequest', 255),
        );
    }

    /**
     * @param GetResponseEvent $event
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function onRequest(GetResponseEvent $event)
    {
        if ($this->sqlCounterEnabled && !self::$done) {
            $logger = new DebugStack();
            $configuration = $this->registry->getConnection()->getConfiguration();
            if (null === $configuration->getSQLLogger()) {
                $loggerChain = new LoggerChain();
                $configuration->setSQLLogger($loggerChain);
            }
            $configuration->getSQLLogger()->addLogger($logger);
            $this->logProcessor->setLogger($logger);
            self::$done = true;
        }
    }
}
