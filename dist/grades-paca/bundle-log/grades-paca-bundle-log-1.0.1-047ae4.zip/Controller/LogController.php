<?php

namespace Oru\Bundle\LogBundle\Controller;

use MyProject\Proxies\__CG__\stdClass;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use APY\DataGridBundle\Grid\Source\Entity;
use APY\DataGridBundle\Grid\Export\CSVExport;
use APY\DataGridBundle\Grid\Export\ExcelExport;
use APY\DataGridBundle\Grid\Export\SCSVExport;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class LogController extends Controller
{
    public function indexAction()
    {
        if(!$this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_LOG'))
        {
            throw new AccessDeniedHttpException();
        }
        
        // Initialisation de la source de données
        $source = new Entity('OruLogBundle:Log');

        // Récupération du service Grid
        $grid = $this->container->get('grid');

        $grid->setDefaultOrder('id', 'DESC');

        $grid->setDefaultFilters(array('master' => 1));

        $grid->setMaxResults(500);

        // Affectation de la source
        $grid->setSource($source);

        $grid->getColumn('browser')->setClass('hidden-xs')->setClass('hidden-sm');
        $grid->getColumn('version')->setClass('hidden-xs')->setClass('hidden-sm');
        $grid->getColumn('queries')->setClass('hidden-xs')->setClass('hidden-sm');
        $grid->getColumn('memory')->setClass('hidden-xs')->setClass('hidden-sm');
        $grid->getColumn('master')->setClass('hidden-xs')->setClass('hidden-sm');

        $grid->addExport(new CSVExport($this->get('translator')->trans('CSV export')));
        $grid->addExport(new SCSVExport($this->get('translator')->trans('SCSV export')));
        $grid->addExport(new ExcelExport($this->get('translator')->trans('Excel export')));

        // Renvoie une réponse
        return $grid->getGridResponse('OruLogBundle:Log:index.html.twig');
    }
}
