<?php

namespace Oru\Bundle\LogBundle;

use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruLogBundle extends Bundle
{
    public function boot()
    {
        DynamicLoader::addYaml('@OruLogBundle/Resources/config/routing/log.yml');
    }
}
