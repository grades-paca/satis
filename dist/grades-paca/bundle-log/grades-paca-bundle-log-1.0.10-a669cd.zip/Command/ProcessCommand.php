<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LogBundle\Command;


use Oru\Bundle\LogBundle\Entity\LogMessage;
use Oru\Bundle\LogBundle\Entity\LogNew;
use Oru\Bundle\LogBundle\Entity\LogProfiler;
use Oru\Bundle\LogBundle\Entity\LogRequest;
use Oru\Bundle\LogBundle\Entity\LogSession;
use Oru\Bundle\LogBundle\Entity\LogTmp;
use Oru\Bundle\LogBundle\Entity\LogUrl;
use Oru\Bundle\LogBundle\Entity\LogUser;
use Oru\Bundle\LogBundle\Entity\LogUserAgent;
use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class ProcessCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    public function configure()
    {
        $this
            ->setName('oru:log:process')
            ->setDescription("Traitement et purge des logs de la table oru_log_tmp")
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        // Process LOG TMP
        $manager = $this->getContainer()->get('oru_log.process_manager');
        $nbLogs = $manager->nbLogs();
        $limit = 100;

        if(!$nbLogs) {
            return $output->writeln('Aucun log à traiter.');
        }

        $progress = new ProgressBar($output, $nbLogs);
        $progress->start();
        while ( $manager->nbLogs() ) {
            $manager->process($limit);
            $progress->advance($limit);
        }
        $progress->finish();
        $output->writeln('');
    }



    public function getMaxRunningTimeSec()
    {
        return 300;
    }

    public function isConcurentAllowed()
    {
        return false;
    }

    public function getTypeFieldFromArgumentName($name, & $type = "text", & $options = [])
    {
        // TODO: Implement getTypeFieldFromArgumentName() method.
    }


}