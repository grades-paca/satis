<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 12/12/13
 * Time: 11:35
 */

namespace Oru\Bundle\LogBundle\EventListener;

use Oru\Bundle\LogBundle\Log\LogManager;
use Symfony\Component\HttpKernel\Event\GetResponseEvent;
use Symfony\Component\HttpKernel\Event\PostResponseEvent;
use Symfony\Component\HttpKernel\EventListener\ExceptionListener as BaseExceptionListener;
use Symfony\Component\HttpKernel\HttpKernelInterface;
use Symfony\Component\HttpKernel\KernelEvents;

class LogListener extends BaseExceptionListener
{
    protected $logger;
    protected $container;
    protected $flag;

    public function __construct(LogManager $logManager)
    {
        $this->logger = $logManager->getLogger();
    }

    /**
     * Par défaut on sauvegarde tous les requêtes, mais il est possible de filtrer sur les HttpKernelInterface::MASTER_REQUEST seulement
     *
     * @param GetResponseEvent $event
     */
    public function onKernelRequest(GetResponseEvent $event) {
        $this->flag = (HttpKernelInterface::MASTER_REQUEST != $event->getRequestType());
    }

    /**
     * LOG !
     *
     * @param PostResponseEvent $event
     */
    public function onKernelTerminate(PostResponseEvent $event)
    {
        if($this->flag) {
            $this->logger->info('End of request');
        } else {
            //$this->logger->debug('End of request');
        }
    }
}