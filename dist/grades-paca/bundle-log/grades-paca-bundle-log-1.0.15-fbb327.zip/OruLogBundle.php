<?php

namespace Oru\Bundle\LogBundle;

use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruLogBundle extends OruBundle
{
    /**
     * OruLogBundle constructor.
     */
    public function __construct()
    {
        DynamicLoader::addYaml('@OruLogBundle/Resources/config/routing.yml');
    }

    /**
     * @inheritdoc
     */
    public function boot()
    {
        if(php_sapi_name() != 'cli' && $this->container->hasParameter('sql_counter_enabled') && true == $this->container->getParameter('sql_counter_enabled')) {
            $doctrine = $this->container->get('doctrine');
            $logger = new \Doctrine\DBAL\Logging\DebugStack();
            $logProcessor = $this->container->get('oru_log.log_processor');
            if (null !== $doctrine->getConnection()->getConfiguration()->getSQLLogger()) {
                $doctrine
                    ->getConnection()
                    ->getConfiguration()
                    ->getSQLLogger()
                    ->addLogger($logger);
            } else {
                $doctrine
                    ->getConnection()
                    ->getConfiguration()
                    ->setSQLLogger($logger);
            }
            $logProcessor->setLogger($logger);
        }
    }

    /**
     * @inheritdoc
     */
    public static function getFriendlyName()
    {
        return "Traçabilité";
    }

    /**
     * @inheritdoc
     */
    public static function getDescription()
    {
        return 'Bundle de gestion de la tracabilité';
    }


}
