<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 12/12/13
 * Time: 16:47
 */

namespace Oru\Bundle\LogBundle\Storage;

use Doctrine\ORM\EntityManager;
use Monolog\Formatter\FormatterInterface;
use Monolog\Handler\AbstractProcessingHandler;
use Monolog\Logger;
use Oru\Bundle\LogBundle\Entity\Log;
use Oru\Bundle\LogBundle\Entity\LogMessage;
use Oru\Bundle\LogBundle\Entity\LogNew;
use Oru\Bundle\LogBundle\Entity\LogProfiler;
use Oru\Bundle\LogBundle\Entity\LogRequest;
use Oru\Bundle\LogBundle\Entity\LogSession;
use Oru\Bundle\LogBundle\Entity\LogTmp;
use Oru\Bundle\LogBundle\Entity\LogUrl;
use Oru\Bundle\LogBundle\Entity\LogUser;
use Oru\Bundle\LogBundle\Entity\LogUserAgent;
use Oru\Bundle\LogBundle\Helper\LogHelper;

class LogStorage extends AbstractProcessingHandler
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    protected $entityManager = null;

    /**
     * @var LogHelper
     */
    protected $helper;

    /**
     * @param \Doctrine\ORM\EntityManager $entityManager
     */
    public function setEntityManager(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param LogHelper $logHelper
     */
    public function setHelper(LogHelper $logHelper)
    {
        $this->helper = $logHelper;
    }

    /**
     * @inheritdoc
     */
    protected function write(array $record)
    {
        if (!isset($record['extra']['url'])) {
            return $record;
        }

        $log = new LogTmp();
        $log->setUrl($this->helper->processUrl($record['extra']['url']));
        $log->setSession($record['extra']['session_id']);
        $log->setAgent($record['extra']['user_agent']);
        $log->setAjax($record['extra']['ajax']);
        $log->setUsername($record['extra']['username']);
        $log->setHttpMethod($record['extra']['http_method']);
        $log->setHttps($record['extra']['https']);
        $log->setMemory(memory_get_peak_usage());
        $log->setQueries($record['extra']['queries']);
        $log->setRemoteAddr($record['extra']['remote_addr']);
        $log->setTime($record['extra']['duration']);

        if (!$this->entityManager->isOpen()) {
            $this->entityManager = $this->entityManager->create(
                $this->entityManager->getConnection(),
                $this->entityManager->getConfiguration()
            );
        }
        $this->entityManager->clear();
        $this->entityManager->persist($log);
        $this->entityManager->flush($log);
    }

}