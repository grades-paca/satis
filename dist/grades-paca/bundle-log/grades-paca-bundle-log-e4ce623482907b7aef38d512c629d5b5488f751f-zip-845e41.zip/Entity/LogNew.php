<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */


namespace Oru\Bundle\LogBundle\Entity;


class LogNew
{
    /**
     * @var string
     */
    private $username;

    /**
     * @var \DateTime
     */
    private $created;

    /**
     * @var boolean
     */
    private $ajax;

    /**
     * @var integer
     */
    private $id;

    /**
     * @var \Oru\Bundle\LogBundle\Entity\LogProfiler
     */
    private $profiler;

    /**
     * @var \Oru\Bundle\LogBundle\Entity\LogRequest
     */
    private $request;

    /**
     * @var \Oru\Bundle\LogBundle\Entity\LogUrl
     */
    private $url;

    /**
     * @var \Oru\Bundle\LogBundle\Entity\LogUserAgent
     */
    private $userAgent;

    /**
     * @var \Oru\Bundle\LogBundle\Entity\LogSession
     */
    private $session;


    /**
     * Set username
     *
     * @param string $username
     *
     * @return LogNew
     */
    public function setUsername($username)
    {
        $this->username = $username;

        return $this;
    }

    /**
     * Get username
     *
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Set created
     *
     * @param \DateTime $created
     *
     * @return LogNew
     */
    public function setCreated($created)
    {
        $this->created = $created;

        return $this;
    }

    /**
     * Get created
     *
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Set ajax
     *
     * @param boolean $ajax
     *
     * @return LogNew
     */
    public function setAjax($ajax)
    {
        $this->ajax = $ajax;

        return $this;
    }

    /**
     * Get ajax
     *
     * @return boolean
     */
    public function getAjax()
    {
        return $this->ajax;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set profiler
     *
     * @param \Oru\Bundle\LogBundle\Entity\LogProfiler $profiler
     *
     * @return LogNew
     */
    public function setProfiler(\Oru\Bundle\LogBundle\Entity\LogProfiler $profiler = null)
    {
        $profiler->setLog($this);
        $this->profiler = $profiler;

        return $this;
    }

    /**
     * Get profiler
     *
     * @return \Oru\Bundle\LogBundle\Entity\LogProfiler
     */
    public function getProfiler()
    {
        return $this->profiler;
    }

    /**
     * Set request
     *
     * @param \Oru\Bundle\LogBundle\Entity\LogRequest $request
     *
     * @return LogNew
     */
    public function setRequest(\Oru\Bundle\LogBundle\Entity\LogRequest $request = null)
    {
        $request->setLog($this);
        $this->request = $request;

        return $this;
    }

    /**
     * Get request
     *
     * @return \Oru\Bundle\LogBundle\Entity\LogRequest
     */
    public function getRequest()
    {
        return $this->request;
    }

    /**
     * Set url
     *
     * @param \Oru\Bundle\LogBundle\Entity\LogUrl $url
     *
     * @return LogNew
     */
    public function setUrl(\Oru\Bundle\LogBundle\Entity\LogUrl $url = null)
    {
        $this->url = $url;

        return $this;
    }

    /**
     * Get url
     *
     * @return \Oru\Bundle\LogBundle\Entity\LogUrl
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * Set userAgent
     *
     * @param \Oru\Bundle\LogBundle\Entity\LogUserAgent $userAgent
     *
     * @return LogNew
     */
    public function setUserAgent(\Oru\Bundle\LogBundle\Entity\LogUserAgent $userAgent = null)
    {
        $this->userAgent = $userAgent;

        return $this;
    }

    /**
     * Get userAgent
     *
     * @return \Oru\Bundle\LogBundle\Entity\LogUserAgent
     */
    public function getUserAgent()
    {
        return $this->userAgent;
    }

    /**
     * Set session
     *
     * @param \Oru\Bundle\LogBundle\Entity\LogSession $session
     *
     * @return LogNew
     */
    public function setSession(\Oru\Bundle\LogBundle\Entity\LogSession $session = null)
    {
        $this->session = $session;

        return $this;
    }

    /**
     * Get session
     *
     * @return \Oru\Bundle\LogBundle\Entity\LogSession
     */
    public function getSession()
    {
        return $this->session;
    }
}
