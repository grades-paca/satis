<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LstBundle\Events;

final class LstEvents
{
    const LST_FORM_PARAMS = 'lst.form.params';
    const LST_GRID_CLOSURE = 'lst.grid.closure';
}
