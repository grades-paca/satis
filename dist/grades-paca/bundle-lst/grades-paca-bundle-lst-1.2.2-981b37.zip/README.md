OruLstBundle
================

Description
-----------

Mise à disposition d'une interface de gestion des listes. Le système d'héritage abstrait de doctrine est utilisé pour identifier les tables à administrer.
Les colonnes disponibles dans la classe de base Lst n'ont pas besoin d'être déclarées, elles seront automatiquement disponibles dans les nouvelles listes.
Voici le lien vers la documentation ApyDataGrid pour gérer les tableaux de listes : https://github.com/Abhoryo/APYDataGridBundle/blob/master/Resources/doc/summary.md.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/lst":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new APY\DataGridBundle\APYDataGridBundle();
$bundles[] = new Oru\Bundle\LstBundle\OruLstBundle();
```


Dans le config.yml, ajouter ce bundle aux paramètres imports :

```
imports:
    ...
    - { resource: @OruLstBundle/Resources/config/config.yml }
```

Dans le routing.yml, ajouter la nouvelle route :

```
oru_lst:
    resource: "@OruLstBundle/Resources/config/routing.yml"
    prefix: /lst
```

Vider le cache de Symfony2.

### Liste des pages

[Pages](./oru_lst_bundle/revisions/master/entry/Resources/config/pages.xml)

Utilisation
-----------

Les colonnes existantes dans la classe Lst sont :

- id

- libelle

- created

- updated

- deleted

Il sera très simple d'en ajouter d'autres qui seront répercutées dans toutes les listes (dates de création et modification ...).

### Exemple de génération d'une liste LstRegion dans le bundle OruRepertoireBundle

- Générer la nouvelle liste via la ligne de commande doctrine:generate:entity. Le nom de la liste doit commencer par Lst :

```
./app/console doctrine:generate:entity --entity=OruRepertoireBundle:LstRegion --format=xml --no-interaction
```

*(Avant)* Voici un exemple de configuration générée dans "Ressources/config/doctrine/LstRegion.orm.xml" :

``` xml
<?xml version="1.0" encoding="utf-8"?>
<doctrine-mapping xmlns="http://doctrine-project.org/schemas/orm/doctrine-mapping" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://doctrine-project.org/schemas/orm/doctrine-mapping http://doctrine-project.org/schemas/orm/doctrine-mapping.xsd">
  <entity name="Oru\Bundle\ProfessionnelBundle\Entity\LstRegion">
    <id name="id" type="integer" column="id">
      <generator strategy="AUTO"/>
    </id>
  </entity>
</doctrine-mapping>
```

*(Après)* Retirer la section fields du fichier généré "Ressources/config/doctrine/LstRegion.orm.xml" et renommer la table :

``` xml
<?xml version="1.0" encoding="utf-8"?>
<doctrine-mapping xmlns="http://doctrine-project.org/schemas/orm/doctrine-mapping" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://doctrine-project.org/schemas/orm/doctrine-mapping http://doctrine-project.org/schemas/orm/doctrine-mapping.xsd">
  <entity name="Oru\Bundle\ProfessionnelBundle\Entity\LstRegion" table="oru_repertoire_lst_region" />
</doctrine-mapping>
```

- Modifier la classe entité en retirant l'attribut id et en ajoutant l'héritage de la classe Lst :

``` php
namespace Oru\Bundle\RepertoireBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;

/**
 * LstRegion
 */
class LstRegion extends Lst
{
}
```

- Générer la classe type pour cette liste :

```
./app/console generate:doctrine:form OruRepertoireBundle:LstRegion
```

Vous devez hériter de la classe LstType pour uniformiser les formulaires de listes.

- Dans le fichier de déclaration de vos services, ajouter une nouvelle dépendance au service taggué ```oru_lst.lst```.

``` xml
...
        <service id="oru_professionnel.lst.repertoire_region" class="Oru\Bundle\ProfessionnelBundle\Entity\LstRegion">
            <tag name="oru_lst.lst" alias="repertoire_region" entityAlias="OruProfessionnelBundle:LstRegion" role="ORU_PROFESSIONNEL_ADMIN" />
            <call method="addNamespace">
                <argument>professionnel</argument>
            </call>
        </service>
...
```

On retrouve notre identifiant unique ```repertoire_region``` qui permet d'identifier cette liste.

Il est maintenant possible d'administrer cette liste en utilisant la route ```/lst/default/repertoire_region```. Toutes les listes sont administrables à l'adresse ```/lst/default```.
L'ajout d'un namespace permettra de bénéficier de l'administration de cette liste via la route ```/lst/professionnel```.

L'ajout d'un rôle surcharge le rôle par défaut ORU_LST_ADMIN qui permet d'administrer une liste.

### Divers

* Il est possible d'utiliser un service pour générer le formulaire de création ou d'édition. Il suffit d'ajouter l'attribut "formService" avec le nom du service Symfony dans le tag.

``` xml
...
        <service id="oru_bundle.lst.name" class="Oru\Bundle\...Bundle\Entity\LstName">
            <tag name="oru_lst.lst" formService="oru_bundle_form_service_name" />
        </service>
...
```

@todo : automatiser la création d'une liste

Pour toute question : acardoso@orupaca.fr
