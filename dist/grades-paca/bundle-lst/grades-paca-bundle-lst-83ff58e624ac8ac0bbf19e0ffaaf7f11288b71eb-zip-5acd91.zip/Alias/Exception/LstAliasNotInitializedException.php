<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 19/06/14
 */

namespace Oru\Bundle\LstBundle\Alias\Exception;

class LstAliasNotInitializedException extends \Exception
{
}
