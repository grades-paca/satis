<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 19/06/14
 */

namespace Oru\Bundle\LstBundle\Form;

use Oru\Bundle\LstBundle\Chain\LstChain;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Translation\TranslatorInterface;
use Symfony\Component\Validator\Constraints\NotBlank;

class LstChainType extends AbstractType
{
    private $lists;
    private $translator;

    public function __construct(LstChain $chain, TranslatorInterface $translator)
    {
        $this->lists = $chain->getLists();
        $this->translator = $translator;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $namespace = (isset($options['namespace'])) ? $options['namespace'] : 'default';
        $lists = array('' => '');
        foreach ($this->lists as $key => $list) {
            if ($list['classInstance']->getNamespaces() && array_search($namespace, $list['classInstance']->getNamespaces(), true) !== false) {
                $lists[$key] = $this->translator->trans($list['entityAlias'], array(), $list['translationDomain']);
            }
        }

        $builder
            ->add('list', ChoiceType::class, array('constraints' => array(new NotBlank()), 'required' => true, 'choices' => $lists, 'label' => 'list.name', 'translation_domain' => 'OruLstBundle', 'attr' => array('placeholder' => 'Choisissez la liste à administrer')));
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefined(array('namespace'));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'lst_form_chain';
    }
}
