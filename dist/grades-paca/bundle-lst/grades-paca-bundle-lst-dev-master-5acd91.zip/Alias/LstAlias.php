<?php
/**
 * Created by PhpStorm.
 * User: andre
 * Date: 18/12/13
 * Time: 11:37
 */

namespace Oru\Bundle\LstBundle\Alias;

use Doctrine\Common\Persistence\ObjectManager;
use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\LstBundle\Alias\Exception\LstAliasNotInitializedException;
use Oru\Bundle\LstBundle\Chain\LstChain;
use Oru\Bundle\LstBundle\Exception\LstNotFoundException;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Exception\RuntimeException;
use Symfony\Component\HttpKernel\Bundle\BundleInterface;

/**
 * Class LstAlias.
 */
class LstAlias
{
    /**
     * @var LstChain
     */
    private $chain;

    /**
     * @var \Doctrine\Common\Persistence\ObjectManager
     */
    private $manager;

    /**
     * @var bool
     */
    private $initialized;

    /**
     * @var string
     */
    private $list;

    /**
     * @var BundleInterface
     */
    private $bundle;

    /**
     * @var string
     */
    private $entity;

    /**
     * @var string
     */
    private $entityAlias;

    /**
     * @var string
     */
    private $translationDomain;

    /**
     * @var string
     */
    private $namespace;

    /**
     * @var string
     */
    private $formType;

    /**
     * @param ObjectManager $manager
     * @param LstChain      $chain
     *
     * @throws LstNotFoundException
     */
    public function __construct(ObjectManager $manager, LstChain $chain)
    {
        $this->manager = $manager;
        $this->chain = $chain;
        $this->initialized = false;
    }

    public function initialize($list)
    {
        $this->list = $list;
        $listClass = $this->chain->getListClassInstance($list);
        if ($listClass) {
            $reflection = new \ReflectionClass($listClass);
            $this->namespace = preg_replace('/\\\Entity/', '', $reflection->getNamespaceName());
            $this->entityAlias = $this->chain->getListEntityAlias($list);
            $this->formType = $this->chain->getListFormType($list);
            $this->bundle = $this->chain->getListBundle($list);
            $this->entity = $this->chain->getListEntity($list);
            $this->translationDomain = $this->chain->getListTranslationDomain($list);
            $this->initialized = true;
            $this->getEntityInstance();

            return $this;
        }
        throw new LstNotFoundException("No list found for {$list}.");
    }

    /**
     * @return object
     */
    public function getEntityInstance()
    {
        $this->checkInitialized();
        $object = $this->namespace.'\Entity\\'.$this->entity;

        return $this->getObject($object);
    }

    /**
     * @return AbstractType
     */
    public function getTypeInstance()
    {
        $this->checkInitialized();

        if($this->formType) {
            return $this->formType;
        }

        $object = $this->namespace."\Form\\{$this->entity}Type";

        return $object;
    }

    /**
     * @return object
     */
    public function getFilterInstance()
    {
        $this->checkInitialized();
        $object = $this->namespace."\Filter\\{$this->entity}Filter";

        return $this->getObject($object);
    }

    /**
     * @return AbstractType
     */
    public function getFilterTypeInstance()
    {
        $this->checkInitialized();
        $object = $this->namespace."\Form\\{$this->entity}FilterType";

        return $this->getObject($object);
    }

    /**
     * @return AbstractListingType
     */
    public function getListingInstance()
    {
        $this->checkInitialized();
        $object = $this->namespace."\Listing\\{$this->entity}ListingType";

        return $this->getObject($object);
    }

    /**
     * @throws RuntimeException
     *
     * @return mixed
     */
    public function getRepository()
    {
        $this->checkInitialized();

        return $this->manager->getRepository($this->entityAlias);
    }

    /**
     * @return string
     */
    public function getEntityAlias()
    {
        $this->checkInitialized();

        return $this->entityAlias;
    }

    public function getTranslationDomain()
    {
        $this->checkInitialized();

        return $this->translationDomain;
    }

    /**
     * @return string
     */
    public function getList()
    {
        return $this->list;
    }

    /**
     * @return string
     */
    public function getEntityClass()
    {
        return $this->namespace.'\Entity\\'.$this->entity;
    }

    /**
     * @param mixed $object
     *
     * @throws LstNotFoundException
     *
     * @return mixed
     */
    private function getObject($object)
    {
        if (class_exists($object)) {
            return new $object();
        }
        throw new LstNotFoundException("$object class not found with bundle '{$this->bundle}' and entity '{$this->entity}'.");
    }

    /**
     * @throws \Oru\Bundle\LstBundle\Alias\Exception\LstAliasNotInitializedException
     */
    private function checkInitialized()
    {
        if (!$this->initialized) {
            throw new LstAliasNotInitializedException('This instance of OruLstBundle:LstAlias is not initialized.');
        }
    }
}
