<?php

namespace Oru\Bundle\LstBundle\Entity;

/**
 * Interface LstAsipInterface.
 *
 * @author Michaël VEROUX
 */
interface LstAsipInterface
{
    /**
     * @return string
     */
    public function getOid();

    /**
     * @return string
     */
    public function getCodeAsip();
}
