<?php

namespace Oru\Bundle\LstBundle\Entity;

use DoctrineExtensions\Taggable\Taggable;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use APY\DataGridBundle\Grid\Mapping as GRID;
use JMS\Serializer\Annotation;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Mapping\ClassMetadata;

/**
 * @GRID\Source(columns="id, code, libelle")
 * @Annotation\ExclusionPolicy("all")
 */
class Lst implements Taggable, LstInterface
{
    /**
     * @var integer
     */
    protected $id;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    protected $code;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    protected $libelle;

    /**
     * @var \DateTime
     */
    protected $deleted;

    /**
     * @var Array tags associés
     */
    private $tags;

    /**
     * @var Datetime
     */
    private $created;

    /**
     * @var Datetime
     */
    private $updated;

    /**
     * @var integer
     */
    private $rang;

    /**
     * @var array
     */
    private $namespaces;

    /**
     * @param $namespaces
     */
    public function __construct()
    {
        $this->namespaces = array('default');
    }

    /**
     * @return array
     */
    public function getNamespaces()
    {
        return $this->namespaces;
    }

    /**
     * @param $namespace
     */
    public function addNamespace($namespace)
    {
        $this->namespaces[] =$namespace;
    }

    /**
     * @param $namespace
     */
    public function removeNamespace($namespace)
    {
        if(($key = array_search($namespace, $this->namespaces)) !== FALSE)
            unset($this->namespaces[$key]);
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set id
     *
     * @param string $id
     * @return lst
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @param string $code
     */
    public function setCode($code)
    {
        $this->code = $code;
    }

    /**
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set libelle
     *
     * @param string $libelle
     * @return Lst
     */
    public function setLibelle($libelle)
    {
        $this->libelle = $libelle;
    
        return $this;
    }

    /**
     * Get libelle
     *
     * @return string 
     */
    public function getLibelle()
    {
        return $this->libelle;
    }


    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->libelle;
    }

    /**
     * Set deleted
     *
     * @param \DateTime $deleted
     * @return Lst
     */
    public function setDeleted($deleted)
    {
        $this->deleted = $deleted;
    
        return $this;
    }

    /**
     * Get deleted
     *
     * @return \DateTime 
     */
    public function getDeleted()
    {
        return $this->deleted;
    }

    /**
     * @return ArrayCollection|\DoctrineExtensions\Taggable\Doctrine\Common\Collections\Collection
     */
    public function getTags()
    {
        $this->tags = $this->tags ?: new ArrayCollection();

        return $this->tags;
    }

    /**
     * @return string
     */
    public function getTaggableType()
    {
        return \Doctrine\Common\Util\ClassUtils::getRealClass(get_called_class());
    }

    /**
     * @return int|string
     */
    public function getTaggableId()
    {
        return $this->getId();
    }

    /**
     * @param \Oru\Bundle\LstBundle\Entity\Datetime $created
     */
    public function setCreated($created)
    {
        $this->created = $created;
    }

    /**
     * @return \Oru\Bundle\LstBundle\Entity\Datetime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param int $rang
     */
    public function setRang($rang)
    {
        $this->rang = $rang;
    }

    /**
     * @return int
     */
    public function getRang()
    {
        return $this->rang;
    }

    /**
     * @param \Oru\Bundle\LstBundle\Entity\Datetime $updated
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;
    }

    /**
     * @return \Oru\Bundle\LstBundle\Entity\Datetime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    public static function loadValidatorMetadata(ClassMetadata $metadata)
    {
        $metadata->addConstraint(new UniqueEntity(array(
            'fields'  => array('code', 'deleted'),
            'ignoreNull' => false,
            'message' => 'Ce code existe déjà.',
            'groups' => 'code_required'
        )));
    }
}