<?php

namespace Oru\Bundle\LstBundle\Controller;

use APY\DataGridBundle\Grid\Action\DeleteMassAction;
use APY\DataGridBundle\Grid\Action\MassAction;
use APY\DataGridBundle\Grid\Action\RowAction;
use APY\DataGridBundle\Grid\Export\CSVExport;
use APY\DataGridBundle\Grid\Export\ExcelExport;
use APY\DataGridBundle\Grid\Export\SCSVExport;
use APY\DataGridBundle\Grid\Source\Entity;
use Oru\Bundle\DesignBundle\Controller\FlashControllerTrait;
use Oru\Bundle\LstBundle\Alias\LstAlias;
use Oru\Bundle\LstBundle\Events\LstEvents;
use Oru\Bundle\LstBundle\Events\LstFormParamsEvent;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Oru\Bundle\LstBundle\Entity\Lst;
use Oru\Bundle\LstBundle\Form\LstType;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

/**
 * Lst controller.
 *
 */
class LstController extends Controller
{
    use FlashControllerTrait;

    /**
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     */
    public function indexAction(Request $request, $namespace)
    {
        if(!count($this->get('oru_lst.lst_chain')->getListsForNamespace($namespace))) {
            throw new AccessDeniedException("No lists or no permissions to edit at least one list.");
        }

        /* Well, a Big Mac's a Big Mac, but they call it le Big-Mac. */
        $form = $this->createListForm($namespace, $request->get('list', null));
        $form->handleRequest($request);
        if ($form->isValid()) {
            $data = $form->getData();
            return $this->redirect($this->generateUrl('lst', array('list' => $data['list'], 'namespace' => $namespace)));
        }

        return $this->render('OruLstBundle:Lst:index.html.twig', array(
            'form'      => $form->createView(),
            'namespace' => $namespace
        ));
    }

    /**
     * @param null $list
     */
    private function createListForm($namespace, $list = null) {
        return $this->createForm('lst_form_chain', array('list' => $list), array(
            'namespace' => $namespace,
            'action' => $this->generateUrl('lst_index', array('namespace' => $namespace)),
            'method' => 'POST'
        ));
    }

    /**
     * Lists all Lst entities.
     *
     * @param mixed $list The list
     *
     */
    public function lstAction(Request $request, $namespace, $list)
    {
        $em = $this->getDoctrine()->getManager();

        $form = $this->createListForm($namespace, $list);

        $alias = $this->get('oru_lst.alias')->initialize($list);
        $source = new Entity($alias->getEntityAlias());

        $tableAlias = $source->getTableAlias();

        $queryBuilder = $em->createQueryBuilder($tableAlias)->from($alias->getEntityAlias(), $tableAlias);

        $source->initQueryBuilder($queryBuilder);

        $grid = $this->get('grid');

        $grid->setSource($source);

        $rowAction = new RowAction($this->get('translator')->trans('edit'), 'lst_edit');
        $rowAction->setRouteParameters(array('id', 'list' => $list, 'namespace' => $namespace));
        $grid->addRowAction($rowAction);

        $grid->addMassAction(new DeleteMassAction());

        $grid->addExport(new CSVExport($this->get('translator')->trans('CSV export')));
        $grid->addExport(new SCSVExport($this->get('translator')->trans('SCSV export')));
        $grid->addExport(new ExcelExport($this->get('translator')->trans('Excel export')));

        // Return the response of the grid to the template
        return $grid->getGridResponse('OruLstBundle:Lst:lst.html.twig', array(
            'translationDomain' => $alias->getTranslationDomain(),
            'list'              => $list,
            'form'              => $form->createView(),
            'namespace'           => $namespace
        ));
    }

    /**
     * Creates a new Lst entity.
     *
     * @param mixed $list The list
     *
     */
    public function createAction(Request $request, $namespace, $list)
    {
        $alias = $this->get('oru_lst.alias')->initialize($list);
        $entity = $alias->getEntityInstance();
        $form = $this->createCreateForm($alias, $entity, $namespace);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($entity);
            $em->flush();

            $this->addSessionMessage($this->get('translator')->trans('list.added', array(), 'OruLstBundle'), 'notice');
            return $this->redirect($this->generateUrl('lst_new', array('namespace' => $namespace, 'list' => $list, 'id' => $entity->getId())));
        }

        return $this->render('OruLstBundle:Lst:edit.html.twig', array(
            'entity'    => $entity,
            'form'      => $form->createView(),
            'name'      => $this->get('translator')->trans($alias->getEntityAlias(),array(),$alias->getTranslationDomain()),
            'list'      => $list,
            'namespace'   => $namespace
        ));
    }

    /**
    * Creates a form to create a Lst entity.
    *
    * @param LstAlias $alias The entity alias
    * @param Lst $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    */
    private function createCreateForm(LstAlias $alias, Lst $entity, $namespace)
    {
        $params = array(
            'action' => $this->generateUrl('lst_create', array('namespace' => $namespace, 'list' => $alias->getList())),
            'method' => 'POST',
            'attr' => array('id' => 'lst_form')
        );
        $event = new LstFormParamsEvent($alias, $params);
        $this->get('event_dispatcher')->dispatch(LstEvents::LST_FORM_PARAMS, $event);

        $form = $this->createForm($this->get('oru_lst.form.loader')->loadObject($alias->getTypeInstance()), $entity, $event->getParams());
        $form->add('submit', 'submit', array('label' => $this->get('translator')->trans('listing.action.create_and_add')));

        return $form;
    }

    /**
     * Displays a form to create a new Lst entity.
     *
     * @param mixed $list The list
     *
     */
    public function newAction(Request $request, $namespace, $list)
    {
        $alias = $this->get('oru_lst.alias')->initialize($list);
        $entity = $this->get('oru_lst.alias')->getEntityInstance();
        $form   = $this->createCreateForm($alias, $entity, $namespace);

        return $this->render('OruLstBundle:Lst:edit.html.twig', array(
            'entity'    => $entity,
            'form'      => $form->createView(),
            'name'      => $this->get('translator')->trans($alias->getEntityAlias(),array(),$alias->getTranslationDomain()),
            'list'      => $list,
            'namespace'   => $namespace
        ));
    }

    /**
     * Finds and displays a Lst entity.
     *
     * @param mixed $list The list
     * @param mixed $id The entity id
     *
     */
    public function showAction(Request $request, $namespace, $list, $id)
    {
        $em = $this->getDoctrine()->getManager();
        if($em->getFilters()->isEnabled('softdeleteable')) {
            $em->getFilters()->disable('softdeleteable');
        }
        $alias = $this->get('oru_lst.alias')->initialize($list);
        $entity = $alias->getRepository()->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Lst entity.');
        }
        $em->getFilters()->enable('softdeleteable');
        $deleteForm = $this->createDeleteForm($alias, $id, $namespace);

        return $this->render('OruLstBundle:Lst:show.html.twig', array(
            'entity'        => $entity,
            'delete_form'   => $deleteForm->createView(),
            'name'          => $this->get('translator')->trans($alias->getEntityAlias(),array(),$alias->getTranslationDomain()),
            'list'          => $list,
            'namespace'       => $namespace
        ));
    }

    /**
     * Displays a form to edit an existing Lst entity.
     *
     * @param mixed $list The list
     * @param mixed $id The entity id
     *
     */
    public function editAction(Request $request, $namespace, $list, $id)
    {
        $em = $this->getDoctrine()->getManager();
        if($em->getFilters()->isEnabled('softdeleteable')) {
            $em->getFilters()->disable('softdeleteable');
        }
        $alias = $this->get('oru_lst.alias')->initialize($list);
        $entity = $alias->getRepository()->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Lst entity.');
        }
        $em->getFilters()->enable('softdeleteable');

        $editForm = $this->createEditForm($alias, $entity, $namespace);
        $deleteForm = $this->createDeleteForm($alias, $id, $namespace);

        return $this->render('OruLstBundle:Lst:edit.html.twig', array(
            'entity'        => $entity,
            'form'          => $editForm->createView(),
            'delete_form'   => $deleteForm->createView(),
            'name'          => $this->get('translator')->trans($alias->getEntityAlias(),array(),$alias->getTranslationDomain()),
            'list'          => $list,
            'namespace'       => $namespace
        ));
    }

    /**
    * Creates a form to edit a Lst entity.
    *
    * @param LstAlias $alias The entity alias
    * @param Lst $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    */
    private function createEditForm(LstAlias $alias, Lst $entity, $namespace)
    {
        $params = array(
            'action' => $this->generateUrl('lst_update', array('namespace' => $namespace, 'list' => $alias->getList(), 'id' => $entity->getId())),
            'method' => 'PUT',
            'attr' => array('id' => 'lst_form')
        );
        $event = new LstFormParamsEvent($alias, $params);
        $this->get('event_dispatcher')->dispatch(LstEvents::LST_FORM_PARAMS, $event);

        $form = $this->createForm($this->get('oru_lst.form.loader')->loadObject($alias->getTypeInstance()), $entity, $event->getParams());
        $form->add('submit', 'submit', array('label' => $this->get('translator')->trans('listing.action.update')));

        return $form;
    }
    /**
     * Edits an existing Lst entity.
     *
     * @param mixed $list The list
     * @param mixed $id The entity id
     *
     */
    public function updateAction(Request $request, $namespace, $list, $id)
    {
        $alias = $this->get('oru_lst.alias')->initialize($list);
        $em = $this->getDoctrine()->getManager();

        $entity = $alias->getRepository()->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Lst entity.');
        }

        $deleteForm = $this->createDeleteForm($alias, $id, $namespace);
        $editForm = $this->createEditForm($alias, $entity, $namespace);
        $editForm->handleRequest($request);

        if ($editForm->isValid()) {
            $em->flush();

            $this->addSessionMessage($this->get('translator')->trans('list.updated', array(), 'OruLstBundle'), 'notice');
            return $this->redirect($this->generateUrl('lst', array('namespace' => $namespace, 'list' => $list)));
        }

        return $this->render('OruLstBundle:Lst:edit.html.twig', array(
            'entity'        => $entity,
            'form'          => $editForm->createView(),
            'delete_form'   => $deleteForm->createView(),
            'name'          => $this->get('translator')->trans($alias->getEntityAlias(),array(),$alias->getTranslationDomain()),
            'list'          => $list,
            'namespace'       => $namespace
        ));
    }
    /**
     * Deletes a Lst entity.
     *
     * @param mixed $list The list
     * @param mixed $id The entity id
     *
     */
    public function deleteAction(Request $request, $namespace, $list, $id)
    {
        $alias = $this->get('oru_lst.alias')->initialize($list);
        $em = $this->getDoctrine()->getManager();

        $form = $this->createDeleteForm($alias, $id, $namespace);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $entity = $alias->getRepository()->find($id);

            if (!$entity) {
                throw $this->createNotFoundException('Unable to find Lst entity.');
            }

            $em->remove($entity);
            $em->flush();

            $this->addSessionMessage($this->get('translator')->trans('list.deleted', array(), 'OruLstBundle'), 'notice');
        }

        return $this->redirect($this->generateUrl('lst', array('list' => $list, 'namespace' => $namespace)));
    }

    /**
     * Creates a form to delete a Lst entity by id.
     *
     * @param mixed $list The list
     * @param mixed $id The entity id
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(LstAlias $alias, $id, $namespace)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('lst_delete', array('list' => $alias->getList(), 'id' => $id, 'namespace' => $namespace)))
            ->setMethod('DELETE')
            ->add('submit', 'submit', array('label' => 'Archive'))
            ->getForm()
        ;
    }


}
