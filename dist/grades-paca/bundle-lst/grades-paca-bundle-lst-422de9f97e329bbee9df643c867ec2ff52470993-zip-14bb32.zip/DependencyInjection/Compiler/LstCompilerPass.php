<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 19/06/14
 */

namespace Oru\Bundle\LstBundle\DependencyInjection\Compiler;


use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Reference;

class LstCompilerPass implements CompilerPassInterface {

    public function process(ContainerBuilder $container)
    {
        if (!$container->hasDefinition('oru_lst.lst_chain')) {
            return;
        }

        $definition = $container->getDefinition(
            'oru_lst.lst_chain'
        );

        $taggedServices = $container->findTaggedServiceIds(
            'oru_lst.lst'
        );

        foreach ($taggedServices as $id => $tagAttributes) {
            foreach ($tagAttributes as $attributes) {
                try {
                    $restricted = isset($attributes['restricted']) && $container->getParameter($attributes['restricted']);
                } catch (\Exception $e) {
                    $restricted = true;
                }

                if(isset($attributes['alias']) && isset($attributes['entityAlias']) && !$restricted) {
                    $definition->addMethodCall(
                        'addList',
                        array(
                            new Reference($id),
                            $attributes['alias'],
                            $attributes['entityAlias'],
                            ((isset($attributes['translationDomain'])) ? $attributes['translationDomain'] : null),
                            ((isset($attributes['role'])) ? $attributes['role'] : null),
                            ((isset($attributes['formService'])) ? $attributes['formService'] : null)
                        )
                    );
                }
            }
        }
    }
} 