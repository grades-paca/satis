$(function() {
    $('#lst_form_chain_list').change(function() {
        $('#lst_form_chain').parent('form').submit();
    });
});