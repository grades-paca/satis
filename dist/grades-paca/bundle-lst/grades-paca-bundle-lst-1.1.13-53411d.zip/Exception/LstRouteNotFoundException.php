<?php
/**
 * Created by PhpStorm.
 * User: andre
 * Date: 18/12/13
 * Time: 10:44
 */

namespace Oru\Bundle\LstBundle\Exception;

/**
 * Class LstRouteNotFoundException
 * @package Oru\Bundle\LstBundle\Exception
 */
class LstRouteNotFoundException extends \RuntimeException {
}