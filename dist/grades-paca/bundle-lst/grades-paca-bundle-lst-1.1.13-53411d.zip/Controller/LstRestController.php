<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LstBundle\Controller;


use Doctrine\ORM\EntityRepository;
use FOS\RestBundle\Controller\Annotations as Rest;
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\Request\ParamFetcherInterface;
use JMS\Serializer\SerializationContext;
use Oru\Bundle\LstBundle\Entity\LstRepository;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\Security\Core\User\UserInterface;

use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\View as RestView;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;


class LstRestController extends FOSRestController {

    /**
     * Ce webservice permet de récupérer la liste des éléments d'une liste administrable.
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @QueryParam(name="lst", requirements="[A-Za-z0-9_]+", nullable=false, description="Nom de la liste")
     * @QueryParam(name="offset", requirements="[0-9]+", nullable=false, description="Offset de départ", default="0")
     * @QueryParam(name="limit", requirements="[0-9]+", nullable=false, description="Nombre d'éléments", default="1000")
     *
     * @RestView(serializerGroups={"Default", "webservice"})
     *
     * @ApiDoc()
     */
    public function lstAllAction(ParamFetcherInterface $paramFetcher)
    {
        $user = $this->container->get('security.token_storage')->getToken()->getUser();
        if (!is_object($user) || !$user instanceof UserInterface) {
            throw new AccessDeniedException('This user does not have access to this section.');
        }

        $liste = $this->get('oru_lst.alias')->initialize($paramFetcher->get('lst'));
        $results = $liste->getRepository()->findAllAndDuplicated($paramFetcher->get('limit'), $paramFetcher->get('offset'));

        return $results;
    }

    /**
     * Ce webservice permet d'effectuer une recherche sur les éléments d'une liste administrable
     * Note: La liste doit avoir un Repository qui hérite de LstRepository pour pouvoir utiliser sa méthode générique de recherche (c'est le cas par défaut)
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @Rest\Get(
     *     options={"expose" = true}
     * )
     * @QueryParam(name="lst", requirements="[A-Za-z0-9_]+", nullable=false, description="Nom de la liste")
     * @QueryParam(name="search", requirements="[A-Za-z0-9_]+", nullable=false, description="Terme à rechercher")
     * @QueryParam(name="page_limit", requirements="[A-Za-z0-9_]+", nullable=true, description="Pagination, nombre maximum d'éléments recherchés")
     * @QueryParam(name="first", requirements="[A-Za-z0-9_]+", nullable=true, description="Pagination, index du premier élément recherché")
     * @QueryParam(name="total", requirements="[A-Za-z0-9_]+", nullable=true, description="Pagination, permet la récupération du total de résultats pour cette recherche")
     *
     * @RestView(serializerGroups={"Default", "search"})
     *
     * @ApiDoc()
     */
    public function lstSearchAction(ParamFetcherInterface $paramFetcher)
    {
        $user = $this->container->get('security.token_storage')->getToken()->getUser();
        if (!is_object($user) || !$user instanceof UserInterface) {
            throw new AccessDeniedException('This user does not have access to this section.');
        }

        //Initialisation de la liste passée en paramètre
        $lstChain = $this->get('oru_lst.lst_chain');
        $lstChain->forceEnableRestrictedLists(); //les listes même restreintes en administration et synchro, doivent pouvoir être utilisées pour la recherche
        $liste = $this->get('oru_lst.alias')->initialize($paramFetcher->get('lst'));
        $lstChain->disableRestrictedLists(); //Par sécurité, on désactive les listes restreintes activées plus haut

        /** @var LstRepository $repository */
        $repository = $liste->getRepository();

        //Récupération des paramètres de recherche
        $search = $paramFetcher->get('search');

        $pageLimit = $paramFetcher->get('page_limit');
        if (!is_numeric($pageLimit) || $pageLimit > 100) {
            $pageLimit = 10;
        }

        $first = 0;
        $fetchFirst = $paramFetcher->get('first');
        if ($fetchFirst) {
            $first = $fetchFirst;
        }

        $total = 0;
        $totalFetch = $paramFetcher->get('total'); //Le paramètre "total" était anciennement appelé "infinite_scroll", il est utilisé notamment dans ce cadre
        if ($totalFetch) {
            $total = $repository->searchByLibelle($search, $pageLimit, $first, true);
        }

        $results = $repository->searchByLibelle($search, $pageLimit, $first);

        return array(
            'total'     => $totalFetch ? $total : null,
            'results'   => $results
        );
    }

    /**
     * Ce webservice permet de récupérer la configuration d'un élément d'une liste administrable dont le code est fourni en argument.
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @QueryParam(name="lst", requirements="[A-Za-z0-9_]+", nullable=false, description="Nom de la liste")
     * @QueryParam(name="code", requirements="[A-Za-z0-9]+", nullable=false, description="Code de l'élément")
     *
     * @RestView(serializerGroups={"Default"})
     *
     * @ApiDoc()
     */
    public function lstConfigAction(ParamFetcherInterface $paramFetcher)
    {
        $user = $this->container->get('security.token_storage')->getToken()->getUser();
        if (!is_object($user) || !$user instanceof UserInterface) {
            throw new AccessDeniedException('This user does not have access to this section.');
        }

        $liste = $this->get('oru_lst.alias')->initialize($paramFetcher->get('lst'));
        $result = $liste->getRepository()->findByCode($paramFetcher->get('code'));
        $view = $this->view($result);
        $context = SerializationContext::create()->setGroups(array('webservice'));
        $view->setSerializationContext($context);
        return $this->handleView($view);
    }

}