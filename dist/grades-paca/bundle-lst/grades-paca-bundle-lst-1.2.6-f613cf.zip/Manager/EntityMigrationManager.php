<?php
/**
 * Created by PhpStorm.
 * User: tdepreau
 * Date: 20/09/2017
 * Time: 16:10
 */

namespace Oru\Bundle\LstBundle\Manager;

use Doctrine\Common\Inflector\Inflector;
use Doctrine\ORM\EntityManager;
use Oru\Bundle\SynchroBundle\Event\LstMigrationEvent;

final class EntityMigrationManager
{
    /**
     * @param LstMigrationEvent $event
     * @param $newLst
     * @param string $fieldName
     * @param $objectClass
     * @param $collection
     * @param mixed $classes
     *
     * @throws \Exception
     */
    public static function migrateEntityLstAssociation(LstMigrationEvent $event, $classes, EntityManager $em)
    {
        $lstClassname = get_class($event->getLst());

        $builder = $em->getRepository($lstClassname)->createQueryBuilder('l');
        $newLst = $builder
            ->select('l')
            ->where('l.code = ( :code )')
            ->setParameter('code', $event->getNewCode())
            ->getQuery()
            ->getOneOrNullResult()
        ;

        if (!$newLst) {
            throw new \Exception("La liste de code {$event->getNewCode()} n'existe pas localement pour la classe '$lstClassname'.");
        }

        foreach ($classes as $entityClass) {
            $objectClass = null;
            $entityClassName = get_class($entityClass);
            if (!$entityClassName or empty($entityClassName)) {
                continue;
            }
            $asso = $em->getClassMetadata($entityClassName)->getAssociationsByTargetClass($lstClassname);
            if (!$asso) {
                continue;
            }
            $asso = reset($asso);
            if (isset($asso['fieldName'])) {
                $fieldName = $asso['fieldName'];
                if ($em->getFilters()->isEnabled('softdeleteable')) {
                    $em->getFilters()->disable('softdeleteable');
                }
                $builder = $em->getRepository($entityClassName)->createQueryBuilder('e');
                $collection = $builder
                    ->select('e')
                    ->join("e.$fieldName", 'l', 'with', 'l.code = ( :code )')
                    ->setParameter('code', $event->getLst()->getCode())
                    ->getQuery()
                    ->getResult()
                ;

                if (!$collection) {
                    $em->getFilters()->enable('softdeleteable');
                    continue;
                }

                $methode = ucfirst(Inflector::singularize($fieldName));
                $methodePlu = ucfirst($fieldName);
                $batchSize = 100;
                $i = 0;
                if (method_exists($entityClass, "add$methode") and (method_exists($entityClass, "remove$methode"))) {
                    foreach ($collection as $entity) {
                        $associations = null;
                        if (method_exists($entityClass, "get$methodePlu")) {
                            $associations = $entity->{"get$methodePlu"}();
                        } elseif (method_exists($entityClass, "get$methode")) {
                            $associations = $entity->{"get$methode"}(); //dans le cas ou le guetter est mal nommé
                        }
                        $entity->{"remove$methode"}($event->getLst());
                        if ($associations and $associations instanceof \Traversable) {
                            foreach ($associations as $association) {
                                if ($association->getCode() === $event->getNewCode()) {
                                    continue 2;
                                }
                            }
                        }
                        $entity->{"add$methode"}($newLst);
                        if (($i % $batchSize) === 0) {
                            $em->flush();
                        }
                        ++$i;
                    }
                    $em->flush();
                } elseif (method_exists($entityClass, "set$methode")) {
                    foreach ($collection as $entity) {
                        $entity->{"set$methode"}($newLst);
                        if (($i % $batchSize) === 0) {
                            $em->flush();
                        }
                        ++$i;
                    }
                    $em->flush();
                } else {
                    throw new \Exception("La liste de code {$event->getNewCode()} n'a pas de guetter 'add$methode', 'remove$methode' ou set$methode");
                }

                $em->getFilters()->enable('softdeleteable');
            }
        }
    }
}
