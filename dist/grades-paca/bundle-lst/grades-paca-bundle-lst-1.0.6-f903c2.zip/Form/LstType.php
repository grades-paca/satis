<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 03/04/14
 */

namespace Oru\Bundle\LstBundle\Form;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;

abstract class LstType extends AbstractType {

    protected $securityContext;
    protected $roleAdmin;
    protected $checkFunction;
    protected $restrictedLists;

    public function __construct() {
        $this->securityContext = null;
        $this->roleAdmin = null;
        $this->checkFunction = 'isGranted';
    }

    public function setSecurityContext($securityContext) {
        $this->securityContext = $securityContext;
    }

    public function setRoleAdmin($roleAdmin) {
        $this->roleAdmin = $roleAdmin;
    }

    public function setCheckFunction($checkFunction) {
        $this->checkFunction = $checkFunction;
    }

    public function setRestrictedLists($restricted) {
        $this->restrictedLists = $restricted;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('code', null, array('required' => true, 'label' => 'list.code', 'translation_domain' => 'OruLstBundle'))
            ->add('libelle', null, array('required' => true, 'label' => 'list.libelle', 'translation_domain' => 'OruLstBundle'))
        ;

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function(FormEvent $event) {
            $lst = $event->getData();
            $form = $event->getForm();
            if ($lst && $lst->getId()) {
                $form->remove('code');
            }
        });
    }

} 