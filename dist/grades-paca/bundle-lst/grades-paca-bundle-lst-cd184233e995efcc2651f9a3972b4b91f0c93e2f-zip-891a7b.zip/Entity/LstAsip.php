<?php

namespace Oru\Bundle\LstBundle\Entity;

use JMS\Serializer\Annotation;
use APY\DataGridBundle\Grid\Mapping as GRID;

/**
 * Class LstAsip.
 * @GRID\Source(columns="id, code, codeDuplicated, libelle, updated, oid, codeAsip")
 *
 * @author Michaël VEROUX
 */
class LstAsip extends Lst implements LstAsipInterface
{
    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    protected $oid;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})*
     */
    protected $codeAsip;

    /**
     * @return string
     */
    public function getOid()
    {
        return $this->oid;
    }

    /**
     * @param string $oid
     */
    public function setOid($oid)
    {
        $this->oid = $oid;
    }

    /**
     * @return string
     */
    public function getCodeAsip()
    {
        return $this->codeAsip;
    }

    /**
     * @param string $codeAsip
     */
    public function setCodeAsip($codeAsip)
    {
        $this->codeAsip = $codeAsip;
    }
}
