<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LstBundle\Events;
use Oru\Bundle\LstBundle\Entity\Lst;
use Symfony\Component\EventDispatcher\Event;


/**
 * Class LstGridClosure
 * @package Oru\Bundle\LstBundle\Events
 *
 * Classe permettant de modifier les données affichées dans un tableau APYDataGrid
 */
class LstGridClosureEvent extends Event
{
    /**
     * @var string name of the list
     */
    protected $list;

    /**
     * @var \Closure
     */
    protected $closure;

    /**
     * LstGridClosure constructor.
     */
    public function __construct($list)
    {
        $this->list = $list;
    }

    /**
     * @return mixed
     */
    public function getList()
    {
        return $this->list;
    }

    /**
     * @return \Closure
     */
    public function getClosure()
    {
        return $this->closure;
    }

    /**
     * @param \Closure $closure
     */
    public function setClosure($closure)
    {
        $this->closure = $closure;
    }
}