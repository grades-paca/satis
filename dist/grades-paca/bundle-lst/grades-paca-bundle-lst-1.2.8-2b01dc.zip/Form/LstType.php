<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 03/04/14
 */

namespace Oru\Bundle\LstBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

abstract class LstType extends AbstractType
{
    protected $securityContext;
    protected $roleAdmin;
    protected $checkFunction;
    protected $restrictedLists;

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $services = (isset($options['services'])) ? $options['services'] : null;
        $this->securityContext = (method_exists($services, 'getSecurityContext')) ? $services->getSecurityContext() : null;
        $this->roleAdmin = (method_exists($services, 'getRoleAdmin')) ? $services->getRoleAdmin() : null;
        $this->checkFunction = (method_exists($services, 'getCheckFunction')) ? $services->getCheckFunction() : 'isGranted';
        $this->restrictedLists = (method_exists($services, 'getRestrictedLists')) ? $services->getRestrictedLists() : null;

        $options = array();
        if (!($this->securityContext and call_user_func_array(array($this->securityContext, $this->checkFunction), array('ORU_LST_MIGRATION')))) {
            $options = array('disabled' => true, 'attr' => array('readonly' => true));
        }
        $builder
            ->add('code', null, array('required' => true, 'label' => 'list.code', 'translation_domain' => 'OruLstBundle'))
            ->add('codeDuplicated', null, array_merge_recursive($options, array('required' => false, 'label' => 'list.codeDuplicated', 'translation_domain' => 'OruLstBundle')))
            ->add('libelle', null, array('required' => true, 'label' => 'list.libelle', 'translation_domain' => 'OruLstBundle'))
        ;

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) {
            $lst = $event->getData();
            $form = $event->getForm();
            if ($lst && $lst->getId()) {
                $form->remove('code');
            }
        });
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefined(array('services'));
    }
}
