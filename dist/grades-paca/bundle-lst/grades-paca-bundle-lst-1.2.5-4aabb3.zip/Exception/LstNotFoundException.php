<?php
/**
 * Created by PhpStorm.
 * User: andre
 * Date: 18/12/13
 * Time: 10:44
 */

namespace Oru\Bundle\LstBundle\Exception;

/**
 * Class LstNotFoundException.
 */
class LstNotFoundException extends \RuntimeException
{
}
