<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 27/06/14
 */

namespace Oru\Bundle\LstBundle\Form;

use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

class LstLoaderType
{
    private $roleAdmin;
    private $securityContext;
    private $restrictedLists;

    public function __construct(AuthorizationCheckerInterface $securityContext, $roleAdmin, $restrictedLists)
    {
        $this->securityContext = $securityContext;
        $this->roleAdmin = $roleAdmin;
        $this->restrictedLists = $restrictedLists;
    }

    public function loadObject($lstType)
    {
        if (method_exists($lstType, 'setSecurityContext')) {
            $lstType->setSecurityContext($this->securityContext);
        }

        if (method_exists($lstType, 'setRoleAdmin')) {
            $lstType->setRoleAdmin($this->roleAdmin);
        }

        if (method_exists($lstType, 'setRestrictedLists')) {
            $lstType->setRestrictedLists($this->restrictedLists);
        }

        return $lstType;
    }
}
