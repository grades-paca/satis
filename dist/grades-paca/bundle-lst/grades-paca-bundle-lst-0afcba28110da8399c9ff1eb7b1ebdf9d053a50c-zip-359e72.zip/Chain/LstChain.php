<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 19/06/14
 */

namespace Oru\Bundle\LstBundle\Chain;

use Oru\Bundle\LstBundle\Entity\Lst;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

class LstChain {

    /**
     * @var array
     */
    private $lists;

    /**
     * @var AuthorizationCheckerInterface
     */
    private $securityContext;

    /**
     * @var string
     */
    private $adminRole;

    public function __construct(AuthorizationCheckerInterface $securityContext, $adminRole)
    {
        $this->lists = array();
        $this->securityContext = $securityContext;
        $this->adminRole = $adminRole;
    }

    public function addList(Lst $list, $alias, $entityAlias, $translationDomain = null, $role = null)
    {
        if($this->checkPermissions($role))
        {
            list($bundle, $entity) = preg_split('/:/', $entityAlias);
            $this->lists[$alias] = array(
                'classInstance' => $list,
                'entityAlias' => $entityAlias,
                'bundle' => $bundle,
                'entity' => $entity,
                'translationDomain' => ($translationDomain) ? $translationDomain : $bundle,
                'role' => $role
            );
        }
    }

    public function getLists()
    {
        return $this->lists;
    }

    /**
     * Get lists for namespace
     *
     * @param $namespace
     * @return array
     */
    public function getListsForNamespace($namespace)
    {
        $lists = array();
        foreach($this->lists as $key => $list) {
            if($list['classInstance']->getNamespaces() && array_search($namespace,$list['classInstance']->getNamespaces()) !== FALSE)
            {
                $lists[$key] = $list;
            }
        }
        return $lists;
    }

    public function getListClassInstance($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['classInstance'];
        }
        return false;
    }

    public function getListEntityAlias($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['entityAlias'];
        }
        return false;
    }

    public function getListTranslationDomain($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['translationDomain'];
        }
        return false;
    }

    public function getListBundle($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['bundle'];
        }
        return false;
    }

    public function getListEntity($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['entity'];
        }
        return false;
    }

    public function getListRole($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['role'];
        }
        return false;
    }

    protected function checkPermissions($role)
    {
        if (($role != null && $this->securityContext->isGranted($role) === false) || ($role == null && $this->securityContext->isGranted($this->adminRole) === false)) {
            return false;
        }

        return true;
    }
} 