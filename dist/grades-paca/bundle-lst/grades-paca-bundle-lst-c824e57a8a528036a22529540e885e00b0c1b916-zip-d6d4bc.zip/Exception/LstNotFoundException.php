<?php
/**
 * Created by PhpStorm.
 * User: andre
 * Date: 18/12/13
 * Time: 10:44
 */

namespace Oru\Bundle\LstBundle\Exception;

/**
 * Class LstNotFoundException
 * @package Oru\Bundle\LstBundle\Exception
 */
class LstNotFoundException extends \RuntimeException {
} 