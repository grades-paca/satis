<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 19/06/14
 */

namespace Oru\Bundle\LstBundle\Chain;

use Oru\Bundle\LstBundle\Entity\Lst;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

class LstChain
{
    /**
     * @var array
     */
    private $lists;

    /**
     * @var array
     */
    private $restrictedLists;

    /**
     * @var AuthorizationCheckerInterface
     */
    private $securityContext;

    /**
     * @var string
     */
    private $adminRole;

    /**
     * @var string
     */
    private $viewRole;

    public function __construct(AuthorizationCheckerInterface $securityContext, $adminRole, $viewRole)
    {
        $this->lists = array();
        $this->restrictedLists = array();
        $this->securityContext = $securityContext;
        $this->adminRole = $adminRole;
        $this->viewRole = $viewRole;
    }

    public function addList(Lst $list, $alias, $entityAlias, $translationDomain = null, $adminRole = null, $formType = null, $restricted = false)
    {
        if ($this->checkViewPermissions()) {
            list($bundle, $entity) = preg_split('/:/', $entityAlias);
            $listConfig = array(
                'classInstance' => $list,
                'entityAlias' => $entityAlias,
                'formType' => $formType,
                'bundle' => $bundle,
                'entity' => $entity,
                'translationDomain' => ($translationDomain) ? $translationDomain : $bundle,
                'adminRole' => $adminRole,
            );

            if (!$restricted) {
                $this->lists[$alias] = $listConfig;
            } else {
                $this->restrictedLists[$alias] = $listConfig;
            }
        }
    }

    public function getLists()
    {
        return $this->lists;
    }

    /**
     * Permet de forcer l'utilisation des listes restreintes en basculant les listes restricted dans le tableau général des listes, récupérables dans getLists()
     * /!\ Attention, cette méthode doit-être utilisée en connaissance de cause car elle active les listes restreintes pour toute la stack en cours.
     */
    public function forceEnableRestrictedLists()
    {
        $this->lists = array_merge($this->lists, $this->restrictedLists);
    }

    /**
     * Permet de désactiver les listes restreintes (à utiliser après forceEnableRestrictedLists), et ainsi revenir à l'état initial des listes.
     */
    public function disableRestrictedLists()
    {
        foreach (array_keys($this->restrictedLists) as $key) {
            if (array_key_exists($key, $this->lists)) {
                unset($this->lists[$key]);
            }
        }
    }

    /**
     * Get lists for namespace.
     *
     * @param $namespace
     *
     * @return array
     */
    public function getListsForNamespace($namespace)
    {
        $lists = array();
        foreach ($this->lists as $key => $list) {
            if ($list['classInstance']->getNamespaces() && array_search($namespace, $list['classInstance']->getNamespaces(), true) !== false) {
                $lists[$key] = $list;
            }
        }

        return $lists;
    }

    public function getListClassInstance($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['classInstance'];
        }

        return false;
    }

    public function getListEntityAlias($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['entityAlias'];
        }

        return false;
    }

    public function getListTranslationDomain($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['translationDomain'];
        }

        return false;
    }

    public function getListBundle($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['bundle'];
        }

        return false;
    }

    public function getListEntity($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['entity'];
        }

        return false;
    }

    public function getListAdminRole($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['adminRole'];
        }

        return false;
    }

    public function getListFormType($alias)
    {
        if (array_key_exists($alias, $this->lists)) {
            return $this->lists[$alias]['formType'];
        }

        return false;
    }

    /**
     * Check if user can view list.
     *
     * @param $role
     * @return bool
     */
    public function checkViewPermissions()
    {
        if ($this->securityContext->isGranted($this->viewRole)) {
            return true;
        }

        return $this->checkAdminPermissions();
    }

    /**
     * Check if user can admin list.
     *
     * @param null $alias List Alias (null = check adminRole)
     * @return bool
     */
    public function checkAdminPermissions($alias = null)
    {
        //On récupère la configuration de rôle particulière s'il y en a une pour cette liste
        $listRole = $alias ? $this->getListAdminRole($alias) : null;
        $role = $listRole ? $listRole : null;

        if (($role !== null && $this->securityContext->isGranted($role)) || ($role === null && $this->securityContext->isGranted($this->adminRole))) {
            return true;
        }

        return false;
    }
}
