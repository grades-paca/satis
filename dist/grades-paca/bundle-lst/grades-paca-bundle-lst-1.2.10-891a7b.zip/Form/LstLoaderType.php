<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 27/06/14
 */

namespace Oru\Bundle\LstBundle\Form;

use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

class LstLoaderType
{
    private $roleAdmin;
    private $securityContext;
    private $restrictedLists;

    public function __construct(AuthorizationCheckerInterface $securityContext, $roleAdmin, $restrictedLists)
    {
        $this->securityContext = $securityContext;
        $this->roleAdmin = $roleAdmin;
        $this->restrictedLists = $restrictedLists;
    }

    /**
     * @return mixed
     */
    public function getRoleAdmin()
    {
        return $this->roleAdmin;
    }

    /**
     * @return AuthorizationCheckerInterface
     */
    public function getSecurityContext()
    {
        return $this->securityContext;
    }

    /**
     * @return mixed
     */
    public function getRestrictedLists()
    {
        return $this->restrictedLists;
    }
}
