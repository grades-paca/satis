<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LstBundle\Events;

use Oru\Bundle\LstBundle\Alias\LstAlias;
use Symfony\Component\EventDispatcher\Event;

class LstFormParamsEvent extends Event
{
    /**
     * @var array
     */
    protected $params;

    /**
     * @var LstAlias
     */
    protected $alias;

    /**
     * LstFormParamsEvent constructor.
     *
     * @param $alias LstAlias
     * @param $params array
     */
    public function __construct(LstAlias $alias, $params)
    {
        $this->params = $params;
        $this->alias = $alias;
    }

    /**
     * @return array
     */
    public function getParams()
    {
        return $this->params;
    }

    /**
     * @param array $params
     */
    public function setParams($params)
    {
        $this->params = $params;
    }

    /**
     * @return LstAlias
     */
    public function getAlias()
    {
        return $this->alias;
    }
}
