<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 19/05/14
 */

namespace Oru\Bundle\LstBundle\Entity;

interface LstInterface
{
    /**
     * @return string
     */
    public function getLibelle();
}
