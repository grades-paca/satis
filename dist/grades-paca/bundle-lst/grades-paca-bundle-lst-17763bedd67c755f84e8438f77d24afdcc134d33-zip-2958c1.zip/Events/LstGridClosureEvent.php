<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LstBundle\Events;

use Symfony\Component\EventDispatcher\Event;

/**
 * Class LstGridClosure.
 */
class LstGridClosureEvent extends Event
{
    /**
     * @var string name of the list
     */
    protected $list;

    /**
     * @var \Closure
     */
    protected $closure;

    /**
     * LstGridClosure constructor.
     *
     * @param mixed $list
     */
    public function __construct($list)
    {
        $this->list = $list;
    }

    /**
     * @return mixed
     */
    public function getList()
    {
        return $this->list;
    }

    /**
     * @return \Closure
     */
    public function getClosure()
    {
        return $this->closure;
    }

    /**
     * @param \Closure $closure
     */
    public function setClosure($closure)
    {
        $this->closure = $closure;
    }
}
