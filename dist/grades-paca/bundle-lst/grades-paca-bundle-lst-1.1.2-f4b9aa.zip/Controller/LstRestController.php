<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\LstBundle\Controller;


use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\Request\ParamFetcherInterface;
use JMS\Serializer\SerializationContext;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\Security\Core\User\UserInterface;

use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\View as RestView;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;


class LstRestController extends FOSRestController {

    /**
     * Ce webservice permet de récupérer la liste des éléments d'une lsite administrable.
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @QueryParam(name="lst", requirements="[A-Za-z0-9_]+", nullable=false, description="Nom de la liste")
     *
     * @RestView(serializerGroups={"Default"})
     *
     * @ApiDoc()
     */
    public function lstAllAction(ParamFetcherInterface $paramFetcher)
    {
        $user = $this->container->get('security.token_storage')->getToken()->getUser();
        if (!is_object($user) || !$user instanceof UserInterface) {
            throw new AccessDeniedException('This user does not have access to this section.');
        }

        ini_set('memory_limit', '1024M');
        $liste = $this->get('oru_lst.alias')->initialize($paramFetcher->get('lst'));
        $results = $liste->getRepository()->findAllAndDuplicated();
        $view = $this->view($results);
        $context = SerializationContext::create()->setGroups(array('webservice'));
        $view->setSerializationContext($context);
        return $this->handleView($view);
    }

    /**
     * Ce webservice permet de récupérer la configuration d'un élément d'une liste administrable dont le code est fourni en argument.
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @QueryParam(name="lst", requirements="[A-Za-z0-9_]+", nullable=false, description="Nom de la liste")
     * @QueryParam(name="code", requirements="[A-Za-z0-9]+", nullable=false, description="Code de l'élément")
     *
     * @RestView(serializerGroups={"Default"})
     *
     * @ApiDoc()
     */
    public function lstConfigAction(ParamFetcherInterface $paramFetcher)
    {
        $user = $this->container->get('security.token_storage')->getToken()->getUser();
        if (!is_object($user) || !$user instanceof UserInterface) {
            throw new AccessDeniedException('This user does not have access to this section.');
        }

        $liste = $this->get('oru_lst.alias')->initialize($paramFetcher->get('lst'));
        $result = $liste->getRepository()->findByCode($paramFetcher->get('code'));
        $view = $this->view($result);
        $context = SerializationContext::create()->setGroups(array('webservice'));
        $view->setSerializationContext($context);
        return $this->handleView($view);
    }

}