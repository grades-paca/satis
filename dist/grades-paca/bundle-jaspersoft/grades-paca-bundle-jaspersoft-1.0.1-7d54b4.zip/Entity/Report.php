<?php

namespace Oru\Bundle\JaspersoftBundle\Entity;
use Oru\Bundle\RorCredentialsBundle\Entity\Credential;
use Oru\Bundle\SettingBundle\Setting\Setting;

/**
 * Report
 */
class Report
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $description;

    /**
     * @var string
     */
    private $idRapport;

    /**
     * @var string
     */
    private $userJasper;

    /**
     * @var string
     */
    private $passJasper;

    /**
     * @var \DateTime
     */
    private $dateDebut;

    /**
     * @var \DateTime
     */
    private $dateFin;

    /**
     * @var integer
     */
    private $dureeMois;

    /**
     * @var array
     */
    private $options;

    /**
     * @var Credential
     */
    private $credential;

    /**
     * @var Setting
     */
    private $settings;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Report
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Report
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set idRapport
     *
     * @param string $idRapport
     *
     * @return Report
     */
    public function setIdRapport($idRapport)
    {
        $this->idRapport = $idRapport;

        return $this;
    }

    /**
     * Get idRapport
     *
     * @return string
     */
    public function getIdRapport()
    {
        return $this->idRapport;
    }

    /**
     * Set userJasper
     *
     * @param string $userJasper
     *
     * @return Report
     */
    public function setUserJasper($userJasper)
    {
        $this->userJasper = $userJasper;

        return $this;
    }

    /**
     * Get userJasper
     *
     * @return string
     */
    public function getUserJasper()
    {
        return $this->userJasper;
    }

    /**
     * Set passJasper
     *
     * @param string $passJasper
     *
     * @return Report
     */
    public function setPassJasper($passJasper)
    {
        if(empty($passJasper)){
            return $this;
        }

        $this->passJasper = base64_encode($passJasper);

        return $this;
    }

    /**
     * Get passJasper
     *
     * @return string
     */
    public function getPassJasper()
    {
        if(empty($this->passJasper)){
            return '';
        }

        return base64_decode($this->passJasper);
    }

    /**
     * Set dateDebut
     *
     * @param \DateTime $dateDebut
     *
     * @return Report
     */
    public function setDateDebut($dateDebut)
    {
        $this->dateDebut = $dateDebut;

        return $this;
    }

    /**
     * Get dateDebut
     *
     * @return \DateTime
     */
    public function getDateDebut()
    {
        return $this->dateDebut;
    }

    /**
     * Set dateFin
     *
     * @param \DateTime $dateFin
     *
     * @return Report
     */
    public function setDateFin($dateFin)
    {
        $this->dateFin = $dateFin;

        return $this;
    }

    /**
     * Get dateFin
     *
     * @return \DateTime
     */
    public function getDateFin()
    {
        return $this->dateFin;
    }

    /**
     * Set dureeMois
     *
     * @param integer $dureeMois
     *
     * @return Report
     */
    public function setDureeMois($dureeMois)
    {
        $this->dureeMois = $dureeMois;

        return $this;
    }

    /**
     * Get dureeMois
     *
     * @return integer
     */
    public function getDureeMois()
    {
        return $this->dureeMois;
    }

    /**
     * Set options
     *
     * @param array $options
     *
     * @return Report
     */
    public function setOptions($options)
    {
        $this->options = $options;

        return $this;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * @return Credential
     */
    public function getCredential()
    {
        return $this->credential;
    }

    /**
     * @param Credential $credential
     */
    public function setCredential($credential)
    {
        $this->credential = $credential;
    }

    /**
     * @return Setting
     */
    public function getSettings()
    {
        return $this->settings;
    }

    /**
     * @param Setting $settings
     */
    public function setSettings($settings)
    {
        $this->settings = $settings;
    }
}


