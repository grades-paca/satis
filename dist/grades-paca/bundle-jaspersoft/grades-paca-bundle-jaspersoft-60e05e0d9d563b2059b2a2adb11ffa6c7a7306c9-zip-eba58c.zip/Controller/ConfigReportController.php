<?php

namespace Oru\Bundle\JaspersoftBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Oru\Bundle\JaspersoftBundle\Entity\Report;
use Oru\Bundle\JaspersoftBundle\Listing\ReportListingType;
use Oru\Bundle\JaspersoftBundle\Form\ConfigReportFilterType;
use Oru\Bundle\JaspersoftBundle\Form\ReportType;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * ConfigReport controller.
 *
 */
class ConfigReportController extends Controller
{

    /**
     * Lists all Report entities.
     *
     */
    public function indexAction(Request $request)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_JASPERSOFT_ADMIN')){
            throw new AccessDeniedHttpException();
        }

        $form = $this->createForm(new ConfigReportFilterType())->submit($request->getSession()->get('report.filter', array()));
        $listing = $this->container->get('paginator.factory')->create(
            new ReportListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruJaspersoftBundle:Report')->findList($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('@OruJaspersoft/Report/index.html.twig', array(
            'listing' => $listing,
            'form' => $this->createForm(new ConfigReportFilterType(), $form->getData())->createView()
        ));
    }
    /**
     * Filters Report entities.
     *
     */
    public function filterAction(Request $request)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_JASPERSOFT_ADMIN')){
            throw new AccessDeniedHttpException();
        }

        $form = $this->createForm(new ConfigReportFilterType())->handleRequest($request);

        if ($form->get('reset')->isClicked()) {
            $request->getSession()->remove('report.filter');
            return $this->redirect($this->generateUrl('oru_jaspersoft_config_report'));
        }

        if($form->isValid()) {
            $request->getSession()->set('report.filter', $request->get($form->getName()));
            return $this->redirect($this->generateUrl('oru_jaspersoft_config_report'));
        }

        $listing = $this->container->get('paginator.factory')->create(
            new ReportListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruJaspersoftBundle:Report')->findList($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('@OruJaspersoft/Report/index.html.twig', array(
            'listing' => $listing,
            'form' => $form->createView()
        ));
    }
    /**
     * Creates a new Report entity.
     *
     */
    public function createAction(Request $request)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_JASPERSOFT_ADMIN')){
            throw new AccessDeniedHttpException();
        }

        $entity = new Report();
        $form = $this->createCreateForm($entity);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($entity);
            $em->flush();

            return $this->redirect($this->generateUrl('oru_jaspersoft_config_report_show', array('id' => $entity->getId())));
        }

        return $this->render('@OruJaspersoft/Report/edit.html.twig', array(
            'entity' => $entity,
            'form'   => $form->createView(),
        ));
    }

    /**
    * Creates a form to create a Report entity.
    *
    * @param Report $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    */
    private function createCreateForm(Report $entity)
    {
        $form = $this->createForm(new ReportType(), $entity, array(
            'action' => $this->generateUrl('oru_jaspersoft_config_report_create'),
            'method' => 'POST',
        ));

        $form->add('submit', 'submit', array('attr'=> array('class' => 'btn btn-primary'), 'label' => $this->get('translator')->trans('listing.action.create')));

        return $form;
    }

    /**
     * Displays a form to create a new Report entity.
     *
     */
    public function newAction()
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_JASPERSOFT_ADMIN')){
            throw new AccessDeniedHttpException();
        }

        $entity = new Report();
        $form   = $this->createCreateForm($entity);

        return $this->render('@OruJaspersoft/Report/edit.html.twig', array(
            'entity' => $entity,
            'form'   => $form->createView(),
        ));
    }

    /**
     * Finds and displays a Report entity.
     *
     */
    public function showAction($id)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_JASPERSOFT_ADMIN')){
            throw new AccessDeniedHttpException();
        }

        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruJaspersoftBundle:Report')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Report entity.');
        }

        $deleteForm = $this->createDeleteForm($id);

        return $this->render('@OruJaspersoft/Report/show.html.twig', array(
            'entity'      => $entity,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing Report entity.
     *
     */
    public function editAction($id)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_JASPERSOFT_ADMIN')){
            throw new AccessDeniedHttpException();
        }

        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruJaspersoftBundle:Report')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Report entity.');
        }

        $editForm = $this->createEditForm($entity);
        $deleteForm = $this->createDeleteForm($id);

        return $this->render('@OruJaspersoft/Report/edit.html.twig', array(
            'entity'      => $entity,
            'form'   => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
    * Creates a form to edit a Report entity.
    *
    * @param Report $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    */
    private function createEditForm(Report $entity)
    {
        $form = $this->createForm(new ReportType(), $entity, array(
            'action' => $this->generateUrl('oru_jaspersoft_config_report_update', array('id' => $entity->getId())),
            'method' => 'PUT',
        ));

        $form->add('submit', 'submit', array('attr'=> array('class' => 'btn btn-primary'),'label' => $this->get('translator')->trans('listing.action.update')));

        return $form;
    }
    /**
     * Edits an existing Report entity.
     *
     */
    public function updateAction(Request $request, $id)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_JASPERSOFT_ADMIN')){
            throw new AccessDeniedHttpException();
        }

        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruJaspersoftBundle:Report')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Report entity.');
        }

        $deleteForm = $this->createDeleteForm($id);
        $editForm = $this->createEditForm($entity);
        $editForm->handleRequest($request);

        if ($editForm->isValid()) {
            $em->flush();

            return $this->redirect($this->generateUrl('oru_jaspersoft_config_report_edit', array('id' => $id)));
        }

        return $this->render('@OruJaspersoft/Report/edit.html.twig', array(
            'entity'      => $entity,
            'form'   => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }
    /**
     * Deletes a Report entity.
     *
     */
    public function deleteAction(Request $request, $id)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_JASPERSOFT_ADMIN')){
            throw new AccessDeniedHttpException();
        }

        $form = $this->createDeleteForm($id);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $entity = $em->getRepository('OruJaspersoftBundle:Report')->find($id);

            if (!$entity) {
                throw $this->createNotFoundException('Unable to find Report entity.');
            }

            $em->remove($entity);
            $em->flush();
        }

        return $this->redirect($this->generateUrl('oru_jaspersoft_config_report'));
    }

    /**
     * Creates a form to delete a Report entity by id.
     *
     * @param mixed $id The entity id
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm($id)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('oru_jaspersoft_config_report_delete', array('id' => $id)))
            ->setMethod('DELETE')
            ->add('submit', 'submit', array('attr'=>array('class'=>'btn btn-danger'),'label' => $this->get('translator')->trans('listing.action.delete')))
            ->getForm()
        ;
    }
}
