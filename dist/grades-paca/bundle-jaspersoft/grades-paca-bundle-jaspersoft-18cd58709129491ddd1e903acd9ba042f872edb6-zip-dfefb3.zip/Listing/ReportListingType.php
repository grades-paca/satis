<?php

namespace Oru\Bundle\JaspersoftBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ReportListingType extends AbstractListingType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('name', null, array('label' => 'listing.name', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('idRapport', null, array('label' => 'listing.idRapport', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('userJasper', null, array('label' => 'listing.userJasper', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('show', 'object_action', array('route' => 'oru_jaspersoft_config_report_show', 'label' => 'listing.action.show'))
            ->add('edit', 'object_action', array('route' => 'oru_jaspersoft_config_report_edit', 'label' => 'listing.action.edit'))
            ->add('visualize', 'object_action', array('route' => 'oru_jaspersoft_report', 'label' => 'listing.visualize', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('new', 'list_action', array('route' => 'oru_jaspersoft_config_report_new', 'label' => 'listing.action.new'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\JaspersoftBundle\Entity\Report'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_jaspersoftbundle_reportlisting';
    }
}
