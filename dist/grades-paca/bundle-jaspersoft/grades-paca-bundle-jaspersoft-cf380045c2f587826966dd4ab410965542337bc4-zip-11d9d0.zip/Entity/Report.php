<?php

namespace Oru\Bundle\JaspersoftBundle\Entity;
use Oru\Bundle\RorCredentialsBundle\Entity\Credential;
use Oru\Bundle\SettingBundle\Setting\Setting;

/**
 * Report
 */
class Report
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $description;

    /**
     * @var string
     */
    private $idRapport;

    /**
     * @var string
     */
    private $userJasper;

    /**
     * @var string
     */
    private $passJasper;

    /**
     * @var \DateTime
     */
    private $dateDebut;

    /**
     * @var \DateTime
     */
    private $dateFin;

    /**
     * @var integer
     */
    private $dureeMois;

    /**
     * @var array
     */
    private $options;

    /**
     * @var Credential
     */
    private $credential;

    /**
     * @var Setting
     */
    private $settings;

    /**
     * @var boolean
     */
    private $exportExcel;

    /**
     * @var boolean
     */
    private $etablissementObligatoire;

    /**
     * @var boolean
     */
    private $uniteObligatoire;

    /**
     * @var boolean
     */
    private $dateDebutObligatoire;

    /**
     * @var boolean
     */
    private $dateFinObligatoire;

    /**
     * @var boolean
     */
    private $etablissementDesactive;

    /**
     * @var boolean
     */
    private $uniteDesactive;

    /**
     * @var boolean
     */
    private $dateDebutDesactive;

    /**
     * @var boolean
     */
    private $dateFinDesactive;

    /**
     * @var string
     */
    private $texteExplicatif;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Report
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Report
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set idRapport
     *
     * @param string $idRapport
     *
     * @return Report
     */
    public function setIdRapport($idRapport)
    {
        $this->idRapport = $idRapport;

        return $this;
    }

    /**
     * Get idRapport
     *
     * @return string
     */
    public function getIdRapport()
    {
        return $this->idRapport;
    }

    /**
     * Set userJasper
     *
     * @param string $userJasper
     *
     * @return Report
     */
    public function setUserJasper($userJasper)
    {
        $this->userJasper = $userJasper;

        return $this;
    }

    /**
     * Get userJasper
     *
     * @return string
     */
    public function getUserJasper()
    {
        return $this->userJasper;
    }

    /**
     * Set passJasper
     *
     * @param string $passJasper
     *
     * @return Report
     */
    public function setPassJasper($passJasper)
    {
        if(empty($passJasper)){
            return $this;
        }

        $this->passJasper = base64_encode($passJasper);

        return $this;
    }

    /**
     * Get passJasper
     *
     * @return string
     */
    public function getPassJasper()
    {
        if(empty($this->passJasper)){
            return '';
        }

        return base64_decode($this->passJasper);
    }

    /**
     * Set dateDebut
     *
     * @param \DateTime $dateDebut
     *
     * @return Report
     */
    public function setDateDebut($dateDebut)
    {
        $this->dateDebut = $dateDebut;

        return $this;
    }

    /**
     * Get dateDebut
     *
     * @return \DateTime
     */
    public function getDateDebut()
    {
        return $this->dateDebut;
    }

    /**
     * Set dateFin
     *
     * @param \DateTime $dateFin
     *
     * @return Report
     */
    public function setDateFin($dateFin)
    {
        $this->dateFin = $dateFin;

        return $this;
    }

    /**
     * Get dateFin
     *
     * @return \DateTime
     */
    public function getDateFin()
    {
        return $this->dateFin;
    }

    /**
     * Set dureeMois
     *
     * @param integer $dureeMois
     *
     * @return Report
     */
    public function setDureeMois($dureeMois)
    {
        $this->dureeMois = $dureeMois;

        return $this;
    }

    /**
     * Get dureeMois
     *
     * @return integer
     */
    public function getDureeMois()
    {
        return $this->dureeMois;
    }

    /**
     * Set options
     *
     * @param array $options
     *
     * @return Report
     */
    public function setOptions($options)
    {
        $this->options = $options;

        return $this;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * @return Credential
     */
    public function getCredential()
    {
        return $this->credential;
    }

    /**
     * @param Credential $credential
     */
    public function setCredential($credential)
    {
        $this->credential = $credential;
    }

    /**
     * @return Setting
     */
    public function getSettings()
    {
        return $this->settings;
    }

    /**
     * @param Setting $settings
     */
    public function setSettings($settings)
    {
        $this->settings = $settings;
    }

    /**
     * @return boolean
     */
    public function isExportExcel()
    {
        return $this->exportExcel;
    }

    /**
     * @param boolean $exportExcel
     */
    public function setExportExcel($exportExcel)
    {
        $this->exportExcel = $exportExcel;
    }

    /**
     * @return boolean
     */
    public function isEtablissementObligatoire()
    {
        return $this->etablissementObligatoire;
    }

    /**
     * @param boolean $etablissementObligatoire
     */
    public function setEtablissementObligatoire($etablissementObligatoire)
    {
        $this->etablissementObligatoire = $etablissementObligatoire;
    }

    /**
     * @return boolean
     */
    public function isUniteObligatoire()
    {
        return $this->uniteObligatoire;
    }

    /**
     * @param boolean $uniteObligatoire
     */
    public function setUniteObligatoire($uniteObligatoire)
    {
        $this->uniteObligatoire = $uniteObligatoire;
    }

    /**
     * @return boolean
     */
    public function isDateDebutObligatoire()
    {
        return $this->dateDebutObligatoire;
    }

    /**
     * @param boolean $dateDebutObligatoire
     */
    public function setDateDebutObligatoire($dateDebutObligatoire)
    {
        $this->dateDebutObligatoire = $dateDebutObligatoire;
    }

    /**
     * @return boolean
     */
    public function isDateFinObligatoire()
    {
        return $this->dateFinObligatoire;
    }

    /**
     * @param boolean $dateFinObligatoire
     */
    public function setDateFinObligatoire($dateFinObligatoire)
    {
        $this->dateFinObligatoire = $dateFinObligatoire;
    }

    /**
     * @return boolean
     */
    public function isEtablissementDesactive()
    {
        return $this->etablissementDesactive;
    }

    /**
     * @param boolean $etablissementDesactive
     */
    public function setEtablissementDesactive($etablissementDesactive)
    {
        $this->etablissementDesactive = $etablissementDesactive;
    }

    /**
     * @return boolean
     */
    public function isUniteDesactive()
    {
        return $this->uniteDesactive;
    }

    /**
     * @param boolean $uniteDesactive
     */
    public function setUniteDesactive($uniteDesactive)
    {
        $this->uniteDesactive = $uniteDesactive;
    }

    /**
     * @return boolean
     */
    public function isDateDebutDesactive()
    {
        return $this->dateDebutDesactive;
    }

    /**
     * @param boolean $dateDebutDesactive
     */
    public function setDateDebutDesactive($dateDebutDesactive)
    {
        $this->dateDebutDesactive = $dateDebutDesactive;
    }

    /**
     * @return boolean
     */
    public function isDateFinDesactive()
    {
        return $this->dateFinDesactive;
    }

    /**
     * @param boolean $dateFinDesactive
     */
    public function setDateFinDesactive($dateFinDesactive)
    {
        $this->dateFinDesactive = $dateFinDesactive;
    }

    /**
     * @return string
     */
    public function getTexteExplicatif()
    {
        return $this->texteExplicatif;
    }

    /**
     * @param string $texteExplicatif
     */
    public function setTexteExplicatif($texteExplicatif)
    {
        $this->texteExplicatif = $texteExplicatif;
    }
}
