<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 04/05/2016
 * Time: 10:07
 */

namespace Oru\Bundle\JaspersoftBundle\Filter;


use Oru\Bundle\JaspersoftBundle\Entity\Report;

class ReportFilter extends Report implements ReportFilterInterface {

    protected $etablissement;

    /**
     * @var array
     */
    protected $unites;

    /**
     * @return mixed
     */
    public function getEtablissement()
    {
        return $this->etablissement;
    }

    /**
     * @param mixed $etablissement
     */
    public function setEtablissement($etablissement)
    {
        $this->etablissement = $etablissement;
    }

    /**
     * @param mixed $etablissement
     */
    public function setUnites($unites)
    {
        $this->unites = $unites;
    }

    /**
     * @return mixed
     */
    public function getUnites()
    {
        return $this->unites;
    }
} 