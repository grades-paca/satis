<?php

namespace Oru\Bundle\JaspersoftBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ConfigReportFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', 'search', array('required' => false, 'label' => 'Report.name', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('idRapport', 'search', array('required' => false, 'label' => 'Report.idRapport', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('userJasper', 'search', array('required' => false, 'label' => 'Report.userJasper', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('filter', 'submit', array('label' => 'listing.action.filter', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-primary')))
            ->add('reset', 'submit', array('label' => 'listing.action.reset', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-default')))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\JaspersoftBundle\Filter\ConfigReportFilter'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_jaspersoftbundle_reportfilter';
    }
}
