Bundle OruJaspersoftBundle
======================

Description
-----------

Ce bundle permet la visualisation de rapports Jaspersoft.

h5. Liste des droits

"Droits":https://redmine.orupaca.fr/projects/ror-3/repository/oru_jaspersoft_bundle/revisions/master/entry/Resources/config/credentials.yml

h5. Liste des pages

"Pages":https://redmine.orupaca.fr/projects/ror-3/repository/oru_jaspersoft_bundle/revisions/master/entry/Resources/config/pages.xml

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/jaspersoft":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\JaspersoftBundle\OruJaspersoftBundle();
```

Dans le config.yml, importer la configuration de ce bundle :

```
imports:
    ...
    - { resource: @OruJaspersoftBundle/Resources/config/config.yml }
    ...
```

Vider le cache de Symfony2

Utilisation du Viewer Javascript
======================

Description
-----------

Jaspersoft utilise la librairie visualize.js pour effectuer le rendu des rapports.
Le viewer javascript est un objet ORUPACA qui surcharge la librairie visualize afin d'ajouter des contrôles plus adaptés à nos besoins.

Il contient notamment :
- Les contrôles de pagination
- Les possibilités d'export du rapport

L'objet principal est encapsulé dans le namespace Oru :

``` javascript
Oru.Jaspersoft.Viewer = function(options){ ... }
```

Pré-requis pour installation Standalone (hors Symfony)
-----------

Vous pouvez utiliser ce bundle hors Symfony afin d'utiliser le Viewer Javascript, pour ce faire, il faut d'abord remplir les pré-requis suivants, puis passer à l'étape d'installation.

1) Inclure les fichiers suivants  :
- jaspersoft-viewer.css
- jaspersoft-viewer.js
- viewer.html.twig (copier le contenu HTML à l'endroit souhaité dans votre page)

2) Inclure la librairie Jaspersoft visualize.js (télécharger dynamiquement depuis le serveur Jaspersoft)

Installation
-----------

1) Créer l'objet ReportBag, qui contient la configuration principale du rapport

Il s'agit de l'objet de configuration du la méthode "report" décrite dans la documentation Jaspersoft.
Le Viewer pré-instancie cet objet afin d'y injecter sa configuration par défaut, il s'agit donc de récupérer l'objet pré-instancié avant de le surcharger :

``` javascript
 var reportBag = Oru.Jaspersoft.Viewer.ReportBag;
```

Puis, ajouter les paramètres souhaités (les paramètres sont documentés dans Jaspersoft, le Viewer ne fait que passer l'objet)

``` javascript
  reportBag.resource = "/chemin/ressource_jaspersoft";
  reportBag.params = {
    'param1': 'value1',
    'param2': 'value2'
  };
```

2) Instancier le Viewer :

L'objet prend en paramètre les options:
- visualize: Il s'agit de l'objet de configuration de la méthode "visualize" décrite dans la documentation Jaspersoft
- reportBag: Il s'agit de l'objet de configuration du la méthode "report" décrite dans la documentation Jaspersoft et précédemment surchargé

``` javascript
 var viewer = new Oru.Jaspersoft.Viewer({
    visualize: {
        auth: {
            name:"user",
            password:"password",
            organization: ""
        }
    },
    reportBag: reportBag
});
```

Configuration
-----------

1) ReportBag & Visualize

L'objet ReportBag encapsule les propriétés de configuration du rapport envoyées lors de la création du rapport.
Mais également des méthodes supplémentaires liées au Viewer, par exemple :

- error
- success

l'objet Visualize fonctionne de la même manière, il est complètement identique à l'objet envoyé dans la documentation Jaspersoft.

2) Méthodes publiques

Des comportements par défaut peuvent être implémentés dans ces méthodes, la surcharge de ces dernières peut donc affecter le comportement.
Par exemple la méthode "success" par défaut fait un appel à la fonction "hideSpinner()" afin de cacher l'animation de chargement lorsque ce dernier est effectué.

Il y a plusieurs méthodes publiques statiques (voir l'objet), il est possible de les réutiliser dans les surcharges de fonctions.
Exemples de méthodes publiques statiques :

``` javascript
    Oru.Jaspersoft.Viewer.hideSpinner();
    Oru.Jaspersoft.Viewer.updateTotalPages();
    Oru.Jaspersoft.Viewer.updateCurrentPage();
```

3) Constantes et paramètres

Le Viewer implémente des constantes et paramètres par défaut, on peut noter par exemple l'objet ReportBag pré-configuré:

``` javascript
    Oru.Jaspersoft.Viewer.ReportBag = {
        container: Oru.Jaspersoft.Viewer.container,
        success: function(data){
            Oru.Jaspersoft.Viewer.hideSpinner();
        },
        error: function(data){},
        events: { changeTotalPages: function(totalPages) { Oru.Jaspersoft.Viewer.updateTotalPages(totalPages); } }
    };
```

Mais également le conteneur principal permettant l'affichage, qui est intégré à la vue du Viewer, mais qui peut être surchargé :

``` javascript
   Oru.Jaspersoft.Viewer.container = "#oru_jaspersoft_container";
```

Pour le surcharger, il suffit :

``` javascript
    var reportBag = Oru.Jaspersoft.Viewer.ReportBag;
    reportBag.container = "#custom_container_div";
```

D'autres exemples de surcharge du ReportBag :

``` javascript
  var reportBag = Oru.Jaspersoft.Viewer.ReportBag;
    [...]
  reportBag.success = function(){};
  reportBag.error = function(){};
  reportBag.events = Oru.Jaspersoft.Viewer.ReportBag.events = {
      changeTotalPages : Oru.Jaspersoft.Viewer.ReportBag.events.changeTotalPages, //Pour garder le comportement par défaut, sinon écraser
  }
```


4) Options Oru.Jaspersoft.Viewer

Lors de l'instanciation, et comme vu précédemment, un objet d'options est envoyé au Viewer.
Il permet de passer les objets de configuration Jaspersoft tels quels ou surchargés (cf "visualize", "report", lors de l'instanciation), mais également des paramètres exclusifs au composant ORU.

Il comprend également deux méthodes "success" et "error", qui résultent de l'appel à la méthode "visualize" de Jaspersoft et permettent d'affiner le paramétrage, un exemple de surcharge :

``` javascript
   viewer = new Oru.Jaspersoft.Viewer({
       visualize: {
           auth: {
               name:"{{ report.userJasper | raw }}",
               password:"{{ report.passJasper | raw }}",
               organization: ""
           }
       },
       reportBag: reportBag,
       success: function(v){
           //@Todo : Action lors du succès, on peut récupérer l'objet "v" documenté dans Jaspersoft
       },
       error: function(err){
           alert(err);
       }
   });
```

5) Objet "report" (Jaspersoft)

On peut avoir besoin de récupérer l'objet "report" de Jaspersoft afin d'affiner des paramétrages ou implémenter des méthodes qui ne sont pas prises en charge par le Viewer.
De cette manière, le Viewer ne restreint pas les possibilités offertes par l'objet Jaspersoft.
Pour ce faire, le viewer stocke cet objet en tant que propriété, il suffit de l'appeler de la manière suivante pour pouvoir le surcharger :

``` javascript
   var viewer = new Oru.Jaspersoft.Viewer({...}); //(cf Instanciation du Viewer)
   var report = viewer.report; //Récupération de l'objet Report Jaspersoft

   [...]
   //Exemple : Page courante du rapport
   var currentPage = report.pages();
   //Exemple : Aller à la page 5 du rapport
   report.pages(5);
   //Exemple : Faire un export personnalisé
   report.export({...});
   //Exemple : Actualiser le rapport
   report.refresh();
   [...]
```
