$(document).ready(function() {
    $('.reveal').on('mousedown', function () {
        $('.revealable').attr('type', 'text');
    });

    $('.reveal').on('mouseup', function () {
        $('.revealable').attr('type', 'password');
    });

    $('.reveal').on('mouseover', function () {
        $('.revealable').attr('type', 'password');
    });
});