<?php

namespace Oru\Bundle\JaspersoftBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ReportFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->addEventListener(FormEvents::PRE_SET_DATA, array($this, 'setCredential'))
            ->addEventListener(FormEvents::PRE_SET_DATA, array($this, 'setSettings'))
            ->add('dateDebut','date', array('widget' => 'single_text', 'label' => 'Report.dateDebut', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('dateFin','date', array('widget' => 'single_text', 'label' => 'Report.dateFin', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('filter','submit', array('label' => 'report.filter', 'translation_domain' => 'OruJaspersoftBundle', 'attr' => array('class' => 'btn btn-primary')))
        ;
    }

    public function setCredential(FormEvent $event){
        $form = $event->getForm();
        if($event->getData() && $event->getData()->getCredential()) {
            $credential = $event->getData()->getCredential();
            $form->add('etablissement', 'oru_etablissement_magic', array('required' => true, 'label' => 'filter.etablissement', 'translation_domain' => 'OruJaspersoftBundle', 'credential' => $credential->getName(), 'position' => 'first'));
        }
    }

    public function setSettings(FormEvent $event){
        $form = $event->getForm();
        $entity = $event->getData();

        if($entity && $entity->getSettings()){
            foreach($entity->getSettings() as $setting){
                $arrayValues = $setting->getValue();
                $form->add('setting_item_'.$setting->getName(), 'choice', array('choices' => $arrayValues, 'mapped' => false, 'position' => array('before' => 'filter'), 'label' => $setting->getDescription()));
            }
        }
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\JaspersoftBundle\Filter\ReportFilter',
            'allow_extra_fields' => true
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_jaspersoftbundle_reportfilter';
    }
}
