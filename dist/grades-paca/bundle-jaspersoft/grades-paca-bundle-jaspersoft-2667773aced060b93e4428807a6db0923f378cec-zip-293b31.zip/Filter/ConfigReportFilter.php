<?php

namespace Oru\Bundle\JaspersoftBundle\Filter;

use Oru\Bundle\JaspersoftBundle\Entity\Report;

class ConfigReportFilter extends Report implements ReportFilterInterface
{
}
