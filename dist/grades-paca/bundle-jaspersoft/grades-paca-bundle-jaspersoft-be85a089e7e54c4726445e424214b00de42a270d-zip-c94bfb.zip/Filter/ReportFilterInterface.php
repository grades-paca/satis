<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 04/05/2016
 * Time: 10:04
 */

namespace Oru\Bundle\JaspersoftBundle\Filter;


interface ReportFilterInterface {

} 