<?php

namespace Oru\Bundle\JaspersoftBundle\Controller;

use Oru\Bundle\JaspersoftBundle\Entity\Report;
use Oru\Bundle\JaspersoftBundle\Form\ReportFilterType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Oru\Bundle\JaspersoftBundle\Filter\ReportFilter;

/**
 * Class ReportController
 * @package Oru\Bundle\JaspersoftBundle\Controller
 * @author Michaël Gonzalez
 */
class ReportController extends Controller{
    public function indexAction(Report $report){
        $form = $this->createReportForm($report);
        return $this->render('OruJaspersoftBundle:Default:index.html.twig', array('report' => $report, 'form' => $form->createView()));
    }

    /**
     * Filters Report entities.
     *
     */
    public function showAction(Request $request, Report $report)
    {
        $jaspersoft_server = $this->getParameter('jaspersoft_server');

        $form = $this->createReportForm($report);
        $form->handleRequest($request);

        if($form->isValid()) {

            //Récupération des paramètres utilisateurs dynamiques
            $settings = array();
            $lenPrefix = strlen('setting_item_');
            $vars = $request->request->get('oru_bundle_jaspersoftbundle_reportfilter');
            foreach($vars as $key => $value){
                if(strpos($key, 'setting_item_') !== false){
                    $settings[substr($key,$lenPrefix,strlen($key) - $lenPrefix)] = $value;
                }
            }

            return $this->render('OruJaspersoftBundle:Default:show.html.twig', array(
                'form' => $form->createView(),
                'jaspersoft_server' => $jaspersoft_server,
                'report' => $report,
                'filter' => $form->getData(),
                'settings' => $settings
            ));
        }

        return $this->render('OruJaspersoftBundle:Default:index.html.twig', array(
            'form' => $form->createView(),
            'entity' => $form->getData()
        ));
    }



    private function createReportForm(Report $report){

        //A revoir : J'aurais bien aimé utiliser le polymorphisme ici en castant $report dans l'enfant $reportFilter, malheureusement PHP ne le permet pas
        $reportFilter = new ReportFilter();
        if(!$report->isDateDebutDesactive()){
            $reportFilter->setDateDebut($report->getDateDebut());
        }
        if(!$report->isDateFinDesactive()){
            $reportFilter->setDateFin($report->getDateFin());
        }
        $reportFilter->setCredential($report->getCredential());
        $reportFilter->setOptions($report->getOptions());
        $reportFilter->setSettings($report->getSettings());
        $reportFilter->setEtablissementObligatoire($report->isEtablissementObligatoire());
        $reportFilter->setDateDebutObligatoire($report->isDateDebutObligatoire());
        $reportFilter->setDateFinObligatoire($report->isDateFinObligatoire());
        $reportFilter->setEtablissementDesactive($report->isEtablissementDesactive());
        $reportFilter->setDateDebutDesactive($report->isDateDebutDesactive());
        $reportFilter->setDateFinDesactive($report->isDateFinDesactive());

        return $this->createForm(new ReportFilterType(), $reportFilter, array('action' => $this->generateUrl('oru_jaspersoft_report_show', array('id' => $report->getId()))));
    }
}