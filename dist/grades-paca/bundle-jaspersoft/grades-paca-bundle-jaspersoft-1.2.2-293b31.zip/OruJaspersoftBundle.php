<?php

namespace Oru\Bundle\JaspersoftBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruJaspersoftBundle extends Bundle
{
}
