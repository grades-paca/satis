<?php

namespace Oru\Bundle\JaspersoftBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ConfigReportFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', SearchType::class, array('required' => false, 'label' => 'Report.name', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('idRapport', SearchType::class, array('required' => false, 'label' => 'Report.idRapport', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('userJasper', SearchType::class, array('required' => false, 'label' => 'Report.userJasper', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('filter', SubmitType::class, array('label' => 'listing.action.filter', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-primary')))
            ->add('reset', SubmitType::class, array('label' => 'listing.action.reset', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-default')))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\JaspersoftBundle\Filter\ConfigReportFilter',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_jaspersoftbundle_reportfilter';
    }
}
