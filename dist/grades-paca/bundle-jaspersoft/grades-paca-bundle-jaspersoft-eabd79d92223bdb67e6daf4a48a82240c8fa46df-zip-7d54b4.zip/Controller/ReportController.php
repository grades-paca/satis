<?php

namespace Oru\Bundle\JaspersoftBundle\Controller;

use Oru\Bundle\JaspersoftBundle\Entity\Report;
use Oru\Bundle\JaspersoftBundle\Form\ReportFilterType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Oru\Bundle\JaspersoftBundle\Filter\ReportFilter;

/**
 * Class ReportController
 * @package Oru\Bundle\JaspersoftBundle\Controller
 * @author Michaël Gonzalez
 */
class ReportController extends Controller{
    public function indexAction(Report $report){

        $reportFilter = new ReportFilter();
        $reportFilter->setDateDebut($report->getDateDebut());
        $reportFilter->setDateFin($report->getDateFin());
        $reportFilter->setCredential($report->getCredential());
        $reportFilter->setOptions($report->getOptions());
        $reportFilter->setSettings($report->getSettings());

        $form = $this->createForm(new ReportFilterType(), $reportFilter, array('action' => $this->generateUrl('oru_jaspersoft_report_show', array('id' => $report->getId()))));
        return $this->render('OruJaspersoftBundle:Default:index.html.twig', array('report' => $report, 'form' => $form->createView()));
    }

    /**
     * Filters Report entities.
     *
     */
    public function showAction(Request $request, Report $report)
    {
        $jaspersoft_server = $this->getParameter('jaspersoft_server');
        $form = $this->createForm(new ReportFilterType())->handleRequest($request);

        //@Todo : Améliorer : cette méthode est inélégante, il faut voir pourquoi les éléments ne ressortent pas dans getData()
        if(!$form->getData()->getCredential()){
            $form->getData()->setCredential($report->getCredential());
            $form = $this->createForm(new ReportFilterType(), $form->getData())->handleRequest($request);
        }
        if(!$form->getData()->getSettings()){
            $form->getData()->setSettings($report->getSettings());
            $form = $this->createForm(new ReportFilterType(), $form->getData())->handleRequest($request);
        }

        if($form->isValid()) {

            //Récupération des paramètres utilisateurs dynamiques
            $settings = array();
            $lenPrefix = strlen('setting_item_');
            $vars = $request->request->get('oru_bundle_jaspersoftbundle_reportfilter');
            foreach($vars as $key => $value){
                if(strpos($key, 'setting_item_') !== false){
                    $settings[substr($key,$lenPrefix,strlen($key) - $lenPrefix)] = $value;
                }
            }

            return $this->render('OruJaspersoftBundle:Default:show.html.twig', array(
                'form' => $form->createView(),
                'jaspersoft_server' => $jaspersoft_server,
                'report' => $report,
                'filter' => $form->getData(),
                'settings' => $settings
            ));
        }

        return $this->render('OruJaspersoftBundle:Default:index.html.twig', array(
            'form' => $form->createView(),
            'entity' => $form->getData()
        ));
    }
}