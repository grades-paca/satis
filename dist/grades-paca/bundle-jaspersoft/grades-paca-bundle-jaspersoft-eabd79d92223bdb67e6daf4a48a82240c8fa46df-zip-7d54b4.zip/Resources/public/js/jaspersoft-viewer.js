if(!Oru){
    var Oru = {};
    if(!Oru.Jaspersoft){
        Oru.Jaspersoft = {};
    }
}

Oru.Jaspersoft.Viewer = function(options){
    this.report = report;
    this.options = options;
    this.visualize();
    this.initEvents();
};

/*********************************************************
 * Constants & Params
 */

Oru.Jaspersoft.Viewer.container = "#oru_jaspersoft_container";

Oru.Jaspersoft.Viewer.ReportBag = {
    container: Oru.Jaspersoft.Viewer.container,
    success: function(data){
        Oru.Jaspersoft.Viewer.hideSpinner();
    },
    error: function(data){},
    events: { changeTotalPages: function(totalPages) { Oru.Jaspersoft.Viewer.updateTotalPages(totalPages); } }
};

/*********************************************************
 * Public Methods
 */

Oru.Jaspersoft.Viewer.updateTotalPages = function(value){
    if(value){
        $('.totalPages').html(value);
    }
}

Oru.Jaspersoft.Viewer.updateCurrentPage = function(value){
    if(value){
        $('.inputPage input').val(value);
        $('.inputPage input').html(value);
    }
}

Oru.Jaspersoft.Viewer.hideSpinner = function(){
    $('#oru_jaspersoft_loading').remove();
}


Oru.Jaspersoft.Viewer.prototype.export = function(options){
    console.warn("export");
    this.report.export({
        outputFormat: "pdf"
    })
        .done(
            function(link){
                window.open(link.href); // open new window to download report
                if(options.success){
                    options.success(link);
                }
            }
        )
        .fail(
            function(message){
                if(options.error){
                    options.error(message);
                }
            }
        )
}


/*********************************************************
 * Private Methods
 */

Oru.Jaspersoft.Viewer.prototype.visualize = function () {
    var me = this;

    visualize(this.options.visualize,
        function (v){
            me.report = v.report(me.options.reportBag);
            if(me.options.success){
                me.options.success(v);
            }
        },
        function(err){
            if(me.options.error){
                me.options.error(err);
            }
        }
    );
}

Oru.Jaspersoft.Viewer.prototype.initEvents = function(){
    var me = this;

    $(".previousPage").click(function() {
        var currentPage = me.report.pages() || 1; me.report .pages(--currentPage) .run() .fail(function(err) {  });
        Oru.Jaspersoft.Viewer.updateCurrentPage(currentPage);//@Todo : à faire au success
    });

    $(".nextPage").click(function() {
        var currentPage = me.report.pages() || 1; me.report .pages(++currentPage) .run() .fail(function(err) {  });
        Oru.Jaspersoft.Viewer.updateCurrentPage(currentPage);//@Todo : à faire au success
    });

    $('.inputPage-go').click(function(){
       var askedPage = $('.inputPage input').val();

       if(askedPage == parseInt(askedPage, 10)){
            me.report.pages(askedPage).run().fail(function(err){
                Oru.Jaspersoft.Viewer.updateCurrentPage(me.report.pages());
            });
       }else{
           Oru.Jaspersoft.Viewer.updateCurrentPage(me.report.pages());
       }
    });

    $('.export').click(function(){
        me.export({
            success: function(link){
                console.warn("Export Succes");
                console.warn(link);
            },
            error: function(message){
                console.warn("Export Error");
                console.warn(message);
            }
        });
    })
}

