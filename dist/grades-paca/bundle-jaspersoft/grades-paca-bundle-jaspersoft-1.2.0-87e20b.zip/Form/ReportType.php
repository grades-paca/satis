<?php

namespace Oru\Bundle\JaspersoftBundle\Form;

use Doctrine\ORM\EntityRepository;
use Oru\Bundle\FormBundle\Form\Type\ConditionalType;
use Oru\Bundle\FormBundle\Form\Type\PurifiedCkeditorType;
use Oru\Bundle\FormBundle\Form\Type\SectionType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ReportType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choiceObligatoire = array(
            null => 'Non',
            0 => 'Non',
            1 => 'Oui',
        );

        $choiceDesactives = array(
            null => 'Activé',
            0 => 'Activé',
            1 => 'Désactivé',
        );

        $builder
            ->add('configuration', SectionType::class, array('label' => 'Report.configuration', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('name', null, array('label' => 'Report.name', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('description', null, array('label' => 'Report.description', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('idRapport', null, array('label' => 'Report.idRapport', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('userJasper', null, array('label' => 'Report.userJasper', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('passJasper', null, array('label' => 'Report.passJasper', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('options', null, array('label' => 'Report.options', 'translation_domain' => 'OruJaspersoftBundle'))

            ->add('optionsChamps', SectionType::class, array('label' => 'Report.optionsChamps', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('etablissementDesactive', ConditionalType::class, array('label' => 'Report.etablissementDesactive', 'translation_domain' => 'OruJaspersoftBundle', 'expanded' => false, 'choices' => $choiceDesactives,
                    'conditionals' => array(
                        0 => array('etablissementObligatoire'),
                    ),
                    'required' => false,
                )
            )
            ->add('uniteDesactive', ConditionalType::class, array('label' => 'Report.uniteDesactive', 'translation_domain' => 'OruJaspersoftBundle', 'expanded' => false, 'choices' => $choiceDesactives,
                    'conditionals' => array(
                        0 => array('uniteObligatoire'),
                    ),
                    'required' => false,
                )
            )
            ->add('dateDebutDesactive', ConditionalType::class, array('label' => 'Report.dateDebutDesactive', 'translation_domain' => 'OruJaspersoftBundle', 'expanded' => false, 'choices' => $choiceDesactives,
                    'conditionals' => array(
                        0 => array('dateDebutObligatoire', 'dateDebut'),
                    ),
                    'required' => false,
                )
            )
            ->add('dateFinDesactive', ConditionalType::class, array('label' => 'Report.dateFinDesactive', 'translation_domain' => 'OruJaspersoftBundle', 'expanded' => false, 'choices' => $choiceDesactives,
                    'conditionals' => array(
                        0 => array('dateFinObligatoire', 'dateFin'),
                    ),
                    'required' => false,
                )
            )
            ->add('etablissementObligatoire', ChoiceType::class, array('label' => 'Report.etablissementObligatoire', 'translation_domain' => 'OruJaspersoftBundle', 'expanded' => false, 'choices' => $choiceObligatoire, 'required' => false))
            ->add('uniteObligatoire', ChoiceType::class, array('label' => 'Report.uniteObligatoire', 'translation_domain' => 'OruJaspersoftBundle', 'expanded' => false, 'choices' => $choiceObligatoire, 'required' => false))
            ->add('dateDebutObligatoire', ChoiceType::class, array('label' => 'Report.dateDebutObligatoire', 'translation_domain' => 'OruJaspersoftBundle', 'expanded' => false, 'choices' => $choiceObligatoire, 'required' => false))
            ->add('dateFinObligatoire', ChoiceType::class, array('label' => 'Report.dateFinObligatoire', 'translation_domain' => 'OruJaspersoftBundle', 'expanded' => false, 'choices' => $choiceObligatoire, 'required' => false))
            ->add('dateDebut', DateType::class, array('required' => false, 'widget' => 'single_text', 'label' => 'Report.dateDebut', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('dateFin', DateType::class, array('required' => false, 'widget' => 'single_text', 'label' => 'Report.dateFin', 'translation_domain' => 'OruJaspersoftBundle'))
            //->add('dureeMois', null, array('label' => 'Report.dureeMois', 'translation_domain' => 'OruJaspersoftBundle')) //Oubli implémentation ? Voir si ce champ est vraiment nécessaire

            ->add('optionsUtilisateur', SectionType::class, array('label' => 'Report.optionsUtilisateur', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('settings', EntityType::class, array(
                'class' => 'Oru\Bundle\SettingBundle\Entity\Setting', 'property' => 'description',
                'query_builder' => function (EntityRepository $er) {
                    $query = $er->createQueryBuilder('s')
                        ->select('s')
                        ->where('s.prefix = :prefix')
                        ->setParameter('prefix', 'OruJaspersoftBundle')
                        ->andWhere("s.type = 'array'")
                        ->orderBy('s.description', 'ASC');

                    return $query;
                },
                'multiple' => true,
                'label' => 'Report.settings',
                'translation_domain' => 'OruJaspersoftBundle',
                'required' => false,
            ))
            ->add('exportExcel', null, array('label' => 'Report.exportExcel', 'translation_domain' => 'OruJaspersoftBundle'))
            ->add('texteExplicatif', PurifiedCkeditorType::class, array('label' => 'Report.texteExplicatif', 'translation_domain' => 'OruJaspersoftBundle', 'required' => false, 'config_name' => 'oru_basic'))

            ->addEventListener(FormEvents::PRE_SET_DATA, array($this, 'credential'));
    }

    public function credential(FormEvent $event)
    {
        $form = $event->getForm();
        $factory = $form->getConfig()->getFormFactory();

        $form->add(
            $factory->createNamed('credential', 'entity', $event->getData()->getCredential(), array(
                    'auto_initialize' => false,
                    'multiple' => false,
                    'by_reference' => true,
                    'class' => 'Oru\Bundle\RorCredentialsBundle\Entity\Credential',
                    'label' => 'Page.credential',
                    'translation_domain' => 'OruMenuBundle',
                )
            )
        );
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\JaspersoftBundle\Entity\Report',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_jaspersoftbundle_report';
    }
}
