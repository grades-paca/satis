<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Transport;


use Oru\Bundle\MailBundle\Mailer\Mailer;
use Oru\Bundle\OtpBundle\Entity\Otp;
use Oru\Bundle\SmsBundle\Manager\SmsManager;
use Symfony\Component\DependencyInjection\Container;

class OtpTransport
{

    /**
     * @var SmsManager
     */
    protected $smsManager;

    /**
     * @var Mailer
     */
    protected $mailer;

    /**
     * @var
     */
    protected $twig;

    /**
     * OtpTransport constructor.
     */
    public function __construct(Container $container)
    {
        if(array_search('OruSmsBundle', $container->getParameter('disabled_bundles')) === FALSE) {
            $this->smsManager = $container->get('oru_sms.manager');
        } else {
            $this->smsManager = null;
        }
        $this->mailer = $container->get('oru_mail.mailer');
    }

    /**
     * Envoi un code en fonction du transort choisi.
     *
     * @param Otp $otp
     * @return int
     */
    public function sendCode(Otp $otp)
    {
        switch($otp->getMethod()) {
            case 'sms' :
                if($this->smsManager) {
                    return $this->smsManager->sendSmsMessage('OruOtpBundle:Otp:sms.txt.twig', array('code' => $otp->getCode()), '0' . $otp->getUser()->getTelephoneSecours()->getNationalNumber());
                }

            case 'email' :
            default :
                return $this->mailer->sendEmailMessage('OruOtpBundle:Otp:email.txt.twig', array('code' => $otp->getCode()), $otp->getUser()->getEmail());
        }
    }
}