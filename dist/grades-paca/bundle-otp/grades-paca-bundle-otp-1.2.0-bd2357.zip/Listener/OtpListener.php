<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Listener;

use Oru\Bundle\OtpBundle\Event\OtpEvent;
use Oru\Bundle\OtpBundle\Event\OtpFirewallEvent;
use Oru\Bundle\OtpBundle\Event\OtpRouteEvent;
use Oru\Bundle\OtpBundle\Manager\OtpManager;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Symfony\Bundle\FrameworkBundle\Routing\Router;
use Symfony\Component\EventDispatcher\EventDispatcher;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpKernel\Event\GetResponseEvent;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class OtpListener
{
    /**
     * @var OtpManager
     */
    protected $otpManager;

    /**
     * @var Setting
     */
    protected $setting;

    /**
     * @var Session
     */
    protected $session;

    /**
     * @var EventDispatcher
     */
    protected $eventDispatcher;

    /**
     * @var TokenStorageInterface
     */
    private $token;

    /**
     * OtpManager constructor.
     */
    public function __construct(OtpManager $otpManager, Setting $setting, Router $router, EventDispatcherInterface $eventDispatcher, TokenStorageInterface $token)
    {
        $this->otpManager = $otpManager;
        $this->setting = $setting;
        $this->router = $router;
        $this->eventDispatcher = $eventDispatcher;
        $this->token = $token;
    }

    /**
     * Ecouteur de vérification si une authentification OTP est nécessaire.
     *
     * @param GetResponseEvent $event
     */
    public function checkOtp(GetResponseEvent $event)
    {
        if (!$this->otpManager->isValid()) {
            if ($this->token && $this->token->getToken()) {
                // ce firewall doit-il être sécurisé via OTP ?
                $otpFirewallEvent = new OtpFirewallEvent($this->token->getToken());
                $this->eventDispatcher->dispatch(OtpFirewallEvent::NAME, $otpFirewallEvent);
                if ($otpFirewallEvent->isPropagationStopped()) {
                    switch ($this->setting->setting('otp', 'OruOtpBundle')) {
                        // nécessaire à la connexion
                        case 1:
                            $route = $event->getRequest()->get('_route');
                            $otpRouteEvent = new OtpRouteEvent();
                            $this->eventDispatcher->dispatch(OtpRouteEvent::NAME, $otpRouteEvent);
                            if ($route && array_search($route, $otpRouteEvent->getRoutes(), true) === false) {
                                $response = new RedirectResponse($this->router->generate('otp_choose'));
                                $event->setResponse($response);
                                $this->otpManager->saveRequest($event->getRequest());
                            }

                            return $event;
                        // optionnel via écouteur (voir bundle OruRorOtpBundle
                        case 2:
                            $otpEvent = new OtpEvent($event->getRequest());
                            $this->eventDispatcher->dispatch(OtpEvent::NAME, $otpEvent);
                            if ($otpEvent->isPropagationStopped()) {
                                $otpRouteEvent = new OtpRouteEvent($event->getRequest(), $this->token);
                                $this->eventDispatcher->dispatch(OtpRouteEvent::NAME, $otpRouteEvent);
                                $route = $event->getRequest()->get('_route');
                                if ($route && array_search($route, $otpRouteEvent->getRoutes(), true) === false) {
                                    $response = new RedirectResponse($this->router->generate('otp_choose'));
                                    $event->setResponse($response);
                                    $this->otpManager->saveRequest($event->getRequest());
                                }
                            }

                            return $event;
                        // pas nécessaire
                        case 0:
                        default:
                            return $event;
                    }
                }
            }
        }
    }
}
