<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Entity;

use Oru\Bundle\ProfessionnelBundle\Entity\Professionnel;
use OTPHP\HOTP;

class Otp
{
    /**
     * @var string
     */
    private $method;

    /**
     * @var string
     */
    private $code;

    /**
     * @var Professionnel
     */
    private $user;

    /**
     * @var HOTP
     */
    private $hotp;

    /**
     * @var string
     */
    private $value;

    /**
     * Otp constructor.
     *
     * @param mixed $user
     * @param mixed $secret
     * @param mixed $counter
     */
    public function __construct($user, $secret = 0, $counter = 0)
    {
        $this->user = $user;
        if ($secret) {
            $this->hotp = new HOTP($user->getEmail(), $secret);
            $this->code = $this->hotp->at($counter);
        }
    }

    /**
     * @return string
     */
    public function getMethod()
    {
        return $this->method;
    }

    /**
     * @param string $method
     */
    public function setMethod($method)
    {
        $this->method = $method;
    }

    /**
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @param string $code
     */
    public function setCode($code)
    {
        $this->code = $code;
    }

    /**
     * @return Professionnel
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * @param Professionnel $user
     */
    public function setUser($user)
    {
        $this->user = $user;
    }

    /**
     * @return HOTP
     */
    public function getHotp()
    {
        return $this->hotp;
    }

    /**
     * @param HOTP $hotp
     */
    public function setHotp($hotp)
    {
        $this->hotp = $hotp;
    }

    /**
     * @return string
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @param string $value
     */
    public function setValue($value)
    {
        $this->value = $value;
    }
}
