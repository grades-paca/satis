<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Form;

use Oru\Bundle\OtpBundle\Manager\OtpManager;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class OtpChooseType extends AbstractType
{
    /**
     * @var array
     */
    private $choices;

    /**
     * OtpType constructor.
     */
    public function __construct(OtpManager $otpManager)
    {
        $rpt = 'x';
        $this->choices = array_flip($otpManager->getAvailableMethods());
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('method', ChoiceType::class, array('choices_as_values' => true, 'required' => true, 'label' => 'Otp.choose', 'translation_domain' => 'OruOtpBundle', 'choices' => $this->choices, 'expanded' => true))
            ->add('submit', SubmitType::class, array('label' => 'listing.action.submit', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-primary')))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\OtpBundle\Entity\Otp',
            'validation_groups' => 'choose',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_otpbundle_choose';
    }

    /**
     * @return string
     */
    public function getExtendedType()
    {
        return method_exists(AbstractType::class, 'getBlockPrefix') ? FormType::class : 'form';
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->getBlockPrefix();
    }
}
