<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Event;

use Symfony\Component\EventDispatcher\Event;

/**
 * Class OtpRouteEvent.
 */
class OtpRouteEvent extends Event
{
    const NAME = 'oru_otp.route.add';

    /**
     * @var array
     */
    protected $routes;

    /**
     * OtpRouteEvent constructor.
     */
    public function __construct()
    {
        $this->routes = array('otp_choose', 'otp_send', 'otp_check');
    }

    public function addRoute($route)
    {
        if (array_search($route, $this->routes, true) === false) {
            $this->routes[] = $route;
        }
    }

    /**
     * @return array
     */
    public function getRoutes()
    {
        return $this->routes;
    }
}
