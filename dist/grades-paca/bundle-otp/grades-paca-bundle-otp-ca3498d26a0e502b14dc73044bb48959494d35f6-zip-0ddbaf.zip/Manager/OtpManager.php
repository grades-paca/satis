<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Manager;


use Base32\Base32;
use Oru\Bundle\OtpBundle\Exception\NeedWaitException;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

class OtpManager
{
    /**
     * @var Session
     */
    protected $session;

    /**
     * @var TokenStorageInterface
     */
    private $tokenStorage;

    /**
     * @var AuthorizationCheckerInterface
     */
    private $authorizationChecker;

    /**
     * @var integer Temps d'attente avant de pouvoir demander un nouveau code
     */
    private $wait;

    /**
     * OtpManager constructor.
     */
    public function __construct(Session $session, TokenStorageInterface $tokenStorage, AuthorizationCheckerInterface $authorizationChecker, Setting $setting)
    {
        $this->session = $session;
        $this->tokenStorage = $tokenStorage;
        $this->authorizationChecker = $authorizationChecker;
        $this->wait = $setting->setting('wait', 'OruOtpBundle');
    }

    /**
     * La connexion OTP a-t-elle été validée
     *
     * @return bool
     */
    public function isValid()
    {
        if($this->session->get('cps.authentification')) {
            return true;
        }

        if($this->session->get('otp.valid')) {
            return true;
        }

        $logged = $this->tokenStorage->getToken() && $this->authorizationChecker->isGranted('IS_AUTHENTICATED_FULLY');
        if(!$logged) {
            return true;
        }

        return false;
    }

    /**
     * Valider la connexion OTP et retirer les données de la session
     *
     * @return mixed
     */
    public function setValid()
    {
        $uri = $this->session->get('otp.request_uri', '/');
        $this->session->remove('otp.secret');
        $this->session->remove('otp.counter');
        $this->session->remove('otp.request_uri');
        $this->session->remove('otp.timestamp');
        $this->session->remove('otp.last');
        $this->session->remove('otp.last_multiple');
        $this->session->set('otp.valid', true);
        return $uri;
    }

    /**
     * Invalider la connexion OTP et retirer les données de la session
     */
    public function setInvalid()
    {
        $this->session->remove('otp.secret');
        $this->session->remove('otp.counter');
        $this->session->remove('otp.timestamp');
        $this->session->remove('otp.valid');
    }

    /**
     * Génère un secret et counter en session
     *
     */
    public function generate()
    {
        $duree = $this->counter();
        if ($duree) {
            throw new NeedWaitException("Merci de patienter {$duree} secondes avant de faire une nouvelle demande de code.");
        }
        $this->session->set('otp.secret', Base32::encode(random_bytes(256)));
        $this->session->set('otp.counter', $this->session->get('otp.counter', 0) + 1);
        $this->session->set('otp.timestamp', time());
    }

    /**
     * Sauvegarde la base demandée
     *
     * @param $uri
     */
    public function saveRequest(Request $request)
    {
        if(!$request->isXmlHttpRequest() && !$this->session->has('otp.request_uri')) {
            $this->session->set('otp.request_uri', $request->getRequestUri());
        }
    }

    /**
     * Vérifie la durée d'expiration du code
     */
    public function verifyDuration($duration)
    {
        return ($this->session->get('otp.timestamp') + $duration < time());
    }

    /**
     * Temps d'attente nécessaire avant de pouvoir demander un nouveau code
     *
     * @return int
     */
    public function counter()
    {
        $duree = $this->wait*$this->session->get('otp.last_multiple', 1);
        $diff = time() - $this->session->get('otp.last', (time() - $duree));
        if ($diff < $duree) {
            $this->session->set('otp.last', time());
            $multiple = $this->session->get('otp.last_multiple', false);
            if ($multiple) {
                $this->session->set('otp.last_multiple', $multiple*2);
            } else {
                $this->session->set('otp.last_multiple', 1);
            }
            return $duree;
        }

        $this->session->set('otp.last', time());
        $this->session->remove('otp.last_multiple');
        return 0;
    }
}