<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Event;

use Symfony\Component\EventDispatcher\Event;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;

/**
 * Class OtpEvent.
 */
class OtpFirewallEvent extends Event
{
    const NAME = 'oru_otp.firewall.pass';

    /**
     * @var TokenInterface
     */
    protected $token;

    /**
     * OtpEvent constructor.
     */
    public function __construct(TokenInterface $token)
    {
        $this->token = $token;
    }

    /**
     * @return TokenInterface
     */
    public function getToken()
    {
        return $this->token;
    }
}
