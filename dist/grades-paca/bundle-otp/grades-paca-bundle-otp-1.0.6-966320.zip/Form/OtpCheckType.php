<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Form;


use Oru\Bundle\ProfessionnelBundle\Entity\Professionnel;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class OtpCheckType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('value', 'text', array('required' => true, 'label' => 'Otp.code', 'translation_domain' => 'OruOtpBundle'))
            ->add('submit', 'submit', array('label' => 'listing.action.submit', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-primary')))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\OtpBundle\Entity\Otp',
            'validation_groups' => 'check'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_otpbundle_check';
    }
}