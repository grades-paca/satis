<?php

namespace Oru\Bundle\OtpBundle;

use Oru\Bundle\SettingBundle\Bundle\OruBundle;

class OruOtpBundle extends OruBundle
{
    public static function getFriendlyName()
    {
        return 'One Time Password';
    }

    public static function getDescription()
    {
        return "Bundle permettant la gestion de codes OTP";
    }

}
