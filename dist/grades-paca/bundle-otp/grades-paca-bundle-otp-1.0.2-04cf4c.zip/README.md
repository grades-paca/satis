OruOtpBundle
================

Description
-----------

Ce bundle fournit un service d'authentification via code OTP.

Installation
------------

Importer le paquet via composer

```
composer require "oru/otp"
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\OtpBundle\OruOtpBundle();
```

Dans le config.yml, ajouter l'import de la config

``` yml
imports:
    ...
    - { resource: @OruOtpBundle/Resources/config/config.yml }
```

Dans le routing, ajouter une entrée pour activer l'interface de ce bundle

``` yml
oru_otp:
    resource: "@OruOtpBundle/Resources/config/routing.xml"
    prefix: /otp
```

Vider le cache de Symfony2

Utilisation
-----------

Deux paramètres permettent de modifier le comportement de ce bundle :
- otp : Activer ou désactiver ce bundle. 0 : désactivé, 1 : activé à la connexion pour tous, 2 : activé via listener (voir bundle OruRorOtpBundle)
- duration : durée de validité d'un code OTP