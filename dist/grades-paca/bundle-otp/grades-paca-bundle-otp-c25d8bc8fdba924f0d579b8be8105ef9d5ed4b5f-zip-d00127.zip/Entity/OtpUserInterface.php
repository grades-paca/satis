<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Entity;

interface OtpUserInterface
{
    public function getTelephone();

    public function getEmail();
}
