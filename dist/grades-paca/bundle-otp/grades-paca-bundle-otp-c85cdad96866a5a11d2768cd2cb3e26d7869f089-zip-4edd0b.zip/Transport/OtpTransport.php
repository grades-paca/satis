<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Transport;


use Oru\Bundle\MailBundle\Mailer\Mailer;
use Oru\Bundle\OtpBundle\Entity\Otp;
use Oru\Bundle\SmsBundle\Manager\SmsManager;
use Symfony\Component\DependencyInjection\Container;

class OtpTransport
{

    /**
     * @var SmsManager
     */
    protected $smsManager;

    /**
     * @var Mailer
     */
    protected $mailer;

    /**
     * @var
     */
    protected $twig;

    /**
     * OtpTransport constructor.
     */
    public function __construct(Container $container)
    {
        if(array_search('OruSmsBundle', $container->getParameter('disabled_bundles')) === FALSE) {
            $this->smsManager = $container->get('oru_sms.manager');
        } else {
            $this->smsManager = null;
        }
        $this->mailer = $container->get('oru_mail.mailer');
    }

    /**
     * Envoi un code en fonction du transort choisi.
     *
     * @param Otp $otp
     * @return int
     */
    public function sendCode(Otp $otp)
    {
        switch($otp->getMethod()) {
            case 'sms' :
                if($this->smsManager) {
                    try {
                        return $this->smsManager->sendSmsMessage('@OruOtp/Otp/sms.txt.twig', array('code' => $otp->getCode()), '0' . $otp->getUser()->getTelephoneSecours()->getNationalNumber());
                    } catch(\Exception $e) {
                        return false;
                    }
                }

            case 'email' :
            default :
                try {
                    return $this->mailer->sendEmailMessage('@OruOtp/Otp/email.txt.twig', array('code' => $otp->getCode()), $otp->getUser()->getEmail());
                } catch(\Exception $e) {
                    return false;
                }
        }
    }
}