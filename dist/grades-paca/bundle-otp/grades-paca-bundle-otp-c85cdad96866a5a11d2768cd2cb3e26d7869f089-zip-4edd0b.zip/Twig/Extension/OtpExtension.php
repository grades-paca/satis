<?php

namespace Oru\Bundle\OtpBundle\Twig\Extension;

use Oru\Bundle\OtpBundle\Manager\OtpManager;

class OtpExtension extends \Twig_Extension
{
    /**
     * @var OtpManager
     */
    public $otpm;

    public function __construct(OtpManager $otpm)
    {
        $this->otpm = $otpm;
    }

    /**
     * {@inheritdoc}
     */
    public function getFunctions()
    {
        return array(
            new \Twig_SimpleFunction('otp_wait', array($this, 'wait'), array('is_safe' => array('html'))),
        );
    }

    /**
     * Temps d'attente avant de pouvoir demander un nouveau code
     *
     * @return int
     */
    public function wait()
    {
        return $this->otpm->counter();
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'oru_otp.twig.extension.otp';
    }
}
