<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Event;


use Symfony\Component\EventDispatcher\Event;
use Symfony\Component\HttpFoundation\Request;

/**
 * Class OtpEvent
 * @package Oru\Bundle\OtpBundle\Event
 *
 * Cet évenement est utilisé si le mode OTP est à 2 : optionnel.
 * Dans ce cas, n'importe quel bundle peut écouter cet évenement et indiquer si un code OTP est nécessaire.
 */
class OtpEvent extends Event
{
    const NAME = 'oru_otp.pass';

    /**
     * @var Request
     */
    protected $request;

    /**
     * OtpEvent constructor.
     */
    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    /**
     * @return Request
     */
    public function getRequest()
    {
        return $this->request;
    }
}