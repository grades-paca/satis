<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Manager;


use Base32\Base32;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

class OtpManager
{
    /**
     * @var Session
     */
    protected $session;

    /**
     * @var TokenStorageInterface
     */
    private $tokenStorage;

    /**
     * @var AuthorizationCheckerInterface
     */
    private $authorizationChecker;

    /**
     * OtpManager constructor.
     */
    public function __construct(Session $session, TokenStorageInterface $tokenStorage, AuthorizationCheckerInterface $authorizationChecker)
    {
        $this->session = $session;
        $this->tokenStorage = $tokenStorage;
        $this->authorizationChecker = $authorizationChecker;
    }

    /**
     * La connexion OTP a-t-elle été validée
     *
     * @return bool
     */
    public function isValid()
    {
        if($this->session->get('cps.authentification')) {
            return true;
        }

        if($this->session->get('otp.valid')) {
            return true;
        }

        $logged = $this->tokenStorage->getToken() && $this->authorizationChecker->isGranted('IS_AUTHENTICATED_FULLY');
        if(!$logged) {
            return true;
        }

        return false;
    }

    /**
     * Valider la connexion OTP et retirer les données de la session
     *
     * @return mixed
     */
    public function setValid()
    {
        $uri = $this->session->get('otp.request_uri', '/');
        $this->session->remove('otp.secret');
        $this->session->remove('otp.counter');
        $this->session->remove('otp.request_uri');
        $this->session->remove('otp.timestamp');
        $this->session->set('otp.valid', true);
        return $uri;
    }

    /**
     * Invalider la connexion OTP et retirer les données de la session
     */
    public function setInvalid()
    {
        $this->session->remove('otp.secret');
        $this->session->remove('otp.counter');
        $this->session->remove('otp.timestamp');
        $this->session->remove('otp.valid');
    }

    /**
     * Génère un secret et counter en session
     *
     */
    public function generate()
    {
        $this->session->set('otp.secret', Base32::encode(random_bytes(256)));
        $this->session->set('otp.counter', $this->session->get('otp.counter', 0) + 1);
        $this->session->set('otp.timestamp', time());
    }

    /**
     * Sauvegarde la base demandée
     *
     * @param $uri
     */
    public function saveRequest($uri)
    {
        $this->session->set('otp.request_uri', $uri);
    }

    /**
     * Vérifie la durée d'expiration du code
     */
    public function verifyDuration($duration)
    {
        return ($this->session->get('otp.timestamp') + $duration < time());
    }
}