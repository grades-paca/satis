<?php

namespace Oru\Bundle\OtpBundle\Controller;

use Oru\Bundle\DesignBundle\Controller\FlashControllerTrait;
use Oru\Bundle\OtpBundle\Entity\Otp;
use Oru\Bundle\OtpBundle\Exception\NeedWaitException;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class OtpController extends Controller
{
    use FlashControllerTrait;

    /**
     * Choix du mode d'envoi d'un code OTP
     *
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function chooseAction()
    {
        // envoi automatique si un seul mode de transport existe, qu'un temps d'attente n'est pas nécessaire et que le paramètre auto est à oui
        $methods = $this->get('oru_otp.manager')->getAvailableMethods($this->getUser());
        if (count($methods) == 1 && !$this->get('oru_otp.manager')->counter() && $this->get('oru_setting')->setting('auto', 'OruOtpBundle')) {
            $this->get('oru_otp.manager')->generate();
            $name = reset ($methods);
            $entity = new Otp($this->getUser(), $this->get('session')->get('otp.secret'), $this->get('session')->get('otp.counter'));
            $entity->setMethod(key($methods));
            if(!$this->get('oru_otp.transport')->sendCode($entity)) {
                $this->addSessionMessage("Une erreur s'est produite en utilisant le mode de transport '" . $entity->getMethod() . "'. Utiliser le formulaire de contact pour demander une assistance.", 'error');
                return $this->redirect($this->generateUrl('contact'));
            } else {
                $this->addSessionMessage("Votre code vous a été transmis sur le seul mode de transport disponible pour votre compte : '$name'.", 'success');

            }

            return $this->redirect($this->generateUrl('otp_check'));
        }

        // sinon formulaire de choix du mode de transport
        $form = $this->createChooseForm(new Otp($this->getUser()));

        return $this->render('@OruOtp/Otp/choose.html.twig', array('form' => $form->createView()));
    }

    /**
     * Envoi du code OTP
     *
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     */
    public function sendAction(Request $request)
    {
        try {
            $this->get('oru_otp.manager')->generate();
        } catch (NeedWaitException $e) {
            $this->addSessionMessage($e->getMessage(), 'error');
            return $this->redirect($this->generateUrl('otp_choose'));
        }

        $entity = new Otp($this->getUser(), $this->get('session')->get('otp.secret'), $this->get('session')->get('otp.counter'));
        $form = $this->createChooseForm($entity)->handleRequest($request);

        if($form->isValid()) {
            if(!$this->get('oru_otp.transport')->sendCode($entity)) {
                $this->addSessionMessage("Une erreur s'est produite en utilisant le mode de transport '" . $entity->getMethod() . "'. Si possible, utilisez un autre mode de transport ou utiliser le formulaire de contact pour demander assistance.", 'error');
                return $this->redirect($this->generateUrl('otp_choose'));
            }

            return $this->redirect($this->generateUrl('otp_check'));
        }

        return $this->render('@OruOtp/Otp/choose.html.twig', array('form' => $form->createView()));
    }

    /**
     * Vérification du code OTP
     *
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     */
    public function checkAction(Request $request)
    {
        $entity = new Otp($this->getUser(), $this->get('session')->get('otp.secret'), $this->get('session')->get('otp.counter'));
        $form = $this->createCheckForm($entity)->handleRequest($request);

        if($request->getMethod() == 'POST') {
            if ($form->isValid()) {
                if($this->get('oru_otp.manager')->verifyDuration($this->get('oru_setting')->setting('duration', 'OruOtpBundle'))) {
                    $this->addSessionMessage("Le code d'authentification a expiré !", 'error');
                    $this->get('oru_otp.manager')->setInvalid();
                    return $this->redirect($this->generateUrl('otp_choose'));
                }

                if ($entity->getHotp()->verify($entity->getValue(), (int)$this->get('session')->get('otp.counter'))) {
                    $uri = $this->get('oru_otp.manager')->setValid();
                    return $this->redirect($uri);
                }

                $this->addSessionMessage("Le code d'authentification est incorrect !", 'error');
                $this->get('oru_otp.manager')->setInvalid();
                try {
                    $this->get('oru_otp.manager')->checkCounter(true);
                } catch (NeedWaitException $e) {
                    $this->addSessionMessage($e->getMessage(), 'error');
                }

                return $this->redirect($this->generateUrl('otp_choose'));
            }
        }

        return $this->render('@OruOtp/Otp/check.html.twig', array('form' => $form->createView()));
    }

    /**
     * Route permettant de réinitialiser le code OTP
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function removeAction()
    {
        $this->get('oru_otp.manager')->setInvalid();
        return $this->redirect($this->generateUrl('ror_homepage'));
    }

    /**
     * @param $entity
     * @return \Symfony\Component\Form\Form
     */
    protected function createChooseForm($entity)
    {
        $form = $this->createForm($this->get('oru_otp.choose.form'), $entity, array(
            'action' => $this->generateUrl('otp_send'),
            'method' => 'POST',
        ));

        return $form;
    }

    /**
     * @param $entity
     * @return \Symfony\Component\Form\Form
     */
    protected function createCheckForm($entity)
    {
        $form = $this->createForm($this->get('oru_otp.check.form'), $entity, array(
            'action' => $this->generateUrl('otp_check'),
            'method' => 'POST',
        ));

        return $form;
    }
}
