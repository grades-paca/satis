<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\OtpBundle\Listener;


use Oru\Bundle\OtpBundle\Event\OtpEvent;
use Oru\Bundle\OtpBundle\Manager\OtpManager;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Oru\Bundle\OtpBundle\Event\OtpRouteEvent;
use Symfony\Bundle\FrameworkBundle\Routing\Router;
use Symfony\Component\EventDispatcher\Debug\TraceableEventDispatcherInterface;
use Symfony\Component\EventDispatcher\EventDispatcher;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpKernel\Event\GetResponseEvent;

class OtpListener
{
    /**
     * @var OtpManager
     */
    protected $otpManager;

    /**
     * @var Setting
     */
    protected $setting;

    /**
     * @var Session
     */
    protected $session;

    /**
     * @var EventDispatcher
     */
    protected $eventDispatcher;

    /**
     * OtpManager constructor.
     */
    public function __construct(OtpManager $otpManager, Setting $setting, Router $router, TraceableEventDispatcherInterface $eventDispatcher)
    {
        $this->otpManager = $otpManager;
        $this->setting = $setting;
        $this->router = $router;
        $this->eventDispatcher = $eventDispatcher;
    }

    /**
     * Ecouteur de vérification si une authentification OTP est nécessaire
     *
     * @param GetResponseEvent $event
     */
    public function checkOtp(GetResponseEvent $event)
    {
        if(!$this->otpManager->isValid()) {
            switch($this->setting->setting('otp', 'OruOtpBundle')) {
                // nécessaire à la connexion
                case 1 :
                    $route = $event->getRequest()->get('_route');
                    $otpRouteEvent = new OtpRouteEvent();
                    $this->eventDispatcher->dispatch(OtpRouteEvent::NAME, $otpRouteEvent);
                    if ($route && array_search($route, $otpRouteEvent->getRoutes()) === FALSE) {
                        $response = new RedirectResponse($this->router->generate('otp_choose'));
                        $event->setResponse($response);
                        $this->otpManager->saveRequest($event->getRequest()->getRequestUri());
                    }
                    return $event;

                // optionnel via écouteur (voir bundle OruRorOtpBundle
                case 2 :
                    $otpEvent = new OtpEvent($event->getRequest());
                    $this->eventDispatcher->dispatch(OtpEvent::NAME, $otpEvent);
                    if ($otpEvent->isPropagationStopped()) {
                        $otpRouteEvent = new OtpRouteEvent();
                        $this->eventDispatcher->dispatch(OtpRouteEvent::NAME, $otpRouteEvent);
                        $route = $event->getRequest()->get('_route');
                        if ($route && array_search($route, $otpRouteEvent->getRoutes()) === FALSE) {
                            $response = new RedirectResponse($this->router->generate('otp_choose'));
                            $event->setResponse($response);
                            $this->otpManager->saveRequest($event->getRequest()->getRequestUri());
                        }
                    }
                    return $event;

                // pas nécessaire
                case 0 :
                default :
                    return $event;
            }
        }
    }
}