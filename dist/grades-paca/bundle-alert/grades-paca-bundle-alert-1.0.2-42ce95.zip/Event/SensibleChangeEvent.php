<?php

namespace Oru\Bundle\AlertBundle\Event;

use Symfony\Component\EventDispatcher\Event;

/**
 * Class SensibleChangeEvent.
 *
 * @author Michaël VEROUX
 */
class SensibleChangeEvent extends Event
{
    /**
     * @var string
     */
    protected $watchedElement;

    /**
     * @var string
     */
    protected $watchedName;

    /**
     * @var string
     */
    protected $before;

    /**
     * @var string
     */
    protected $after;

    /**
     * @var string
     */
    protected $template = 'OruAlertBundle::sensibleChange.html.twig';

    /**
     * @return string
     */
    public function getWatchedElement()
    {
        return $this->watchedElement;
    }

    /**
     * @param string $watchedElement
     *
     * @return $this
     */
    public function setWatchedElement($watchedElement)
    {
        $this->watchedElement = $watchedElement;

        return $this;
    }

    /**
     * @return string
     */
    public function getWatchedName()
    {
        return $this->watchedName;
    }

    /**
     * @param string $watchedName
     *
     * @return $this
     */
    public function setWatchedName($watchedName)
    {
        $this->watchedName = $watchedName;

        return $this;
    }

    /**
     * @return string
     */
    public function getBefore()
    {
        return $this->before;
    }

    /**
     * @param string $before
     *
     * @return $this
     */
    public function setBefore($before)
    {
        $this->before = $before;

        return $this;
    }

    /**
     * @return string
     */
    public function getAfter()
    {
        return $this->after;
    }

    /**
     * @param string $after
     *
     * @return $this
     */
    public function setAfter($after)
    {
        $this->after = $after;

        return $this;
    }

    /**
     * @return string
     */
    public function getTemplate()
    {
        return $this->template;
    }

    /**
     * @param string $template
     *
     * @return $this
     */
    public function setTemplate($template)
    {
        $this->template = $template;

        return $this;
    }
}
