<?php

namespace Oru\Bundle\AlertBundle;

use Oru\Bundle\AlertBundle\DependencyInjection\Compiler\AlertCompilerPass;
use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Symfony\Component\DependencyInjection\ContainerBuilder;

/**
 * Class OruAlertBundle.
 *
 * @author Michaël VEROUX
 */
class OruAlertBundle extends OruBundle
{
    /**
     * @param ContainerBuilder $container
     */
    public function build(ContainerBuilder $container)
    {
        parent::build($container);

        $container->addCompilerPass(new AlertCompilerPass());
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getFriendlyName()
    {
        return 'Alerte des changements sensibles';
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getDescription()
    {
        return 'Module pour alerter des changements sensibles surveillés sur l\'application';
    }
}
