<?php

namespace Oru\Bundle\AlertBundle\Event;

/**
 * Class Events.
 *
 * @author Michaël VEROUX
 */
class Events
{
    const SENSIBLE_CHANGE = 'oru_alert.sensible_change';
}
