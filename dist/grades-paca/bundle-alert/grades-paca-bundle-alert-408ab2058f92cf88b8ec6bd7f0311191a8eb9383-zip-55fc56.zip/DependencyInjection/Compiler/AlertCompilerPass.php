<?php

namespace Oru\Bundle\AlertBundle\DependencyInjection\Compiler;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

/**
 * Class AlertCompilerPass.
 *
 * @author Michaël VEROUX
 */
class AlertCompilerPass implements CompilerPassInterface
{
    /**
     * You can modify the container here before it is dumped to PHP code.
     */
    public function process(ContainerBuilder $container)
    {
        if ($container->hasDefinition('oru_alert.sensible_change')) {
            $definition = $container->getDefinition('oru_alert.sensible_change');

            $email = null;
            if ($container->hasParameter('email_alert')) {
                $email = $container->getParameter('email_alert');
            }

            $definition->replaceArgument(5, $email);
        }
    }
}
