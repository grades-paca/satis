OruAlertBundle
==============

Utilisation
-----------

Créer un événement et le lancer. Un email sera envoyé à l'adresse contenue dans le setting email_alert, s'il n'est pas renseigné, l'adresse mail_rcpt sera utilisée.

```php
use Oru\Bundle\AlertBundle\Event\Events;
use Oru\Bundle\AlertBundle\Event\SensibleChangeEvent;

        $event = new SensibleChangeEvent();
        $event->setWatchedElement('Setting');
        $event->setWatchedName('param_name');
        $event->setAfter('better_value');
        $event->setBefore('first_value');

        $this->get('event_dispatcher')->dispatch(Events::SENSIBLE_CHANGE, $event);
```

Le mail envoyé ressemblera à ceci :

```html
Changement sensible

Région : Paca
Changement de param_name dans Setting le 1 avril 2017 à 9h20m25s par Michael Veroux.
Valeur initiale : first_value
Nouvelle valeur : better_value
```

Il est possible de fournir un template de mail différent. Pour cela, il faut faire un template twig et le donner à l'évènement tel que suit :

```php
$event->setTemplate('@My/Alert/MyTplMail.html.twig');
```

Les variables envoyées au template en plus des variables globales, sont :
- watchedElement
- watchedName
- before
- after
- updatedAt
- professionnel
- region
