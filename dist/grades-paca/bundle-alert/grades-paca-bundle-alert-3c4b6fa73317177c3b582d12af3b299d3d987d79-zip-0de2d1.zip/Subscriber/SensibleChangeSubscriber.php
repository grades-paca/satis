<?php

namespace Oru\Bundle\AlertBundle\Subscriber;

use Oru\Bundle\AlertBundle\Event\Events;
use Oru\Bundle\AlertBundle\Event\SensibleChangeEvent;
use Oru\Bundle\MailBundle\Mailer\Mailer;
use Oru\Bundle\ProfessionnelBundle\Entity\Professionnel;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Validator\ValidatorInterface;

/**
 * Class SensibleChangeSubscriber.
 *
 * @author Michaël VEROUX
 */
class SensibleChangeSubscriber implements EventSubscriberInterface
{
    /**
     * @var Mailer
     */
    protected $oruMailer;

    /**
     * @var Setting
     */
    protected $setting;

    /**
     * @var ValidatorInterface
     */
    protected $validator;

    /**
     * @var Professionnel|null
     */
    protected $professionnel;

    /**
     * @var string
     */
    protected $region;

    /**
     * SensibleChangeSubscriber constructor.
     *
     * @param Mailer                $oruMailer
     * @param Setting               $setting
     * @param ValidatorInterface    $validator
     * @param TokenStorageInterface $token
     * @param string                $region
     */
    public function __construct(Mailer $oruMailer, Setting $setting, ValidatorInterface $validator, TokenStorageInterface $token, $region = '')
    {
        $this->oruMailer = $oruMailer;
        $this->setting = $setting;
        $this->validator = $validator;
        $this->professionnel = $token->getToken()->getUser();
        $this->region = $region;
    }

    /**
     * Returns an array of event names this subscriber wants to listen to.
     *
     * The array keys are event names and the value can be:
     *
     *  * The method name to call (priority defaults to 0)
     *  * An array composed of the method name to call and the priority
     *  * An array of arrays composed of the method names to call and respective
     *    priorities, or 0 if unset
     *
     * For instance:
     *
     *  * array('eventName' => 'methodName')
     *  * array('eventName' => array('methodName', $priority))
     *  * array('eventName' => array(array('methodName1', $priority), array('methodName2')))
     *
     * @return array The event names to listen to
     */
    public static function getSubscribedEvents()
    {
        return array(
            Events::SENSIBLE_CHANGE => 'handle',
        );
    }

    /**
     * @param SensibleChangeEvent $sensibleChangeEvent
     *
     * @author Michaël VEROUX
     */
    public function handle(SensibleChangeEvent $sensibleChangeEvent)
    {
        $disabled = !$this->setting->setting('enabled', 'OruAlertBundle');
        if ($disabled) {
            return;
        }

        $template = $sensibleChangeEvent->getTemplate();
        $params = array(
            'watchedElement' => $sensibleChangeEvent->getWatchedElement(),
            'watchedName' => $sensibleChangeEvent->getWatchedName(),
            'updatedAt' => new \DateTime(),
            'professionnel' => $this->professionnel,
            'before' => $sensibleChangeEvent->getBefore(),
            'after' => $sensibleChangeEvent->getAfter(),
            'region' => $this->region,
        );

        $to = $this->setting->setting('email_alert', 'OruAlertBundle');
        if (!$this->isEmailValid($to)) {
            $to = $this->getDefaultEmail();
        }

        $this->oruMailer->sendEmailMessage($template, $params, $to);
    }

    /**
     * @param string|null $email
     *
     * @return bool
     *
     * @author Michaël VEROUX
     */
    private function isEmailValid($email)
    {
        if (!$email) {
            return false;
        }

        $violationList = $this->validator->validate($email, new Email());

        if ($violationList->count()) {
            return false;
        }

        return true;
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    private function getDefaultEmail()
    {
        $email = $this->setting->setting('mail_rcpt', 'OruMailBundle');

        return $email;
    }
}
