<?php

namespace Oru\Bundle\ProjectHumhubBundle\Helper;

use RestClient\Exception;
use stdClass;
use FOS\UserBundle\Model\UserInterface;
use Oru\Bundle\ProjectHumhubBundle\Date\Since;
use Oru\Bundle\ProjectHumhubBundle\Rest\Client;
use Oru\Bundle\ProjectHumhubBundle\Synchro\HumhubInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

/**
 * Class HumhubHelper
 *
 * @package Oru\Bundle\ProjectHumhubBundle\Helper
 * @author Michaël VEROUX
 */
class HumhubHelper
{
    /**
     * @var Client
     */
    protected $restClient;

    /**
     * @var TokenStorageInterface
     */
    protected $tokenStorage;

    /**
     * @var Since
     */
    protected $since;

    /**
     * HumhubHelper constructor.
     *
     * @param Client                $restClient
     * @param TokenStorageInterface $tokenStorage
     * @param Since                 $since
     */
    public function __construct(Client $restClient, TokenStorageInterface $tokenStorage, Since $since)
    {
        $this->restClient = $restClient;
        $this->tokenStorage = $tokenStorage;
        $this->since = $since;
    }

    /**
     * @param int $limit
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function getJsonNotifications($limit = 5)
    {
        return $this->getNotifications($limit, true);
    }

    /**
     * @param int  $limit
     * @param bool $json
     *
     * @return array|string|null
     * @author Michaël VEROUX
     */
    public function getNotifications($limit = 5, $json = false)
    {
        try {
            $humhubToken = $this->getCurrentUserAccessToken();
            if (!$humhubToken) {
                return array();
            }
        } catch (Exception $e) {
            return array();
        }

        $restUri = HumhubInterface::REST_NOTIFICATION_LIST;
        $response = $this->restClient->setAccessToken($humhubToken)->get($restUri, array('limit' => $limit));
        $notifications = json_decode($response->getParsedResponse(), true);
        if (!$notifications) {
            if ($json) {
                return json_encode(array());
            }

            return null;
        }
        if ($json) {
            return $response->getParsedResponse();
        }

        return $notifications;
    }

    /**
     * @param int $space
     * @param int $limit
     *
     * @return array|mixed|null|string
     * @author Michaël VEROUX
     */
    public function getSpaceActivitiesJson($space, $limit = 10)
    {
        return $this->getSpaceActivities($limit, true);
    }

    /**
     * @param int  $space
     * @param int  $limit
     * @param bool $json
     *
     * @return array|mixed|null|string
     * @author Michaël VEROUX
     */
    public function getSpaceActivities($space, $limit = 10, $json = false)
    {
        try {
            $humhubToken = $this->getCurrentUserAccessToken();
            if (!$humhubToken) {
                return array();
            }
        } catch (Exception $e) {
            return array();
        }

        $restUri = sprintf(HumhubInterface::REST_SPACE_MEMBER_ACTIVITIES, $space);
        $response = $this->restClient->setAccessToken($humhubToken)->get($restUri, array('limit' => $limit));
        $activities = json_decode($response->getParsedResponse(), true);
        $since = $this->since;
        $activities = array_map(function ($vars) use ($since) {
            if (isset($vars['date_raw']) && $date = new \DateTime($vars['date_raw'])) {
                $vars['date'] = $since->getHumanLocal($date);
            }

            return $vars;
        }, $activities);
        if (!$activities) {
            if ($json) {
                return json_encode(array());
            }

            return null;
        }
        if ($json) {
            return $response->getParsedResponse();
        }

        return $activities;
    }

    /**
     * @param int $limit
     *
     * @return array|mixed|null|string
     * @author Michaël VEROUX
     */
    public function getActivitiesJson($limit = 10)
    {
        return $this->getActivities($limit, true);
    }

    /**
     * @param int  $limit
     * @param bool $json
     *
     * @return array|mixed|null|string
     * @author Michaël VEROUX
     */
    public function getActivities($limit = 10, $json = false)
    {
        try {
            $humhubToken = $this->getCurrentUserAccessToken();
            if (!$humhubToken) {
                return array();
            }
        } catch (Exception $e) {
            return array();
        }

        $restUri = HumhubInterface::REST_MEMBER_ACTIVITIES;
        $response = $this->restClient->setAccessToken($humhubToken)->get($restUri, array('limit' => $limit));
        $activities = json_decode($response->getParsedResponse(), true);
        $since = $this->since;
        $activities = array_map(function ($vars) use ($since) {
            if (isset($vars['date_raw']) && $date = new \DateTime($vars['date_raw'])) {
                $vars['date'] = $since->getHumanLocal($date);
            }

            return $vars;
        }, $activities);
        if (!$activities) {
            if ($json) {
                return json_encode(array());
            }

            return null;
        }
        if ($json) {
            return $response->getParsedResponse();
        }

        return $activities;
    }

    /**
     * @param int $spaceId
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function getSpaceUri($spaceId)
    {
        $restUri = sprintf(HumhubInterface::REST_SPACE_VIEW, $spaceId);
        $response = $this->restClient->get($restUri);
        $space = json_decode($response->getParsedResponse(), true);
        $uri = '';
        if (isset($space['url'])) {
            $uri = sprintf('/s/%s', $space['url']);
        }

        return $uri;
    }

    /**
     * @return string|null
     * @throws Exception
     * @author Michaël VEROUX
     */
    private function getCurrentUserAccessToken()
    {
        if (!$this->tokenStorage->getToken()->getUser() instanceof UserInterface) {
            return null;
        }

        $restUri = sprintf(HumhubInterface::REST_USER_TOKEN, $this->tokenStorage->getToken()->getUser()->getId());
        $response = $this->restClient->get($restUri);
        $humhubToken = json_decode($response->getParsedResponse(), true);
        if (!$humhubToken) {
            return null;
        }
        if (is_array($humhubToken) && isset($humhubToken['code'])) {
            $message = 'Error';
            if (isset($humhubToken['message'])) {
                $message = $humhubToken['message'];
            }

            throw new Exception($message);
        }

        return $humhubToken;
    }
}
