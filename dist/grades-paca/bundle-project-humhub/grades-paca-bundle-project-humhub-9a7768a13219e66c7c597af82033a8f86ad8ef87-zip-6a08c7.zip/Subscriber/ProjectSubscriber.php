<?php

namespace Oru\Bundle\ProjectHumhubBundle\Subscriber;

use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\OnFlushEventArgs;
use Doctrine\ORM\Event\PostFlushEventArgs;
use Doctrine\ORM\Events;
use Oru\Bundle\MeetingBundle\Entity\Meeting;
use Oru\Bundle\ProjectBundle\Entity\Document;
use Oru\Bundle\ProjectBundle\Entity\Project;
use Oru\Bundle\SpoolBundle\Entity\Spool;
use Oru\Bundle\SpoolBundle\Event\SpoolEvent;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;

/**
 * Class ProjectSubscriber
 *
 * @package Oru\Bundle\ProjectHumhubBundle\Subscriber
 * @author Michaël VEROUX
 */
class ProjectSubscriber implements EventSubscriber
{
    /**
     * @var EventDispatcherInterface
     */
    protected $eventDispatcher;

    /**
     * @var array
     */
    private $events = array(
        'space'     => array(
            'new'       => array(),
            'update'    => array(),
        ),
        'meeting'   => array(
            'new'       => array(),
            'update'    => array(),
        ),
        'document'   => array(
            'new'       => array(),
            'update'    => array(),
        ),
    );

    /**
     * ProjectSubscriber constructor.
     *
     * @param EventDispatcherInterface $eventDispatcher
     */
    public function __construct(EventDispatcherInterface $eventDispatcher)
    {
        $this->eventDispatcher = $eventDispatcher;
    }

    /**
     * Returns an array of events this subscriber wants to listen to.
     *
     * @return array
     */
    public function getSubscribedEvents()
    {
        return array(
            Events::onFlush,
            Events::postFlush,
        );
    }

    /**
     * @param OnFlushEventArgs $args
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function onFlush(OnFlushEventArgs $args)
    {
        $uow = $args->getEntityManager()->getUnitOfWork();

        foreach ($uow->getScheduledEntityInsertions() as $scheduledEntityInsertion) {
            if ($scheduledEntityInsertion instanceof Project) {
                $this->events['space']['new'][] = $scheduledEntityInsertion;
            }
            if ($scheduledEntityInsertion instanceof Meeting) {
                $this->events['meeting']['new'][] = $scheduledEntityInsertion;
            }
            if ($scheduledEntityInsertion instanceof Document) {
                $this->events['document']['new'][] = $scheduledEntityInsertion;
            }
        }

        foreach ($uow->getScheduledEntityUpdates() as $scheduledEntityUpdate) {
            if ($scheduledEntityUpdate instanceof Project) {
                $this->events['space']['update'][] = $scheduledEntityUpdate;
            }
            if ($scheduledEntityUpdate instanceof Meeting) {
                $this->events['meeting']['update'][] = $scheduledEntityUpdate;
            }
            if ($scheduledEntityUpdate instanceof Document) {
                $changes = $uow->getEntityChangeSet($scheduledEntityUpdate);
                if (isset($changes['visible'])) {
                    $this->events['document']['update'][] = $scheduledEntityUpdate;
                }
            }
        }
    }

    /**
     * @param PostFlushEventArgs $args
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function postFlush(PostFlushEventArgs $args)
    {
        foreach ($this->events['space']['new'] as $entity) {
            /** @var Project $entity */
            $event = new SpoolEvent('oru_project_humhub.synchro');
            $event->setServiceCalls(array(
                'setProject'    =>  array($entity->getId()),
                'newProject'    =>  array(),
            ));
            $event->setPriority(Spool::PRIORITY_VERY_HIGH);

            $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
        }
        foreach ($this->events['space']['update'] as $entity) {
            $event = new SpoolEvent('oru_project_humhub.synchro');
            $event->setServiceCalls(array(
                'setProject'    =>  array($entity->getId()),
                'updateProject' =>  array(),
            ));
            $event->setPriority(Spool::PRIORITY_VERY_HIGH);

            $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
        }

        foreach ($this->events['meeting']['new'] as $entity) {
            /** @var Meeting $entity */
            $event = new SpoolEvent('oru_project_humhub.synchro');
            $event->setServiceCalls(array(
                                        'setProject'        =>  array($entity->getProject()->getId()),
                                        'setMeeting'        =>  array($entity->getId()),
                                        'newMeeting'        =>  array(),
                                    ));
            $event->setPriority(Spool::PRIORITY_HIGH);

            $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
        }
        foreach ($this->events['meeting']['update'] as $entity) {
            $event = new SpoolEvent('oru_project_humhub.synchro');
            $event->setServiceCalls(array(
                                        'setProject'        =>  array($entity->getProject()->getId()),
                                        'setMeeting'        =>  array($entity->getId()),
                                        'updateMeeting'     =>  array(),
                                    ));
            $event->setPriority(Spool::PRIORITY_HIGH);

            $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
        }

        foreach ($this->events['document']['new'] as $entity) {
            /** @var Document $entity */
            if ($entity->getVisible()) {
                $event = new SpoolEvent('oru_project_humhub.synchro');
                $event->setServiceCalls(array(
                                            'setProject'        =>  array($entity->getProject()->getId()),
                                            'setDocument'       =>  array($entity->getId()),
                                            'newDocument'       =>  array(),
                                        ));
                $event->setPriority(Spool::PRIORITY_HIGH);

                $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
            }
        }
        foreach ($this->events['document']['update'] as $entity) {
            if ($entity->getVisible()) {
                $event = new SpoolEvent('oru_project_humhub.synchro');
                $event->setServiceCalls(array(
                                            'setProject'     => array($entity->getProject()->getId()),
                                            'setDocument'    => array($entity->getId()),
                                            'newDocument' => array(),
                                        ));
                $event->setPriority(Spool::PRIORITY_HIGH);

                $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
            }
        }
    }
}
