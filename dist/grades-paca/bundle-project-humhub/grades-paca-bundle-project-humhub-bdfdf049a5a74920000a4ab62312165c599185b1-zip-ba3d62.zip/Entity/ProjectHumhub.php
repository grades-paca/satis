<?php

namespace Oru\Bundle\ProjectHumhubBundle\Entity;

use Oru\Bundle\ProjectBundle\Entity\Project;

/**
 * Class ProjectHumhub.
 *
 * @author Michaël VEROUX
 */
class ProjectHumhub
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var Project
     */
    protected $project;

    /**
     * @var int
     */
    protected $spaceHumhubId;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return Project
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * @param Project $project
     *
     * @return $this
     */
    public function setProject($project)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * @return int
     */
    public function getSpaceHumhubId()
    {
        return $this->spaceHumhubId;
    }

    /**
     * @param int $spaceHumhubId
     *
     * @return $this
     */
    public function setSpaceHumhubId($spaceHumhubId)
    {
        $this->spaceHumhubId = $spaceHumhubId;

        return $this;
    }
}
