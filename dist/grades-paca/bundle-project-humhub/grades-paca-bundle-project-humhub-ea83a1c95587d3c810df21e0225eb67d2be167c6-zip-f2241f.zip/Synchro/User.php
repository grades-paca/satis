<?php

namespace Oru\Bundle\ProjectHumhubBundle\Synchro;

use Doctrine\ORM\EntityManager;
use Monolog\Logger;
use Oru\Bundle\ProjectHumhubBundle\Rest\Client;
use Oru\Bundle\SpoolBundle\Exception\FailedException;
use RestClient\IResponse;

/**
 * Class User
 *
 * @package Oru\Bundle\ProjectHumhubBundle\Synchro
 * @author Michaël VEROUX
 */
class User implements HumhubInterface
{
    /**
     * @var EntityManager
     */
    protected $em;

    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @var Client
     */
    protected $restClient;

    /**
     * User constructor.
     *
     * @param EntityManager $em
     * @param Logger        $logger
     * @param Client        $restClient
     */
    public function __construct(EntityManager $em, Logger $logger, Client $restClient)
    {
        $this->em = $em;
        $this->logger = $logger;
        $this->restClient = $restClient;
    }

    /**
     * @param int $id
     *
     * @return void
     * @throws FailedException
     * @author Michaël VEROUX
     */
    public function createUser($id)
    {
        $professionnel = $this->em->getRepository('OruProfessionnelBundle:Professionnel')->find($id);
        if (!$professionnel) {
            throw new FailedException('Professionnel not found!');
        }

        $data = array(
            'id'        =>  $professionnel->getId(),
            'username'  =>  $professionnel->getUsername(),
            'firstname' =>  $professionnel->getPrenom(),
            'lastname'  =>  $professionnel->getNom(),
            'email'     =>  $professionnel->getEmail(),
        );

        $restUrl = self::REST_USER_CREATE;
        $this->logger->addDebug('Call to rest POST '.$restUrl);
        $response = $this->restClient->post($restUrl, $data);
        var_dump($this->getDataFromResponse($response).PHP_EOL);
    }

    /**
     * @param int $id
     *
     * @return void
     * @throws FailedException
     * @author Michaël VEROUX
     */
    public function updateUser($id)
    {
        $professionnel = $this->em->getRepository('OruProfessionnelBundle:Professionnel')->find($id);
        if (!$professionnel) {
            throw new FailedException('Professionnel not found!');
        }

        $data = array(
            'id'        =>  $professionnel->getId(),
            'username'  =>  $professionnel->getUsername(),
            'firstname' =>  $professionnel->getPrenom(),
            'lastname'  =>  $professionnel->getNom(),
            'email'     =>  $professionnel->getEmail(),
        );

        $restUrl = self::REST_USER_UPDATE;
        $this->logger->addDebug('Call to rest PUT '.$restUrl);
        $response = $this->restClient->put($restUrl, $data);
        var_dump($this->getDataFromResponse($response));
    }

    /**
     * @param IResponse $response
     *
     * @return mixed
     * @throws FailedException
     * @author Michaël VEROUX
     */
    protected function getDataFromResponse(IResponse $response)
    {
        $data = json_decode($response->getParsedResponse(), true);
        if (null === $data) {
            throw new FailedException('Unknow error');
        }

        return $data;
    }
}
