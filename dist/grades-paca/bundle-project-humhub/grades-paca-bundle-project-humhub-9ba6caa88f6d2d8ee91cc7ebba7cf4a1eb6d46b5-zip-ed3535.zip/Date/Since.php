<?php

namespace Oru\Bundle\ProjectHumhubBundle\Date;

use Symfony\Component\Translation\TranslatorInterface;
use DateTime;

/**
 * Class Since
 *
 * @package Oru\Bundle\ProjectHumhubBundle\Date
 * @author Michaël VEROUX
 */
class Since
{
    const SEC_YEAR = 31536000;
    const SEC_MONTH = 2592000;
    const SEC_WEEK = 604800;
    const SEC_DAY = 86400;
    const SEC_HOUR = 3600;
    const SEC_MIN = 60;

    /**
     * @var TranslatorInterface
     */
    protected $translator;

    /**
     * Since constructor.
     *
     * @param TranslatorInterface $translator
     */
    public function __construct(TranslatorInterface $translator)
    {
        $this->translator = $translator;
    }

    /**
     * @param DateTime $dateFrom
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function getHumanLocal(DateTime $dateFrom)
    {
        $now = new DateTime();
        $seconds = $now->format('U') - $dateFrom->format('U');

        if (self::SEC_YEAR < $seconds) {
            $count = floor($seconds / self::SEC_YEAR);

            return $this->translator->transChoice('Since.year', $count, array('%count%' => $count), 'OruProjectHumhubBundle');
        }

        if (self::SEC_MONTH < $seconds) {
            $count = floor($seconds / self::SEC_MONTH);

            return $this->translator->transChoice('Since.month', $count, array('%count%' => $count), 'OruProjectHumhubBundle');
        }

        if (self::SEC_WEEK < $seconds) {
            $count = floor($seconds / self::SEC_WEEK);

            return $this->translator->transChoice('Since.week', $count, array('%count%' => $count), 'OruProjectHumhubBundle');
        }

        if (self::SEC_DAY < $seconds) {
            $count = floor($seconds / self::SEC_DAY);

            return $this->translator->transChoice('Since.day', $count, array('%count%' => $count), 'OruProjectHumhubBundle');
        }

        if (self::SEC_HOUR < $seconds) {
            $count = floor($seconds / self::SEC_HOUR);

            return $this->translator->transChoice('Since.hour', $count, array('%count%' => $count), 'OruProjectHumhubBundle');
        }

        if (self::SEC_MIN < $seconds) {
            $count = floor($seconds / self::SEC_MIN);

            return $this->translator->transChoice('Since.minute', $count, array('%count%' => $count), 'OruProjectHumhubBundle');
        }

        return $this->translator->trans('Since.few', array(), 'OruProjectHumhubBundle');
    }
}
