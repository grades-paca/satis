<?php

namespace Oru\Bundle\ProjectHumhubBundle\Subscriber;

use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\OnFlushEventArgs;
use Doctrine\ORM\Event\PostFlushEventArgs;
use Doctrine\ORM\Events;
use Oru\Bundle\ProfessionnelBundle\Entity\Professionnel;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Oru\Bundle\SpoolBundle\Entity\Spool;
use Oru\Bundle\SpoolBundle\Event\SpoolEvent;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;

/**
 * Class ProfessionnelSubscriber
 *
 * @package Oru\Bundle\ProjectHumhubBundle\Subscriber
 * @author Michaël VEROUX
 */
class ProfessionnelSubscriber implements EventSubscriber
{
    /**
     * @var EventDispatcherInterface
     */
    protected $eventDispatcher;

    /**
     * @var Setting
     */
    protected $setting;

    /**
     * @var array
     */
    private $events = array('create' => array(), 'update' => array());

    /**
     * ProfessionnelSubscriber constructor.
     *
     * @param EventDispatcherInterface $eventDispatcher
     * @param Setting                  $setting
     */
    public function __construct(EventDispatcherInterface $eventDispatcher, Setting $setting)
    {
        $this->eventDispatcher = $eventDispatcher;
        $this->setting = $setting;
    }

    /**
     * Returns an array of events this subscriber wants to listen to.
     *
     * @return array
     */
    public function getSubscribedEvents()
    {
        return array(
            Events::onFlush,
            Events::postFlush,
        );
    }

    /**
     * @param OnFlushEventArgs $args
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function onFlush(OnFlushEventArgs $args)
    {
        $uow = $args->getEntityManager()->getUnitOfWork();
        foreach ($uow->getScheduledEntityInsertions() as $scheduledEntityInsertion) {
            if ($scheduledEntityInsertion instanceof Professionnel) {
                $this->events['create'][] = $scheduledEntityInsertion;
            }
        }
        foreach ($uow->getScheduledEntityUpdates() as $scheduledEntityUpdate) {
            if ($scheduledEntityUpdate instanceof Professionnel) {
                $changes = $uow->getEntityChangeSet($scheduledEntityUpdate);
                $synchroFields = array('nom', 'prenom', 'username', 'email');
                if ($this->setting->setting('synchro_professionnel_onconnect', 'OruProjectHumhubBundle')) {
                    $synchroFields[] = 'last_login';
                }
                if ($this->setting->setting('synchro_professionnel_force', 'OruProjectHumhubBundle')) {
                    $synchroFields[] = 'updated';
                }
                $diff = array_intersect($synchroFields, array_keys($changes));
                if (count($diff)) {
                    $this->events['update'][] = $scheduledEntityUpdate;
                }
            }
        }
    }

    /**
     * @param PostFlushEventArgs $args
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function postFlush(PostFlushEventArgs $args)
    {
        foreach ($this->events['create'] as $entity) {
            /** @var Professionnel $entity */
            $event = new SpoolEvent('oru_project_humhub.synchro_user');
            $event->setServiceCalls(array(
                                        'createUser'    =>  array($entity->getId()),
                                    ));
            $event->setPriority(Spool::PRIORITY_NORMAL);

            $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
        }

        foreach ($this->events['update'] as $entity) {
            /** @var Professionnel $entity */
            $event = new SpoolEvent('oru_project_humhub.synchro_user');
            $event->setServiceCalls(array(
                                        'updateUser'    =>  array($entity->getId()),
                                    ));
            $event->setPriority(Spool::PRIORITY_NORMAL);

            $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
        }
    }
}
