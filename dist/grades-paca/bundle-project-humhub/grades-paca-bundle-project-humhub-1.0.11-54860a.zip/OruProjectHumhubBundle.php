<?php

namespace Oru\Bundle\ProjectHumhubBundle;

use Oru\Bundle\SettingBundle\Bundle\OruBundle;

/**
 * Class OruProjectHumhubBundle
 *
 * @package Oru\Bundle\ProjectHumhubBundle
 * @author Michaël VEROUX
 */
class OruProjectHumhubBundle extends OruBundle
{
    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getFriendlyName()
    {
        return 'Lien ROR <-> HUMHUB';
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getDescription()
    {
        return 'Accès au réseau social';
    }
}
