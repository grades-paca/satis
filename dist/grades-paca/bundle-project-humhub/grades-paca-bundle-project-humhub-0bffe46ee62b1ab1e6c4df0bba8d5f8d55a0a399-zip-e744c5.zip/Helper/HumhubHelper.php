<?php

namespace Oru\Bundle\ProjectHumhubBundle\Helper;

use FOS\UserBundle\Model\UserInterface;
use Oru\Bundle\ProjectHumhubBundle\Date\Since;
use Oru\Bundle\ProjectHumhubBundle\Rest\Client;
use Oru\Bundle\ProjectHumhubBundle\Synchro\HumhubInterface;
use RestClient\Exception;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

/**
 * Class HumhubHelper.
 *
 * @author Michaël VEROUX
 */
class HumhubHelper
{
    /**
     * @var Client
     */
    protected $restClient;

    /**
     * @var TokenStorageInterface
     */
    protected $tokenStorage;

    /**
     * @var Since
     */
    protected $since;

    /**
     * HumhubHelper constructor.
     *
     * @param Client                $restClient
     * @param TokenStorageInterface $tokenStorage
     * @param Since                 $since
     */
    public function __construct(Client $restClient, TokenStorageInterface $tokenStorage, Since $since)
    {
        $this->restClient = $restClient;
        $this->tokenStorage = $tokenStorage;
        $this->since = $since;
    }

    /**
     * @param int  $limit
     * @param bool $json
     *
     * @return array|mixed|null|string
     *
     * @author Michaël VEROUX
     */
    public function getActivities($limit = 10, $json = false)
    {
        try {
            $humhubToken = $this->getCurrentUserAccessToken();
            if (!$humhubToken) {
                return array();
            }
        } catch (Exception $e) {
            return array();
        }

        $restUri = HumhubInterface::REST_MEMBER_ACTIVITIES;
        $response = $this->restClient->setAccessToken($humhubToken)->get($restUri, array('limit' => $limit));
        $activities = json_decode($response->getParsedResponse(), true);
        $since = $this->since;
        $activities = array_map(function ($vars) use ($since) {
            if (isset($vars['date_raw']) && $date = new \DateTime($vars['date_raw'])) {
                $vars['date'] = $since->getHumanLocal($date);
            }

            return $vars;
        }, $activities);
        if (!$activities) {
            if ($json) {
                return json_encode(array());
            }

            return null;
        }
        if ($json) {
            return $response->getParsedResponse();
        }

        return $activities;
    }

    /**
     * @throws Exception
     *
     * @return string|null
     *
     * @author Michaël VEROUX
     */
    private function getCurrentUserAccessToken()
    {
        if (!$this->tokenStorage->getToken()->getUser() instanceof UserInterface) {
            return null;
        }

        $humhubToken = $this->retreiveAccessToken($this->tokenStorage->getToken()->getUser()->getId());

        return $humhubToken;
    }

    /**
     * @param int $professionnelId
     *
     * @throws Exception
     *
     * @return string|null
     *
     * @author Michaël VEROUX
     */
    private function retreiveAccessToken($professionnelId)
    {
        $restUri = sprintf(HumhubInterface::REST_USER_TOKEN, $professionnelId);
        $response = $this->restClient->get($restUri);
        $humhubToken = json_decode($response->getParsedResponse(), true);
        if (!$humhubToken) {
            return null;
        }
        if (is_array($humhubToken) && isset($humhubToken['code'])) {
            $message = 'Error';
            if (isset($humhubToken['message'])) {
                $message = $humhubToken['message'];
            }

            throw new Exception($message);
        }

        return $humhubToken;
    }
}
