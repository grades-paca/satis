<?php

namespace Oru\Bundle\ProjectHumhubBundle\Subscriber;

use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\OnFlushEventArgs;
use Doctrine\ORM\Event\PostFlushEventArgs;
use Doctrine\ORM\Events;
use Doctrine\ORM\PersistentCollection;
use Oru\Bundle\MeetingBundle\Entity\Meeting;
use Oru\Bundle\ProfessionnelBundle\Entity\Professionnel;
use Oru\Bundle\ProjectBundle\Entity\Document;
use Oru\Bundle\ProjectBundle\Entity\Project;
use Oru\Bundle\SpoolBundle\Entity\Spool;
use Oru\Bundle\SpoolBundle\Event\SpoolEvent;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

/**
 * Class ProjectSubscriber
 *
 * @package Oru\Bundle\ProjectHumhubBundle\Subscriber
 * @author Michaël VEROUX
 */
class ProjectSubscriber implements EventSubscriber
{
    /**
     * @var EventDispatcherInterface
     */
    protected $eventDispatcher;

    /**
     * @var TokenStorageInterface
     */
    protected $token;

    /**
     * @var array
     */
    private $events = array(
        'space'     => array(
            'new'       => array(),
            'update'    => array(),
            'delete'    => array(),
            'restaure'  => array(),
        ),
        'meeting'   => array(
            'new'       => array(),
            'update'    => array(),
        ),
        'document'  => array(
            'new'       => array(),
            'update'    => array(),
        ),
        'admin'     => array(
        ),
    );

    /**
     * ProjectSubscriber constructor.
     *
     * @param EventDispatcherInterface $eventDispatcher
     * @param TokenStorageInterface    $token
     */
    public function __construct(EventDispatcherInterface $eventDispatcher, TokenStorageInterface $token)
    {
        $this->eventDispatcher = $eventDispatcher;
        $this->token = $token;
    }

    /**
     * Returns an array of events this subscriber wants to listen to.
     *
     * @return array
     */
    public function getSubscribedEvents()
    {
        return array(
            Events::onFlush,
            Events::postFlush,
        );
    }

    /**
     * @param OnFlushEventArgs $args
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function onFlush(OnFlushEventArgs $args)
    {
        $uow = $args->getEntityManager()->getUnitOfWork();

        foreach ($uow->getScheduledEntityInsertions() as $scheduledEntityInsertion) {
            if ($scheduledEntityInsertion instanceof Project) {
                $this->events['space']['new'][] = $scheduledEntityInsertion;
            }
            if ($scheduledEntityInsertion instanceof Meeting) {
                $this->events['meeting']['new'][] = $scheduledEntityInsertion;
            }
            if ($scheduledEntityInsertion instanceof Document) {
                $this->events['document']['new'][] = $scheduledEntityInsertion;
            }
        }

        foreach ($uow->getScheduledEntityUpdates() as $scheduledEntityUpdate) {
            if ($scheduledEntityUpdate instanceof Project) {
                $changes = $uow->getEntityChangeSet($scheduledEntityUpdate);
                $delete = false;
                if (isset($changes['closedAt']) && array_key_exists(1, $changes['closedAt'])) {
                    $delete = $changes['closedAt'][1];
                }
                if (false === $delete && isset($changes['canceledAt']) && array_key_exists(1, $changes['canceledAt'])) {
                    $delete = $changes['canceledAt'][1];
                }
                if (false !== $delete) {
                    if (null === $delete) {
                        $this->events['space']['restaure'][] = $scheduledEntityUpdate;
                    } else {
                        $this->events['space']['delete'][] = $scheduledEntityUpdate;
                    }
                } else {
                    $this->events['space']['update'][] = $scheduledEntityUpdate;
                    $managers = $scheduledEntityUpdate->getManagers();
                    $this->events['admin'][$scheduledEntityUpdate->getId()] = array();
                    if ($managers instanceof PersistentCollection) {
                        $removes = $managers->getDeleteDiff();
                        foreach ($removes as $remove) {
                            /** @var Professionnel $remove */
                            $this->events['admin'][$scheduledEntityUpdate->getId()][] = $remove->getId();
                        }
                    }
                }
            }
            if ($scheduledEntityUpdate instanceof Meeting) {
                $this->events['meeting']['update'][] = $scheduledEntityUpdate;
            }
            if ($scheduledEntityUpdate instanceof Document) {
                $changes = $uow->getEntityChangeSet($scheduledEntityUpdate);
                if (isset($changes['visible'])) {
                    $this->events['document']['update'][] = $scheduledEntityUpdate;
                }
            }
        }
    }

    /**
     * @param PostFlushEventArgs $args
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function postFlush(PostFlushEventArgs $args)
    {
        foreach ($this->events['space']['new'] as $entity) {
            /** @var Project $entity */
            $event = new SpoolEvent('oru_project_humhub.synchro');
            $event->setServiceCalls(array(
                'setProject'        =>  array($entity->getId()),
                'newProject'        =>  array(),
                'putProjectMembers' =>  array(),
                'putAdmins'         =>  array(),
            ));
            $event->setPriority(Spool::PRIORITY_VERY_HIGH);

            $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
        }
        foreach ($this->events['space']['update'] as $entity) {
            $creator = $this->getCreatorAdmin($entity);
            $event = new SpoolEvent('oru_project_humhub.synchro');
            $event->setServiceCalls(array(
                'setProject'    =>  array($entity->getId()),
                'putAdmins'         =>  array(),
                'setCreator'        =>  array($creator),
                'updateProject' =>  array(),
                'putProjectMembers' =>  array(),
                'removeProjectMembers' =>  array(),
                'removeAdmins'      =>  array($this->events['admin'][$entity->getId()]),
            ));
            $event->setPriority(Spool::PRIORITY_VERY_HIGH);

            $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
        }
        foreach ($this->events['space']['delete'] as $entity) {
            $creator = $this->getCreatorAdmin($entity);
            $event = new SpoolEvent('oru_project_humhub.synchro');
            $event->setServiceCalls(array(
                'setProject'    =>  array($entity->getId()),
                'setCreator'        =>  array($creator),
                'deleteProject'     =>  array(),
            ));
            $event->setPriority(Spool::PRIORITY_VERY_HIGH);

            $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
        }
        foreach ($this->events['space']['restaure'] as $entity) {
            $creator = $this->getCreatorAdmin($entity);
            $event = new SpoolEvent('oru_project_humhub.synchro');
            $event->setServiceCalls(array(
                'setProject'    =>  array($entity->getId()),
                'setCreator'        =>  array($creator),
                'restaureProject'   =>  array(),
            ));
            $event->setPriority(Spool::PRIORITY_VERY_HIGH);

            $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
        }

        foreach ($this->events['meeting']['new'] as $entity) {
            /** @var Meeting $entity */
            $creator = $this->getCreatorAdmin($entity->getProject());
            $event = new SpoolEvent('oru_project_humhub.synchro');
            $event->setServiceCalls(array(
                                        'setProject'        =>  array($entity->getProject()->getId()),
                                        'setMeeting'        =>  array($entity->getId()),
                                        'setCreator'        =>  array($creator),
                                        'newMeeting'        =>  array(),
                                    ));
            $event->setPriority(Spool::PRIORITY_HIGH);

            $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
        }
        foreach ($this->events['meeting']['update'] as $entity) {
            $creator = $this->getCreatorAdmin($entity->getProject());
            $event = new SpoolEvent('oru_project_humhub.synchro');
            $event->setServiceCalls(array(
                                        'setProject'        =>  array($entity->getProject()->getId()),
                                        'setMeeting'        =>  array($entity->getId()),
                                        'setCreator'        =>  array($creator),
                                        'updateMeeting'     =>  array(),
                                    ));
            $event->setPriority(Spool::PRIORITY_HIGH);

            $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
        }

        foreach ($this->events['document']['new'] as $entity) {
            /** @var Document $entity */
            $creator = $this->getCreatorAdmin($entity->getProject());
            if ($entity->getVisible()) {
                $event = new SpoolEvent('oru_project_humhub.synchro');
                $event->setServiceCalls(array(
                                            'setProject'        =>  array($entity->getProject()->getId()),
                                            'setDocument'       =>  array($entity->getId()),
                                            'setCreator'        =>  array($creator),
                                            'newDocument'       =>  array(),
                                        ));
                $event->setPriority(Spool::PRIORITY_HIGH);

                $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
            }
        }
        foreach ($this->events['document']['update'] as $entity) {
            if ($entity->getVisible()) {
                $creator = $this->getCreatorAdmin($entity->getProject());
                $event = new SpoolEvent('oru_project_humhub.synchro');
                $event->setServiceCalls(array(
                                            'setProject'     => array($entity->getProject()->getId()),
                                            'setDocument'    => array($entity->getId()),
                                            'setCreator'        =>  array($creator),
                                            'newDocument' => array(),
                                        ));
                $event->setPriority(Spool::PRIORITY_HIGH);

                $this->eventDispatcher->dispatch(\Oru\Bundle\SpoolBundle\Event\Events::SPOOL_ADD, $event);
            }
        }
    }

    /**
     * @param Project $project
     *
     * @return null|int
     * @author Michaël VEROUX
     */
    private function getCreatorAdmin(Project $project)
    {
        $user = null;
        $token = $this->token->getToken();
        if ($token && $token->getUser() instanceof Professionnel) {
            $user = $token->getUser()->getId();
        }

        $admins = array_map(function (Professionnel $professionnel) {
            return $professionnel->getId();
        }, $project->getAllManagers());
        if (!in_array($user, $admins)) {
            $user = null;
        }

        return $user;
    }
}
