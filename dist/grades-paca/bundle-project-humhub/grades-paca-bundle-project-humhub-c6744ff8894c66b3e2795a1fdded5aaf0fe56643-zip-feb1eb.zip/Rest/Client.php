<?php

namespace Oru\Bundle\ProjectHumhubBundle\Rest;

use Oru\Bundle\SpoolBundle\Exception\UnvailableException;
use RestClient\Exception;
use RestClient\IResponse;
use RestClient\Client as RestClient;

/**
 * Class Client
 *
 * @package Oru\Bundle\ProjectHumhubBundle\Rest
 * @author Michaël VEROUX
 */
class Client
{
    /**
     * @var string|null
     */
    protected $humhubBaseUrl;

    /**
     * @var string|null
     */
    protected $humhubAccessToken;

    /**
     * @var string|null
     */
    protected $userAccessToken;

    /**
     * @var RestClient
     */
    protected $restClient;

    /**
     * @var string
     */
    protected $proxy;

    /**
     * Client constructor.
     *
     * @param null|string $humhubBaseUrl
     * @param null|string $humhubAccessToken
     * @param null|string $proxy
     */
    public function __construct($humhubBaseUrl = null, $humhubAccessToken = null, $proxy = null)
    {
        $this->humhubBaseUrl = $humhubBaseUrl;
        $this->humhubAccessToken = $humhubAccessToken;
        $this->proxy = $proxy;
    }

    /**
     * @param string $token
     *
     * @return $this
     * @author Michaël VEROUX
     */
    public function setAccessToken($token)
    {
        if (!$token) {
            $this->userAccessToken = false;

            return $this;
        }

        $this->userAccessToken = $token;

        return $this;
    }

    /**
     * @return void
     * @author Michaël VEROUX
     */
    public function resetAccessToken()
    {
        $this->userAccessToken = null;
    }

    /**
     * @param string     $uri
     * @param null|array $data
     *
     * @return IResponse
     * @author Michaël VEROUX
     */
    public function get($uri, $data = null)
    {
        if (null !== $data && is_array($data)) {
            $uri = sprintf('%s?%s', $uri, http_build_query($data));
        }
        $response = $this->send($uri, null);

        return $response;
    }

    /**
     * @param string $uri
     * @param mixed  $data
     *
     * @return \RestClient\IResponse
     * @author Michaël VEROUX
     */
    public function post($uri, $data)
    {
        $response = $this->send($uri, $data, 'POST');

        return $response;
    }

    /**
     * @param string $uri
     * @param mixed  $data
     *
     * @return \RestClient\IResponse
     * @author Michaël VEROUX
     */
    public function put($uri, $data)
    {
        $response = $this->send($uri, $data, 'PUT');

        return $response;
    }

    /**
     * @param string $uri
     * @param mixed  $data
     *
     * @return \RestClient\IResponse
     * @author Michaël VEROUX
     */
    public function delete($uri, $data)
    {
        $response = $this->send($uri, $data, 'DELETE');

        return $response;
    }

    /**
     * @return RestClient
     * @author Michaël VEROUX
     */
    protected function getRestClient()
    {
        if (!$this->humhubBaseUrl) {
            throw new \RuntimeException('Humhub base URL missing.');
        }
        if (!$this->humhubAccessToken) {
            throw new \RuntimeException('Humhub access_token missing.');
        }

        if (!$this->restClient) {
            $this->restClient = new RestClient($this->humhubBaseUrl);
        }

        return $this->restClient;
    }

    /**
     * @param string $resource
     *
     * @return string
     * @author Michaël VEROUX
     */
    protected function generateUrlResource($resource)
    {
        $sep = '?';
        if (strrpos($resource, '?')) {
            $sep = '&';
        }

        $token = $this->userAccessToken;
        if (null === $token) {
            $token = $this->humhubAccessToken;
        }

        $uri = sprintf('%s%saccess_token=%s', $resource, $sep, urlencode($token));
        $this->resetAccessToken();

        return $uri;
    }

    /**
     * @param string $uri
     * @param mixed  $data
     * @param string $method
     *
     * @return IResponse
     * @throws UnvailableException
     * @author Michaël VEROUX
     */
    private function send($uri, $data, $method = 'GET')
    {
        $client = $this->getRestClient();
        $uri = $this->generateUrlResource($uri);

        $cookieFile = '/tmp/cookie.txt';
        $options = array(
            CURLOPT_COOKIEJAR => $cookieFile,
            CURLOPT_COOKIEFILE => $cookieFile,
            CURLOPT_ENCODING => 'gzip',
        );

        try {
            $request = $client->newRequest($uri, $method, json_encode($data), array('accept' => 'application/json', 'accept-encoding' => 'gzip, deflate', 'accept-language' => 'fr', 'content-type' => 'application/json'));
            $request->setOption(RestClient::USER_AGENT_KEY, 'REST Client ROR');
            if (preg_match('#^[^:]+:[^:]+$#', $this->proxy)) {
                $request->setOption(RestClient::CURL_OPTIONS_KEY, array(CURLOPT_PROXY => $this->proxy));
            }
            $mergedOptions = $request->getOption(RestClient::CURL_OPTIONS_KEY) + $options;
            $request->setOption(RestClient::CURL_OPTIONS_KEY, $mergedOptions);
            $response = $request->getResponse();
        } catch (Exception $e) {
            throw new UnvailableException($e->getMessage());
        }

        return $response;
    }
}
