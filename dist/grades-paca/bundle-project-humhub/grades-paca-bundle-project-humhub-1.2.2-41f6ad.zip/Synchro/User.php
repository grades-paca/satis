<?php

namespace Oru\Bundle\ProjectHumhubBundle\Synchro;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\ProjectHumhubBundle\Rest\Client;
use Psr\Log\LoggerInterface;
use RestClient\IResponse;

/**
 * Class User.
 *
 * @author Michaël VEROUX
 */
class User implements HumhubInterface
{
    /**
     * @var EntityManager
     */
    protected $em;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var Client
     */
    protected $restClient;

    /**
     * User constructor.
     *
     * @param EntityManager   $em
     * @param LoggerInterface $logger
     * @param Client          $restClient
     */
    public function __construct(EntityManager $em, LoggerInterface $logger, Client $restClient)
    {
        $this->em = $em;
        $this->logger = $logger;
        $this->restClient = $restClient;
    }

    /**
     * @param int $id
     *
     * @throws \RuntimeException
     *
     * @author Michaël VEROUX
     */
    public function createUser($id)
    {
        $professionnel = $this->em->getRepository('OruProfessionnelBundle:Professionnel')->find($id);
        if (!$professionnel) {
            throw new \RuntimeException('Professionnel not found!');
        }
        if (!$professionnel->getEmail()) {
            throw new \RuntimeException('Professionnel has not email!');
        }

        $data = array(
            'id' => $professionnel->getId(),
            'username' => $professionnel->getUsername(),
            'firstname' => $professionnel->getPrenom(),
            'lastname' => $professionnel->getNom(),
            'email' => $professionnel->getEmail(),
        );

        $restUrl = self::REST_USER_CREATE;
        $this->logger->debug('Call to rest POST '.$restUrl);
        $response = $this->restClient->post($restUrl, $data);
    }

    /**
     * @param int $id
     *
     * @throws \RuntimeException
     *
     * @author Michaël VEROUX
     */
    public function updateUser($id)
    {
        $professionnel = $this->em->getRepository('OruProfessionnelBundle:Professionnel')->find($id);
        if (!$professionnel) {
            throw new \RuntimeException('Professionnel not found!');
        }
        if (!$professionnel->getEmail()) {
            throw new \RuntimeException('Professionnel has not email!');
        }

        $data = array(
            'id' => $professionnel->getId(),
            'username' => $professionnel->getUsername(),
            'firstname' => $professionnel->getPrenom(),
            'lastname' => $professionnel->getNom(),
            'email' => $professionnel->getEmail(),
        );

        $restUrl = self::REST_USER_UPDATE;
        $this->logger->debug('Call to rest PUT '.$restUrl);
        $response = $this->restClient->put($restUrl, $data);
    }

    /**
     * @param IResponse $response
     *
     * @throws \RuntimeException
     *
     * @return mixed
     *
     * @author Michaël VEROUX
     */
    protected function getDataFromResponse(IResponse $response)
    {
        $data = json_decode($response->getParsedResponse(), true);
        if (null === $data) {
            throw new \RuntimeException('Unknow error');
        }

        return $data;
    }
}
