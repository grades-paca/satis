<?php

namespace Oru\Bundle\ProjectHumhubBundle\Entity;

use Oru\Bundle\MeetingBundle\Entity\Meeting;

/**
 * Class MeetingHumhub.
 *
 * @author Michaël VEROUX
 */
class MeetingHumhub
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var Meeting
     */
    protected $meeting;

    /**
     * @var string
     */
    protected $uri;

    /**
     * @var int
     */
    protected $humhubId;

    /**
     * @var \DateTime
     */
    protected $created;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return Meeting
     */
    public function getMeeting()
    {
        return $this->meeting;
    }

    /**
     * @param Meeting $meeting
     *
     * @return $this
     */
    public function setMeeting(Meeting $meeting)
    {
        $this->meeting = $meeting;

        return $this;
    }

    /**
     * @return string
     */
    public function getUri()
    {
        return $this->uri;
    }

    /**
     * @param string $uri
     *
     * @return $this
     */
    public function setUri($uri)
    {
        $this->uri = $uri;

        return $this;
    }

    /**
     * @return int
     */
    public function getHumhubId()
    {
        return $this->humhubId;
    }

    /**
     * @param int $humhubId
     *
     * @return $this
     */
    public function setHumhubId($humhubId)
    {
        $this->humhubId = $humhubId;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param \DateTime $created
     *
     * @return $this
     */
    public function setCreated($created)
    {
        $this->created = $created;

        return $this;
    }
}
