<?php

namespace Oru\Bundle\ProjectHumhubBundle\Synchro;

use Doctrine\ORM\EntityManager;
use FOS\UserBundle\Model\UserInterface;
use Monolog\Logger;
use Oru\Bundle\AttachmentBundle\Entity\Attachment;
use Oru\Bundle\MeetingBundle\Entity\Meeting;
use Oru\Bundle\ProfessionnelBundle\Entity\Professionnel;
use Oru\Bundle\ProjectBundle\Entity\Document;
use Oru\Bundle\ProjectBundle\Entity\Project;
use Oru\Bundle\ProjectHumhubBundle\Entity\MeetingHumhub;
use Oru\Bundle\ProjectHumhubBundle\Entity\ProjectHumhub;
use Oru\Bundle\ProjectHumhubBundle\Helper\HumhubHelper;
use Oru\Bundle\ProjectHumhubBundle\Rest\Client;
use Oru\Bundle\SpoolBundle\Exception\FailedException;
use RestClient\IResponse;
use Symfony\Component\Routing\RouterInterface;

/**
 * Class Humhub
 *
 * @package Oru\Bundle\ProjectHumhubBundle\Synchro
 * @author Michaël VEROUX
 */
class Humhub implements HumhubInterface
{
    /**
     * @var EntityManager
     */
    protected $em;

    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @var Project|null
     */
    protected $project;

    /**
     * @var Meeting|null
     */
    protected $meeting;

    /**
     * @var Document
     */
    protected $document;

    /**
     * @var UserInterface
     */
    protected $creator;

    /**
     * @var Client
     */
    protected $restClient;

    /**
     * @var RouterInterface
     */
    protected $router;

    /**
     * @var HumhubHelper
     */
    protected $humhubHelper;

    /**
     * Humhub constructor.
     *
     * @param EntityManager   $em
     * @param Logger          $logger
     * @param Client          $restClient
     * @param RouterInterface $router
     * @param HumhubHelper    $humhubHelper
     */
    public function __construct(EntityManager $em, Logger $logger, Client $restClient, RouterInterface $router, HumhubHelper $humhubHelper)
    {
        $this->em = $em;
        $this->logger = $logger;
        $this->restClient = $restClient;
        $this->router = $router;
        $this->humhubHelper = $humhubHelper;
    }

    /**
     * @return null|Project
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * @param int $project
     *
     * @return $this
     */
    public function setProject($project)
    {
        $this->project = $this->em->getRepository('OruProjectBundle:Project')->find($project);

        return $this;
    }

    /**
     * @return null|Meeting
     */
    public function getMeeting()
    {
        return $this->meeting;
    }

    /**
     * @param null|Meeting $meeting
     *
     * @return $this
     */
    public function setMeeting($meeting)
    {
        if (!$meeting instanceof Meeting) {
            $meeting = $this->em->getRepository('OruMeetingBundle:Meeting')->find($meeting);
        }
        if (!$meeting) {
            return $this;
        }

        $this->meeting = $meeting;

        return $this;
    }

    /**
     * @return Document
     */
    public function getDocument()
    {
        return $this->document;
    }

    /**
     * @param Document $document
     *
     * @return $this
     */
    public function setDocument($document)
    {
        if (!$document instanceof Meeting) {
            $document = $this->em->getRepository('OruProjectBundle:Document')->find($document);
        }
        if (!$document) {
            return $this;
        }

        $this->document = $document;

        return $this;
    }

    /**
     * @return UserInterface|null
     */
    public function getCreator()
    {
        return $this->creator;
    }

    /**
     * @param UserInterface $creator
     *
     * @return $this
     */
    public function setCreator($creator)
    {
        if (!$creator) {
            $this->creator = null;

            return $this;
        }
        if (!$creator instanceof UserInterface) {
            $creator = $this->em->getRepository('OruProfessionnelBundle:Professionnel')->find($creator);
        }

        $this->creator = $creator;

        return $this;
    }


    /**
     * @return void
     * @throws FailedException
     * @author Michaël VEROUX
     */
    public function newProject()
    {
        if (null === $this->project ) {
            throw new FailedException('Project not found');
        }

        $data = array(
            'name'          =>  $this->project->getName(),
            'description'   =>  $this->project->getDescription(),
        );

        $restUrl = self::REST_SPACE_NEW;
        $this->logger->addDebug('Call to rest POST '.$restUrl);
        $response = $this->restClient->post($restUrl, $data);

        $return = $this->getDataProjectFromResponse($response);

        $this->createProjectHumhub($return['id']);
    }

    /**
     * @return void
     * @throws FailedException
     * @author Michaël VEROUX
     */
    public function updateProject()
    {
        if (null === $this->project ) {
            throw new FailedException('Project not found');
        }
        $projectHumhub = $this->getProjectHumhub();

        $data = array(
            'name'          =>  $this->project->getName(),
            'description'   =>  $this->project->getDescription(),
        );
        $restUrl = sprintf(self::REST_SPACE_UPDATE, $projectHumhub->getSpaceHumhubId());
        $this->logger->addDebug('Call to rest PUT '.$restUrl);
        $response = $this->callAsCreator()->put($restUrl, $data);

        $this->getDataProjectFromResponse($response);
    }

    /**
     * @return void
     * @throws FailedException
     * @author Michaël VEROUX
     */
    public function newDocument()
    {
        if (null === $this->project ) {
            throw new FailedException('Project not found');
        }
        if (null === $this->document ) {
            throw new FailedException('Document not found');
        }
        $projectHumhub = $this->getProjectHumhub();

        $url = $this->document->getLink();
        if ($this->document->getAttachment() instanceof Attachment) {
            $url = $this->router->generate('oru_attachment_download', array('id' => $this->document->getAttachment()->getId()), RouterInterface::ABSOLUTE_URL);
        }

        $message = 'Nouveau fichier : ' . $this->document->getName() . PHP_EOL;
        $message .= $url;

        $data = array(
            'message'       =>  $message,
        );

        $response = $this->callAsCreator()->post(sprintf(self::REST_SPACE_POST_NEW, $projectHumhub->getSpaceHumhubId()), $data);
        $return = $this->getDataMembersFromResponse($response);
    }

    /**
     * @return void
     * @throws FailedException
     * @author Michaël VEROUX
     */
    public function newMeeting()
    {
        if (null === $this->project ) {
            throw new FailedException('Project not found');
        }
        if (null === $this->meeting ) {
            throw new FailedException('Meeting not found');
        }
        if ($meetingHumhub = $this->em->getRepository('OruProjectHumhubBundle:MeetingHumhub')->findOneBy(array('meeting' => $this->meeting))) {
            $this->addAttendees($meetingHumhub->getHumhubId());

            return;
        }

        $projectHumhub = $this->getProjectHumhub();

        $data = array(
            'title'             =>  $this->meeting->getSummary(),
            'description'       =>  $this->meeting->getDescription(),
            'start_datetime'    =>  $this->meeting->getDtStart()->format('Y-m-d H:i:00'),
        );
        if ($this->meeting->getDtEnd() instanceof \DateTime) {
            $data['end_datetime'] = $this->meeting->getDtEnd()->format('Y-m-d H:i:00');
        }

        $restUrl = sprintf(self::REST_SPACE_MEETING_NEW, $projectHumhub->getSpaceHumhubId());
        $this->logger->addDebug('Call to rest POST '.$restUrl);
        $response = $this->callAsCreator()->post($restUrl, $data);
        $return = $this->getDataFromResponse($response);

        if (isset($return['uri']) && isset($return['id'])) {
            $meetingHumhub = new MeetingHumhub();
            $meetingHumhub->setMeeting($this->meeting);
            $meetingHumhub->setUri($return['uri']);
            $meetingHumhub->setHumhubId($return['id']);

            $this->em->persist($meetingHumhub);
            $this->em->flush($meetingHumhub);

            $this->addAttendees($meetingHumhub->getHumhubId());
        }
    }

    /**
     * @return void
     * @throws FailedException
     * @author Michaël VEROUX
     */
    public function updateMeeting()
    {
        if (null === $this->project ) {
            throw new FailedException('Project not found');
        }
        if (null === $this->meeting ) {
            throw new FailedException('Meeting not found');
        }
        if (!$meetingHumhub = $this->em->getRepository('OruProjectHumhubBundle:MeetingHumhub')->findOneBy(array('meeting' => $this->meeting))) {
            $this->newMeeting();

            return;
        }

        $projectHumhub = $this->getProjectHumhub();

        $data = array(
            'title'             =>  $this->meeting->getSummary(),
            'description'       =>  $this->meeting->getDescription(),
            'start_datetime'    =>  $this->meeting->getDtStart()->format('Y-m-d H:i:00'),
        );
        if ($this->meeting->getDtEnd() instanceof \DateTime) {
            $data['end_datetime'] = $this->meeting->getDtEnd()->format('Y-m-d H:i:00');
        }

        $restUrl = sprintf(self::REST_SPACE_MEETING_UPDATE, $meetingHumhub->getHumhubId());
        $this->logger->addDebug('Call to rest PUT '.$restUrl);
        $response = $this->callAsCreator()->put($restUrl, $data);
        $return = $this->getDataFromResponse($response);

        if (isset($return['uri']) && isset($return['id'])) {
            $meetingHumhub->setMeeting($this->meeting);
            $meetingHumhub->setUri($return['uri']);
            $meetingHumhub->setHumhubId($return['id']);

            $this->em->flush($meetingHumhub);

            $this->addAttendees($meetingHumhub->getHumhubId());
        }
    }

    /**
     * @return void
     * @throws FailedException
     * @author Michaël VEROUX
     */
    public function putProjectMembers()
    {
        if (null === $this->project ) {
            throw new FailedException('Project not found');
        }
        $projectHumhub = $this->getProjectHumhub();

        $proIds = $this->em->getRepository('OruProjectBundle:Project')->getMembersIds($this->project, $this->project->getInherit());
        $this->logger->addDebug('Project members', array('members' => var_export($proIds, true)));

        $response = $this->callAsCreator()->post(sprintf(self::REST_SPACE_INVITE, $projectHumhub->getSpaceHumhubId()), array('ids' => $proIds));

        $return = $this->getDataMembersFromResponse($response);

        if (count($return[self::HUMHUB_USER_UNKNOWN])) {
            throw new FailedException('This members mails does not exists in humhub: '.var_export($return[self::HUMHUB_USER_UNKNOWN], true));
        }
    }

    /**
     * @return void
     * @throws FailedException
     * @author Michaël VEROUX
     */
    public function removeProjectMembers()
    {
        if (null === $this->project ) {
            throw new FailedException('Project not found');
        }
        $projectHumhub = $this->getProjectHumhub();

        $proIds = $this->em->getRepository('OruProjectBundle:Project')->getMembersIds($this->project, $this->project->getInherit());
        $response = $this->callAsCreator()->get(sprintf(self::REST_SPACE_MEMBERS, $projectHumhub->getSpaceHumhubId()));
        $return = $this->getDataMembersFromResponse($response);

        $humhubIds = $return['ids'];

        $diff = array_diff($humhubIds, $proIds);
        if (count($diff)) {
            $this->logger->addDebug('Delete members', array('members' => var_export($proIds, true)));
            $response = $this->callAsCreator()->delete(sprintf(self::REST_SPACE_MEMBER_REMOVE, $projectHumhub->getSpaceHumhubId()), array('ids' => $diff));
            $return = $this->getDataMembersFromResponse($response);

            if (count($return[self::HUMHUB_USER_UNKNOWN])) {
                throw new FailedException('This members mails does not exists in humhub: '.var_export($return[self::HUMHUB_USER_UNKNOWN], true));
            }
        }
    }

    /**
     * @return void
     * @throws FailedException
     * @author Michaël VEROUX
     */
    public function putAdmins()
    {
        if (null === $this->project ) {
            throw new FailedException('Project not found');
        }
        $projectHumhub = $this->getProjectHumhub();
        $admins = $this->project->getAllManagers();
        $adminIds = array_map(function (Professionnel $professionnel) {
            return $professionnel->getId();
        }, $admins);
        $adminIds = array_unique($adminIds);
        $this->logger->addDebug('Project admins', array('admins' => var_export($adminIds, true)));

        $data = array('ids' => $adminIds);
        $restUrl = sprintf(self::REST_SPACE_ADMIN, $projectHumhub->getSpaceHumhubId());
        $response = $this->callAsCreator()->put($restUrl, $data);
    }

    /**
     * @param array $ids
     *
     * @return void
     * @throws FailedException
     * @author Michaël VEROUX
     */
    public function removeAdmins($ids)
    {
        if (null === $this->project ) {
            throw new FailedException('Project not found');
        }
        $projectHumhub = $this->getProjectHumhub();
        $this->logger->addDebug('Project admins remove', array('admins' => var_export($ids, true)));

        $data = array('ids' => $ids);
        $restUrl = sprintf(self::REST_SPACE_ADMIN, $projectHumhub->getSpaceHumhubId());
        $response = $this->callAsCreator()->put($restUrl, $data);
    }

    /**
     * @param int $calendarId
     *
     * @return void
     * @author Michaël VEROUX
     */
    protected function addAttendees($calendarId)
    {
        $proIds = $this->em->getRepository('OruMeetingBundle:Meeting')->getAttendeesIds($this->meeting);
        $response = $this->callAsCreator()->post(sprintf(self::REST_SPACE_MEETING_PARTICIPANT, $calendarId), array('ids' => $proIds));
        // A priori rien à faire de plus...
        $return = $this->getDataFromResponse($response);
    }

    /**
     * @param IResponse $response
     *
     * @return mixed
     * @throws FailedException
     * @author Michaël VEROUX
     */
    protected function getDataFromResponse(IResponse $response)
    {
        $data = json_decode($response->getParsedResponse(), true);
        if (null === $data) {
            throw new FailedException('Unknow error');
        }

        return $data;
    }

    /**
     * @return Client
     * @author Michaël VEROUX
     */
    private function callAsCreator()
    {
        if ($this->getCreator()) {
            $token = $this->humhubHelper->getProfessionnelAccessToken($this->getCreator()->getId());
            if ($token) {
                $this->restClient->setAccessToken($token);
            }
        }

        return $this->restClient;
    }

    /**
     * @return ProjectHumhub
     * @author Michaël VEROUX
     */
    private function getProjectHumhub()
    {
        $projectHumhub = $this->em->getRepository('OruProjectHumhubBundle:ProjectHumhub')->findOneBy(array(
            'project'    => $this->project,
        ));
        if (!$projectHumhub) {
            $this->newProject();

            return $this->getProjectHumhub();
        }

        return $projectHumhub;
    }

    /**
     * @param IResponse $response
     *
     * @return array
     * @throws FailedException
     * @author Michaël VEROUX
     */
    private function getDataProjectFromResponse(IResponse $response)
    {
        $data = $this->getDataFromResponse($response);

        if (!isset($data['id'])) {
            $msg = 'Failed to create space.';
            if (isset($data['message'])) {
                $msg = $data['message'];
            }

            throw new FailedException($msg);
        }

        return $data;
    }

    /**
     * @param IResponse $response
     *
     * @return array
     * @throws FailedException
     * @author Michaël VEROUX
     */
    private function getDataMembersFromResponse(IResponse $response)
    {
        return $this->getDataFromResponse($response);
    }

    /**
     * @param int $id
     *
     * @return ProjectHumhub
     * @author Michaël VEROUX
     */
    private function createProjectHumhub($id)
    {
        $projectHumhub = new ProjectHumhub();
        $projectHumhub->setProject($this->project);
        $projectHumhub->setSpaceHumhubId($id);

        $this->em->persist($projectHumhub);
        $this->em->flush($projectHumhub);

        return $projectHumhub;
    }
}
