<?php

namespace Oru\Bundle\ProjectHumhubBundle\Synchro;

/**
 * Interface HumhubInterface
 *
 * @package Oru\Bundle\ProjectHumhubBundle\Synchro
 * @author Michaël VEROUX
 */
interface HumhubInterface
{
    const REST_SPACE_VIEW = '/ror/space/view/%d';
    const REST_SPACE_NEW = '/ror/space';
    const REST_SPACE_UPDATE = '/ror/space/%d';
    const REST_SPACE_INVITE = 'ror/space/member/invite/%d';
    const REST_SPACE_ADMIN = 'ror/space/member/admin/%d';
    const REST_SPACE_MEMBERS = 'ror/space/members/%d';
    const REST_SPACE_MEMBER_REMOVE = 'ror/space/member/remove/%d';
    const REST_SPACE_POST_NEW = 'ror/space/post/%d';
    const REST_SPACE_MEETING_NEW = 'ror/space/calendar/%d';
    const REST_SPACE_MEETING_UPDATE = 'ror/space/calendar/%d';
    const REST_SPACE_MEETING_PARTICIPANT = 'ror/space/calendar/participant/%d';
    const REST_SPACE_MEMBER_ACTIVITIES = 'ror/space/activity/%d';
    const REST_MEMBER_ACTIVITIES = 'ror/activity';

    const REST_USER_TOKEN = 'ror/user/token/%s';
    const REST_USER_CREATE = 'ror/user/usercreate';
    const REST_USER_UPDATE = 'ror/user/userupdate';

    const REST_NOTIFICATION_LIST = 'ror/notification/list';

    const HUMHUB_USER_SUCCESS = 0;
    const HUMHUB_USER_UNCHANGED = 1;
    const HUMHUB_USER_UNKNOWN = 2;
}
