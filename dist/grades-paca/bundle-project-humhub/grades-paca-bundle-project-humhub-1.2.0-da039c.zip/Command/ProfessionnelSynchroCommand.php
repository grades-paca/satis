<?php

namespace Oru\Bundle\ProjectHumhubBundle\Command;

use Oru\Bundle\ScheduleBundle\Command\AbstractContainerAwareScheduleDynamicCommand;
use Oru\Bundle\SpoolBundle\Exception\FailedException;
use RestClient\Exception;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class ProfessionnelSynchroCommand.
 *
 * @author Michaël VEROUX
 */
class ProfessionnelSynchroCommand extends AbstractContainerAwareScheduleDynamicCommand
{
    const NAME = 'oru:synchro:humhub';

    /**
     * Doit renvoyer le nombre de secondes d'exécution acceptable avant que le gestionnaire de taches ne tue le processus
     * 0 si pas de limite.
     *
     * @param int $pid
     *
     * @return int
     **/
    public function getMaxRunningTime($pid)
    {
        return 600;
    }

    /**
     * Doit renvoyer un booleen signalant si la tache accepte d'être exécutée en parallèle avec d'autres taches issus de la même commande.
     *
     * @return bool
     */
    public function isConcurentAllowed()
    {
        return false;
    }

    /**
     * Cette methode fait le lien entre un nom de parametre ou d'option, et le type de champ au sens "formulaire symfony"
     * Si elle est implémentée vide, tout sera considéré comme du texte.
     *
     * Fonctionnement:
     * En fonction du nom de l'argument ou de l'option spécifié par $name
     * il faut affecter les variables passées en référence $type et $options
     * Ces variables seront utilisées lors de la génération du formulaire symfony d'interface graphique pour gêrer l'exécution du script
     * et seront passées à la commande FormBuilder::add (voir options de cette commande pour plus de détail sur le contenu éventuel de $options)
     *
     * @param mixed $name
     *
     * @return mixed
     */
    public function getTypeFieldFromArgumentName($name, &$type = 'text', &$options = array())
    {
    }

    /**
     * @author Michaël VEROUX
     */
    protected function configure()
    {
        $this
            ->setName(self::NAME)
            ->setDescription('Synchronise les professionnels du ROR sur Humhub.')
        ;
    }

    /**
     * Executes the current command.
     *
     * This method is not abstract because you can use this class
     * as a concrete class. In this case, instead of defining the
     * execute() method, you set the code to execute by passing
     * a Closure to the setCode() method.
     *
     * @param InputInterface  $input  An InputInterface instance
     * @param OutputInterface $output An OutputInterface instance
     *
     * @throws \LogicException When this abstract method is not implemented
     *
     * @return null|int null or 0 if everything went fine, or an error code
     *
     * @see setCode()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $professionnelIds = $this->getContainer()->get('doctrine.orm.default_entity_manager')
            ->getRepository('OruProfessionnelBundle:Professionnel')
            ->getEnabledIds();

        foreach ($professionnelIds as $professionnelId) {
            try {
                $this->getContainer()->get('oru_project_humhub.helper')->getProfessionnelAccessToken($professionnelId);
            } catch (Exception $e) {
                try {
                    $this->getContainer()->get('oru_project_humhub.synchro_user')->createUser($professionnelId);
                } catch (FailedException $e) {
                    echo "Le professionnel d'identifiant $professionnelId n'a pas pu être créé : {$e->getMessage()}.\n";
                }
            }
        }
    }
}
