Bundle OruProjectHumhubBundle
=============================

Description
-----------

Ce bundle permet de faire le lien avec l'application réseau social.

Installation du Bundle
------------

Importer le paquet via composer

    ./composer.phar require "oru/project-humhub-bundle":~1.0

Dans le AppKernel.php, activer ce bundle

    $bundles[] = new Oru\Bundle\ProjectHumhubBundle\OruProjectHumhubBundle();

Dans le config.yml, ajouter ce bundle au mapping Doctrine :

```
    doctrine:
        orm:
            ...
            entity_managers:
                default:
                    ...
                    mappings:
                        OruProjectHumhubBundle: ~
```

Dans parameters.yml, renseigner les variables :
```
    humhub_url: 'https://rse.e-santepaca.fr'
    humhub_access_token: tokenOfAdminUserOfHumhub
```

Vérifier que le bundle n'est pas dans les disabled_bundle

Vider le cache de Symfony
