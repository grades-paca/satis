<?php
/**
 * Author: Michaël VEROUX
 * Date: 03/04/14
 * Time: 12:16
 */

namespace Oru\Bundle\TranslationBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Security\Csrf\CsrfTokenManagerInterface;

/**
 * Class TranslationListingType
 * @package Oru\Bundle\TranslationBundle\Listing
 * @author Michaël VEROUX
 */
class TranslationListingType extends AbstractListingType
{
    /**
     * @var CsrfTokenManagerInterface
     */
    protected $csrfProvider;

    /**
     * @param CsrfTokenManagerInterface $csrfProvider
     */
    function __construct(CsrfTokenManagerInterface $csrfProvider)
    {
        $this->csrfProvider = $csrfProvider;
    }

    /**
     * @param ListingBuilderInterface $builder
     * @author Michaël VEROUX
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('nameUnprefixed', null, array(
                    'label'         =>  'oru_translation.nameUnprefixed',
                    'translation_domain'    => 'OruTranslationBundle',
                )
            )
            ->add('valuePreview', null, array(
                    'label'         =>  'oru_translation.valuePreview',
                    'translation_domain'    => 'OruTranslationBundle',
                )
            )
            ->add('locale', null, array(
                    'label'         =>  'oru_translation.locale',
                    'translation_domain'    => 'OruTranslationBundle',
                )
            )
            ->add('domain', null, array(
                    'sort'      => 't.domain',
                    'label'         =>  'oru_translation.domain',
                    'translation_domain'    => 'OruTranslationBundle',
                )
            )
            ->add('edit', 'object_action', array(
                    'route'     => 'oru_translation_edit',
                    'label'     => 'listing.action.edit',
                    'role'      => 'ROLE_ADMIN',
                )
            )
            ->add('delete', 'object_action', array(
                    'route'     => 'oru_translation_delete',
                    'label'     => 'listing.action.delete',
                    'role'      => 'ROLE_SUPER_ADMIN',
                    'route_parameters'  =>  array(
                        '_method'           =>  'DELETE',
                        'token'             =>  $this->csrfProvider->getToken('delete'),
                    ),
                )
            )
            ->add('new', 'list_action', array(
                    'route'     => 'oru_translation_new',
                    'label'     => 'listing.action.new',
                    'role'      => 'ROLE_SUPER_ADMIN',
                )
            )
        ;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'oru_translation_listing';
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\TranslationBundle\Entity\Translation',
        ));
    }
}