<?php

namespace Oru\Bundle\TranslationBundle;

use Oru\Bundle\TranslationBundle\DependencyInjection\Compiler\TranslationCompilerPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruTranslationBundle extends Bundle
{
    /**
     * @param ContainerBuilder $container
     */
    public function build(ContainerBuilder $container)
    {
        parent::build($container);

        $container->addCompilerPass(new TranslationCompilerPass());
    }
}
