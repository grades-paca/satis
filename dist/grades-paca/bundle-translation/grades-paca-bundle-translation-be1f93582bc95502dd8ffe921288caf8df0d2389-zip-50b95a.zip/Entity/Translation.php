<?php

namespace Oru\Bundle\TranslationBundle\Entity;

/**
 * Translation
 */
class Translation
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $domain;

    /**
     * @var string
     */
    private $locale;

    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $value;

    /**
     * @var string
     */
    private $defaultValue;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set domain
     *
     * @param string $domain
     * @return Translation
     */
    public function setDomain($domain)
    {
        $this->domain = $domain;
    
        return $this;
    }

    /**
     * Get domain
     *
     * @return string 
     */
    public function getDomain()
    {
        return $this->domain;
    }

    /**
     * Set locale
     *
     * @param string $locale
     * @return Translation
     */
    public function setLocale($locale)
    {
        $this->locale = $locale;

        return $this;
    }

    /**
     * Get locale
     *
     * @return string
     */
    public function getLocale()
    {
        return $this->locale;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Translation
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set value
     *
     * @param string $value
     * @return Translation
     */
    public function setValue($value)
    {
        $this->value = $value;
    
        return $this;
    }

    /**
     * Get value
     *
     * @return string 
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * Set defaultValue
     *
     * @param string $defaultValue
     * @return Translation
     */
    public function setDefaultValue($defaultValue)
    {
        if(null === $this->value || $this->value === $this->defaultValue)
            $this->value = $defaultValue;

        $this->defaultValue = $defaultValue;
    
        return $this;
    }

    /**
     * Get defaultValue
     *
     * @return string 
     */
    public function getDefaultValue()
    {
        return $this->defaultValue;
    }

    public function getNameUnprefixed()
    {
        return preg_replace('#^[^\.]+\.(.+)$#', '$1', $this->getName());
    }

    public function getValuePreview()
    {
        if(strlen($this->getValue()) > 24)
            return mb_substr($this->getValue(), 0, 12, 'UTF-8') . ' ... ' . mb_substr($this->getValue(), -12, 12, 'UTF-8');

        return $this->getValue();
    }
}
