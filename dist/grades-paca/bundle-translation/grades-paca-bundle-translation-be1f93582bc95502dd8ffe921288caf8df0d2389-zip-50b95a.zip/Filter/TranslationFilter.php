<?php
/**
 * Author: Michaël VEROUX
 * Date: 03/04/14
 * Time: 13:37
 */

namespace Oru\Bundle\TranslationBundle\Filter;

/**
 * Class TranslationFilter
 * @package Oru\Bundle\TranslationBundle\Filter
 * @author Michaël VEROUX
 */
class TranslationFilter
{
    /**
     * @var string
     */
    protected $name;

    /**
     * @var string
     */
    protected $value;

    /**
     * @var string
     */
    protected $defaultValue;

    /**
     * @var string
     */
    protected $domain;

    /**
     * @var string
     */
    protected $locale;

    /**
     * @var boolean
     */
    protected $valueChanged;

    /**
     * @param string $domain
     */
    public function setDomain($domain)
    {
        $this->domain = $domain;
    }

    /**
     * @return string
     */
    public function getDomain()
    {
        return $this->domain;
    }

    /**
     * @param string $locale
     */
    public function setLocale($locale)
    {
        $this->locale = $locale;
    }

    /**
     * @return string
     */
    public function getLocale()
    {
        return $this->locale;
    }

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $value
     */
    public function setValue($value)
    {
        $this->value = $value;
    }

    /**
     * @return string
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @param string $defaultValue
     */
    public function setDefaultValue($defaultValue)
    {
        $this->defaultValue = $defaultValue;
    }

    /**
     * @return string
     */
    public function getDefaultValue()
    {
        return $this->defaultValue;
    }

    /**
     * @param boolean $valueChanged
     */
    public function setValueChanged($valueChanged)
    {
        $this->valueChanged = $valueChanged;
    }

    /**
     * @return boolean
     */
    public function getValueChanged()
    {
        return null !== $this->valueChanged ? (bool)$this->valueChanged : null;
    }
} 