<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Oru\Bundle\TranslationBundle\Tests\Loader;

use Symfony\Component\Config\Resource\FileResource;
use Oru\Bundle\TestBundle\Tests\ModelTestCase;

class OrmLoaderTest extends ModelTestCase
{
    /**
     * @var Doctrine\ORM\EntityManager
     */
    protected $entityManager;

    public function setUp()
    {
        parent::setUp();
        if (!class_exists('Oru\Bundle\TranslationBundle\Loader\OrmLoader')) {
            $this->markTestSkipped('The "OrmLoader" component is not available');
        }

        if (!class_exists('Symfony\Component\Config\Loader\Loader')) {
            $this->markTestSkipped('The "Config" component is not available');
        }

        if (!class_exists('Symfony\Component\Yaml\Yaml')) {
            $this->markTestSkipped('The "Yaml" component is not available');
        }

        $this->entityManager = $this->get('doctrine')->getManager();
    }

    public function testLoad()
    {
        $loader = $this->get('oru_translation.loader.orm');
        $resource = __DIR__.'/../fixtures/resources_default.yml';
        $catalogue = $loader->load($resource, 'en', 'domain1');
        $values = $this->entityManager->getRepository('OruTranslationBundle:Translation')
            ->createQueryBuilder('t')
            ->where('t.name IN (:name) AND t.locale = :locale AND t.domain = :domain')
            ->setParameters(array(
                'name'      =>  'foo',
                'locale'    =>  'en',
                'domain'    =>  'domain1',
            ))
            ->getQuery()
            ->getResult();
        $message = reset($values);

        $this->assertEquals(array('foo' => 'bar'), $catalogue->all('domain1'));
        $this->assertEquals('en', $catalogue->getLocale());
        $this->assertEquals(array(new FileResource($resource)), $catalogue->getResources());
        $this->assertCount(1, $values);
        $this->assertInstanceOf('Oru\Bundle\TranslationBundle\Entity\Translation', $message);
        $this->assertEquals($message->getValue(), 'bar');
        $this->assertEquals($message->getValue(), $message->getDefaultValue());
        $this->assertEquals($message->getDomain(), 'domain1');
        $this->assertEquals($message->getLocale(), 'en');

        // test entity
        $message->setValue('bor');
        $this->entityManager->flush();
        $this->assertTrue($message->getValue() != $message->getDefaultValue());
        $values = $this->entityManager->getRepository('OruTranslationBundle:Translation')
            ->createQueryBuilder('t')
            ->where('t.id = (:id)')
            ->setParameters(array(
                'id'      =>  $message->getId()
            ))
            ->getQuery()
            ->getResult();
        $message = reset($values);
        $this->assertCount(1, $values);
        $this->assertInstanceOf('Oru\Bundle\TranslationBundle\Entity\Translation', $message);
        $this->assertEquals($message->getValue(), 'bor');

        // reset
        $this->entityManager->remove($message);
        $this->entityManager->flush();
    }

    public function testLoadWithValues()
    {
        $loader = $this->get('oru_translation.loader.orm');
        $resource = __DIR__.'/../fixtures/resources_default.yml';
        $catalogue = $loader->load($resource, 'en', 'domain1');

        $loader = $this->get('oru_translation.loader.orm');
        $resource = __DIR__.'/../fixtures/resources.yml';
        $catalogue = $loader->load($resource, 'en', 'domain1');
        $values = $this->entityManager->getRepository('OruTranslationBundle:Translation')
            ->createQueryBuilder('t')
            ->where('t.locale = :locale AND t.domain = :domain')
            ->setParameters(array(
                'locale'    =>  'en',
                'domain'    =>  'domain1',
            ))
            ->getQuery()
            ->getResult();
        $message = reset($values);

        $this->assertEquals(array(
            'sports.ball.squash' => 'squash',
            'sports.ball.tennis' => 'tennis',
            'sports.ball.foot'   => 'football',
            'foo'                => 'bar'
        ), $catalogue->all('domain1'));
        $this->assertEquals('en', $catalogue->getLocale());
        $this->assertEquals(array(new FileResource($resource)), $catalogue->getResources());
        $this->assertCount(4, $values);
        $this->assertInstanceOf('Oru\Bundle\TranslationBundle\Entity\Translation', $message);

        // reset
        foreach($values as $value)
            $this->entityManager->remove($value);
        $this->entityManager->flush();
    }

    public function testLoadWithSameValues()
    {
        $loader = $this->get('oru_translation.loader.orm');
        $resource = __DIR__.'/../fixtures/resources_default.yml';
        $catalogue = $loader->load($resource, 'en', 'domain1');

        $loader = $this->get('oru_translation.loader.orm');
        $resource = __DIR__.'/../fixtures/resources_default.yml';
        $catalogue = $loader->load($resource, 'en', 'domain1');
        $values = $this->entityManager->getRepository('OruTranslationBundle:Translation')
            ->createQueryBuilder('t')
            ->where('t.locale = :locale AND t.domain = :domain')
            ->setParameters(array(
                'locale'    =>  'en',
                'domain'    =>  'domain1',
            ))
            ->getQuery()
            ->getResult();
        $message = reset($values);

        $this->assertEquals(array('foo' => 'bar'), $catalogue->all('domain1'));
        $this->assertEquals('en', $catalogue->getLocale());
        $this->assertEquals(array(new FileResource($resource)), $catalogue->getResources());
        $this->assertCount(1, $values);
        $this->assertInstanceOf('Oru\Bundle\TranslationBundle\Entity\Translation', $message);
        $this->assertEquals($message->getValue(), 'bar');

        // reset
        $this->entityManager->remove($message);
        $this->entityManager->flush();
    }

    public function testLoadDoesNothingIfEmpty()
    {
        $loader = $this->get('oru_translation.loader.orm');
        $resource = __DIR__.'/../fixtures/empty.yml';
        $catalogue = $loader->load($resource, 'en', 'domain1');

        $this->assertEquals(array(), $catalogue->all('domain1'));
        $this->assertEquals('en', $catalogue->getLocale());
        $this->assertEquals(array(new FileResource($resource)), $catalogue->getResources());
    }

    /**
     * @expectedException \Symfony\Component\Translation\Exception\NotFoundResourceException
     */
    public function testLoadNonExistingResource()
    {
        $loader = $this->get('oru_translation.loader.orm');
        $resource = __DIR__.'/../fixtures/non-existing.yml';
        $loader->load($resource, 'en', 'domain1');
    }

    /**
     * @expectedException \Symfony\Component\Translation\Exception\InvalidResourceException
     */
    public function testLoadThrowsAnExceptionIfFileNotLocal()
    {
        $loader = $this->get('oru_translation.loader.orm');
        $resource = 'http://example.com/resources.yml';
        $loader->load($resource, 'en', 'domain1');
    }

    /**
     * @expectedException \Symfony\Component\Translation\Exception\InvalidResourceException
     */
    public function testLoadThrowsAnExceptionIfNotAnArray()
    {
        $loader = $this->get('oru_translation.loader.orm');
        $resource = __DIR__.'/../fixtures/non-valid.yml';
        $loader->load($resource, 'en', 'domain1');
    }
}
