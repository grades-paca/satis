<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 09/01/14
 * Time: 10:07
 */

namespace Oru\Bundle\TranslationBundle\DependencyInjection\Compiler;


use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Reference;

/**
 * Class TranslationCompilerPass
 * @package Oru\Bundle\TranslationBundle\DependencyInjection\Compiler
 * @author Michaël VEROUX
 */
class TranslationCompilerPass implements CompilerPassInterface
{

    /**
     * You can modify the container here before it is dumped to PHP code.
     *
     * @param ContainerBuilder $container
     *
     * @api
     */
    public function process(ContainerBuilder $container)
    {
        if(
            $container->hasDefinition('oru_translation.dynamic_security')
            && $container->hasDefinition('oru_ror_credentials.credentials_checker')
        )
        {
            $definition = $container->getDefinition('oru_translation.dynamic_security');
            $definition->addMethodCall('setAlternativContext', array(new Reference('oru_ror_credentials.credentials_checker')));
        }
    }
}