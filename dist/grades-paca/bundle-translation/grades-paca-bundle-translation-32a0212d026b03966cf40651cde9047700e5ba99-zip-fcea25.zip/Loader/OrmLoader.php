<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 20/11/13
 * Time: 10:12
 */

namespace Oru\Bundle\TranslationBundle\Loader;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Criteria;
use Doctrine\ORM\EntityManager;
use Oru\Bundle\TranslationBundle\Entity\Translation;
use Symfony\Component\Config\Resource\FileResource;
use Symfony\Component\Translation\Exception\InvalidResourceException;
use Symfony\Component\Translation\Exception\NotFoundResourceException;
use Symfony\Component\Translation\Loader\ArrayLoader;
use Symfony\Component\Translation\MessageCatalogue;
use Symfony\Component\Validator\Exception\ValidatorException;
use Symfony\Component\Validator\Validator\ValidatorInterface;
use Symfony\Component\Yaml\Exception\ParseException;
use Symfony\Component\Yaml\Parser as YamlParser;

/**
 * Class OrmLoader
 * @package Oru\Bundle\TranslationBundle\Loader
 */
class OrmLoader extends ArrayLoader
{

    /**
     * @var \Doctrine\ORM\EntityManager|null
     */
    private $entityManagerSingle;

    /**
     * @var \Symfony\Component\Yaml\Parser
     */
    private $yamlParser;

    private $validator;

    /**
     * @param EntityManager $entityManager
     */
    public function __construct(EntityManager $entityManager, ValidatorInterface $validator)
    {
        $this->entityManagerSingle = EntityManager::create(
            $entityManager->getConnection(),
            $entityManager->getConfiguration()
        );
        $this->validator = $validator;
    }

    /**
     * {@inheritdoc}
     *
     * @api
     */
    public function load($resource, $locale, $domain = 'messages')
    {
        if (!stream_is_local($resource)) {
            throw new InvalidResourceException(sprintf('This is not a local file "%s".', $resource));
        }

        if (!file_exists($resource)) {
            throw new NotFoundResourceException(sprintf('File "%s" not found.', $resource));
        }

        if (null === $this->yamlParser) {
            $this->yamlParser = new YamlParser();
        }

        try {
            $messages = $this->yamlParser->parse(file_get_contents($resource));
        } catch (ParseException $e) {
            throw new InvalidResourceException('Error parsing YAML.', 0, $e);
        }

        // empty file
        if (null === $messages) {
            $messages = array();
        }

        $this->flatten($messages);

        if(!empty($messages))
        {
            $translations = $this->entityManagerSingle->getRepository('OruTranslationBundle:Translation')
                ->createQueryBuilder('t')
                ->where('t.name IN (:name) AND t.locale = :locale AND t.domain = :domain')
                ->setParameters(array(
                    'name'      =>  array_keys($messages),
                    'locale'    =>  $locale,
                    'domain'    =>  $domain,
                ))
                ->getQuery()
                ->getResult();

            foreach($messages as $key => $message)
            {
                if(count($translations))
                {
                    if(! $translations instanceof ArrayCollection)
                        $translations = new ArrayCollection($translations);

                    $translation = $translations->matching(
                        Criteria::create()->where(
                            Criteria::expr()->eq('name', $key)
                        )
                    )->first();
                }
                else
                    $translation = null;

                if($translation instanceof Translation)
                {
                    $translation->setDefaultValue($message);
                }
                else
                {
                    $translation = new Translation();
                    $translation
                        ->setName($key)
                        ->setDomain($domain)
                        ->setLocale($locale)
                        ->setDefaultValue($message)
                    ;
                    $errors = $this->validator->validate($translation);
                    if(count($errors))
                    {
                        $message = array();
                        foreach($errors as $error)
                        {
                            $message[] = $error->getMessage();
                        }
                        $errorOutput = implode("\n", $message);
                        $errorOutput .= sprintf(' values : %s, %s, %s', $key, $domain, $locale);

                        throw new ValidatorException($errorOutput);
                    }
                }
                $this->entityManagerSingle->persist($translation);
            }

            $this->entityManagerSingle->flush();
        }

        $query = $this->entityManagerSingle->getRepository('OruTranslationBundle:Translation')
            ->createQueryBuilder('t')
            ->where('t.domain = :domain AND t.locale = :locale')
            ->setParameter('domain', $domain)
            ->setParameter('locale', $locale)
            ->getQuery()
        ;

        $catalogue = new MessageCatalogue($locale);

        // add first ressource to catalogue
        $catalogue->addResource(new FileResource($resource));

        foreach($query->getArrayResult() as $tmp)
        {
            $catalogue->set($tmp['name'], $tmp['value'], $domain);
        }

        return $catalogue;
    }

    /**
     * Flattens an nested array of translations
     *
     * The scheme used is:
     *   'key' => array('key2' => array('key3' => 'value'))
     * Becomes:
     *   'key.key2.key3' => 'value'
     *
     * This function takes an array by reference and will modify it
     *
     * @param array  &$messages The array that will be flattened
     * @param array  $subnode Current subnode being parsed, used internally for recursive calls
     * @param string $path    Current path being parsed, used internally for recursive calls
     */
    private function flatten(array &$messages, array $subnode = null, $path = null)
    {
        if (null === $subnode) {
            $subnode =& $messages;
        }
        foreach ($subnode as $key => $value) {
            if (is_array($value)) {
                $nodePath = $path ? $path.'.'.$key : $key;
                $this->flatten($messages, $value, $nodePath);
                if (null === $path) {
                    unset($messages[$key]);
                }
            } elseif (null !== $path) {
                $messages[$path.'.'.$key] = $value;
            }
        }
    }
}