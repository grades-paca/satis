<?php
/**
 * Author: Michaël VEROUX
 * Date: 03/04/14
 * Time: 12:23
 */

namespace Oru\Bundle\TranslationBundle\Entity;

use Doctrine\Common\Util\Inflector;
use Doctrine\ORM\EntityRepository;
use Oru\Bundle\TranslationBundle\Filter\TranslationFilter;

/**
 * Class TranslationRepository
 * @package Oru\Bundle\TranslationBundle\Entity
 * @author Michaël VEROUX
 */
class TranslationRepository extends EntityRepository
{
    /**
     * @param TranslationFilter $translationFilter
     * @return \Doctrine\ORM\QueryBuilder
     * @author Michaël VEROUX
     */
    public function findList(TranslationFilter $translationFilter)
    {
        $builder = $this->createQueryBuilder("t");

        $searchFields = array('name', 'value', 'defaultValue', 'domain', 'locale');

        foreach($searchFields as $field)
        {
            $method = 'get' . Inflector::camelize($field);

            $builder
                ->andWhere(sprintf('t.%1$s LIKE :%1$s', $field))
                ->setParameter($field, sprintf('%%%s%%', $translationFilter->$method()))
            ;
        }

        if(true === $translationFilter->getValueChanged())
        {
            $builder
                ->andWhere('t.value != t.defaultValue')
            ;
        }
        elseif(false === $translationFilter->getValueChanged())
        {
            $builder
                ->andWhere('t.value = t.defaultValue')
            ;
        }

        return $builder;
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    public function getDomains()
    {
        $domains = $this->createQueryBuilder('t')
            ->select('t.domain')
            ->groupBy('t.domain')
            ->getQuery()
            ->getArrayResult()
        ;

        return array_map(function($value){ return $value['domain']; }, $domains);
    }
} 