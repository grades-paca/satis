<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\TranslationBundle\Manager;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Criteria;
use Doctrine\ORM\EntityManager;
use Oru\Bundle\TranslationBundle\Cache\Refresh;
use Oru\Bundle\TranslationBundle\Entity\Translation;
use Symfony\Component\Config\Resource\FileResource;
use Symfony\Component\Translation\MessageCatalogue;
use Symfony\Component\Translation\TranslatorInterface;
use Symfony\Component\Validator\Exception\ValidatorException;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class TranslationManager
{
    /**
     * @var \Doctrine\ORM\EntityManager|null
     */
    protected $entityManagerSingle;

    /**
     * @var ValidatorInterface
     */
    protected $validator;

    /**
     * @var string chemin vers le cache des traductions
     */
    protected $cacheRefresh;

    /**
     * TranslationManager constructor.
     *
     * @param EntityManager $entityManager
     * @param ValidatorInterface $validator
     * @throws \Doctrine\ORM\ORMException
     */
    public function __construct(EntityManager $entityManager, ValidatorInterface $validator, Refresh $cacheRefresh)
    {
        $this->entityManagerSingle = EntityManager::create(
            $entityManager->getConnection(),
            $entityManager->getConfiguration()
        );
        $this->validator = $validator;
        $this->cacheRefresh = $cacheRefresh;
    }

    /**
     * Traite un ensemble de messages pour une locale et un domaine donné
     *
     * @param array $messages Format 'key.key2.key3' => 'value'
     * @param string $locale
     * @param string $domain
     * @throws \Doctrine\ORM\OptimisticLockException
     */
    public function parseMessages(array $messages, $locale, $domain = 'messages')
    {
        if (!empty($messages)) {
            $translations = $this->entityManagerSingle->getRepository('OruTranslationBundle:Translation')
                ->createQueryBuilder('t')
                ->where('t.name IN (:name) AND t.locale = :locale AND t.domain = :domain')
                ->setParameters(array(
                    'name' => array_keys($messages),
                    'locale' => $locale,
                    'domain' => $domain,
                ))
                ->getQuery()
                ->getResult();

            foreach ($messages as $key => $message) {
                if (count($translations)) {
                    if (!$translations instanceof ArrayCollection)
                        $translations = new ArrayCollection($translations);

                    $translation = $translations->matching(
                        Criteria::create()->where(
                            Criteria::expr()->eq('name', $key)
                        )
                    )->first();
                } else
                    $translation = null;

                if ($translation instanceof Translation) {
                    $translation->setDefaultValue($message);
                } else {
                    $translation = new Translation();
                    $translation
                        ->setName($key)
                        ->setDomain($domain)
                        ->setLocale($locale)
                        ->setDefaultValue($message);
                    $errors = $this->validator->validate($translation);
                    if (count($errors)) {
                        $message = array();
                        foreach ($errors as $error) {
                            $message[] = $error->getMessage();
                        }
                        $errorOutput = implode("\n", $message);
                        $errorOutput .= sprintf(' values : %s, %s, %s', $key, $domain, $locale);

                        throw new ValidatorException($errorOutput);
                    }
                }
                $this->entityManagerSingle->persist($translation);
            }

            $this->entityManagerSingle->flush();
        }
    }

    /**
     * Renvoie le catalogue de traductions pour une locale et un domaine donné
     *
     * @param $resource
     * @param string $locale
     * @param string $domain
     * @return MessageCatalogue
     */
    public function getCatalogue($resource, $locale, $domain = 'messages')
    {
        $query = $this->entityManagerSingle->getRepository('OruTranslationBundle:Translation')
            ->createQueryBuilder('t')
            ->where('t.domain = :domain AND t.locale = :locale')
            ->setParameter('domain', $domain)
            ->setParameter('locale', $locale)
            ->getQuery()
        ;

        $catalogue = new MessageCatalogue($locale);

        // add first ressource to catalogue
        $catalogue->addResource(new FileResource($resource));

        foreach($query->getArrayResult() as $tmp)
        {
            $catalogue->set($tmp['name'], $tmp['value'], $domain);
        }

        return $catalogue;
    }

    /**
     * Invalide le cache des traductions
     */
    public function invalidateTranslationsCache()
    {
        $this->cacheRefresh->now();
    }
}