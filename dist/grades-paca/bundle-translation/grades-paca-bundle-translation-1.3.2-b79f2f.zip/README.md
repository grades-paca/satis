Bundle TranslationBundle
========================

Installation
------------

Dans le AppKernel.php, activer ce bundle

    $bundles[] = new Oru\Bundle\TranslationBundle\OruTranslationBundle();

Dans le routing.yml, ajouter les routes :

    oru_translation:
        resource: "@OruTranslationBundle/Resources/config/routing.xml"
        prefix:  /label

Vider le cache de Symfony

Description
-----------

Ce bundle permet de mettre les traductions en base de données et les surcharger via l'IHM.

Utilisation
-----------

Il faut créer un dossier translations dans le dossier Resources.
Ajouter un fichier dont la convention de nommage est la suivante NomDuBundle.fr.orm

Les fichiers sont parsés lorsque le cache est vidé.
