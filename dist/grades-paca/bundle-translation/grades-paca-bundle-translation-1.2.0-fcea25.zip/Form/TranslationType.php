<?php
/**
 * Author: Michaël VEROUX
 * Date: 03/04/14
 * Time: 14:15
 */

namespace Oru\Bundle\TranslationBundle\Form;

use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class TranslationType
 * @package Oru\Bundle\TranslationBundle\Form
 * @author Michaël VEROUX
 */
class TranslationType extends AbstractType
{
    /**
     * @var ObjectManager
     */
    protected $objectManager;

    /**
     * @param ObjectManager $objectManager
     */
    public function __construct(ObjectManager $objectManager)
    {
        $this->objectManager = $objectManager;
    }

    public function setFullEditable($boolean)
    {
        $this->fullEditable = $boolean;

        return $this;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $domains = $this->objectManager->getRepository('OruTranslationBundle:Translation')->getDomains();

        if($this->fullEditable)
            $builder->add('name');
        else
            $builder->add('name', 'oru_static', array('disabled' => true));

        $builder
            ->add('default_value', 'oru_static', array('disabled' => true)
            )
            ->add('value'
            )
        ;

        if($this->fullEditable)
            $builder
                ->add('locale'
                )
                ->add('domain', 'choice', array(
                    'choices'       =>  array_combine($domains,$domains),
                    )
                )
            ;
        else
            $builder
                ->add('locale', 'oru_static', array('disabled' => true)
                )
                ->add('domain', 'oru_static', array('disabled' => true));

        $builder
            ->add('save', 'submit', array(
                    'label'                 =>  'save',
                    'translation_domain'    => 'messages',
                    'attr'                  => array(
                        'class'                 => 'btn btn-primary',
                    ),
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\TranslationBundle\Entity\Translation',
            'translation_domain'    => 'OruTranslationBundle',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_translation';
    }
}