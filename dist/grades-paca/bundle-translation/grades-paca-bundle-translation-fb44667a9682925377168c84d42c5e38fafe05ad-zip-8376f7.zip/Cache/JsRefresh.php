<?php

namespace Oru\Bundle\TranslationBundle\Cache;

use Bazinga\Bundle\JsTranslationBundle\Dumper\TranslationDumper;
use Symfony\Bundle\FrameworkBundle\Console\Application;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Output\NullOutput;
use Symfony\Component\HttpKernel\KernelInterface;

/**
 * Class JsRefresh.
 */
class JsRefresh
{
    /**
     * @var TranslationDumper
     */
    protected $translationDumper;

    /**
     * @var KernelInterface
     */
    protected $kernel;

    /**
     * @param TranslationDumper $translationDumper
     */
    public function setTranslationDumper($translationDumper)
    {
        $this->translationDumper = $translationDumper;
    }

    /**
     * @param KernelInterface $kernel
     */
    public function setKernel($kernel)
    {
        $this->kernel = $kernel;
    }

    /**
     * @param string $locale
     */
    public function dump()
    {
        //Refresh js from jsTranslation
        $this->translationDumper->dump('js', array('js'), null);

        //Then refresh assetic
        $application = new Application($this->kernel);
        $application->setAutoExit(false);

        $input = new ArrayInput(array(
            'command' => 'assetic:dump',
        ));
        $output = new NullOutput();

        $application->run($input, $output);
    }
}
