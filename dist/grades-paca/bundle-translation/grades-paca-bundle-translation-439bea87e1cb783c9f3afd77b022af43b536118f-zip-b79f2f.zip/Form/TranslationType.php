<?php
/**
 * Author: Michaël VEROUX
 * Date: 03/04/14
 * Time: 14:15
 */

namespace Oru\Bundle\TranslationBundle\Form;

use Doctrine\Common\Persistence\ObjectManager;
use Oru\Bundle\FormBundle\Form\Type\StaticType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class TranslationType.
 *
 * @author Michaël VEROUX
 */
class TranslationType extends AbstractType
{
    /**
     * @var ObjectManager
     */
    protected $objectManager;

    /**
     * @param ObjectManager $objectManager
     */
    public function __construct(ObjectManager $objectManager)
    {
        $this->objectManager = $objectManager;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $this->fullEditable = $options['fullEditable'];
        $domains = $this->objectManager->getRepository('OruTranslationBundle:Translation')->getDomains();

        if ($this->fullEditable) {
            $builder->add('name');
        } else {
            $builder->add('name', StaticType::class, array('disabled' => true));
        }

        $builder
            ->add('default_value', StaticType::class, array('disabled' => true)
            )
            ->add('value'
            )
        ;

        if ($this->fullEditable) {
            $builder
                ->add('locale'
                )
                ->add('domain', ChoiceType::class, array(
                    'choices' => array_combine($domains, $domains),
                    )
                )
            ;
        } else {
            $builder
                ->add('locale', StaticType::class, array('disabled' => true)
                )
                ->add('domain', StaticType::class, array('disabled' => true));
        }

        $builder
            ->add('save', SubmitType::class, array(
                    'label' => 'save',
                    'translation_domain' => 'messages',
                    'attr' => array(
                        'class' => 'btn btn-primary',
                    ),
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\TranslationBundle\Entity\Translation',
            'translation_domain' => 'OruTranslationBundle',
            'fullEditable' => false
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_translation';
    }
}
