<?php
/**
 * Author: Michaël VEROUX
 * Date: 07/04/14
 * Time: 15:48
 */

namespace Oru\Bundle\TranslationBundle\Cache;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\SpoolBundle\Entity\Spool;
use Oru\Bundle\SpoolBundle\Event\Events;
use Oru\Bundle\SpoolBundle\Event\SpoolEvent;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\Filesystem\Filesystem;

/**
 * Class Refresh
 * @package Oru\Bundle\TranslationBundle\Cache
 * @author Michaël VEROUX
 */
class Refresh
{
    /**
     * @var Filesystem
     */
    protected $filesystem;

    /**
     * @var string
     */
    protected $cacheDir;

    /**
     * @var EntityManager
     */
    protected $entityManager;

    /** @var EventDispatcherInterface $eventDispatcher */
    private $eventDispatcher;

    /**
     * @param EventDispatcherInterface $eventDispatcher
     */
    public function setEventDispatcher($eventDispatcher)
    {
        $this->eventDispatcher = $eventDispatcher;
    }

    /**
     * @param Filesystem $filesystem
     * @param $cacheDir
     */
    public function __construct(Filesystem $filesystem, EntityManager $entityManager, $cacheDir)
    {
        $this->filesystem = $filesystem;
        $this->entityManager = $entityManager;
        $this->cacheDir = $cacheDir;
    }

    /**
     * @param string $locale
     * @author Michaël VEROUX
     */
    public function now($locale = 'fr')
    {
        $sha1FallbackFr = '74ad548a14679603165a68a05f1f6a84f1ab7740';
        $fileMeta = sprintf('%s/catalogue.%s.%s.php', $this->cacheDir, $locale, $sha1FallbackFr);

        if($this->filesystem->exists($fileMeta))
            $this->filesystem->remove($fileMeta);

        $event = new SpoolEvent('oru_translation.cache_js_refresh');
        $event  ->setServiceCalls(array('dump'=>array()))
                ->setPriority(Spool::PRIORITY_VERY_LOW);
        $this->eventDispatcher->dispatch(Events::SPOOL_ADD,$event);
    }

    /**
     * @return bool
     * @author Michaël VEROUX
     */
    public function purge()
    {
        $file = sprintf('%s/purge.lck', $this->cacheDir);
        if ($this->filesystem->exists($file)) {
            return false;
        }

        $repository = $this->entityManager->getRepository('OruTranslationBundle:Translation');
        $repository->createQueryBuilder('t')
            ->delete()
            ->where('t.defaultValue = t.value AND t.defaultValue != :empty')
            ->orWhere('t.defaultValue = t.value AND t.value = :empty')
            ->setParameter('empty', '')
            ->getQuery()
            ->execute()
        ;
        $this->filesystem->dumpFile($file, '');
        $this->now();

        return true;
    }
} 