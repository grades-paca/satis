<?php
/**
 * Author: Michaël VEROUX
 * Date: 03/04/14
 * Time: 13:33
 */

namespace Oru\Bundle\TranslationBundle\Form\Filter;

use Oru\Bundle\FormBundle\Form\Type\OuiNonType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class TranslationFilterType.
 *
 * @author Michaël VEROUX
 */
class TranslationFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', SearchType::class, array(
                    'label' => 'oru_translation.name',
                )
            )
            ->add('defaultValue', SearchType::class, array(
                    'label' => 'oru_translation.defaultValue',
                )
            )
            ->add('value', SearchType::class, array(
                    'label' => 'oru_translation.value',
                )
            )
            ->add('domain', SearchType::class, array(
                    'label' => 'oru_translation.domain',
                )
            )
            ->add('locale', SearchType::class, array(
                    'label' => 'oru_translation.locale',
                )
            )
            ->add('valueChanged', OuiNonType::class, array(
                    'expanded' => false,
                    'required' => false,
                    'label' => 'oru_translation.valueChanged',
                )
            )
            ->add('filter', SubmitType::class, array(
                    'label' => 'listing.action.filter',
                    'translation_domain' => 'messages',
                    'attr' => array('class' => 'btn btn-primary'),
                )
            )
            ->add('reset', SubmitType::class, array(
                    'label' => 'listing.action.reset',
                    'translation_domain' => 'messages',
                    'attr' => array('class' => 'btn btn-default'),
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\TranslationBundle\Filter\TranslationFilter',
            'csrf_protection' => false,
            'validation_groups' => false,
            'required' => false,
            'translation_domain' => 'OruTranslationBundle',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_translation_filter';
    }
}
