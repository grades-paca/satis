<?php
/**
 * Author: Michaël VEROUX
 * Date: 03/04/14
 * Time: 11:42
 */

namespace Oru\Bundle\TranslationBundle\Controller;

use Oru\Bundle\DesignBundle\Controller\FlashControllerTrait;
use Oru\Bundle\TranslationBundle\Entity\Translation;
use Oru\Bundle\TranslationBundle\Filter\TranslationFilter;
use Oru\Bundle\TranslationBundle\Form\Filter\TranslationFilterType;
use Oru\Bundle\TranslationBundle\Form\TranslationType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\Security\Core\Exception\InvalidCsrfTokenException;

/**
 * Class TranslationController.
 *
 * @author Michaël VEROUX
 */
class TranslationController extends Controller
{
    use FlashControllerTrait;

    /**
     * @param Request               $request
     * @param TranslationFilterType $form
     *
     * @throws \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException
     *
     * @return Response
     *
     * @author Michaël VEROUX
     */
    public function indexAction(Request $request, TranslationFilterType $form = null)
    {
        if (!$this->get('oru_translation.dynamic_security')->isGranted('ORU_TRANSLATION')) {
            throw new AccessDeniedHttpException();
        }
        if (null === $form) {
            $form = $this->createForm(TranslationFilterType::class, new TranslationFilter())->submit($request->getSession()->get('oru_translation.filter'));
        }

        $em = $this->getDoctrine()->getManager();

        $entities = $em->getRepository('OruTranslationBundle:Translation')->findList($form->getData());

        $listing = $this->container->get('oru_ror_credentials.paginator')->create(
            $this->get('oru_translation.listing'),
            $entities,
            $request->query->get('page', 1)
        );

        return $this->render('@OruTranslation/Translation/index.html.twig',
            array(
                'listing' => $listing,
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     *
     * @throws \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
     *
     * @author Michaël VEROUX
     */
    public function filterAction(Request $request)
    {
        if (!$this->get('oru_translation.dynamic_security')->isGranted('ORU_TRANSLATION')) {
            throw new AccessDeniedHttpException();
        }
        $form = $this->createForm(TranslationFilterType::class)->handleRequest($request);

        if ($form->get('reset')->isClicked()) {
            $request->getSession()->set('oru_translation.filter', array());

            return $this->redirect($this->generateUrl('oru_translation'));
        }

        if ($form->isValid()) {
            $request->getSession()->set('oru_translation.filter', $request->get($form->getName()));

            return $this->redirect($this->generateUrl('oru_translation'));
        }

        return $this->indexAction($request, $form);
    }

    /**
     * @param Translation $entity
     *
     * @throws \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException
     *
     * @return Response
     *
     * @author Michaël VEROUX
     */
    public function editAction(Translation $entity)
    {
        if (!$this->get('oru_translation.dynamic_security')->isGranted('ORU_TRANSLATION', $entity)) {
            throw new AccessDeniedHttpException();
        }
        $form = $this->container->get('form.factory')->create(
            TranslationType::class,
            $entity,
            array('fullEditable' => $this->get('oru_translation.dynamic_security')->isGranted('ORU_TRANSLATION_ADMIN', $entity))
        );

        return $this->render('@OruTranslation/Translation/edit.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request     $request
     * @param Translation $entity
     *
     * @throws \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
     *
     * @author Michaël VEROUX
     */
    public function updateAction(Request $request, Translation $entity)
    {
        if (!$this->get('oru_translation.dynamic_security')->isGranted('ORU_TRANSLATION', $entity)) {
            throw new AccessDeniedHttpException();
        }
        $form = $this->container->get('form.factory')->create(
            TranslationType::class,
            $entity,
            array('fullEditable' => $this->get('oru_translation.dynamic_security')->isGranted('ORU_TRANSLATION_ADMIN', $entity))
        );

        $form->submit($request->request->get($form->getName()));

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->flush();
            $this->get('oru_translation.cache_refresh')->now($entity->getLocale());
            $this->addSessionMessage('Vos données sont enregistrées.');

            return $this->redirect($this->generateUrl('oru_translation_edit', array('id' => $entity->getId())));
        }

        $this->addSessionMessage('Le formulaire soumis contient des erreurs...', 'warning');

        return $this->render('@OruTranslation/Translation/edit.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     *
     * @throws \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException
     *
     * @return Response
     *
     * @author Michaël VEROUX
     */
    public function newAction(Request $request)
    {
        if (!$this->get('oru_translation.dynamic_security')->isGranted('ORU_TRANSLATION')) {
            throw new AccessDeniedHttpException();
        }
        $form = $this->container->get('form.factory')->create(
            TranslationType::class,
            new Translation(),
            array('fullEditable' => true)
        );

        return $this->render('@OruTranslation/Translation/new.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     *
     * @throws \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
     *
     * @author Michaël VEROUX
     */
    public function createAction(Request $request)
    {
        if (!$this->get('oru_translation.dynamic_security')->isGranted('ORU_TRANSLATION')) {
            throw new AccessDeniedHttpException();
        }
        $translation = new Translation();

        $form = $this->container->get('form.factory')->create(
            TranslationType::class,
            $translation,
            array('fullEditable' => true)
        );

        $form->submit($request->request->get($form->getName()));

        if ($form->isValid()) {
            $translation->setDefaultValue('');
            $em = $this->getDoctrine()->getManager();
            $em->persist($translation);
            $em->flush();
            $this->get('oru_translation.cache_refresh')->now($translation->getLocale());
            $this->addSessionMessage('Vos données sont enregistrées.');

            return $this->redirect($this->generateUrl('oru_translation_edit', array('id' => $translation->getId())));
        }

        $this->addSessionMessage('Le formulaire soumis contient des erreurs...', 'warning');

        return $this->render('@OruTranslation/Translation/new.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request     $request
     * @param Translation $translation
     *
     * @throws \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException
     * @throws \Symfony\Component\Security\Core\Exception\InvalidCsrfTokenException
     *
     * @return Response
     *
     * @author Michaël VEROUX
     */
    public function deleteAction(Request $request, Translation $translation)
    {
        if (!$this->get('oru_translation.dynamic_security')->isGranted('ORU_TRANSLATION_ADMIN')) {
            throw new AccessDeniedHttpException();
        }
        if (!$this->get('security.csrf.token_manager')->isTokenValid('delete', $request->get('token'))) {
            throw new InvalidCsrfTokenException();
        }
        $em = $this->getDoctrine()->getManager();
        $em->remove($translation);
        $em->flush();
        $this->get('oru_translation.cache_refresh')->now($translation->getLocale());

        $this->addSessionMessage('L\'élément à été supprimé.');

        $response = new Response();

        $response->setContent(json_encode(array(
            'redirect' => $this->generateUrl('oru_translation'),
        )));
        $response->headers->set('Content-Type', 'application/json');

        return $response;
    }
}
