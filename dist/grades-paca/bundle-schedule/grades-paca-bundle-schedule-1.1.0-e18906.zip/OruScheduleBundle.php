<?php

namespace Oru\Bundle\ScheduleBundle ;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruScheduleBundle extends Bundle
{


}
