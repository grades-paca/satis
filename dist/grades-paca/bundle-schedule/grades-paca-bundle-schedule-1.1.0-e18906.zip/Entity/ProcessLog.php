<?php

namespace Oru\Bundle\ScheduleBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\ScheduleBundle\lib\RorDatetime;
use Symfony\Component\DependencyInjection\Container;
use Oru\Bundle\ScheduleBundle\lib\CommandHandler ;

/**
 * ProcessLog
 */
class ProcessLog
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var \DateTime
     */
    private $startDatetime;

    /**
     * @var \DateTime
     */
    private $endDatetime;


    /**
     * @var string
     */
    private $commandNamespace;

    /**
     * @var string
     */
    private $args;

    /**
     * @var int
     */
    private $done;

    /**
     * @var int
     */
    private $waskilled ;

    /**
     * @return int
     */
    public function getWaskilled()
    {
        return $this->waskilled;
    }

    /**
     * @param int $waskilled
     */
    public function setWaskilled($waskilled)
    {
        $this->waskilled = $waskilled;
    }




    /**
     * @param int $done
     */
    public function setDone($done)
    {
        $this->done = $done;
    }

    /**
     * @return int
     */
    public function getDone()
    {
        return $this->done;
    }



    /**
     * @var string
     */
    private $return;




    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }



    /**
     * Set startDatetime
     *
     * @param \DateTime $startDatetime
     * @return ProcessLog
     */
    public function setStartDatetime($startDatetime)
    {
        $this->startDatetime = $startDatetime;
    
        return $this;
    }

    /**
     * Get startDatetime
     *
     * @return \DateTime 
     */
    public function getStartDatetime()
    {
        return $this->startDatetime;
    }

    /**
     * Set endDatetime
     *
     * @param \DateTime $endDatetime
     * @return ProcessLog
     */
    public function setEndDatetime($endDatetime)
    {
        $this->endDatetime = $endDatetime;
    
        return $this;
    }

    /**
     * Get endDatetime
     *
     * @return \DateTime 
     */
    public function getEndDatetime()
    {
        return $this->endDatetime;
    }

    /**
     * Set htmlReturn
     *
     * @param string $htmlReturn
     * @return ProcessLog
     */
    public function setReturn($htmlReturn)
    {
        $this->return = $htmlReturn;
    
        return $this;
    }

    /**
     * Get htmlReturn
     *
     * @return string 
     */
    public function getReturn()
    {
        return $this->return;
    }



    /**
     * Set namespace
     *
     * @param string $commandNamespace
     * @return ProcessLog
     */
    public function setCommandNamespace($commandNamespace)
    {

        $this->commandNamespace = $commandNamespace;
        return $this;
    }


    public function getCommandNamespaceCourt()
    {
        $tab = explode('\\',$this->getCommandNamespace());
        return $tab[count($tab)-1];
    }

    /**
     * Get task
     *
     * @return \Oru\Bundle\ScheduleBundle\Entity\Task
     */
    public function getCommandNamespace()
    {
        return $this->commandNamespace;
    }

    /**
     * Set args
     *
     * @param string $args
     * @return ProcessLog
     */
    public function setArgs($args)
    {
        $this->args = $args;
    
        return $this;
    }

    /**
     * Get args
     *
     * @return string 
     */
    public function getArgs()
    {
        return $this->args;
    }
    /**
     * @var string
     */
    private $pid;


    /**
     * Set pid
     *
     * @param string $pid
     * @return ProcessLog
     */
    public function setPid($pid)
    {
        $this->pid = $pid;
    
        return $this;
    }

    /**
     * Get pid
     *
     * @return string 
     */
    public function getPid()
    {
        return $this->pid;
    }


    public function kill() {
        $this->setDone(1);
        $this->setWaskilled(1);
        $this->setEndDatetime(RorDatetime::getInstance());
        //shell_exec("kill -9 {$this->getPid()}");
        //Le PID qu'on a, c'est pas le script PHP, mais le bash qui a lancé le PHP
        shell_exec("pkill -P {$this->getPid()}");
    }

    /**

    public function isZombie() {
        if($this->getDone()) return false ;
        $ps = shell_exec("ps o command p " . $this->getPid());
        $ps = explode("\n", $ps);
        if (count($ps) < 2) {
            return true ;
        }
    }*/

    /**
     * @param Container $container
     * @return CommandHandler
     */
    public function getCommand(Container $container) {
        $commande = CommandHandler::getInstanceFromCommandNamespace($this->getCommandNamespace(),$container);
        return $commande ;
    }



    /**
     * @return RorDatetime
     */
    public function getRorDatetimeStart() {
       return  RorDatetime::getInstance($this->getStartDatetime());
    }


    /**
     * L'exécution a-t-elle dépassé sa limite ?
     * @param Container $container
     */
    public function isOutOfTime(Container $container,RorDatetime $now) {
        $maximalDateTimeExecutionAllowed = $this->getRorDatetimeStart()->getCloned()->addSeconds($this->getCommand($container)->getCommand()->getMaxRunningTimeSec()) ;
        if( $maximalDateTimeExecutionAllowed->isEarlierThan($now) ) {
            return true ;
        }
        return false ;
    }


}