<?php
/**
 * Created by PhpStorm.
 * User: ecervetti
 * Date: 06/12/13
 * Time: 14:36
 */

namespace Oru\Bundle\ScheduleBundle\Command;

use Oru\Bundle\ScheduleBundle\lib\CommandHandler;
use Oru\Bundle\ScheduleBundle\lib\RorDatetime;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;




class CleanCommand  extends ContainerAwareCommand {

    public function configure()
    {
        $this
            ->setName('oru:schedule:clean')
            ->setDescription("Nettoyage des données relatives au planificateur de taches");
    }

    public function execute(InputInterface $input, OutputInterface $output)
    {
        //On nettoie les fichiers en cache plus vieux de 10 jours
        self::nettoieRep(CommandHandler::getDefaultCacheDirectoryFromContainer($this->getContainer()),'.*',7);

        //On nettoie les fichiers intégrés par les flux entrants plus vieux de 10 jours
        $urlHistoFluxEntrants = $this->getContainer()->get('oru_setting')->setting('urlloc_releve').'/histo' ;
        if(file_exists($urlHistoFluxEntrants )) {
            self::nettoieRep($urlHistoFluxEntrants,'.*',7);
        }

        //On vire les logs d'exécution plus vieux de 10 jours
        $this->getContainer()->get("doctrine")->getRepository("OruScheduleBundle:ProcessLog")->deleteOlderThen(RorDatetime::getNow()->addDay(-10));


    }

    static function nettoieRep($rep, $type, $dureejours) {
        $duree = $dureejours * 24;
        $r = opendir($rep);
        while ($fic = readdir($r)) {
            if ($fic != "." AND $fic != "..") {
                $date = filemtime("$rep/$fic");
                if (preg_match('@' . $type . '$@', $fic) && $date < (time() - ( $duree * 3600 )) && !is_dir("$rep/$fic") && is_file("$rep/$fic")) {
                    unlink("$rep/$fic");
                }
            }
        }
        closedir($r);
    }





} 