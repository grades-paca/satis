<?php

namespace Oru\Bundle\ScheduleBundle\Controller;

use Oru\Bundle\ScheduleBundle\Entity\Task;
use Oru\Bundle\ScheduleBundle\lib\CommandHandler;
use Symfony\Component\HttpFoundation\Response ;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;


class DefaultController extends Controller

{

    /**
     * Affichage général de la page de gestion des taches
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function indexAction($optionsFrom=[]) {

        if( ! $this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('OruSchedule_admin') ) {
            return $this->render('OruRorCredentialsBundle::echecDroits.html.twig',['credentialname'=>'OruSchedule_admin']);
        }

        $defaults = [] ;
        $defaults['handlers'] = [] ;
        $defaults['from'] = $optionsFrom ;
        foreach(CommandHandler::getAllCommandHandlersFromContainer($this->container) as $commandHandler) {

            $tabTasksInfo = [];

            $defaults['handlers'][] = [
                'name' => $commandHandler->getCommand()->getName(),
                'clarification' => $commandHandler->getCommand()->getDescription(),
                'taskNamespace' =>$commandHandler->getNamespaceCommand(),
                'taskNamespaceMini' =>$commandHandler->getCommandNamespaceCourt(),
                    'tasks' => $tabTasksInfo
            ]   ;
        }
        return $this->render('OruScheduleBundle::index.html.twig', [
                'defaultsJsonConfig' => $this->container->get("serializer")->serialize($defaults,'json'),
                'urlGetSfFormFromCommand' =>  $this->generateUrl('getSfFormFromCommand'),
                'jsns' =>  'IhmGestionTaches',
                'urlSetNewPlanifCommand'=>  $this->generateUrl('setNewPlanifCommand'),
                'urlGetAllTaskForCommand' => $this->generateUrl('getAllTaskForCommand'),
                'urlGetAllTaskForAllCommand' => $this->generateUrl('getAllTaskForAllCommand'),
                'urlDeleteTask'  => $this->generateUrl('deleteTask'),
                'urlLaunchCommand'  => $this->generateUrl('launchCommand'),
                'urlKillProcess'  => $this->generateUrl('killProcess'),
                'urlShowCommandLogs'=> $this->generateUrl('showCommandLogs'),
            ]
        );
    }

    /**
     * Renvoit l'affichage du sfForm dédié à la gestion du script
     * @return \Symfony\Component\HttpFoundation\Response
     */
    function getSfFormFromCommandAction() {

        if( ! $this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('OruSchedule_admin') ) {
            return $this->render('OruRorCredentialsBundle::echecDroits.html.twig',['credentialname'=>'OruSchedule_admin']);
        }

        $namespacecommand = $this->getRequest()->get('commandNamespace');
        $handler = CommandHandler::getInstanceFromCommandNamespace($namespacecommand,$this->container);
        $formView = $handler->getSfForm()->createView();
        return $this->render('OruScheduleBundle::commandForm.html.twig',['form'=>$formView]);
    }

    /**
     * Enregistre la nouvelle tache à exécuter pour la commande
     */
    function setNewPlanifCommandAction() {

        if( ! $this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('OruSchedule_admin') ) {
            return $this->render('OruRorCredentialsBundle::echecDroits.html.twig',['credentialname'=>'OruSchedule_admin']);
        }

        $namespacecommand = $this->getRequest()->get('commandNamespace');
        $handler = CommandHandler::getInstanceFromCommandNamespace($namespacecommand,$this->container);
        $crontabParameter = $this->getRequest()->get('commandCron');
        $sfForm = $handler->getSfForm();
        $sfForm->handleRequest($this->getRequest());
        if ($sfForm->isValid()  &&  $handler->validateRequestExecution($this->getRequest(),$sfForm )) {
            $task = new Task();
            $task->setCrontabTypeScheduling($crontabParameter);
            $task->setCommandNamespace($namespacecommand);
            $task->setArgs($handler->getFullCommandLineArgumentsFromForm($sfForm));
            $task->setAutoInstalled(false);
            $this->getDoctrine()->getManager()->persist($task);
            $this->getDoctrine()->getManager()->flush();
            $retour = array('ok' => true) ;
        } else {
            $retour = array('ko' => true,'message' => "Echec: certains arguments obligatoires ne sont pas présents" ) ;
        }
        if($this->getRequest()->get('reloadFullPage')) {
            return $this->forward("OruScheduleBundle:Default:index",['optionsFrom'=>$retour]);
        }
        $response = new Response($this->get("serializer")->serialize($retour,'json'));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }


    function launchCommandAction() {

        if( ! $this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('OruSchedule_admin') ) {
            return $this->render('OruRorCredentialsBundle::echecDroits.html.twig',['credentialname'=>'OruSchedule_admin']);
        }

        $namespacecommand = $this->getRequest()->get('commandNamespace');
        $handler = CommandHandler::getInstanceFromCommandNamespace($namespacecommand,$this->container);
        $crontabParameter = $this->getRequest()->get('commandCron');
        $sfForm = $handler->getSfForm($this->container);
        $sfForm->handleRequest($this->getRequest());
        if ($sfForm->isValid()  &&  $handler->validateRequestExecution($this->getRequest(),$sfForm )) {
            $messageRetour = "" ;
            $okCommande = $handler->forkExecute($handler->getFullCommandLineArgumentsFromForm($sfForm),$messageRetour);
            if($okCommande) {
                $retour = array('ok' => true) ;
            } else {
                $retour = array('ko' => true,'message'=>$messageRetour) ;
            }
        } else {
            $retour = array('ko' => true,'message'=>"Echec: certains arguments obligatoires ne sont pas présents") ;
        }
        if($this->getRequest()->get('reloadFullPage')) {
            return $this->forward("OruScheduleBundle:Default:index",['optionsFrom'=>$retour]);
        }

        $response = new Response($this->get("serializer")->serialize($retour,'json'));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }


    public function getAllTaskForAllCommandAction()
    {
        if( ! $this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('OruSchedule_admin') ) {
            return $this->render('OruRorCredentialsBundle::echecDroits.html.twig',['credentialname'=>'OruSchedule_admin']);
        }
        $tabData = [];
        foreach ($this->getDoctrine()->getRepository("OruScheduleBundle:Task")->findAll() as $task) {
            $tabData[] = $this->getTabInfoForTasknamespace($task->getCommandNamespace());
        }
        $json = $this->get("serializer")->serialize($tabData,'json');
        $response = new Response($json);
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * Renvoie la liste des taches planifiées pour un namespace précis
     * @return Response
     */
    function getAllTaskForCommandAction() {

        if( ! $this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('OruSchedule_admin') ) {
            return $this->render('OruRorCredentialsBundle::echecDroits.html.twig',['credentialname'=>'OruSchedule_admin']);
        }

        $taskNameSpace = $this->getRequest()->get('commandNamespace');
        $tabInfoTask = $this->getTabInfoForTasknamespace($taskNameSpace);
        $json = $this->get("serializer")->serialize($tabInfoTask,'json');
        $response = new Response($json);
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }


    /**
     * Supprime une tache planifiée
     */

    function deleteTaskAction() {

        if( ! $this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('OruSchedule_admin') ) {
            return $this->render('OruRorCredentialsBundle::echecDroits.html.twig',['credentialname'=>'OruSchedule_admin']);
        }

        $task = $this->getDoctrine()->getRepository("OruScheduleBundle:Task")->find($this->getRequest()->get('taskId'));
        $this->getDoctrine()->getManager()->remove($task);
        $this->getDoctrine()->getManager()->flush();
        $response = new Response('{}');
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }


    /**
     * Tue un processus actif
     */
    function killProcessAction() {

        if( ! $this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('OruSchedule_admin') ) {
            return $this->render('OruRorCredentialsBundle::echecDroits.html.twig',['credentialname'=>'OruSchedule_admin']);
        }

        $process = $this->getDoctrine()->getRepository("OruScheduleBundle:ProcessLog")->find($this->getRequest()->get('processId'));
        $process->kill();
        $this->getDoctrine()->getManager()->persist($process);
        $this->getDoctrine()->getManager()->flush();
        $response = new Response('{}');
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @param Task
     * @return array
     */
    private function getTabInfoForTasknamespace($taskNameSpace)
    {
        $sheduledTasks = $this->getDoctrine()->getRepository("OruScheduleBundle:Task")->getAllTaskFromCommandNamespace($taskNameSpace);
        $runningProcesses = $this->getDoctrine()->getRepository("OruScheduleBundle:ProcessLog")
            ->getCurrentRunningProcessesFromCommandNamespace($taskNameSpace);
        $tabInfoTask = ['taskNamespace' => $taskNameSpace, 'sheduledTasks' => $sheduledTasks, 'runningProcesses' => $runningProcesses];
        return $tabInfoTask;
    }


}
