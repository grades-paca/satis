<?php

namespace Oru\Bundle\ScheduleBundle\Form;

use Oru\Bundle\ScheduleBundle\Form\Type\TermineType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ProcessLogFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('startDatetime', DateTimeType::class, array('required' => false, 'date_widget' => 'single_text', 'time_widget' => 'single_text', 'label' => 'Début', 'translation_domain' => 'OruScheduleBundle'))
            ->add('endDatetime', DateTimeType::class, array('required' => false, 'date_widget' => 'single_text', 'time_widget' => 'single_text', 'label' => 'Fin', 'translation_domain' => 'OruScheduleBundle'))
            //->add('args', 'search', array('required' => false, 'label' => 'Nom', 'translation_domain' => 'OruScheduleBundle'))
            //->add('pid', 'search', array('required' => false, 'label' => 'ProcessLog.pid', 'translation_domain' => 'OruScheduleBundle'))
            ->add('commandNamespace', SearchType::class, array('required' => false, 'label' => 'Commande (classe)', 'translation_domain' => 'OruScheduleBundle'))
            ->add('return', SearchType::class, array('required' => false, 'label' => 'Retour', 'translation_domain' => 'OruScheduleBundle'))
            ->add('done', TermineType::class, array('required' => false, 'label' => 'Termine', 'translation_domain' => 'OruScheduleBundle'))
            ->add('filter', SubmitType::class, array('label' => 'listing.action.filter', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-primary')))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\ScheduleBundle\Filter\ProcessLogFilter',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_schedulebundle_processlogfilter';
    }
}
