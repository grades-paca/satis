<?php
/**
 * Created by PhpStorm.
 * User: ecervetti
 * Date: 06/12/13
 * Time: 14:36
 */

namespace Oru\Bundle\ScheduleBundle\Command;

use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class ExempleCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    public function configure()
    {
        $this
            ->setName('oru:schedule:exemple')
            ->setDescription('Exemple de tache planifiable')
            //->addOption('date1', null, InputOption::VALUE_OPTIONAL )
            //->addOption('date2', null, InputOption::VALUE_OPTIONAL )
            //->addOption('idEtab', null, InputOption::VALUE_OPTIONAL )
        ;
    }

    public function execute(InputInterface $input, OutputInterface $output)
    {
        // sleep(60);
    }

    public function getMaxRunningTimeSec()
    {
        return 100;
    }

    /**
     * Renvoit un booleen signalant si la tache accepte d'être exécutée en parallèle avec d'autres taches issus de la même commande.
     *
     * @return bool
     */
    public function isConcurentAllowed()
    {
        return false;
    }

    /**
     * Renvoit, pour chaque nom d'argument, un type de champ (au sens form symfony) correspondant à la nature de l'argument.
     *
     * @param mixed $name
     *
     * @return mixed
     */
    public function getTypeFieldFromArgumentName($name, &$type = 'text', &$options = array())
    {
        //if($name=='date1') $type = "date" ;
        //if($name=='date2') $type = "datetime" ;
    }
}
