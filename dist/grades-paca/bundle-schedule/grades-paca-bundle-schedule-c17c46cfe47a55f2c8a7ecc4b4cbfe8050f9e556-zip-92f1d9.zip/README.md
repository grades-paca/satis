OruScheduleBundle
================

Description
-----------

Bundle qui permet la planification de commandes, leur exécution manuelle interfacée, et leur suivi.

Note: ce bundle n'est pas compatible avec un serveur windows il car utilise des appels systèmes spécifiques POSIX.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/schedule":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\ListingBundle\OruScheduleBundle();
```

Vider le cache de Symfony2

Installation
-----------

Installer dans le crontab système l'appel à la commande suivante chaque minute:

app/console oru:schedule:cron --env=prod

Supervision
-----------
La route @oru_schedule_main ( /schedule_main ) associée au droit OruSchedule_admin permet d'accéder à l'interface du planificateur de taches


Implementation d'une tache planifiée
-----------

Le planificateur de taches parcourt toutes les commandes existantes symfony (composant Command) et relève celles qui implémentent l'interface Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface

Si votre Commande doit être planifiable, il faut donc qu'elle implémente cette interface.

Les méthodes suivantes sont à implémenter:

``` php
    /**
     * Doit renvoyer le nombre de secondes d'exécution acceptable avant que le gestionnaire de taches ne tue le processus
     * 0 si pas de limite
     * @return integer
     **/
    public function getMaxRunningTimeSec() ;

    /**
     * Doit renvoyer un booleen signalant si la tache accepte d'être exécutée en parallèle avec d'autres taches issus de la même commande
     * @return bool
     */
    public function isConcurentAllowed() ;

    /**
     * Cette methode fait le lien entre un argument de la commande , et un type de champ au sens "formulaire symfony" 
     * Elle permet de spécialiser des arguments possibles. Si rien n'est précisé dans cette methode (et qu'elle est laissée vide, ce qui est une possibilité) tout argument sera considéré comme un champ texte
     * 
     * Fonctionnement:
     * En fonction du nom de l'argument  spécifié par $name
     * il faut affecter les variables passées en référence $type et $options
     * Ces variables seront utilisées lors de la génération du formulaire symfony d'interface graphique pour gêrer l'exécution du script
     * et seront passées à la commande FormBuilder::add (voir options de cette commande pour plus de détail sur le contenu éventuel de $options)
     * @return mixed
     */
    public function getTypeFieldFromArgumentName($name,& $type = TextType::class , & $options = [] ) ;

   //Exemple d'implémentation, pour un argument "file1" qui attend un fichier, et "date1" qui attend un datetime

  public function getTypeFieldFromArgumentName($name,& $type , & $options )  {
    if($name=="date1") $type = "datetime" ;
    if($name=="file1") $type = "file" ;

 }
```

Pré-paramétrer une planification automatique de tache dans le code
-----------

Il faut créer un fichier scheduling.yml dans le répertoire Resources/config de votre bundle. Pour chaque tache à ajouter on spécifie le nom de la commande (namespace complet) et la syntaxe cron correspondant à sa planification
```
scheduling:
    task1:
        commandNamespace: "Oru\Bundle\RorCredentialsBundle\Command\RebuildCredentialsCacheCommand" 
        crontabTypeScheduling: "0 * * * *" 
    task2:
        .....
```

