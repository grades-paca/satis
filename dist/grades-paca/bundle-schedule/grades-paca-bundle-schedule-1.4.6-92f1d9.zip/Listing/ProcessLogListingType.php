<?php

namespace Oru\Bundle\ScheduleBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ProcessLogListingType extends AbstractListingType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('startDatetime', null, array('sort' => 'u.startDatetime', 'label' => 'Début', 'translation_domain' => 'OruScheduleBundle'))
            ->add('endDatetime', null, array('sort' => 'u.endDatetime', 'label' => 'Fin', 'translation_domain' => 'OruScheduleBundle'))
          //  ->add('args', null, array('label' => 'ProcessLog.args', 'translation_domain' => 'OruScheduleBundle'))
         //   ->add('pid', null, array('label' => 'ProcessLog.pid', 'translation_domain' => 'OruScheduleBundle'))
            ->add('commandNamespaceCourt', null, array('sort' => 'u.commandNamespace', 'label' => 'Commande', 'translation_domain' => 'OruScheduleBundle'))
           // ->add('return', null, array('label' => 'ProcessLog.return', 'translation_domain' => 'OruScheduleBundle'))
            ->add('done', 'checkbox', array('sort' => 'u.done', 'label' => 'Terminé', 'translation_domain' => 'OruScheduleBundle'))
          //  ->add('edit', 'object_action', array('route' => 'showCommandLogs_edit', 'label' => 'listing.action.edit'))
            ->add('show', 'object_action', array('route' => 'showCommandLogs_show', 'label' => 'listing.action.show'))
          //  ->add('new', 'list_action', array('route' => 'showCommandLogs_new', 'label' => 'listing.action.new'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\ScheduleBundle\Entity\ProcessLog',
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_schedulebundle_processloglisting';
    }
}
