<?php

namespace Oru\Bundle\ScheduleBundle\Controller;


use Oru\Bundle\ScheduleBundle\Filter\ProcessLogFilter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Oru\Bundle\ScheduleBundle\Entity\ProcessLog;
use Oru\Bundle\ScheduleBundle\Listing\ProcessLogListingType;
use Oru\Bundle\ScheduleBundle\Form\ProcessLogFilterType;
use Symfony\Component\HttpFoundation\Request ;

/**
 * ProcessLog controller.
 *
 */
class ProcessLogController extends Controller
{

    /**
     * Lists all ProcessLog entities.
     *
     */
    public function indexAction(Request $request,$nameCommand="")
    {

        ini_set('memory_limit', '500M');

        $filter = $request->getSession()->get('processlog.filter');

        if ($nameCommand) {
            $filter['commandNamespace'] = $nameCommand ;
        }

        $form = $this->createForm(new ProcessLogFilterType())->submit($filter);
        $listing = $this->container->get('paginator.factory')->create(
            new ProcessLogListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruScheduleBundle:ProcessLog')->findList($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('OruScheduleBundle:ProcessLog:index.html.twig', array(
            'listing' => $listing,
            'form' => $this->createForm(new ProcessLogFilterType(), $form->getData())->createView()
        ));
    }
    /**
     * Filters ProcessLog entities.
     *
     */
    public function filterAction(Request $request)
    {
        ini_set('memory_limit', '500M');

        $form = $this->createForm(new ProcessLogFilterType())->handleRequest($request);

        if($form->isValid()) {
            $request->getSession()->set('processlog.filter', $request->get($form->getName()));
            return $this->redirect($this->generateUrl('showCommandLogs'));
        }

        $filter = $form->getData();
        if($filter === null){
            $filter = new ProcessLogFilter();
        }

        $listing = $this->container->get('paginator.factory')->create(
            new ProcessLogListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruScheduleBundle:ProcessLog')->findList($filter),
            $request->query->get('page', 1)
        );

        return $this->render('OruScheduleBundle:ProcessLog:index.html.twig', array(
            'listing' => $listing,
            'form' => $form->createView()
        ));
    }

    /**
     * Finds and displays a ProcessLog entity.
     *
     */
    public function showAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruScheduleBundle:ProcessLog')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find ProcessLog entity.');
        }

        return $this->render('OruScheduleBundle:ProcessLog:show.html.twig', array(
            'entity'      => $entity,
        ));
    }
}
