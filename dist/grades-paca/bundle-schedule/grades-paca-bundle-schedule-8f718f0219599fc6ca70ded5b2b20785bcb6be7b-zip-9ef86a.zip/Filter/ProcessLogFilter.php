<?php

namespace Oru\Bundle\ScheduleBundle\Filter;

use Oru\Bundle\ScheduleBundle\Entity\ProcessLog;


class ProcessLogFilter  extends ProcessLog
{
}