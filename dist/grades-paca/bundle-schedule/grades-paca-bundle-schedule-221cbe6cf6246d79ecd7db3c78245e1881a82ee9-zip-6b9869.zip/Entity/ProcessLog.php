<?php

namespace Oru\Bundle\ScheduleBundle\Entity;

use JMS\Serializer\Annotation;
use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableDynamicTimeInterface;
use Oru\Bundle\ScheduleBundle\lib\CommandHandler;
use Oru\Bundle\ScheduleBundle\lib\RorDatetime;
use Symfony\Component\DependencyInjection\Container;

/**
 * ProcessLog.
 */
class ProcessLog
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var \DateTime
     */
    private $startDatetime;

    /**
     * @var \DateTime
     */
    private $endDatetime;

    /**
     * @var string
     */
    private $commandNamespace;

    /**
     * @var string
     */
    private $args;

    /**
     * @var int
     */
    private $done;

    /**
     * @var int
     */
    private $waskilled;

    /**
     * @var string
     */
    private $return;
    /**
     * @var string
     */
    private $pid;

    /**
     * @return int
     */
    public function getWaskilled()
    {
        return $this->waskilled;
    }

    /**
     * @param int $waskilled
     */
    public function setWaskilled($waskilled)
    {
        $this->waskilled = $waskilled;
    }

    /**
     * @param int $done
     */
    public function setDone($done)
    {
        $this->done = $done;
    }

    /**
     * @return int
     */
    public function getDone()
    {
        return $this->done;
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set startDatetime.
     *
     * @param \DateTime $startDatetime
     *
     * @return ProcessLog
     */
    public function setStartDatetime($startDatetime)
    {
        $this->startDatetime = $startDatetime;

        return $this;
    }

    /**
     * Get startDatetime.
     *
     * @return \DateTime
     */
    public function getStartDatetime()
    {
        return $this->startDatetime;
    }

    /**
     * Set endDatetime.
     *
     * @param \DateTime $endDatetime
     *
     * @return ProcessLog
     */
    public function setEndDatetime($endDatetime)
    {
        $this->endDatetime = $endDatetime;

        return $this;
    }

    /**
     * Get endDatetime.
     *
     * @return \DateTime
     */
    public function getEndDatetime()
    {
        return $this->endDatetime;
    }

    /**
     * Set htmlReturn.
     *
     * @param string $htmlReturn
     *
     * @return ProcessLog
     */
    public function setReturn($htmlReturn)
    {
        $this->return = $htmlReturn;

        return $this;
    }

    /**
     * Get htmlReturn.
     *
     * @return string
     */
    public function getReturn()
    {
        return $this->return;
    }

    /**
     * Set namespace.
     *
     * @param string $commandNamespace
     *
     * @return ProcessLog
     */
    public function setCommandNamespace($commandNamespace)
    {
        $this->commandNamespace = $commandNamespace;

        return $this;
    }

    public function getCommandNamespaceCourt()
    {
        $tab = explode('\\', $this->getCommandNamespace());

        return $tab[count($tab) - 1];
    }

    /**
     * Get task.
     *
     * @return \Oru\Bundle\ScheduleBundle\Entity\Task
     */
    public function getCommandNamespace()
    {
        return $this->commandNamespace;
    }

    /**
     * Set args.
     *
     * @param string $args
     *
     * @return ProcessLog
     */
    public function setArgs($args)
    {
        $this->args = $args;

        return $this;
    }

    /**
     * Get args.
     *
     * @return string
     */
    public function getArgs()
    {
        return $this->args;
    }

    /**
     * Set pid.
     *
     * @param string $pid
     *
     * @return ProcessLog
     */
    public function setPid($pid)
    {
        $this->pid = $pid;

        return $this;
    }

    /**
     * Get pid.
     *
     * @return string
     */
    public function getPid()
    {
        return $this->pid;
    }

    public function kill()
    {
        $this->setDone(1);
        $this->setWaskilled(1);
        $this->setEndDatetime(RorDatetime::getInstance());
        //shell_exec("kill -9 {$this->getPid()}");
        //Le PID qu'on a, c'est pas le script PHP, mais le bash qui a lancé le PHP
        shell_exec("pkill -P {$this->getPid()}");
    }

    /**
    public function isZombie() {
        if($this->getDone()) return false ;
        $ps = shell_exec("ps o command p " . $this->getPid());
        $ps = explode("\n", $ps);
        if (count($ps) < 2) {
            return true ;
        }
    }*/

    /**
     * @param Container $container
     *
     * @return CommandHandler
     */
    public function getCommand(Container $container)
    {
        $commande = CommandHandler::getInstanceFromCommandNamespace($this->getCommandNamespace(), $container);

        return $commande;
    }

    /**
     * @Annotation\Exclude()
     *
     * @return RorDatetime
     */
    public function StartRorDatetime()
    {
        return  RorDatetime::getInstance($this->getStartDatetime());
    }

    public function getStrDatetimeStart()
    {
        return $this->StartRorDatetime()->getStrDateTimeFr();
    }

    /**
     * L'exécution a-t-elle dépassé sa limite ?
     *
     * @param Container   $container
     * @param RorDatetime $now
     *
     * @return bool
     */
    public function isOutOfTime(Container $container, RorDatetime $now)
    {
        $command = $this->getCommand($container)->getCommand();
        $nbSecondsAutho = CommandHandler::MAX_EXECUTION_TIME;
        if ($command instanceof OruSchedulableCommandInterface) {
            $nbSecondsAutho = $command->getMaxRunningTimeSec();
        }
        if ($command instanceof OruSchedulableDynamicTimeInterface) {
            $nbSecondsAutho = $command->getMaxRunningTime($this->getPid());
        }
        if (0 === $nbSecondsAutho) {
            return false;
        }
        $maximalDateTimeExecutionAllowed = $this->StartRorDatetime()->getCloned()->addSeconds($nbSecondsAutho);
        if ($maximalDateTimeExecutionAllowed->isEarlierThan($now)) {
            return true;
        }

        return false;
    }
}
