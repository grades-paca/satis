<?php

namespace Oru\Bundle\ScheduleBundle\Interfaces;

/**
 * Interface OruSchedulableDynamicTimeInterface.
 *
 * @author Michaël VEROUX
 */
interface OruSchedulableDynamicTimeInterface extends OruSchedulableInterface
{
    /**
     * Doit renvoyer le nombre de secondes d'exécution acceptable avant que le gestionnaire de taches ne tue le processus
     * 0 si pas de limite.
     *
     * @param int $pid
     *
     * @return int
     **/
    public function getMaxRunningTime($pid);

    /**
     * Important: use trait Oru\Bundle\ScheduleBundle\Command\OruSchedulableDynamicTrait to implement this method!
     *
     * @author Michaël VEROUX
     */
    public function addLocalIdOption();
}
