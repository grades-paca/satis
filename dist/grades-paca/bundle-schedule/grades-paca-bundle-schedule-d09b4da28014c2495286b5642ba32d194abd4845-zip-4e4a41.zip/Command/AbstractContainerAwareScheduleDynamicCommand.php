<?php

namespace Oru\Bundle\ScheduleBundle\Command;

use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableDynamicTimeInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class AbstractContainerAwareScheduleDynamicCommand
 *
 * @package Oru\Bundle\ScheduleBundle\Command
 * @author Michaël VEROUX
 */
abstract class AbstractContainerAwareScheduleDynamicCommand extends ContainerAwareCommand implements OruSchedulableDynamicTimeInterface
{
    use OruSchedulableDynamicTrait;

    /**
     * Doit renvoyer le nombre de secondes d'exécution acceptable avant que le gestionnaire de taches ne tue le processus
     * 0 si pas de limite
     *
     * @param int $pid
     *
     * @return integer
     **/
    abstract public function getMaxRunningTime($pid);

    /**
     * Runs the command.
     *
     * The code to execute is either defined directly with the
     * setCode() method or by overriding the execute() method
     * in a sub-class.
     *
     * @param InputInterface  $input An InputInterface instance
     * @param OutputInterface $output An OutputInterface instance
     *
     * @return int The command exit code
     *
     * @throws \Exception
     *
     * @see setCode()
     * @see execute()
     */
    public function run(InputInterface $input, OutputInterface $output)
    {
        $this->addLocalIdOption();

        return parent::run($input, $output);
    }

}
