<?php

namespace Oru\Bundle\ScheduleBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ProcessLogFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('startDatetime', 'datetime', array('required' => false, 'label' => 'Début', 'translation_domain' => 'OruScheduleBundle'))
            ->add('endDatetime', 'datetime', array('required' => false, 'label' => 'Fin', 'translation_domain' => 'OruScheduleBundle'))
            //->add('args', 'search', array('required' => false, 'label' => 'Nom', 'translation_domain' => 'OruScheduleBundle'))
            //->add('pid', 'search', array('required' => false, 'label' => 'ProcessLog.pid', 'translation_domain' => 'OruScheduleBundle'))
            ->add('commandNamespace', 'search', array('required' => false, 'label' => 'Commande (classe)', 'translation_domain' => 'OruScheduleBundle'))
            ->add('return', 'search', array('required' => false, 'label' => 'Retour', 'translation_domain' => 'OruScheduleBundle'))
            ->add('done', 'oru_schedule_termine', array('required' => false, 'label' => 'Termine', 'translation_domain' => 'OruScheduleBundle'))
            ->add('filter', 'submit', array('label' => 'listing.action.filter', 'translation_domain' => 'messages'))
        ;
    }

    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\ScheduleBundle\Filter\ProcessLogFilter'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_schedulebundle_processlogfilter';
    }
}
