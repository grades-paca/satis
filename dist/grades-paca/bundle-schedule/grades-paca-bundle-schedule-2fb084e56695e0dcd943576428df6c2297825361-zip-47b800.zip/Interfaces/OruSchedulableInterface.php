<?php

namespace Oru\Bundle\ScheduleBundle\Interfaces;

/**
 * Class OruSchedulableInterface
 *
 * @package Oru\Bundle\ScheduleBundle\Interfaces
 * @author Michaël VEROUX
 */
interface OruSchedulableInterface
{
    /**
     * Doit renvoyer un booleen signalant si la tache accepte d'être exécutée en parallèle avec d'autres taches issus de la même commande
     *
     * @return bool
     */
    public function isConcurentAllowed();

    /**
     * Cette methode fait le lien entre un nom de parametre ou d'option, et le type de champ au sens "formulaire symfony"
     * Si elle est implémentée vide, tout sera considéré comme du texte.
     *
     * Fonctionnement:
     * En fonction du nom de l'argument ou de l'option spécifié par $name
     * il faut affecter les variables passées en référence $type et $options
     * Ces variables seront utilisées lors de la génération du formulaire symfony d'interface graphique pour gêrer l'exécution du script
     * et seront passées à la commande FormBuilder::add (voir options de cette commande pour plus de détail sur le contenu éventuel de $options)
     *
     * @return mixed
     */
    public function getTypeFieldFromArgumentName($name, & $type = "text", & $options = []);
}
