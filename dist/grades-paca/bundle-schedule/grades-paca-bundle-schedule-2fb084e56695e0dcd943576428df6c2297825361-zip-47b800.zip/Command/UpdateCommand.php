<?php
/**
 * Created by PhpStorm.
 * User: ecervetti
 * Date: 06/12/13
 * Time: 14:36
 */

namespace Oru\Bundle\ScheduleBundle\Command;

use Oru\Bundle\ScheduleBundle\lib\CommandHandler;
use Oru\Bundle\ScheduleBundle\lib\RorDatetime;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;



class UpdateCommand  extends ContainerAwareCommand {

    public function configure()
    {
        $this
            ->setName('oru:schedule:update')
            ->setDescription('Exécuté apres une tache planifiée pour mettre à jour son statut')
            ->addArgument(
                'lid',
                InputArgument::REQUIRED,
                'Local ID of process'
            )
        ;
    }

    public function execute(InputInterface $input, OutputInterface $output)
    {
        $localId = $input->getArgument('lid');
        $pid = file_get_contents(CommandHandler::getDefaultCacheDirectoryFromContainer($this->getContainer()).'/'.$localId.'.pid');

        $fileLog = CommandHandler::getDefaultCacheDirectoryFromContainer($this->getContainer()).'/'.$localId ;

        $logFileContents = file_get_contents($fileLog);

        $processLog = $this->getContainer()->get("doctrine")->getManager()->getRepository("OruScheduleBundle:ProcessLog")->findOneBy(['pid'=>$pid,'done'=>0],['id'=>'DESC']);
        if (!$processLog) {
            throw new \Exception("Post Scheduling : La tache planifiée pid=$pid n'a pas pu être mise à jour car elle n'existe pas. + d'infos dans $fileLog ?");
        }
        $processLog->setEndDatetime(RorDatetime::getNow());
        $processLog->setReturn($logFileContents);
        $processLog->setDone(1);
        $this->getContainer()->get("doctrine")->getManager()->flush();
    }




} 