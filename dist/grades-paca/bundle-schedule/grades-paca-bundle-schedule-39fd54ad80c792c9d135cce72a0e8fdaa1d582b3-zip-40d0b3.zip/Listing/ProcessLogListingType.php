<?php

namespace Oru\Bundle\ScheduleBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ProcessLogListingType extends AbstractListingType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('startDatetime', null, array('label' => 'Début', 'translation_domain' => 'OruScheduleBundle'))
            ->add('endDatetime', null, array('label' => 'Fin', 'translation_domain' => 'OruScheduleBundle'))
          //  ->add('args', null, array('label' => 'ProcessLog.args', 'translation_domain' => 'OruScheduleBundle'))
         //   ->add('pid', null, array('label' => 'ProcessLog.pid', 'translation_domain' => 'OruScheduleBundle'))
            ->add('commandNamespaceCourt', null, array('label' => 'Commande', 'translation_domain' => 'OruScheduleBundle'))
           // ->add('return', null, array('label' => 'ProcessLog.return', 'translation_domain' => 'OruScheduleBundle'))
            ->add('done', 'checkbox', array('label' => 'Terminé', 'translation_domain' => 'OruScheduleBundle'))
          //  ->add('edit', 'object_action', array('route' => 'showCommandLogs_edit', 'label' => 'listing.action.edit'))
            ->add('show', 'object_action', array('route' => 'showCommandLogs_show', 'label' => 'listing.action.show'))
          //  ->add('new', 'list_action', array('route' => 'showCommandLogs_new', 'label' => 'listing.action.new'))
        ;
    }

    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\ScheduleBundle\Entity\ProcessLog'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_schedulebundle_processloglisting';
    }
}
