<?php

namespace Oru\Bundle\ScheduleBundle\Exception;

use \RuntimeException;

/**
 * Class ScheduleRuntimeException
 *
 * @package Oru\Bundle\ScheduleBundle\RuntimeException
 * @author Michaël VEROUX
 */
class ScheduleRuntimeException extends RuntimeException
{

}
