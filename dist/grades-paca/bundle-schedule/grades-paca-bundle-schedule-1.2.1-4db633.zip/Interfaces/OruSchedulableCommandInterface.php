<?php
/**
 * Created by PhpStorm.
 * User: ecervetti
 * Date: 12/02/14
 * Time: 14:40
 */

namespace Oru\Bundle\ScheduleBundle\Interfaces;

/**
 * Interface OruSchedulableCommandInterface
 *
 * @package Oru\Bundle\ScheduleBundle\Interfaces
 */
interface OruSchedulableCommandInterface extends OruSchedulableInterface
{
    /**
     * Doit renvoyer le nombre de secondes d'exécution acceptable avant que le gestionnaire de taches ne tue le processus
     * 0 si pas de limite
     * @return integer
     **/
    public function getMaxRunningTimeSec();
} 