<?php

namespace Oru\Bundle\ScheduleBundle\Event;

/**
 * Class ScheduleEvents
 *
 * @package Oru\Bundle\ScheduleBundle\Event
 * @author Michaël VEROUX
 */
class ScheduleEvents
{
    const KILL = 'schedule.kill';
}
