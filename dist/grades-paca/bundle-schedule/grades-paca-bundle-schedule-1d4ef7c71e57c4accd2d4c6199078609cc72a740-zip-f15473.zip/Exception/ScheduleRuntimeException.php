<?php

namespace Oru\Bundle\ScheduleBundle\Exception;

use RuntimeException;

/**
 * Class ScheduleRuntimeException.
 *
 * @author Michaël VEROUX
 */
class ScheduleRuntimeException extends RuntimeException
{
}
