<?php
/**
 * Created by PhpStorm.
 * User: ecervetti
 * Date: 06/12/13
 * Time: 14:36
 */

namespace Oru\Bundle\ScheduleBundle\Command;

use Oru\Bundle\ScheduleBundle\Entity\Task;
use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Oru\Bundle\ScheduleBundle\lib\CommandHandler;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Yaml\Yaml;

class CheckScheduleCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    private $tabNameActiveCredentials;

    /**
     * @var \Oru\Bundle\RorCredentialsBundle\OruRorCredentialsChecker
     */
    private $serviceCredentials;

    /**
     * @return \Doctrine\Common\Persistence\ObjectManager|object
     */
    public function getDoctrineManager()
    {
        return $this->getContainer()->get('doctrine')->getManager();
    }

    public function getMaxRunningTimeSec()
    {
        return 30;
    }

    /**
     * Renvoit un booleen signalant si la tache accepte d'être exécutée en parallèle avec d'autres taches issus de la même commande.
     *
     * @return bool
     */
    public function isConcurentAllowed()
    {
        return false;
    }

    /**
     * Renvoit, pour chaque nom d'argument, un type de champ (au sens form symfony) correspondant à la nature de l'argument.
     *
     * @param mixed $name
     *
     * @return mixed
     */
    public function getTypeFieldFromArgumentName($name, &$type = 'text', &$options = array())
    {
    }

    protected function configure()
    {
        $this
            ->setName('oru:schedule:check')
            ->setDescription('Installe les taches planifiées par defaut');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $text = 'Installation des taches planifiées par defaut [OK]';
        $query = $this->getDoctrineManager()->createQuery('DELETE FROM OruScheduleBundle:Task d WHERE d.autoInstalled = true ');
        $query->execute();

        foreach ($this->getContainer()->getParameter('kernel.bundles') as $nameBundle => $nameSpaceBundle) {
            $bundle = new $nameSpaceBundle();
            $shedulingConfigFileUrl = $bundle->getPath().'/Resources/config/scheduling.yml';

            try {
                if (file_exists($shedulingConfigFileUrl)) {
                    $yaml = Yaml::parse(file_get_contents($shedulingConfigFileUrl));
                    foreach ($yaml['scheduling'] as  $name => $yamlTask) {
                        $scriptNamespace = $yamlTask['commandNamespace'];
                        CommandHandler::getInstanceFromCommandNamespace($scriptNamespace, $this->getContainer());
                        $crontabTypeScheduling = $yamlTask['crontabTypeScheduling'];
                        if (isset($yamlTask['args'])) {
                            $args = $yamlTask['args'];
                        } else {
                            $args = '';
                        }
                        $task = new Task();
                        $task->setCommandNamespace($scriptNamespace);
                        $task->setCrontabTypeScheduling($crontabTypeScheduling);
                        $task->setArgs($args);
                        $task->setAutoInstalled(true);
                        $this->getDoctrineManager()->persist($task);
                        $this->getDoctrineManager()->flush();
                    }
                }
            } catch (\Exception $e) {
                throw new \Exception("Le fichier $shedulingConfigFileUrl ne contient pas ce qui est attendu. ({$e->getMessage()})");
            }
        }

        $output->writeln($text);
    }
}
