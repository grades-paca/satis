<?php

namespace Oru\Bundle\ScheduleBundle\Event;

/**
 * Class ScheduleEvents.
 *
 * @author Michaël VEROUX
 */
class ScheduleEvents
{
    const KILL = 'schedule.kill';
}
