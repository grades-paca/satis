<?php
/**
 * Created by PhpStorm.
 * User: ecervetti
 * Date: 12/02/14
 * Time: 14:30
 */

namespace Oru\Bundle\ScheduleBundle\lib;



use Oru\Bundle\ScheduleBundle\Entity\ProcessLog;
use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableDynamicTimeInterface;
use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableInterface;
use Oru\Bundle\ScheduleBundle\Exception\ScheduleRuntimeException;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\Finder\Finder;
use Symfony\Component\Form\Form;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Validator\Constraints\NotBlank;


class CommandHandler {

    const MAX_EXECUTION_TIME = 3600;

    private $command ;

    /**
     * @var File[]
     */
    private $tabCacheFiles ;

    /**
     * @var \Symfony\Component\DependencyInjection\Container
     */
    private $container ;

    public function __construct(Command $command,Container $container) {
        //$command->configure() ;

        if($command instanceof ContainerAwareCommand) {
            $command->setContainer($container);
        }

        $this->command = $command ;
        $this->container = $container ;
    }

    /**
     * @return \stdClass
     */
    public function getStorageObjectDefault() {
        $default = new \stdClass();
        foreach($this->getCommand()->getDefinition()->getArguments() as $argument) {
            $default->{'arg_'.$argument->getName()} = $argument->getDefault();
        }
        foreach($this->getCommand()->getDefinition()->getOptions() as $option) {
            $default->{'opt_'.$option->getName()} = $option->getDefault();
        }
        return $default ;
    }

    public function getCommandNamespaceCourt()
    {
        $tab = explode('\\',$this->getNamespaceCommand());
        return $tab[count($tab)-1];
    }


    /**
     *
     * @return Form
     */
    public function getSfForm() {

        $container = $this->container ;

        $formBuilder = $container->get('form.factory')->createBuilder('form', $this->getStorageObjectDefault(),['validation_groups' => false ]);

        foreach($this->getCommand()->getDefinition()->getArguments() as $argument) {
            $typeArg = 'text' ;
            $options = [] ;
            $this->getCommand()->getTypeFieldFromArgumentName($argument->getName(),$typeArg,$options);
            //http://symfony.com/fr/doc/current/reference/forms/types/choice.html

            $baseOptions = [
                'label' => $argument->getDescription(),
                'required' => $argument->isRequired(),
                'constraints' => []
            ];

            if($argument->isRequired())
                $baseOptions['constraints'][] = new NotBlank(); //ne marche pas :/

            $options = array_merge($baseOptions,$options);

            $formBuilder->add('arg_'.$argument->getName(),$typeArg,$options);
        }


        foreach($this->getCommand()->getDefinition()->getOptions() as $option) {
            $typeArg = 'text' ;
            $options = [] ;
            $this->getCommand()->getTypeFieldFromArgumentName($option->getName(),$typeArg,$options);
            $baseOptions = [
                'label' => $option->getDescription(),
                'required' => false,
                'constraints' => []
            ];
            $options = array_merge($baseOptions,$options);
            if (!$option->isValueRequired() &&  ! $option->isValueOptional()) {
                $typeArg = 'checkbox';
            }


            if($option->isValueRequired())
                $baseOptions['constraints'][] = new NotBlank(); //ne marche pas :/

            $formBuilder->add('opt_'.$option->getName(),$typeArg,$options);
        }
        return $formBuilder->getForm();
    }

    /**
     * Renvoie l'espace de stockage temporaire dédié à ce bundle
     * @return string
     */
    public function getDefaultCacheDirectory() {
        return self::getDefaultCacheDirectoryFromContainer($this->container) ;
    }

    static public function getDefaultCacheDirectoryFromContainer($container) {
        $dir = $container->getParameter("kernel.cache_dir").'/oruschedulable' ;
        if( ! file_exists($dir)) {
            mkdir($dir);
        }
        return $dir ;
    }


    /**
     * Valide les données du controller en fonction des parametres attendus dans la commande
     * N'arrivant pas à faire marcher l'option constraints dans le formulaire symfony, je valide manuellement...
     * @param $form
     */
    public function validateRequestExecution($request,Form $form) {

        $container = $this->container ;

        $validateMainFunc = function($argoption,$argOrOption) use ($request,$container,$form) {
            $index = $argOrOption.'_'.$argoption->getName() ;
            $typeArg = 'text' ;
            $this->getCommand()->getTypeFieldFromArgumentName($argoption->getName(),$typeArg);
            if($typeArg == 'file') {
                if( ! isset($form[$index]) || ! ($form[$index]->getData() instanceof UploadedFile) ) {
                    //var_dump($form[$index]->getData());
                    //throw new \Exception ("pas un type file");
                    return false ;
                }

                $file = $form[$index]->getData() ;
                $newFile = $file->move($this->getDefaultCacheDirectory(), $file->getClientOriginalName());
                $this->tabCacheFiles[$index] = $newFile ;
                //$form[$index]->setData($newFile);
                return true ;
            }
            $isRequired = ($argOrOption=='arg'?$argoption->isRequired():$argoption->isValueRequired());
            if($isRequired) {
                if( !isset($request->get('form')[$index]) || ! $request->get('form')[$index] ) {
                    return false ;
                }
            }
            return true ;
        };

        foreach($this->getCommand()->getDefinition()->getArguments() as $argument) {
            if( ! $validateMainFunc($argument,'arg') )
                return false ;
        }
        foreach($this->getCommand()->getDefinition()->getOptions() as $option) {
            if( ! $validateMainFunc($option,'opt') )
                return false ;
        }

        return true ;
    }

    /**
     * Génere la commande complète
     * @param Form $form
     */
    public function getFullCommandLineArgumentsFromForm(Form $form) {
        $strCommand = "" ;

        $toString = function($o) {
            if(is_object($o) && method_exists($o,'__toString')) return $o->__toString();
            if( $o instanceof \DateTime ) return $o->format('Y-m-d H:i');
            return $o ;
        };

        $traitement = function($name,$argOrOpt,& $value) use ($toString) {
            $typeArg = 'text' ;
            $this->getCommand()->getTypeFieldFromArgumentName($name,$typeArg);
            if($typeArg=='file') {
                $value = $this->tabCacheFiles[$argOrOpt.'_'.$name]->getRealPath();
            } else {
                $value = $toString($value) ;
            }
        };
        foreach($form->getData() as $name => $value ) {
            $tabReg = [] ;
            if(preg_match('/^arg_(.*)/',$name,$tabReg) && $value) {
                $originalname =  $tabReg[1] ;
                $traitement($originalname,'arg',$value);
                $strCommand.=" \"$value\" " ;
            }
        }
        foreach($form->getData() as $name => $value ) {
            $tabReg = [] ;
            if(preg_match('/^opt_(.*)$/',$name,$tabReg) && $value) {
                $originalname =  $tabReg[1] ;
                $option = $this->getCommand()->getDefinition()->getOption($originalname);
                $traitement($originalname,'opt',$value);

                if (!$option->isValueOptional() && !$option->isValueOptional()) {
                    $strCommand .= " --$originalname ";
                } else {
                    $strCommand.=" --$originalname=\"$value\" " ;
                }

            }
        }
        return $strCommand ;
    }

    public function isCurrentlyRunning() {
        return count(
            $this->container->get("doctrine")->getRepository("OruScheduleBundle:ProcessLog")
                ->getCurrentRunningProcessesFromCommandNamespace($this->getNamespaceCommand())
        );
    }


    /**
     * @return Command
     */
    public function getCommand() {
        return $this->command ;
    }

    public function getNamespaceCommand() {
        return get_class($this->getCommand());
    }

    /**
     * @param Container $container
     * @return CommandHandler[]
     */
    static public function getAllCommandHandlersFromContainer(Container $container) {

        $tabReturn = [] ;
        foreach($container->getParameter('kernel.bundles') as $nameBundle => $nameSpaceBundle ) {
            $bundle = new $nameSpaceBundle ;
            $path = $bundle->getPath().'/Command' ;
            if( ! file_exists($path))
                continue ;
            foreach( Finder::create()->files()->in($path)->depth(0)->name('*Command.php') as $file ) {
                $commandClassName = $bundle->getNamespace().'\\Command\\'.$file->getBasename('.php');
                $reflexion = new \ReflectionClass($commandClassName);
                if( $reflexion->implementsInterface('Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableInterface') ) {
                    if ($reflexion->isInstantiable()) {
                        $tabReturn[] = new CommandHandler($reflexion->newInstance(),$container);
                    }
                }
            }
        }
        return $tabReturn ;
    }

    /**
     * Renvoie un handler de commande étant donné le namespace de la commande
     *
     * @param string    $strCommandNamespace
     * @param Container $container
     *
     * @return CommandHandler
     */
    static public function getInstanceFromCommandNamespace( $strCommandNamespace,Container $container)
    {
        try {
            $reflection = new \ReflectionClass($strCommandNamespace);
        } catch (\ReflectionException $e) {
            $msg = sprintf('La classe "%" n\'existe pas. (Bug YAML qui nécessite d\'échapper certains caracteres ? )', $strCommandNamespace);
            throw new ScheduleRuntimeException($msg);
        }
        /** @var Command $command */
        $command = $reflection->newInstance();

        if (!$command instanceof OruSchedulableInterface) {
            $msg = sprintf('La classe "%s" n\'implémente pas OruSchedulableInterface', $strCommandNamespace);
            throw new ScheduleRuntimeException($msg);
        }

        $handler = new CommandHandler($command, $container);

        return $handler ;
    }

    /**
     * Lance l'exécution du script dans un processus forké
     * @param $strArgs
     */
    public function forkExecute($strArgs, & $strMessageRetour ='' ) {
        //Tout d'abord on vérifie qu'il n'y a pas de verrou actuellement actif
        if(! $this->getCommand()->isConcurentAllowed() && $this->isCurrentlyRunning()) {
            $strMessageRetour = "Le processus est déjà en cours d'exécution, et la commande n'autorise pas d'exécution simultanée.";
            return false ;
        }

        $now = RorDatetime::getNow();

        foreach($this->container->get('doctrine')->getRepository("OruScheduleBundle:ProcessLog")->getCurrentRunningProcesses() as $runningProcess ) {
            try {
                if( /*$runningProcess->isZombie() || */ $runningProcess->isOutOfTime($this->container,$now) ) {
                    //echo "\nLe process {$runningProcess->getPid()} a dépassé sa durée d'exécution, on le kill";
                    $runningProcess->kill();
                    $this->container->get('doctrine')->getManager()->persist($runningProcess);
                    $this->container->get('doctrine')->getManager()->flush();
                }
            }catch (\Exception $e) {
                continue ;
            }
        }

        //Génération d'un unique id pour commencer, car on ne sait pas encore quel va être le PID
        $privateProcessId = uniqid();
        $container = $this->container ;

        $cacheBash = $container->get('oru_schedule.cache_bash_manager');
        $cacheBash->setId(array($privateProcessId));
        $consoleExe = sprintf('%s/console', $container->get('kernel')->getRootDir());
        $commandName = $this->getCommand()->getName();
        $env = sprintf('--env=%s', $container->get('kernel')->getEnvironment());
        $args = array($strArgs);
        if ($this->getCommand() instanceof OruSchedulableDynamicTimeInterface) {
            $args[] = sprintf('--localId=%s', $privateProcessId);
        }
        $args[] = $env;

        $commandCache = array();
        $commandCache[] = sprintf(
            'nice php %s %s %s > %s 2>&1',
            $consoleExe,
            $commandName,
            implode(' ', $args),
            $cacheBash->getPath()
        );

        $argsUpdate = array($privateProcessId, $env);
        $commandCache[] = sprintf(
            'php %s oru:schedule:update %s',
            $consoleExe,
            implode(' ', $argsUpdate)
        );

        $cacheBash->setId(array($privateProcessId, 'sh'));
        $cacheBash->write($commandCache);

        $cacheString = $container->get('oru_schedule.cache_string_manager');
        $cacheString->setId(array($privateProcessId, 'pid'));

        $execCommand = sprintf('/bin/bash %s > /dev/null 2>&1 & echo $! & ', $cacheBash->getPath());
        exec($execCommand ,$op);
        $pid = (int)$op[0];

        $cacheString->write((string)$pid);

        $process = new ProcessLog();
        $process->setCommandNamespace('a');
        $process->setCommandNamespace($this->getNamespaceCommand());
        $process->setArgs($strArgs);
        $process->setStartDatetime(RorDatetime::getNow());
        $process->setPid($pid);
        $process->setDone(0);
        $container->get('doctrine')->getManager()->persist($process);
        $container->get('doctrine')->getManager()->flush();

        return true ;
    }


    static public function cron(Container $container)
    {
        $now = RorDatetime::getNow();
        foreach($container->get('doctrine')->getRepository("OruScheduleBundle:Task")->findAll() as $task ) {
            if( ! $task->getPaused() && $task->isLaunchableAtRorDatetime($now)) {
                try {
                    $commandHandler = CommandHandler::getInstanceFromCommandNamespace($task->getCommandNamespace(),$container);
                    $commandHandler->forkExecute($task->getArgs());
                }catch (\Exception $e) {
                    $container->get('doctrine')->getManager()->remove($task);
                    $container->get('doctrine')->getManager()->flush();
                }
            }
        }
    }
}
