<?php

namespace Oru\Bundle\ScheduleBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

use Oru\Bundle\ScheduleBundle\lib\RorDatetime;

/**
 * Task
 */
class Task
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $commandNamespace;

    /**
     * @var string
     */
    private $crontabTypeScheduling;

    /**
     * @var string
     */
    private $args;


    /**
     * @var bool
     */

    private $autoInstalled ;



    /**
     * @return boolean
     */
    public function isAutoInstalled()
    {
        return $this->autoInstalled;
    }

    /**
     * @param boolean $autoInstalled
     */
    public function setAutoInstalled($autoInstalled)
    {
        $this->autoInstalled = $autoInstalled;
    }


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set scriptNamespace
     *
     * @param string $scriptNamespace
     * @return Task
     */
    public function setCommandNamespace($scriptNamespace)
    {
        $this->commandNamespace = $scriptNamespace;
    
        return $this;
    }

    /**
     * Get scriptNamespace
     *
     * @return string 
     */
    public function getCommandNamespace()
    {
        return $this->commandNamespace;
    }

    /**
     * Set crontabTypeScheduling
     *
     * @param string $crontabTypeScheduling
     * @return Task
     */
    public function setCrontabTypeScheduling($crontabTypeScheduling)
    {
        $this->crontabTypeScheduling = $crontabTypeScheduling;
    
        return $this;
    }

    /**
     * Get crontabTypeScheduling
     *
     * @return string 
     */
    public function getCrontabTypeScheduling()
    {
        return $this->crontabTypeScheduling;
    }

    /**
     * Set jsonArgs
     *
     * @param string $args
     * @return Task
     */
    public function setArgs($args)
    {
        $this->args = $args;
    
        return $this;
    }

    /**
     * Get jsonArgs
     *
     * @return string 
     */
    public function getArgs()
    {
        return $this->args;
    }




    public function isLaunchableAtRorDatetime(RorDatetime $rdatetime) {
        if($rdatetime->isCronLaunchable($this->getCrontabTypeScheduling())) {
            return true ;
        }
        return false ;
    }

    /**
     * @var boolean
     */
    private $paused;


    /**
     * Get autoInstalled
     *
     * @return boolean
     */
    public function getAutoInstalled()
    {
        return $this->autoInstalled;
    }

    /**
     * Set paused
     *
     * @param boolean $paused
     *
     * @return Task
     */
    public function setPaused($paused)
    {
        $this->paused = $paused;

        return $this;
    }

    /**
     * Get paused
     *
     * @return boolean
     */
    public function getPaused()
    {
        return $this->paused;
    }
}
