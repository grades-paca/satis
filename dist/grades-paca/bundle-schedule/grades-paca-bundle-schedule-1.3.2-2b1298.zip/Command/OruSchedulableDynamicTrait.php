<?php

namespace Oru\Bundle\ScheduleBundle\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputOption;

/**
 * Trait OruSchedulableDynamicTrait
 *
 * @package Oru\Bundle\ScheduleBundle\Command
 * @author Michaël VEROUX
 */
trait OruSchedulableDynamicTrait
{
    /**
     * @return void
     * @author Michaël VEROUX
     */
    public function addLocalIdOption()
    {
        if ($this instanceof Command) {
            try {
                $this->addOption(
                    'localId',
                    null,
                    InputOption::VALUE_REQUIRED,
                    'Local ID of process'
                );
            } catch (\LogicException $e) {
                // Option already defined, nothing to do!
            }
        }
    }
}
