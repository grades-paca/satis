<?php

namespace Oru\Bundle\ScheduleBundle\Interfaces;

/**
 * Interface OruSchedulableDynamicTimeInterface
 *
 * @package Oru\Bundle\ScheduleBundle\Interfaces
 * @author Michaël VEROUX
 */
interface OruSchedulableDynamicTimeInterface extends OruSchedulableInterface
{
    /**
     * Doit renvoyer le nombre de secondes d'exécution acceptable avant que le gestionnaire de taches ne tue le processus
     * 0 si pas de limite
     * @param int $pid
     *
     * @return integer
     **/
    public function getMaxRunningTime($pid);

    /**
     * Important: use trait Oru\Bundle\ScheduleBundle\Command\OruSchedulableDynamicTrait to implement this method!
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function addLocalIdOption();
}
