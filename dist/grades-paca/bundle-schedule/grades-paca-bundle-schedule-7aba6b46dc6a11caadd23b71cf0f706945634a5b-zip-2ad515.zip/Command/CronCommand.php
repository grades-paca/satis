<?php
/**
 * Created by PhpStorm.
 * User: ecervetti
 * Date: 06/12/13
 * Time: 14:36
 */

namespace Oru\Bundle\ScheduleBundle\Command;

use Oru\Bundle\ScheduleBundle\lib\CommandHandler;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class CronCommand extends ContainerAwareCommand
{
    public function configure()
    {
        $this
            ->setName('oru:schedule:cron')
            ->setDescription('Ce script doit être appellé chaque minute, il va gérer toutes les planifications de taches');
    }

    public function execute(InputInterface $input, OutputInterface $output)
    {
        CommandHandler::cron($this->getContainer());
    }
}
