<?php
/**
 * Created by PhpStorm.
 * User: ecervetti
 * Date: 06/12/13
 * Time: 14:36
 */

namespace Oru\Bundle\ScheduleBundle\Command;

use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Oru\Bundle\ScheduleBundle\lib\CommandHandler;
use Oru\Bundle\ScheduleBundle\lib\RorDatetime;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class CleanCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    public function configure()
    {
        $this
            ->setName('oru:schedule:clean')
            ->setDescription('Nettoyage des données relatives au planificateur de taches');
    }

    public function execute(InputInterface $input, OutputInterface $output)
    {
        //On nettoie les fichiers en cache plus vieux de 1 jours
        self::nettoieRep(CommandHandler::getDefaultCacheDirectoryFromContainer($this->getContainer()), '.*', 1);

        //On vire les logs d'exécution plus vieux de 10 jours
        $this->getContainer()->get('doctrine')->getRepository('OruScheduleBundle:ProcessLog')->deleteOlderThen(RorDatetime::getNow()->addDay(-10));
    }

    public function getMaxRunningTimeSec()
    {
        return 0;
    }

    public function isConcurentAllowed()
    {
        return false;
    }

    public function getTypeFieldFromArgumentName($name, &$type = TextType::class, &$options = array())
    {
    }

    public static function nettoieRep($rep, $type, $dureejours)
    {
        $duree = $dureejours * 24;
        $r = opendir($rep);
        while ($fic = readdir($r)) {
            if ($fic !== '.' and $fic !== '..') {
                $date = filemtime("$rep/$fic");
                if (preg_match('@'.$type.'$@', $fic) && $date < (time() - ($duree * 3600)) && !is_dir("$rep/$fic") && is_file("$rep/$fic")) {
                    unlink("$rep/$fic");
                }
            }
        }
        closedir($r);
    }
}
