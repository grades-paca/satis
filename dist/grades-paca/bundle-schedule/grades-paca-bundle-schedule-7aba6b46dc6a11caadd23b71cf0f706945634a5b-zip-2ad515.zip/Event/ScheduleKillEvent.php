<?php

namespace Oru\Bundle\ScheduleBundle\Event;

use Symfony\Component\EventDispatcher\Event;

/**
 * Class ScheduleKillEvent.
 *
 * @author Michaël VEROUX
 */
class ScheduleKillEvent extends Event
{
    /**
     * @var string|int
     */
    private $pid;

    /**
     * ScheduleKillEvent constructor.
     *
     * @param int|string $pid
     */
    public function __construct($pid)
    {
        $this->pid = $pid;
    }

    /**
     * @return int|string
     */
    public function getPid()
    {
        return $this->pid;
    }

    /**
     * @param int|string $pid
     *
     * @return $this
     */
    public function setPid($pid)
    {
        $this->pid = $pid;

        return $this;
    }
}
