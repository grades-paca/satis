<?php
/**
 * Created by PhpStorm.
 * User: Thierry de Préaumont
 * Date: 28/12/2017
 */

namespace Oru\Bundle\AddressBundle\Form\Type;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\AddressBundle\Form\DataTransformer\ZoneGeographiqueTreeTransformer;
use Oru\Bundle\FormBundle\Form\Type\AutocompleteType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormView;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\FormBuilderInterface;

class ZoneGeographiqueSearchAutocompleteType extends AutocompleteType {

    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefined(array('field_type', 'field'));
        $resolver->setDefaults(array('class' => 'OruAddress:ZoneGeographique'));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);
        $view->vars['field'] = (isset($options['field'])) ? $options['field'] : null ;
        $view->vars['field_type'] = (isset($options['field_type'])) ? $options['field_type'] : null;
    }

    public function getName()
    {
        return 'oru_zone_geographique_search_autocomplete';
    }
}