<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 09/07/2015
 * Time: 11:25
 */

namespace Oru\Bundle\AddressBundle\Form\Type;

use Oru\Bundle\FormBundle\Form\Type\AutocompleteType;
use Oru\Bundle\AddressBundle\Entity\LstCommune;
use Oru\Bundle\AddressBundle\Form\LstCommuneType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class LstCommuneAutocompleteType
 * @package Oru\Bundle\AddressBundle\Form\Type
 */
class LstCommuneAutocompleteType extends  AutocompleteType{
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array('class' => 'OruAddressBundle:LstCommune', 'placeholder' => 'Chercher une commune', 'create' => false));
        $resolver->setDefined(array('fillCodePostal', 'fillCommune', 'fillDepartement'));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        $view->vars['create'] = $options['create'];

        if(array_key_exists('fillCodePostal', $options)){
            $view->vars['fillCodePostal'] = $options['fillCodePostal'];
        }

        if(array_key_exists('fillCommune', $options)){
            $view->vars['fillCommune'] = $options['fillCommune'];
        }

        if(array_key_exists('fillDepartement', $options)){
            $view->vars['fillDepartement'] = $options['fillDepartement'];
        }
    }

    public function getName()
    {
        return 'oru_lstcommune_autocomplete';
    }
} 