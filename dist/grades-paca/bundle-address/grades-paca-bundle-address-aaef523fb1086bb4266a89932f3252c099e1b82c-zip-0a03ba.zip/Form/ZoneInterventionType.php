<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 07/10/2016
 * Time: 09:56
 */

namespace Oru\Bundle\AddressBundle\Form;

use Oru\Bundle\AddressBundle\Form\Type\ZoneGeographiqueTreeType;
use Oru\Bundle\FormBundle\Form\Type\StaticType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ZoneInterventionType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);
        $builder
            ->add('nom', $options['readonly'] ? StaticType::class : null, array(
                'label' => 'zoneIntervention.nom',
                'translation_domain' => 'OruAddressBundle',
            ))
            ->add('description', $options['readonly'] ? StaticType::class : null, array(
                'label' => 'zoneIntervention.description',
                'translation_domain' => 'OruAddressBundle',
            ))
            ->add('zoneGeographique', ZoneGeographiqueTreeType::class, array(
                'label' => 'zoneIntervention.zoneGeographique',
                'translation_domain' => 'OruAddressBundle',
                'readonly' => $options['readonly'],
            ))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\AddressBundle\Entity\ZoneIntervention',
            'translation_domain' => 'OruAddressBundle',
            'required' => false,
            'readonly' => false,
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_addressbundle_zone_intervention';
    }
}
