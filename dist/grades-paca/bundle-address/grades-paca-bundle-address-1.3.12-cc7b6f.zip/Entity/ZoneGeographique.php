<?php

namespace Oru\Bundle\AddressBundle\Entity;

/**
 * ZoneGeographique
 */
class ZoneGeographique
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var \DateTime
     */
    private $created;

    /**
     * @var \DateTime
     */
    private $updated;

    /**
     * @var LstRegion
     */
    private $regions;

    /**
     * @var LstDepartement
     */
    private $departements;

    /**
     * @var LstCommune
     */
    private $communes;

    /**
     * @var LstQuartierIris
     */
    private $quartiers;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return LstCommune
     */
    public function getCommunes()
    {
        return $this->communes;
    }

    /**
     * @param LstCommune $communes
     */
    public function setCommunes($communes)
    {
        $this->communes = $communes;
    }

    /**
     * @return LstDepartement
     */
    public function getDepartements()
    {
        return $this->departements;
    }

    /**
     * @param LstDepartement $departements
     */
    public function setDepartements($departements)
    {
        $this->departements = $departements;
    }

    /**
     * @return LstRegion
     */
    public function getRegions()
    {
        return $this->regions;
    }

    /**
     * @param LstRegion $regions
     */
    public function setRegions($regions)
    {
        $this->regions = $regions;
    }

    /**
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param \DateTime $created
     */
    public function setCreated($created)
    {
        $this->created = $created;
    }

    /**
     * @return \DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * @param \DateTime $updated
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;
    }

    /**
     * @return LstQuartierIris
     */
    public function getQuartiers()
    {
        return $this->quartiers;
    }

    /**
     * @param LstQuartierIris $quartiers
     */
    public function setQuartiers($quartiers)
    {
        $this->quartiers = $quartiers;
    }

    /**
     * Vide la sélection de lieux
     */
    public function clear(){
        $this->regions = [];
        $this->departements = [];
        $this->communes = [];
        $this->quartiers = [];
    }
}

