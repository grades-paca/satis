<?php

namespace Oru\Bundle\AddressBundle\Import;

use Doctrine\Common\Inflector\Inflector;
use Doctrine\Common\Persistence\Mapping\MappingException;
use Oru\Bundle\AddressBundle\Entity\Address;
use Oru\Bundle\CoreImportBundle\Events\FilterImportUndefinedEvent;
use Oru\Bundle\CoreImportBundle\Exception\NotFoundException;
use Oru\Bundle\CoreImportBundle\Exception\UndefinedException;

/**
 * Class AddressImport
 *
 * @package Oru\Bundle\AddressBundle\Import
 * @author Michaël VEROUX
 */
class AddressImport
{
    /**
     * @param FilterImportUndefinedEvent $event
     * @param Address                    $address
     *
     * @return bool
     * @throws NotFoundException
     * @throws UndefinedException
     * @author Michaël VEROUX
     */
    public function eventProceed(FilterImportUndefinedEvent $event, Address $address)
    {
        $match = $this->isAddress($event);
        if (!$match) {
            return false;
        }

        if (preg_match('#^(.+)_(libelle|code)$#', $match[1], $submatch)) {
            $setter = $this->getSetterFromKey($submatch[1]);
            if (method_exists($address, $setter)) {
                $reflMethod = new \ReflectionMethod($address, $setter);
                $parameters = $reflMethod->getParameters();
                if (count($parameters) && null !== $parameters[0]->getClass()) {
                    $class = $parameters[0]->getClass()->getName();
                    if (!is_subclass_of($class, 'Oru\Bundle\LstBundle\Entity\Lst')) {
                        return false;
                    }

                    try {
                        if (null == $event->getValue()) {
                            $address->$setter(null);

                            $event->setProcessed();

                            return true;
                        }

                        $linkedEntity = $event->getImportFactory()->getEntityManager()->getRepository($class)
                            ->findOneBy(array(
                                            $submatch[2] => $event->getValue(),
                                        ));

                        if (isset($linkedEntity) && $linkedEntity) {
                            $address->$setter($linkedEntity);

                            $event->setProcessed();

                            return true;
                        } else {
                            $e = new NotFoundException(
                                sprintf(
                                    '%s::%s(%s), entity not found!',
                                    get_class($address),
                                    $setter,
                                    $event->getValue()
                                ),
                                sprintf('%s : "%s", l\'élément lié n\'a pas été trouvé !', $event->getKey(), $event->getValue())
                            );
                            $e->setName((string) $event->getImport()->getEntity());

                            throw $e;
                        }
                    } catch (MappingException $e) {
                    }
                }
            } else {
                $e = new UndefinedException(
                    sprintf(
                        'Call to undefined method %s on %s',
                        $setter,
                        get_class($address)
                    ),
                    sprintf('L\'application ne sait pas importer le champ "%s"', $event->getKey())
                );
                $e->setName((string) $event->getImport()->getEntity());

                throw $e;
            }
        } else {
            $setter = $this->getSetterFromKey($match[1]);
            if (method_exists($address, $setter)) {
                $address->$setter($event->getValue());

                $event->setProcessed();

                return true;
            } else {
                $e = new UndefinedException(
                    sprintf(
                        'Call to undefined method %s on %s',
                        $setter,
                        get_class($address)
                    ),
                    sprintf('L\'application ne sait pas importer le champ "%s"', $event->getKey())
                );
                $e->setName((string) $event->getImport()->getEntity());

                throw $e;
            }
        }

        return false;
    }

    /**
     * @param FilterImportUndefinedEvent $event
     *
     * @return array|bool
     * @author Michaël VEROUX
     */
    public function isAddress(FilterImportUndefinedEvent $event)
    {
        $match = array();
        if (!preg_match('#^adresse_(.+)$#', $event->getKey(), $match)) {
            return false;
        }

        return $match;
    }

    /**
     * @param string $key
     *
     * @return string
     * @author Michaël VEROUX
     */
    protected function getSetterFromKey($key)
    {
        return sprintf('set%s', ucfirst(Inflector::camelize($key)));
    }
}
