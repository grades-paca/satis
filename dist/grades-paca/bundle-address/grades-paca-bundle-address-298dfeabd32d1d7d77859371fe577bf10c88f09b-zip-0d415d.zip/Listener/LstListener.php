<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\AddressBundle\Lst;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\AddressBundle\Entity\Address;
use Oru\Bundle\LstBundle\Entity\Lst;
use Oru\Bundle\LstBundle\Manager\EntityMigrationManager;
use Oru\Bundle\SynchroBundle\Event\LstMigrationEvent;

/**
 * Class LstListener permettant de migrer les éléments de listes archivés
 * @package Oru\Bundle\AddressBundle\Lst
 */
class LstListener
{
    /**
     * @var EntityManager
     */
    private $em;

    /**
     * @param EntityManager $em
     */
    public function setEm($em)
    {
        $this->em = $em;
    }

    /**
     * @param LstMigrationEvent $event
     * Migre les donneés des Listes suite à la réception d'un event
     */
    public function onLstEvent($event)
    {
        if($event->getLst() instanceof Lst){
            $classes[] = new Address();

            EntityMigrationManager::migrateEntityLstAssociation($event, $classes, $this->em);
        }
    }
}