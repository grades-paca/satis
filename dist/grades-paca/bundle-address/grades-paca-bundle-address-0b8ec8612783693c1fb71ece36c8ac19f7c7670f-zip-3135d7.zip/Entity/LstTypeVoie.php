<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use APY\DataGridBundle\Grid\Mapping as GRID;

/**
 * LstTypeVoie
 */
class LstTypeVoie extends Lst
{
}