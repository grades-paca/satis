<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use JMS\Serializer\Annotation;
use APY\DataGridBundle\Grid\Mapping as GRID;

/**
 * LstQuartierIris
 * @GRID\Source(columns="id, code, libelle, oid, codeAsip")
 * @Annotation\ExclusionPolicy("all")
 */
class LstQuartierIris extends Lst
{
    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstCommune
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $iris;

    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstCommune
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $typeIris;

    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstCommune
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $commune;

    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_quartiers","webservice"})
     */
    protected $id;

    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_quartiers","webservice"})
     */
    protected $libelle;

    /**
     * @return mixed
     */
    public function getCommune()
    {
        return $this->commune;
    }

    /**
     * @param mixed $commune
     */
    public function setCommune($commune)
    {
        $this->commune = $commune;
    }
    private $origine;

    /**
     * @return mixed
     */
    public function getIris()
    {
        return $this->iris;
    }

    /**
     * @param mixed $iris
     */
    public function setIris($iris)
    {
        $this->iris = $iris;
    }

    /**
     * @return mixed
     */
    public function getOrigine()
    {
        return $this->origine;
    }

    /**
     * @param mixed $origine
     */
    public function setOrigine($origine)
    {
        $this->origine = $origine;
    }

    /**
     * @return mixed
     */
    public function getTypeIris()
    {
        return $this->typeIris;
    }

    /**
     * @param mixed $typeIris
     */
    public function setTypeIris($typeIris)
    {
        $this->typeIris = $typeIris;
    }
}
