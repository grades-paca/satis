<?php
/**
 * Created by PhpStorm.
 * User: TDEPREAUMONT
 * Date: 04/12/2017
 * Time: 13:25
 */

namespace Oru\Bundle\AddressBundle\Controller;

use Doctrine\ORM\Query\ResultSetMapping;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

class ZoneGeographiqueController extends Controller
{
    /**
     * @param Request $request
     * @param $_format
     * @return JsonResponse
     * @throws ParameterNotFoundException
     */
    public function searchLstZoneGeographiqueAction(Request $request)
    {
        $entities = array();
        $search = $request->get('search');
        if ($request->get('search') == '') {
            throw new ParameterNotFoundException("Parameter 'search' not found.");
        }

        $page_limit = $request->get('page_limit', 10);
        if (!is_numeric($page_limit) || $page_limit > 100) {
            $page_limit = 10;
        }

        $first = $total = 0;
        if ($request->get('first')) {
            $first = $request->get('first');
        }

        $entities = $this->getDoctrine()->getRepository('OruAddressBundle:ZoneGeographique')->searchByLibelle($search, $page_limit, $first);
        if ($request->get('infinite_scroll') and ((int)$first === 0 and (count($entities) >= $page_limit))) {
            $total = $this->getDoctrine()->getRepository('OruAddressBundle:ZoneGeographique')->countByLibelle($search);
        } else {
            $total = count($entities);
        }

        return new JsonResponse(array('total' => (int)$total, 'entities' => $entities));
    }
}