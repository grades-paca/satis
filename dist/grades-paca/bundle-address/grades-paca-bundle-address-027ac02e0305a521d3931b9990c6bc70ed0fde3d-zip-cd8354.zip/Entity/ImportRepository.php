<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 10/07/2015
 * Time: 10:38
 */

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\EntityRepository;
use Oru\Bundle\LstBundle\Entity\LstRepository;

class ImportRepository extends LstRepository {
    public function findLastImportByFile($fileName){
       return $this->createQueryBuilder('i')->where('i.fileName = :filename')->setParameter('filename', $fileName)->orderBy('i.createdAt', 'DESC')->setMaxResults(1)->getQuery()->getOneOrNullResult();
    }
} 