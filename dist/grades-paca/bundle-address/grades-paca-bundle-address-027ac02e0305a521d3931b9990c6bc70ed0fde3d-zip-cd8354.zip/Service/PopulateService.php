<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 24/06/2015
 * Time: 15:51
 */

namespace Oru\Bundle\AddressBundle\Service;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\AddressBundle\Entity\LstCodePostal;
use Oru\Bundle\SpoolBundle\Spool\UnstackInterface;

class PopulateService implements UnstackInterface {

    /**
     * @var EntityManager
     */
    protected $em;

    protected $emCarto;

    public function __construct($em ,$emCarto)
    {
        $this->em = $em;
        $this->emCarto = $emCarto;
    }

    private function replaceQuotes($str){
        return str_replace("'", "''", $str) ;
    }

    private function showProgress($i, $label, $modulo){
        if($i % $modulo == 0){
            echo $i." ".$label." \n";
        }
    }

    private function showTotalLines($i) {
        echo "Total : " . $i . " lignes insérées \n";
    }

    public function importCommunes ($filePath, $cartoEnabled = false){

        $f = fopen($filePath,'rb');

        $depts = array();
        $departements = $this->em->getRepository('OruAddressBundle:LstDepartement')->findAll();
        $errors = array();

        foreach($departements as $d){

            $code = $d->getCode();

            if(strpos($code,'0')!== false && strpos($code,'0') == 0)
                $code = substr($code,1,1);

            $depts[$code] = $d->getId();
        }

        $conn = $this->em->getConnection();
        $i = 0; $class=  $this->em->getClassMetadata('OruAddressBundle:LstCommune')->getTableName();
        $batch = "";


        if($cartoEnabled){
            $connC =  $this->emCarto->getConnection();
            $batchC = "";
            $sql = "DELETE FROM lst_commune_geo";
            $connC->query($sql);
        }

        while($line = fgetcsv($f,1024000,';')) {
            if ($line[0] != 'the_geom') {

                if($cartoEnabled){
                    $sqlC = " INSERT INTO lst_commune_geo";
                    $sqlC .= " (the_geom,id_geofla, code_com, insee_com, nom_com, statut, x_chf_lieu, y_chf_lieu, x_centroid, y_centroid, z_moyen, superficie, population, code_cant, code_arr, code_dept, nom_dept, code_reg, nom_reg) ";
                    $sqlC .= " VALUES('".$line[0]."','".$line[1]."','".$line[2]."','".$line[3]."','".$this->replaceQuotes($line[4])."','".$this->replaceQuotes($line[5])."','".$line[6]."',";
                    $sqlC .= "'".$line[7]."','".$line[10]."','".$line[11]."','".$line[14]."','".$line[15]."','".$line[16]."',";
                    $sqlC .= "'".$line[17]."','".$line[18]."','".$line[19]."','".$this->replaceQuotes($line[20])."','".$line[21]."','".$this->replaceQuotes($line[22])."'); ";
                    $batchC .= $sqlC;
                }

                if(array_key_exists($line[19], $depts)) {
                    $sql = " INSERT IGNORE INTO " . $class;
                    $sql .= "(departement_id,code,libelle,statut,x_chef_lieu, y_chef_lieu, long_chef_lieu, lat_chef_lieu,x_centroid,y_centroid, long_centroid, lat_centroid, z_moyen, superficie, population, code_cant, code_arr, created, updated)";
                    $sql .= "VALUES('" . $depts[$line[19]] . "','" . $line[3] . "','" . $this->replaceQuotes($line[4]) . "','" . $this->replaceQuotes($line[5]) . "','" . $line[6] . "','" . $line[7] . "','" . $line[8] . "','" . $line[9] . "','" . $line[10] . "','" . $line[11] . "','" . $line[12] . "','" . $line[13] . "','" . $line[14] . "','" . $line[15] . "','" . $line[16] . "','" . $line[17] . "','" . $line[18] . "', NOW(), NOW()); ";
                    $batch .= $sql;
                }else{
                    array_push($errors, array('code' => $line[3], 'libelle' => $this->replaceQuotes($line[4]), 'code_dept' => $line[19]));
                }

                if($i % 100 == 0){

                    $conn->exec('BEGIN; '.$batch.' COMMIT;');
                    if($cartoEnabled) {
                        $connC->exec('BEGIN; ' . $batchC . ' COMMIT;');
                        $batchC = "";
                    }
                    $batch = "";
                }

                $i++;
                $this->showProgress($i, "lignes traitées", 2500);
            }
        }

        if($batch != "")
            $conn->exec('BEGIN; '.$batch.' COMMIT;');
        if($cartoEnabled AND $batchC != "")
            $connC->exec('BEGIN; '.$batchC.' COMMIT;');

        $this->showTotalLines($i);
        if(count($errors)){
            echo count($errors). " erreurs => codes département non trouvés dans la base de données, les communes suivantes n'ont pas été insérées : \n\n";
            foreach($errors as $error){
                echo "- Commune : ".$error['code'].", libellé : ".$error['libelle'].", code département (introuvable) : ".$error['code_dept']. "\n";
            }
        }

        fclose($f);
        $conn->close();
    }

    public function importCodesPostaux($filePath){
        $f = fopen($filePath,'rb');

        $errors = array();
        $coms = array();
        $communes = $this->em->getRepository('OruAddressBundle:LstCommune')->findAll();

        foreach($communes as $c){
            $coms[$c->getCode()] = $c->getId();
        }

        $conn = $this->em->getConnection();
        $i = 0;
        $batch = "";

        while($line = fgetcsv($f,1024,';')) {
            if ($line[0] != 'code postal') {

                if(array_key_exists($line[0], $coms)){

                    //Code unique
                    $codeUnique = $line[0].$line[2];

                    //Préparation données géolocalisation
                    $lat = null;
                    $lng = null;

                    $coords = explode(",", $line[5]);
                    if(count($coords) == 2){
                        $lat = floatval($coords[0]);
                        $lng = floatval($coords[1]);
                    }

                    //Insertion
                    $sql = " INSERT IGNORE INTO " . $this->em->getClassMetadata('OruAddressBundle:LstCodePostal')->getTableName();
                    $sql .= "(commune_id,code,libelle, libelle_acheminement, lat, lng, created, updated)";
                    $sql .= "VALUES('" . $coms[$line[0]] . "',".$codeUnique.",'" . $line[2] . "','" . $this->replaceQuotes($line[1]) . "','".$lat."','".$lng."', NOW(), NOW()); ";
                    $batch .= $sql;
                }else{
                    array_push($errors, array('code' => $line[2], 'libelle' => $line[1], 'code_com' => $line[0]));
                }

                if($i % 100 == 0){
                    $conn->exec('BEGIN; '.$batch.' COMMIT;');
                    $batch = "";
                }

                $i++;
                $this->showProgress($i, "lignes traitées", 5000);
            }
        }


        if($batch != "")
            $conn->exec('BEGIN; '.$batch.' COMMIT;');
        $this->showTotalLines($i);

        if(count($errors)){
            echo count($errors). " erreurs => codes communes non trouvés dans la base de données, les codes postaux suivants n'ont pas été insérés : \n\n";
            foreach($errors as $error){
                echo "- Code postal : ".$error['code'].", libellé : ".$error['libelle'].", code commune (introuvable) : ".$error['code_com']. "\n";
            }
        }

        fclose($f);
        $conn->close();
    }

    public function importQuartiersIris($filePath, $cartoEnabled = false){
        $f = fopen($filePath,'rb');

        $errors = array();
        $coms = array();
        $communes = $this->em->getRepository('OruAddressBundle:LstCommune')->findAll();

        foreach($communes as $c){
            $coms[$c->getCode()] = $c->getId();
        }

        $conn = $this->em->getConnection();
        if($cartoEnabled){
            $connC = $this->emCarto->getConnection();
            $sql = "DELETE FROM lst_commune_geo";
            $connC->query($sql);
            $batchC = "";
        }
        $i = 0;
        $batch = "";
        while($line = fgetcsv($f,1024000,';')) {
            if ($line[0] != 'the_geom') {

                if($cartoEnabled){
                    $sqlC = " INSERT INTO lst_iris_geo ";
                    $sqlC .= " (the_geom,depcom,nom_com,iris,nom_iris,typ_iris,origin) ";
                    $sqlC .= " VALUES('".$line[0]."','".$line[1]."','".$this->replaceQuotes($line[2])."','".$line[3]."','".$this->replaceQuotes($line[4])."','".$line[5]."'); ";
                    $batchC .= $sqlC;
                }

                if(array_key_exists($line[1], $coms)) {
                    $sql = " INSERT IGNORE INTO " . $this->em->getClassMetadata('OruAddressBundle:LstQuartierIris')->getTableName();
                    $sql .= "(commune_id,iris,code,libelle,type_iris,origine, created, updated)";
                    $sql .= "VALUES('" . $coms[$line[1]] . "','" . $this->replaceQuotes($line[3]) . "','" . $this->replaceQuotes($line[1]).$this->replaceQuotes($line[3]) . "','" . $this->replaceQuotes($line[4]) . "','" . $this->replaceQuotes($line[5]) . "','" . $this->replaceQuotes($line[6]) . "', NOW(), NOW()); ";
                    $batch .= $sql;

                }else{
                    array_push($errors, array('code' => $line[3], 'libelle' => $line[4], 'code_com' => $line[1]));
                }

                if($i % 100 == 0){

                    $conn->exec('BEGIN; '.$batch.' COMMIT;');
                    if($cartoEnabled) {
                        $connC->exec('BEGIN; ' . $batchC . ' COMMIT;');
                        $batchC = "";
                    }
                    $batch = "";
                }

                $i++;
                $this->showProgress($i,"lignes traitées", 5000);
            }
        }

        if($batch != "")
            $conn->exec('BEGIN; '.$batch.' COMMIT;');
        if($cartoEnabled AND $batchC != "" )
            $connC->exec('BEGIN; '.$batchC.' COMMIT;');

        $this->showTotalLines($i);

        if(count($errors)){
            echo count($errors). " erreurs => codes communes non trouvés dans la base de données, les quartiers suivants n'ont pas été insérés : \n\n";
            foreach($errors as $error){
                echo "- Code quartier : ".$error['code'].", libellé : ".$error['libelle'].", code commune (introuvable) : ".$error['code_com']. "\n";
            }
        }

        fclose($f);
        $conn->close();
    }

    /**
     * Permet le peuplement des codes postaux dans les adresses (liaison forte)
     * La méthode se base sur les textes bruts de la commune et le code renseignés dans l'adresse pour le lier le bon code postal
     * Peut être rejoué plusieurs fois si nécessaire, on ne modifie que les adresses qui n'ont aucune liaison préalable
     */
    public function linkCPToAddresses()
    {

        $this->em->getConnection()->getConfiguration()->setSQLLogger(null);

        /**
         * Approche par communes: on recherche toutes les communes dont le libellé est la valeur renseignée en texte brut dans l'adresse
         */
        $resultCommunes = $this->em->getRepository('OruAddressBundle:LstCommune')->createQueryBuilder('c')
            ->select('c.id AS cid, c.code AS ccode, a.id AS aid, a.code AS acode')
            ->join('OruAddressBundle:Address', 'a', 'WITH', 'c.libelle = a.commune')
            ->where('a.codePostal IS NULL')
            ->getQuery()->getResult();

        $this->linkCPToAddressesFromCommunesResult($resultCommunes);

        /**
         * Approche par libellés d'acheminement: on recherche toutes les communes dont les codes postaux associés ont un libellé d'acheminement identique au texte brut dans l'adresse
         */
        $resultCommunes = $this->em->getRepository('OruAddressBundle:LstCommune')->createQueryBuilder('c')
            ->select('c.id AS cid, c.code AS ccode, a.id AS aid, a.code AS acode')
            ->join('OruAddressBundle:LstCodePostal', 'cp', 'WITH', 'cp.commune = c')
            ->join('OruAddressBundle:Address', 'a', 'WITH', 'cp.libelleAcheminement = a.commune')
            ->where('a.codePostal IS NULL')
            ->getQuery()->getResult();

        $this->linkCPToAddressesFromCommunesResult($resultCommunes);

    }

    private function linkCPToAddressesFromCommunesResult($resultCommunes){
        $i=0;
        $sql = "";

        foreach($resultCommunes as $result){
            $communeId = $result["cid"];
            $communeCode = $result["ccode"];
            $addressId = $result["aid"];
            $addressCode = $result["acode"];

            $codesPostaux =  $this->em->getRepository('Oru\Bundle\AddressBundle\Entity\LstCodePostal')->createQueryBuilder('cp')
                ->select('PARTIAL cp.{id, code}')
                ->where('cp.commune = :commune')
                ->setParameter('commune', $communeId)
                ->getQuery()->getResult();

            /** @var LstCodePostal $cp */
            foreach($codesPostaux as $cp){
                $cpCode = $cp->getCode();

                //Gestion des codes postaux dont le "0" de départ a été ommis dans le code unique
                if(strlen($cpCode) === 9 && substr($communeCode, 0, 1 ) === "0" && substr($cpCode, 0, 1) !== "0"){
                    $cpCode = "0".$cpCode;
                }

                //Le code unique du code postal est composé du code commune concaténé avec le libellé du code postal
                if($cpCode === $communeCode.$addressCode){
                    $sql .= " UPDATE oru_address a SET a.code_postal_id = {$cp->getId()} WHERE a.id = {$addressId} AND a.code_postal_id IS NULL ; ";
                    $i++;
                    break;
                }
            }

            if($i % 100 == 0 && !empty($sql)){
                $this->em->getConnection()->exec($sql);
                $sql = "";
            }
        }

        if(!empty($sql)){
            $this->em->getConnection()->exec($sql);
        }
    }

    public function maxAllowedExecutionTime()
    {
        return 3600;
    }
}