<?php

namespace Oru\Bundle\AddressBundle\Form;

use Oru\Bundle\LstBundle\Form\LstType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class LstTerritoireType extends LstType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);
        $builder->add('region', null, array('required' => true, 'label' => 'Address.region' , 'translation_domain' => 'OruAddressBundle'));
        $builder->add('code', null, array('required' => true, 'label' => 'list.code' , 'translation_domain' => 'OruLstBundle'));
    }
    
    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\AddressBundle\Entity\LstTerritoire'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_addressbundle_lstterritoire';
    }
}
