<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use APY\DataGridBundle\Grid\Mapping as GRID;
use JMS\Serializer\Annotation;

/**
 * LstDepartement
 * @Annotation\ExclusionPolicy("all")
 */
class LstDepartement extends Lst
{
    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstRegion
     */
    private $region;

    /**
     * @var LstCommune
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_communes"})
     */
    private $communes;

    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_structure"})
     */
    protected $id;

    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_structure"})
     */
    protected $libelle;


    /**
     * Set region
     *
     * @param \Oru\Bundle\AddressBundle\Entity\LstRegion $region
     * @return LstDepartement
     */
    public function setRegion(\Oru\Bundle\AddressBundle\Entity\LstRegion $region = null)
    {
        $this->region = $region;
    
        return $this;
    }

    /**
     * Get region
     *
     * @return \Oru\Bundle\AddressBundle\Entity\LstRegion 
     */
    public function getRegion()
    {
        return $this->region;
    }

    /**
     * @return mixed
     */
    public function getCompleteLibelle()
    {
        return $this->getCode()." - ".$this->getLibelle();
    }

    /**
     * @return LstCommune
     */
    public function getCommunes()
    {
        return $this->communes;
    }

    /**
     * @param LstCommune $communes
     */
    public function setCommunes($communes)
    {
        $this->communes = $communes;
    }
}
