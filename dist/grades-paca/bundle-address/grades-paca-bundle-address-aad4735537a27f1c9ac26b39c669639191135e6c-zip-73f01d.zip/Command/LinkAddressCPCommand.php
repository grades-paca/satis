<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 06/07/2015
 * Time: 09:46
 */

namespace Oru\Bundle\AddressBundle\Command;

use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class LinkAddressCPCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    public function getMaxRunningTimeSec()
    {
        return 0;
    }

    public function isConcurentAllowed()
    {
        return false;
    }

    public function getTypeFieldFromArgumentName($name, &$type = 'text', &$options = array())
    {
    }

    protected function configure()
    {
        $this
            ->setName('oru:address:link_cp')
            ->setDescription('Etablit la relation entre un code postal et une adresse depuis le code manuel renseigné dans l\'adresse (VARCHAR)')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->getContainer()->get('oru_address.populate')->linkCPToAddresses();
    }
}
