<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 24/06/2015
 * Time: 15:51
 */

namespace Oru\Bundle\AddressBundle\Service;

use Oru\Bundle\AddressBundle\Entity\LstCommune;
use Oru\Bundle\AddressBundle\Entity\LstQuartierIris;

class PopulateService{

    /**
     * @var EntityManager
     */
    protected $em;
    protected $emCarto;

    public function __construct($em ,$emCarto)
    {
        $this->em = $em;
        $this->emCarto = $emCarto;
    }

    private function replaceQuotes($str){
        return str_replace("'", "''", $str) ;
    }

    private function showProgress($i, $label, $modulo){
        if($i % $modulo == 0){
            echo $i." ".$label." \n";
        }
    }

    private function showTotalLines($i) {
        echo "Total : " . $i . " lignes insérées \n";
    }

    public function importCommunes ($filePath, $cartoEnabled = false){

        $f = fopen($filePath,'rb');

        $depts = array();
        $departements = $this->em->getRepository('OruAddressBundle:LstDepartement')->findAll();
        $errors = array();

        foreach($departements as $d){

            $code = $d->getCode();

            if(strpos($code,'0')!== false && strpos($code,'0') == 0)
                $code = substr($code,1,1);

            $depts[$code] = $d->getId();
        }

        $conn = $this->em->getConnection();
        $i = 0; $class=  $this->em->getClassMetadata('OruAddressBundle:LstCommune')->getTableName();
        $batch = "";


        if($cartoEnabled){
            $connC =  $this->emCarto->getConnection();
            $batchC = "";
            $sql = "DELETE FROM lst_commune_geo";
            $connC->query($sql);
        }

        while($line = fgetcsv($f,1024000,';')) {
            if ($line[0] != 'the_geom') {

                if($cartoEnabled){
                    $sqlC = " INSERT INTO lst_commune_geo";
                    $sqlC .= " (the_geom,id_geofla, code_com, insee_com, nom_com, statut, x_chf_lieu, y_chf_lieu, x_centroid, y_centroid, z_moyen, superficie, population, code_cant, code_arr, code_dept, nom_dept, code_reg, nom_reg) ";
                    $sqlC .= " VALUES('".$line[0]."','".$line[1]."','".$line[2]."','".$line[3]."','".$this->replaceQuotes($line[4])."','".$this->replaceQuotes($line[5])."','".$line[6]."',";
                    $sqlC .= "'".$line[7]."','".$line[10]."','".$line[11]."','".$line[14]."','".$line[15]."','".$line[16]."',";
                    $sqlC .= "'".$line[17]."','".$line[18]."','".$line[19]."','".$this->replaceQuotes($line[20])."','".$line[21]."','".$this->replaceQuotes($line[22])."'); ";
                    $batchC .= $sqlC;
                }

                if(array_key_exists(intval($line[19]), $depts)) {
                    $sql = " INSERT IGNORE INTO " . $class;
                    $sql .= "(departement_id,code,libelle,statut,x_chef_lieu, y_chef_lieu, long_chef_lieu, lat_chef_lieu,x_centroid,y_centroid, long_centroid, lat_centroid, z_moyen, superficie, population, code_cant, code_arr, created, updated)";
                    $sql .= "VALUES('" . $depts[intval($line[19])] . "','" . $line[3] . "','" . $this->replaceQuotes($line[4]) . "','" . $this->replaceQuotes($line[5]) . "','" . $line[6] . "','" . $line[7] . "','" . $line[8] . "','" . $line[9] . "','" . $line[10] . "','" . $line[11] . "','" . $line[12] . "','" . $line[13] . "','" . $line[14] . "','" . $line[15] . "','" . $line[16] . "','" . $line[17] . "','" . $line[18] . "', NOW(), NOW()); ";
                    $batch .= $sql;
                    //


                }else{
                    array_push($errors, array('code' => $line[3], 'libelle' => $this->replaceQuotes($line[4]), 'code_dept' => intval($line[19])));
                }

                if($i % 100 == 0){

                    $conn->exec('BEGIN; '.$batch.' COMMIT;');
                    if($cartoEnabled) {
                        $connC->exec('BEGIN; ' . $batchC . ' COMMIT;');
                        $batchC = "";
                    }
                    $batch = "";
                }

                $i++;
                $this->showProgress($i, "lignes traitées", 2500);
            }
        }

        if($batch != "")
            $conn->exec('BEGIN; '.$batch.' COMMIT;');
        if($cartoEnabled AND $batchC != "")
            $connC->exec('BEGIN; '.$batchC.' COMMIT;');

        $this->showTotalLines($i);
        if(count($errors)){
            echo count($errors). " erreurs => codes département non trouvés dans la base de données, les communes suivantes n'ont pas été insérées : \n\n";
            foreach($errors as $error){
                echo "- Commune : ".$error['code'].", libellé : ".$error['libelle'].", code département (introuvable) : ".$error['code_dept']. "\n";
            }
        }

        fclose($f);
        $conn->close();
    }

    public function importCodesPostaux($filePath){
        $f = fopen($filePath,'rb');

        $errors = array();
        $coms = array();
        $communes = $this->em->getRepository('OruAddressBundle:LstCommune')->findAll();

        foreach($communes as $c){
            $coms[$c->getCode()] = $c->getId();
        }

        $conn = $this->em->getConnection();
        $i = 0;
        $batch = "";
        while($line = fgetcsv($f,1024,';')) {
            if ($line[0] != 'code postal') {

                if(array_key_exists($line[2], $coms)){
                    $sql = " INSERT IGNORE INTO " . $this->em->getClassMetadata('OruAddressBundle:LstCodePostal')->getTableName();
                    $sql .= "(commune_id,code,libelle, created, updated)";
                    $sql .= "VALUES('" . $coms[$line[2]] . "','" . $line[0] . "','" . $this->replaceQuotes($line[1]) . "', NOW(), NOW()); ";
                    $batch .= $sql;
                }else{
                    array_push($errors, array('code' => $line[0], 'libelle' => $line[1], 'code_com' => $line[2]));
                }

                if($i % 100 == 0){
                    $conn->exec('BEGIN; '.$batch.' COMMIT;');
                    $batch = "";
                }

                $i++;
                $this->showProgress($i, "lignes insérées", 5000);
            }
        }


        if($batch != "")
            $conn->exec('BEGIN; '.$batch.' COMMIT;');
        $this->showTotalLines($i);

        if(count($errors)){
            echo count($errors). " erreurs => codes communes non trouvés dans la base de données, les codes postaux suivants n'ont pas été insérés : \n\n";
            foreach($errors as $error){
                echo "- Code postal : ".$error['code'].", libellé : ".$error['libelle'].", code commune (introuvable) : ".$error['code_com']. "\n";
            }
        }

        fclose($f);
        $conn->close();
    }

    public function importQuartiersIris($filePath, $cartoEnabled = false){
        $f = fopen($filePath,'rb');

        $errors = array();
        $coms = array();
        $communes = $this->em->getRepository('OruAddressBundle:LstCommune')->findAll();

        foreach($communes as $c){
            $coms[$c->getCode()] = $c->getId();
        }

        $conn = $this->em->getConnection();
        if($cartoEnabled){
            $connC = $this->emCarto->getConnection();
            $sql = "DELETE FROM lst_commune_geo";
            $connC->query($sql);
            $batchC = "";
        }
        $i = 0;
        $batch = "";
        while($line = fgetcsv($f,1024000,';')) {
            if ($line[0] != 'the_geom') {

                if($cartoEnabled){
                    $sqlC = " INSERT INTO lst_iris_geo ";
                    $sqlC .= " (the_geom,depcom,nom_com,iris,nom_iris,typ_iris,origin) ";
                    $sqlC .= " VALUES('".$line[0]."','".$line[1]."','".$this->replaceQuotes($line[2])."','".$line[3]."','".$this->replaceQuotes($line[4])."','".$line[5]."'); ";
                    $batchC .= $sqlC;
                }

                if(array_key_exists($line[1], $coms)) {
                    $sql = " INSERT IGNORE INTO " . $this->em->getClassMetadata('OruAddressBundle:LstQuartierIris')->getTableName();
                    $sql .= "(commune_id,iris,code,libelle,type_iris,origine, created, updated)";
                    $sql .= "VALUES('" . $coms[$line[1]] . "','" . $this->replaceQuotes($line[3]) . "','" . $this->replaceQuotes($line[1]).$this->replaceQuotes($line[3]) . "','" . $this->replaceQuotes($line[4]) . "','" . $this->replaceQuotes($line[5]) . "','" . $this->replaceQuotes($line[6]) . "', NOW(), NOW()); ";
                    $batch .= $sql;

                }else{
                    array_push($errors, array('code' => $line[3], 'libelle' => $line[4], 'code_com' => $line[1]));
                }

                if($i % 100 == 0){

                    $conn->exec('BEGIN; '.$batch.' COMMIT;');
                    if($cartoEnabled) {
                        $connC->exec('BEGIN; ' . $batchC . ' COMMIT;');
                        $batchC = "";
                    }
                    $batch = "";
                }

                $i++;
                $this->showProgress($i,"lignes insérées", 5000);
            }
        }

        if($batch != "")
            $conn->exec('BEGIN; '.$batch.' COMMIT;');
        if($cartoEnabled AND $batchC != "" )
            $connC->exec('BEGIN; '.$batchC.' COMMIT;');

        $this->showTotalLines($i);

        if(count($errors)){
            echo count($errors). " erreurs => codes communes non trouvés dans la base de données, les quartiers suivants n'ont pas été insérés : \n\n";
            foreach($errors as $error){
                echo "- Code quartier : ".$error['code'].", libellé : ".$error['libelle'].", code commune (introuvable) : ".$error['code_com']. "\n";
            }
        }

        fclose($f);
        $conn->close();
    }

    public function linkAddressCP(){
        $conn = $this->em->getConnection();
        $sql  = "UPDATE " . $this->em->getClassMetadata('OruAddressBundle:Address')->getTableName()." as a";
        $sql .=" SET code_postal_id = (SELECT id FROM ". $this->em->getClassMetadata('OruAddressBundle:LstCodePostal')->getTableName()." as cp WHERE cp.code = a.code) WHERE code_postal_id IS NULL AND code IS NOT NULL";
        $conn->query($sql);
        $conn->close();
    }

    public function migrateZonesIntervention(){

        global $kernel;
        $container = $kernel->getContainer();

        if($container->hasParameter('region'))
            return;

        $region = $container->get('region');
        $em = $this->em;
        $zones = $em->getRepository('OruRorBundle:LstZoneIntervention')->findAll();

        $oldZi = array();
        $oldZI_precisions = array();

        switch($region){
            case 'paca':

            $oldZI = array(
                1 => 'HYERES',
                2 => 'LA LONDE',
                3 => 'BORMES-LES-MIMOSAS',
                7 => 'LE LAVANDOU',
                9 => 'COLLOBRIERES',
                10 => 'PIERREFEU',
                11 => 'PUGET-VILLE',
                12 => 'CUERS',
                13 => 'SOLLIES-PONT',
                14 => 'LA CRAU',
                15 => 'LA GARDE',
                16 => 'CARQUEIRANNE',
                17 => 'LE PRADET',
                18 => 'TOULON',
                19 => 'SOLLIES-VILLE'
            );

            $oldZI_precisions = array(
                4 => 'PORQUEROLLES',
                5 => 'PORT-CROS',
                6 => 'LE LEVANT',
                8 => 'CAVALIERE',
                20 => 'AUTRE'
            );
                break;

            case 'centre':

                $oldZI = array(
                    1 => 'AIGURANDE',
                    2 => 'AMBOISE',
                    3 => 'AMILLY',
                    4 => 'ANET',
                    5 => 'ARDENTES',
                    8 => 'ARTENAY',
                    10 => 'AUNEAU',
                    14 => 'BAUGY',
                    15 => 'BEAUGENCY',
                    17 => 'BÉLÂBRE',
                    18 => 'BELLEGARDE',
                    19 => 'BLÉRÉ',
                    25 => 'BONNEVAL',
                    31 => 'BOURGUEIL',
                    32 => 'BRACIEUX',
                    33 => 'BREZOLLES',
                    34 => 'BRIARE',
                    35 => 'BROU',
                    36 => 'BUZANÇAIS',
                    40 => 'CHAROST',
                    47 => 'CHÂTEAUDUN',
                    48 => 'CHÂTEAUMEILLANT',
                    57 => 'CHÉCY',
                    58 => 'CHINON',
                    61 => 'CONTRES',
                    62 => 'COURTENAY',
                    64 => 'DESCARTES',
                    68 => 'DROUÉ',
                    70 => 'ECUEILLÉ',
                    71 => 'EGUZON-CHANTÔME',
                    74 => 'GIEN',
                    75 => 'GRAÇAY',
                    76 => 'HENRICHEMONT',
                    77 => 'HERBAULT',
                    79 => 'INGRÉ',
                    82 => 'JANVILLE',
                    83 => 'JARGEAU',
                    87 => 'LA CHÂTRE',
                    91 => 'LA LOUPE',
                    93 => 'LANGEAIS',
                    94 => 'LE BLANC',
                    96 => 'LÉRÉ',
                    98 => 'LEVET',
                    99 => 'LEVROUX',
                    100 => 'LIGNIÈRES',
                    101 => 'LIGUEIL',
                    103 => 'LOCHES',
                    104 => 'LORRIS',
                    105 => 'LUCÉ',
                    107 => 'LUYNES',
                    108 => 'MAINTENON',
                    109 => 'MAINVILLIERS',
                    110 => 'MALESHERBES',
                    111 => 'MARCHENOIR',
                    114 => 'MER',
                    117 => 'MONDOUBLEAU',
                    118 => 'MONTARGIS',
                    119 => 'MONTBAZON',
                    122 => 'MONTRÉSOR',
                    123 => 'MONTRICHARD',
                    124 => 'MORÉE',
                    125 => 'NÉRONDES',
                    133 => 'OLIVET',
                    141 => 'OUTARVILLE',
                    144 => 'PATAY',
                    145 => 'PITHIVIERS',
                    147 => 'PUISEAUX',
                    148 => 'RICHELIEU',
                    167 => 'SALBRIS',
                    168 => 'SANCERGUES',
                    169 => 'SANCERRE',
                    170 => 'SANCOINS',
                    174 => 'SELOMMES',
                    175 => 'SENONCHES',
                    187 => 'VALENÇAY',
                    188 => 'VATAN',
                    193 => 'VINEUIL',
                    194 => 'VOUVRAY',
                    195 => 'VOVES',
                    198 => 'AVRILLÉ-LES-PONCEAUX',
                    199 => 'ABILLY',
                    200 => 'AMBILLOU',
                    201 => 'ANCHÉ',
                    204 => 'ASSAY',
                    206 => 'AUTRÈCHE',
                    208 => 'AVOINE',
                    212 => 'BARROU',
                    216 => 'BEAUMONT-VILLAGE',
                    217 => 'BENAIS',
                    218 => 'BERTHENAY',
                    219 => 'BETZ-LE-CHÂTEAU',
                    220 => 'BOSSAY-SUR-CLAISE',
                    221 => 'BOSSÉE',
                    222 => 'BOURNAN',
                    223 => 'BOUSSAY',
                    210 => 'AZAY-SUR-CHER',
                    211 => 'AZAY-SUR-INDRE',
                    6 => 'ARGENT-SUR-SAULDRE',
                    7 => 'ARGENTON-SUR-CREUSE',
                    9 => 'AUBIGNY-SUR-NERE',
                    11 => 'AUTHON-DU-PERCHE',
                    12 => 'AZAY-LE-RIDEAU',
                    13 => 'BALLAN-MIRE',
                    16 => 'BEAUNE-LA-ROLANDE',
                    37 => 'CHALETTE-SUR-LOING',
                    38 => 'CHAMBRAY-LES-TOURS',
                    39 => 'CHARENTON-DU-CHER',
                    44 => 'CHÂTEAU-LA-VALLIERE',
                    45 => 'CHÂTEAU-RENARD',
                    46 => 'CHÂTEAU-RENAULT',
                    49 => 'CHÂTEAUNEUF-EN-THYMERAIS',
                    50 => 'CHÂTEAUNEUF-SUR-LOIRE',
                    55 => 'CHATILLON-COLIGNY',
                    56 => 'CHÂTILLON-SUR-LOIRE',
                    59 => 'CLÉRY-SAINT-ANDRÉ',
                    60 => 'CLOYES-SUR-LE-LOIR',
                    63 => 'COURVILLE-SUR-EURE',
                    69 => 'DUN-SUR-AURON',
                    72 => 'FERRIÈRES-EN-GÂTINAIS',
                    73 => 'FLEURY-LES-AUBRAIS',
                    78 => 'ILLIERS-COMBRAY',
                    88 => 'LA FERTÉ-SAINT-AUBIN',
                    89 => 'LA FERTÉ-VIDAME',
                    90 => 'LA GUERCHE-SUR-L\'AUBOIS',
                    92 => 'LAMOTTE-BEUVRON',
                    95 => 'LE GRAND-PRESSIGNY',
                    97 => 'LES AIX-D\'ANGILLON',
                    102 => 'L\'ILE-BOUCHARD',
                    106 => 'LURY-SUR-ARNON',
                    112 => 'MEHUN-SUR-YÈVRE',
                    113 => 'MENNETOU-SUR-CHER',
                    115 => 'MEUNG-SUR-LOIRE',
                    116 => 'MEZIÈRES-EN-BRENNE',
                    120 => 'MONTLOUIS-SUR-LOIRE',
                    121 => 'MONTOIRE-SUR-LE-LOIR',
                    126 => 'NEUILLÉ-PONT-PIERRE',
                    127 => 'NEUNG-SUR-BEUVRON',
                    128 => 'NEUVILLE-AUX-BOIS',
                    129 => 'NEUVY-LE-ROI',
                    130 => 'NEUVY-SAINT-SÉPULCHRE',
                    131 => 'NOGENT-LE-ROI',
                    132 => 'NOGENT-LE-ROTROU',
                    134 => 'ORGÈRES-EN-BEAUCE',
                    146 => 'PREUILLY-SUR-CLAISE',
                    151 => 'SAINT-AIGNAN',
                    152 => 'SAINT-AMAND-LONGPRÉ',
                    153 => 'SAINT-AMAND-MONTROND',
                    154 => 'SAINT-AVERTIN',
                    155 => 'SAINT-BENOÎT-DU-SAULT',
                    156 => 'SAINT-CHRISTOPHE-EN-BAZELLE',
                    157 => 'SAINT-CYR-SUR-LOIRE',
                    158 => 'SAINT-DOULCHARD',
                    159 => 'SAINT-GAULTIER',
                    160 => 'SAINT-JEAN-DE-BRAYE',
                    161 => 'SAINT-JEAN-DE-LA-RUELLE',
                    162 => 'SAINT-JEAN-LE-BLANC',
                    163 => 'SAINT-MARTIN-D\'AUXIGNY',
                    164 => 'SAINT-PIERRE-DES-CORPS',
                    165 => 'SAINT-SÉVÈRE-SUR-INDRE',
                    166 => 'SAINTE-MAURE-DE-TOURAINE',
                    171 => 'SAULZAIS-LE-POTIER',
                    172 => 'SAVIGNY-SUR-BRAYE',
                    173 => 'SELLES-SUR-CHER',
                    176 => 'SULLY-SUR-LOIRE',
                    177 => 'THIRON-GARDAIS',
                    178 => 'TOURNON-SAINT-MARTIN',
                    202 => 'ANTOGNY-LE-TILLAC',
                    203 => 'ARTANNES-SUR-INDRE',
                    205 => 'ATHÉE-SUR-CHER',
                    207 => 'AUZOUER-EN-TOURAINE',
                    209 => 'AVON-LES-ROCHES',
                    213 => 'BEAULIEU-LES-LOCHES',
                    214 => 'BEAUMONT-EN-VÉRON',
                    215 => 'BEAUMONT-LA-RONCE',
                    224 => 'CHATEAUNEUF-SUR-CHER',
                    225 => 'CHATILLON-SUR-INDRE'

                );

                $oldZI_precisions = array(
                    20 => 'BLOIS 1ER CANTON',
                    21 => 'BLOIS 2E CANTON',
                    22 => 'BLOIS 3E CANTON',
                    23 => 'BLOIS 4E CANTON',
                    24 => 'BLOIS 5E CANTON',
                    26 => 'BOURGES 1ER CANTON',
                    27 => 'BOURGES 2E CANTON',
                    28 => 'BOURGES 3E CANTON',
                    29 => 'BOURGES 4E CANTON',
                    30 => 'BOURGES 5E CANTON',
                    65 => 'DREUX EST',
                    66 => 'DREUX OUEST',
                    67 => 'DREUX SUD',
                    80 => 'ISSOUDUN NORD',
                    81 => 'ISSOUDUN SUD',
                    84 => 'JOUÉ LES TOURS NORD',
                    85 => 'JOUÉ LES TOURS SUD',
                    135 => 'ORLÉANS BANNIER',
                    136 => 'ORLÉANS BOURGOGNE',
                    137 => 'ORLÉANS CARMES',
                    138 => 'ORLÉANS LA SOURCE',
                    139 => 'ORLÉANS ST MARC ARGONNE',
                    140 => 'ORLÉANS ST MARCEAU',
                    142 => 'OUZOUER LE MARCHÉ',
                    143 => 'OUZOUER SUR LOIRE',
                    179 => 'TOURS CENTRE',
                    180 => 'TOURS EST',
                    181 => 'TOURS NORD EST',
                    182 => 'TOURS NORD OUEST',
                    183 => 'TOURS OUEST',
                    184 => 'TOURS SUD',
                    185 => 'TOURS VAL DU CHER',
                    186 => 'VAILLY SUR SAULDRE',
                    189 => 'VENDÔME 1ER CANTON',
                    190 => 'VENDÔME 2E CANTON',
                    191 => 'VIERZON 1ER CANTON',
                    192 => 'VIERZON 2E CANTON',
                    196 => '--CANTON--',
                    197 => '--COMMUNES INDRE ET LOIRE--',
                    149 => 'ROMORANTIN LANTHENAY NORD',
                    150 => 'ROMORANTIN LANTHENAY SUD',
                    51 => 'CHÂTEAUROUX CENTRE',
                    52 => 'CHÂTEAUROUX EST',
                    53 => 'CHÂTEAUROUX OUEST',
                    54 => 'CHÂTEAUROUX SUD',
                    41 => 'CHARTRES NORD EST',
                    42 => 'CHARTRES SUD EST',
                    43 => 'CHARTRES SUD OUEST',
                    86 => 'LA CHAPELLE D\'ANGILLON'
                );

                break;

            default:
                break;
        }


        $query = $em->getConnection()->query('SELECT u.id, a.zone_intervention_id FROM oru_ror_unite u INNER JOIN oru_ror_unite_asso_zones_interventions a ON u.id = a.unite_id');
        $results = $query->fetchAll(\PDO::FETCH_ASSOC);
        $sql = "";
        foreach($results as $result){
            if(array_key_exists($result['zone_intervention_id'], $oldZI)) {
                $sql .= " INSERT IGNORE INTO oru_ror_unite_asso_communes (unite_id,commune_id) VALUES ('" . $result['id'] . "',(SELECT id FROM oru_address_lst_commune WHERE libelle = '".$oldZI[$result['zone_intervention_id']]."' LIMIT 1)) ;";
            }else if(array_key_exists($result['zone_intervention_id'], $oldZI_precisions)) {
                $unite = $em->getRepository('OruRorBundle:Unite')->find($result['id']);
                if($unite) {
                    $unite->setZonesInterventionPrecisions($unite->getZonesInterventionPrecisions() . $oldZI_precisions[$result['zone_intervention_id']] . "; ");
                }
            }
        }

        $em->flush();

        $conn = $em->getConnection();
        $conn->executeQuery($sql);
        $conn->close();
    }
}