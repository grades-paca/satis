<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;

/**
 * LstCodePostal
 */
class LstCodePostal extends Lst
{
    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstCommune
     */
    private $commune;

    /**
     * @return LstCommune
     */
    public function getCommune()
    {
        return $this->commune;
    }

    /**
     * @param LstCommune $commune
     */
    public function setCommune(LstCommune $commune)
    {
        $this->commune = $commune;
    }
}
