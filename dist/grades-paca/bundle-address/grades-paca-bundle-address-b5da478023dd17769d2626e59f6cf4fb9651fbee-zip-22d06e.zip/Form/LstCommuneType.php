<?php

namespace Oru\Bundle\AddressBundle\Form;

use Doctrine\ORM\EntityManager;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class LstCommuneType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);
        $builder->add('codeCommune', null, array('required' => true, 'label' => 'Address.codeCommune' , 'translation_domain' => 'OruAddressBundle'));
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\AddressBundle\Entity\LstCommune'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_addressbundle_lstcommune';
    }
}