<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 06/10/2016
 * Time: 13:49
 */

namespace Oru\Bundle\AddressBundle\Form\DataTransformer;


use Doctrine\Common\Util\Debug;
use Doctrine\ORM\EntityManager;
use Oru\Bundle\AddressBundle\Entity\ZoneGeographique;
use Symfony\Component\Form\DataTransformerInterface;

class ZoneGeographiqueTreeTransformer implements DataTransformerInterface
{
    /**
     * @var EntityManager
     */
    private $em;

    public function __construct(EntityManager $em = null)
    {
        $this->em = $em;
    }

    public function transform($zone)
    {
        /** @var ZoneGeographique $zone */
        if($zone){

            $regions = array();
            foreach($zone->getRegions() as $region){
                $regions[] = $region->getId();
            }

            $departements = array();
            foreach($zone->getDepartements() as $departement){
                $departements[] = $departement->getId();
            }

            $communes = array();
            foreach($zone->getCommunes() as $commune){
                $communes[] = array(
                    'id' => $commune->getId(),
                    'departement' => $commune->getDepartement()->getId()
                );
            }

            $quartiers = array();
            foreach($zone->getQuartiers() as $quartier){
                $quartiers[] = array(
                    'id' => $quartier->getId(),
                    'commune' => $quartier->getCommune()->getId(),
                    'departement' => $quartier->getCommune()->getDepartement()->getId()
                );
            }

            return json_encode(array(
                'id' => $zone->getId(),
                'region' => $regions,
                'departement' => $departements,
                'commune' => $communes,
                'quartier' => $quartiers
            ));
        }

        return '';
    }

    public function reverseTransform($data)
    {
        $zone = null;
        if(!empty($data)){
            $data = json_decode($data);
            $zone = new ZoneGeographique();
            if(!empty($data->id)){
                $zone = $this->em->getRepository('OruAddressBundle:ZoneGeographique')->find($data->id);
            }

            $zone->clear();

            if(!empty($data->region)){
                foreach($data->region as $region){
                    $zone->addRegion($this->em->getReference('OruAddressBundle:LstRegion', $region));
                }
            }

            if(!empty($data->departement)){
                foreach($data->departement as $departement){
                    $zone->addDepartement($this->em->getReference('OruAddressBundle:LstDepartement', $departement));
                }
            }

            if(!empty($data->commune)){
                foreach($data->commune as $commune){
                    $zone->addCommune($this->em->getReference('OruAddressBundle:LstCommune', $commune));
                }
            }

            if(!empty($data->quartier)){
                foreach($data->quartier as $quartier){
                    $zone->addQuartier($this->em->getReference('OruAddressBundle:LstQuartierIris', $quartier));
                }
            }
        }

        return $zone;
    }
}