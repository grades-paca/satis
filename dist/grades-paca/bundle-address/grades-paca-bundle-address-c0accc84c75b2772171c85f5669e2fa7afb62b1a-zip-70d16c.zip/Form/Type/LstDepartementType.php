<?php
/**
 * Created by PhpStorm.
 */

namespace Oru\Bundle\AddressBundle\Form\Type;

use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\ORM\EntityRepository;
use Symfony\Bridge\Doctrine\Form\Type\DoctrineType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Bridge\Doctrine\Form\ChoiceList\ORMQueryBuilderLoader;
use Symfony\Component\Form\Exception\UnexpectedTypeException;
use Symfony\Component\OptionsResolver\Options;

/**
 * Class LstDepartementType
 * @package Oru\Bundle\AddressBundle\Form\Type
 */
class LstDepartementType extends AbstractType
{

    /**
     * @var string
     */
    private $codeRegion;

    /**
     * LstDepartementType constructor.
     * @param EntityManager $em
     */
    public function __construct($codeRegion)
    {
        $this->codeRegion = $codeRegion;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(
            array(
                'required' => false,
                'class' => 'Oru\Bundle\AddressBundle\Entity\LstDepartement',
                'group_by' => 'region',
                'query_builder' => function (EntityRepository $er) {

                    if ($this->codeRegion) {
                        return $er->createQueryBuilder('u')
                            ->join('u.region', 'r')
                            ->orderBy('FIELD', '(r.code,:codeRegion) DESC')
                            ->setParameter('codeRegion', $this->codeRegion);
                    } else {
                        return $er->createQueryBuilder('u')->join('u.region', 'r')->orderBy('u.region', 'ASC');
                    }
                },
            )
        );
    }

    /**
     * @return null|string|\Symfony\Component\Form\FormTypeInterface
     */
    public function getParent()
    {
        return 'entity';
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_lstdepartement';
    }
}