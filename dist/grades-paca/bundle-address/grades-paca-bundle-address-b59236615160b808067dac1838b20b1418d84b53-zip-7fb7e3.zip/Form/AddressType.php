<?php

namespace Oru\Bundle\AddressBundle\Form;

use Oru\Bundle\AddressBundle\Entity\Address;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AddressType extends AbstractType
{
    private $disabledBundles;
    private $container;

    public function __construct($disabledBundles, Container $container) {
        $this->disabledBundles = $disabledBundles;
        $this->container = $container;
    }


    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('adresse', null, array('label' => 'Address.adresse', 'translation_domain' => 'OruAddressBundle', 'read_only' => true, 'disabled' => true))
            ->add('numero', null, array('label' => 'Address.numero', 'translation_domain' => 'OruAddressBundle'))
            ->add('numeroComplement', null, array('label' => 'Address.numero_complement', 'translation_domain' => 'OruAddressBundle'))
            ->add('type_voie', null, array('label' => 'Address.type_voie', 'translation_domain' => 'OruAddressBundle'))
            ->add('voie', null, array('label' => 'Address.voie', 'translation_domain' => 'OruAddressBundle'))
            ->add('adresseComplement', null, array('label' => 'Address.adresse_complement', 'translation_domain' => 'OruAddressBundle'))
            ->add('code', null, array('label' => 'Address.code', 'translation_domain' => 'OruAddressBundle'))
            ->add('commune', null, array('label' => 'Address.commune', 'translation_domain' => 'OruAddressBundle'))
            ->add('departement', null, array('label' => 'Address.departement', 'translation_domain' => 'OruAddressBundle'))
            ->add('territoire', null, array('label' => 'Address.territoire', 'translation_domain' => 'OruAddressBundle'))
            ->add('pays', 'country', array('label' => 'Address.pays', 'translation_domain' => 'OruAddressBundle', 'preferred_choices' => array('FR')))
        ;

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function(FormEvent $event) {
            $adresse = $event->getData();
            $form = $event->getForm();

            if (!$adresse || trim($adresse->getAdresse()) == '' || $adresse->getVoie()) {
                $form->remove('adresse');
            }
        });

        if(in_array('OruCartoBundle', $this->disabledBundles) === FALSE) {
            $builder->addEventSubscriber($this->container->get('oru_carto.listener.carto_type'));
        }
    }
    
    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\AddressBundle\Entity\Address'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_address';
    }
}
