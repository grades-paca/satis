<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 18/06/14
 */

namespace Oru\Bundle\AddressBundle\Form;

use Doctrine\ORM\EntityManager;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class DepartementType extends AbstractType
{
    protected $manager;

    public function __construct(EntityManager $manager)
    {
        $this->manager = $manager;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $departements = $this->manager->getRepository('OruAddressBundle:LstDepartement')->findAll();
        $resolver->setDefaults(array(
            'choices_as_values' => true,
            'choices' => array_combine(
                    array_map(function ($element) {
                        return $element->getLibelle();
                    }, $departements),
                    array_map(function ($element) {
                        return $element->getCode();
                    }, $departements)
                ),
            'label' => 'Address.departement',
            'translation_domain' => 'OruAddressBundle',
        ));
    }

    public function getParent()
    {
        return ChoiceType::class;
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'departement';
    }
}
