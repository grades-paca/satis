<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 10/07/2015
 * Time: 10:25
 */

namespace Oru\Bundle\AddressBundle\DependencyInjection\Compiler;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class FormPass implements  CompilerPassInterface {
    /**
     * You can modify the container here before it is dumped to PHP code.
     *
     * @param ContainerBuilder $container
     *
     * @api
     */
    public function process(ContainerBuilder $container)
    {
        $resources = $container->getParameter('twig.form.resources');
        $resources[] = 'OruAddressBundle:Form:commune_layout.html.twig';
        $resources[] = 'OruAddressBundle:Form:codepostal_layout.html.twig';
        $resources[] = 'OruAddressBundle:Form:codepostal_commune_text_layout.html.twig';
        $resources[] = 'OruAddressBundle:Form:zone_geographique_tree.html.twig';
        $container->setParameter('twig.form.resources', $resources);
    }
}