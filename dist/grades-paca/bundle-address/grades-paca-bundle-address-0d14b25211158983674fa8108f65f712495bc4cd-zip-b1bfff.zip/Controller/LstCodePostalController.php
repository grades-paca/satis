<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 08/03/2016
 * Time: 15:51
 */

namespace Oru\Bundle\AddressBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

class LstCodePostalController extends Controller {

    /**
     * @param Request $request
     * @param $_format
     * @return JsonResponse
     * @throws ParameterNotFoundException
     */
    public function searchLstCodePostalAction(Request $request, $_format){
        $codes = array();
        $search = $request->get('search');

        if ($request->get('search') == '') {
            throw new ParameterNotFoundException("Parameter 'search' not found.");
        }

        $page_limit = 10;
        if ($request->get('page_limit')) {
            $page_limit = $request->get('page_limit');
        }

        $first = 0;
        if ($request->get('first')) {
            $first = $request->get('first');
        }

        $total = 0;

        //Recherche par un code entier
        if((string)(int)$search == $search){

            if ($request->get('infinite_scroll')) {
                $total = $this->getDoctrine()->getRepository('OruAddressBundle:LstCodePostal')->countSearchByName($search);
            }
            $str_entities = $this->getDoctrine()->getRepository('OruAddressBundle:LstCodePostal')->searchByName($search, $page_limit, $first);

        }else{//Recherche par commune

            if ($request->get('infinite_scroll')) {
                $total = $this->getDoctrine()->getRepository('OruAddressBundle:LstCodePostal')->countSearchByNameCommune($search);
            }
            $str_entities = $this->getDoctrine()->getRepository('OruAddressBundle:LstCodePostal')->searchByNameCommune($search, $page_limit, $first);
        }

        if (count($str_entities)) {
            foreach ($str_entities as $str_entitie) {
                $codes[] = array(
                    'id' => $str_entitie->getId(),
                    'libelle' => $str_entitie->__toString(),
                    'libelle_acheminement' => $str_entitie->getLibelleAcheminement()
                );
            }
        }

        if ($_format == 'json') {
            return new JsonResponse(array('total' => $total, 'lstcodes' => $codes));
        }
    }

    /**
     * @param Request $request
     * @param $_ids
     * @param $_format
     * @return JsonResponse
     */
    public function getLstCodePostalByIdsAction(Request $request, $_ids, $_format)
    {
        $ids = explode(',', $_ids);
        $codes = array();
        $entities = $this->getDoctrine()->getRepository('OruAddressBundle:LstCodePostal')->findById($ids);

        foreach ($entities as $entity) {
            if ($entity) {
                $codes[] = array('id' => $entity->getId(), 'libelle' => $entity->__toString());
            }
        }

        if ($_format == 'json') {
            return new JsonResponse($codes);
        }
    }

} 