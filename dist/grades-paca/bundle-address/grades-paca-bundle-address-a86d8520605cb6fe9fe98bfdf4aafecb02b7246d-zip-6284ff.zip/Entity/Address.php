<?php

namespace Oru\Bundle\AddressBundle\Entity;

use JMS\Serializer\Annotation;
use Oru\Bundle\GedmoBundle\Entity\LoggableInterface;
use Oru\Bundle\GedmoBundle\Entity\LoggableTrait;

/**
 * Address.
 *
 * @Annotation\ExclusionPolicy("all")
 */
class Address implements LoggableInterface
{
    use LoggableTrait;

    /**
     * @var int
     */
    private $id;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $numero;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $numeroComplement;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $voie;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $code;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $localite;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $commune;

    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstTerritoire
     */
    private $territoire;

    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstTypeVoie
     */
    private $typeVoie;

    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstDepartement
     */
    private $departement;

    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstRegion
     */
    private $region;

    /**
     * @var string
     */
    private $adresse;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $adresseComplement;

    /**
     * @var string
     */
    private $pays = 'FR';

    /**
     * @var mixed
     */
    private $carto;

    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstCodePostal
     */
    private $codePostal;

    private $created;

    private $updated;

    /**
     * @return string
     */
    public function __toString()
    {
        $delimiter = "\n";
        $adresseComplete = '';

        if ($this->getAdresse() !== '' && $this->getVoie() === '') {
            $adresseComplete .= $this->getAdresse()."$delimiter";
        }

        if ($this->getVoie() !== '') {
            if ($this->getNumero() !== '') {
                $adresseComplete .= $this->getNumero().$this->getNumeroComplement().' ';
            }
            $adresseComplete .= $this->getTypeVoie().' '.$this->getVoie()."$delimiter";
        }

        if ($this->getAdresseComplement()) {
            $adresseComplete .= $this->getAdresseComplement()."$delimiter";
        }

        $adresseComplete .= $this->getCode().' '.$this->getLocalite().' '.$this->getCommune();

        return $adresseComplete;
    }

    /**
     * @return mixed
     */
    public function getCodePostal()
    {
        return $this->codePostal;
    }

    /**
     * @param mixed $codePostal
     */
    public function setCodePostal(LstCodePostal $codePostal)
    {
        $this->codePostal = $codePostal;
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set numero.
     *
     * @param string $numero
     *
     * @return Address
     */
    public function setNumero($numero)
    {
        $this->numero = $numero;

        return $this;
    }

    /**
     * Get numero.
     *
     * @return string
     */
    public function getNumero()
    {
        return $this->numero;
    }

    /**
     * Set numeroComplement.
     *
     * @param string $numeroComplement
     *
     * @return Address
     */
    public function setNumeroComplement($numeroComplement)
    {
        $this->numeroComplement = $numeroComplement;

        return $this;
    }

    /**
     * Get numeroComplement.
     *
     * @return string
     */
    public function getNumeroComplement()
    {
        return $this->numeroComplement;
    }

    /**
     * Set voie.
     *
     * @param string $voie
     *
     * @return Address
     */
    public function setVoie($voie)
    {
        $this->voie = $voie;

        return $this;
    }

    /**
     * Get voie.
     *
     * @return string
     */
    public function getVoie()
    {
        return $this->voie;
    }

    /**
     * Set code.
     *
     * @param string $code
     *
     * @return Address
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code.
     *
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set localite.
     *
     * @param string $localite
     *
     * @return Address
     */
    public function setLocalite($localite)
    {
        $this->localite = $localite;

        return $this;
    }

    /**
     * Get localite.
     *
     * @return string
     */
    public function getLocalite()
    {
        return $this->localite;
    }

    /**
     * Set commune.
     *
     * @param string $commune
     *
     * @return Address
     */
    public function setCommune($commune)
    {
        $this->commune = $commune;

        return $this;
    }

    /**
     * Get commune.
     *
     * @return string
     */
    public function getCommune()
    {
        return $this->commune;
    }

    /**
     * Set territoire.
     *
     * @param string $territoire
     *
     * @return Address
     */
    public function setTerritoire(LstTerritoire $territoire = null)
    {
        $this->territoire = $territoire;

        return $this;
    }

    /**
     * Get territoire.
     *
     * @return string
     */
    public function getTerritoire()
    {
        try {
            if ($this->territoire) {
                $this->territoire->getDeleted();
            }
        } catch (\Exception $e) {
            return null;
        }

        return $this->territoire;
    }

    /**
     * Set typeVoie.
     *
     * @param \Oru\Bundle\AddressBundle\Entity\LstTypeVoie $typeVoie
     *
     * @return Address
     */
    public function setTypeVoie(\Oru\Bundle\AddressBundle\Entity\LstTypeVoie $typeVoie = null)
    {
        $this->typeVoie = $typeVoie;

        return $this;
    }

    /**
     * Get typeVoie.
     *
     * @return \Oru\Bundle\AddressBundle\Entity\LstTypeVoie
     */
    public function getTypeVoie()
    {
        try {
            if ($this->typeVoie) {
                $this->typeVoie->getDeleted();
            }
        } catch (\Exception $e) {
            return null;
        }

        return $this->typeVoie;
    }

    /**
     * Set departement.
     *
     * @param \Oru\Bundle\AddressBundle\Entity\LstDepartement $departement
     *
     * @return Address
     */
    public function setDepartement(\Oru\Bundle\AddressBundle\Entity\LstDepartement $departement = null)
    {
        $this->departement = $departement;

        return $this;
    }

    /**
     * Get departement.
     *
     * @return \Oru\Bundle\AddressBundle\Entity\LstDepartement
     */
    public function getDepartement()
    {
        try {
            if ($this->departement) {
                $this->departement->getDeleted();
            }
        } catch (\Exception $e) {
            return null;
        }

        return $this->departement;
    }

    /**
     * Set region.
     *
     * @param \Oru\Bundle\AddressBundle\Entity\LstRegion $region
     *
     * @return Address
     */
    public function setRegion(\Oru\Bundle\AddressBundle\Entity\LstRegion $region = null)
    {
        $this->region = $region;

        return $this;
    }

    /**
     * Get region.
     *
     * @return \Oru\Bundle\AddressBundle\Entity\LstRegion
     */
    public function getRegion()
    {
        try {
            if ($this->region) {
                $this->region->getDeleted();
            }
        } catch (\Exception $e) {
            return null;
        }

        return $this->region;
    }

    /**
     * @param string $adresse
     */
    public function setAdresse($adresse)
    {
        $this->adresse = $adresse;
    }

    /**
     * @return string
     */
    public function getAdresse()
    {
        return $this->adresse;
    }

    /**
     * @param string $adresseComplements
     * @param mixed  $adresseComplement
     */
    public function setAdresseComplement($adresseComplement)
    {
        $this->adresseComplement = $adresseComplement;
    }

    /**
     * @return string
     */
    public function getAdresseComplement()
    {
        return $this->adresseComplement;
    }

    /**
     * ToString avec un delimiter différent du \n par défaut.
     *
     * @param mixed $delimiter
     *
     * @return string
     */
    public function toString($delimiter = "\n")
    {
        return str_replace("\n", $delimiter, $this->__toString());
    }

    /**
     * @return string
     */
    public function getPays()
    {
        return $this->pays;
    }

    /**
     * @param string $pays
     */
    public function setPays($pays)
    {
        $this->pays = $pays;
    }

    /**
     * @param mixed $carto
     */
    public function setCarto($carto)
    {
        $this->carto = $carto;
    }

    /**
     * @return mixed $carto
     */
    public function getCarto()
    {
        return $this->carto;
    }

    /**
     * @return mixed
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param mixed $created
     */
    public function setCreated($created)
    {
        $this->created = $created;
    }

    /**
     * @return mixed
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * @param mixed $updated
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;
    }

    /**
     * Permet de savoir si l'adresse structurée est renseignée (ensemble de champs).
     *
     * @return bool
     */
    public function hasStructuredAddress()
    {
        return $this->typeVoie && $this->voie && $this->code && $this->commune;
    }
}
