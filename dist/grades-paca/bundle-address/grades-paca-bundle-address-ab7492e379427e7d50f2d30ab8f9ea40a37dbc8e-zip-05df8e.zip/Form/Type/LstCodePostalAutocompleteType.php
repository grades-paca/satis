<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 08/03/2016
 * Time: 15:59
 */

namespace Oru\Bundle\AddressBundle\Form\Type;

use Oru\Bundle\FormBundle\Form\Type\AutocompleteType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class LstCodePostalAutocompleteType.
 */
class LstCodePostalAutocompleteType extends AutocompleteType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array('class' => 'OruAddressBundle:LstCodePostal', 'placeholder' => 'Chercher une code postal', 'create' => false));
        $resolver->setDefined(array('fillCodePostal', 'fillCommune', 'fillLstDepartement'));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        $view->vars['create'] = $options['create'];

        if (array_key_exists('fillCodePostal', $options)) {
            $view->vars['fillCodePostal'] = $options['fillCodePostal'];
        }

        if (array_key_exists('fillCommune', $options)) {
            $view->vars['fillCommune'] = $options['fillCommune'];
        }

        if (array_key_exists('fillLstDepartement', $options)) {
            $view->vars['fillLstDepartement'] = $options['fillLstDepartement'];
        }
    }

    public function getBlockPrefix()
    {
        return 'oru_lstcodepostal_autocomplete';
    }
}
