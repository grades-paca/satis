<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use APY\DataGridBundle\Grid\Mapping as GRID;

/**
 * LstTerritoire
 */
class LstTerritoire extends Lst
{
    /**
     * @var LstRegion
     */
    private $region;

    /**
     * @return LstRegion
     */
    public function getRegion()
    {
        return $this->region;
    }

    /**
     * @param LstRegion $region
     */
    public function setRegion(LstRegion $region)
    {
        $this->region = $region;
    }


}
