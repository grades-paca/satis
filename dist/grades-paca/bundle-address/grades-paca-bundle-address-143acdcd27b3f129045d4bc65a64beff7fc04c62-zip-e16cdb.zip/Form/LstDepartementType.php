<?php

namespace Oru\Bundle\AddressBundle\Form;

use Oru\Bundle\LstBundle\Form\LstType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class LstDepartementType extends LstType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);
        $builder->add('region', null, array('required' => true, 'label' => 'Address.region', 'translation_domain' => 'OruAddressBundle'));
        $builder->add('code', null, array('label' => 'list.code', 'translation_domain' => 'OruLstBundle'));
        $builder->remove('codeDuplicated');
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\AddressBundle\Entity\LstDepartement',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_addressbundle_lstdepartement';
    }
}
