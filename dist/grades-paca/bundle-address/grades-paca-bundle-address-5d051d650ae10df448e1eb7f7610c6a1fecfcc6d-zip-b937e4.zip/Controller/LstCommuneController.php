<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 10/07/2015
 * Time: 10:31
 */

namespace Oru\Bundle\AddressBundle\Controller;

use Oru\Bundle\AddressBundle\Entity\LstCommune;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\DependencyInjection\Exception\ParameterNotFoundException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class LstCommuneController extends Controller{
    /**
     * Search for commune by his name.
     *
     * @param string $_format
     * @param string search : the term to search
     * @param integer structure : the id of the structure to search in
     * @return JsonResponse
     */
    public function searchLstCommunesAction(Request $request, $_format)
    {

        $communes = array();
        if ($request->get('search') == '') {
            throw new ParameterNotFoundException("Parameter 'search' not found.");
        }

        $page_limit = $request->get('page_limit', 10);
        if (!is_numeric($page_limit) || $page_limit > 100) {
            $page_limit = 10;
        }

        $first = 0;
        if ($request->get('first')) {
            $first = $request->get('first');
        }

        $total = 0;
        if ($request->get('infinite_scroll')) {
            $total = $this->getDoctrine()->getRepository('OruAddressBundle:LstCommune')->countSearchByNameCodePostal($request->get('search'));
        }

        $str_entities = $this->getDoctrine()->getRepository('OruAddressBundle:LstCommune')->searchByNameCodePostal($request->get('search'), $page_limit, $first);

        if (count($str_entities)) {
            /** @var LstCommune $str_entitie */
            foreach ($str_entities as $str_entitie) {
                if(count($str_entitie->getCodePostal())){
                    foreach($str_entitie->getCodePostal() as $codePostal){
                        $communes[] = array(
                            'id' => $str_entitie->getId(),
                            'libelle' => $str_entitie->__toString(),
                            'code' => $codePostal->getLibelle(),
                            'code_id' => $codePostal->getId(),
                            'departement_id' => $str_entitie->getDepartement()->getId(),
                            'departement_code' => $str_entitie->getDepartement()->getCode(),
                            'departement_libelle' => $str_entitie->getDepartement()->getLibelle()
                        );
                    }
                }else{
                    $communes[] = array(
                        'id' => $str_entitie->getId(),
                        'libelle' => $str_entitie->__toString(),
                        'code' => '',
                        'departement_id' => $str_entitie->getDepartement()->getId(),
                        'departement_code' => $str_entitie->getDepartement()->getCode(),
                        'departement_libelle' => $str_entitie->getDepartement()->getLibelle()
                    );
                }
            }
        }

        if ($_format == 'json') {
            return new JsonResponse(array('total' => $total, 'lstcommunes' => $communes));
        }
    }

    /**
     * Get a commune by identifier.
     *
     * @param id $_id
     * @param string $_format
     *
     * @return JsonResponse
     */
    public function getLstCommunesByIdsAction(Request $request, $_ids, $_format)
    {
        $ids = explode(',', $_ids);
        $communes = array();
        $entities = $this->getDoctrine()->getRepository('OruAddressBundle:LstCommune')->findById($ids);

        foreach ($entities as $entity) {
            if ($entity) {
                $communes[] = array('id' => $entity->getId(), 'libelle' => $entity->__toString());
            }
        }

        if ($_format == 'json') {
            return new JsonResponse($communes);
        }
    }
} 