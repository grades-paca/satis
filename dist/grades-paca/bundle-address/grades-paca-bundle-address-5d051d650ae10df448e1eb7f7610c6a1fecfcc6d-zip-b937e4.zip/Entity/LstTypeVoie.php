<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use JMS\Serializer\Annotation;

/**
 * LstTypeVoie
 * @Annotation\ExclusionPolicy("all")
 */
class LstTypeVoie extends Lst
{
}