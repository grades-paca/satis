<?php

namespace Oru\Bundle\AddressBundle\Entity;

use JMS\Serializer\Annotation;
use Oru\Bundle\LstBundle\Entity\Lst;

/**
 * LstTypeVoie.
 *
 * @Annotation\ExclusionPolicy("all")
 */
class LstTypeVoie extends Lst
{
}
