<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use JMS\Serializer\Annotation;
use APY\DataGridBundle\Grid\Mapping as GRID;

/**
 * LstTypeVoie
 * @GRID\Source(columns="id, code, libelle, oid, codeAsip")
 * @Annotation\ExclusionPolicy("all")
 */
class LstTypeVoie extends Lst
{
}