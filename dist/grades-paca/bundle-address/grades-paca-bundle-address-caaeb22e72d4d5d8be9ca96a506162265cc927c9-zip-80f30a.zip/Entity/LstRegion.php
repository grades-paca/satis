<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use APY\DataGridBundle\Grid\Mapping as GRID;

use JMS\Serializer\Annotation;

/**
 * LstRegion
 * @Annotation\ExclusionPolicy("all")
 */
class LstRegion extends Lst
{
    /**
     * @var \Doctrine\Common\Collections\Collection
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_structure"})
     */
    private $departements;

    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_structure"})
     */
    protected $id;

    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_structure"})
     */
    protected $libelle;

    /**
     * @var \Doctrine\Common\Collections\Collection
     */
    private $territoires;

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
        $this->departements = new \Doctrine\Common\Collections\ArrayCollection();
        $this->territoires = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add departements
     *
     * @param \Oru\Bundle\AddressBundle\Entity\LstDepartement $departements
     * @return LstRegion
     */
    public function addDepartement(\Oru\Bundle\AddressBundle\Entity\LstDepartement $departements)
    {
        $this->departements[] = $departements;
    
        return $this;
    }

    /**
     * Remove departements
     *
     * @param \Oru\Bundle\AddressBundle\Entity\LstDepartement $departements
     */
    public function removeDepartement(\Oru\Bundle\AddressBundle\Entity\LstDepartement $departements)
    {
        $this->departements->removeElement($departements);
    }

    /**
     * Get departements
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getDepartements()
    {
        return $this->departements;
    }

    /**
     * Add territoires
     *
     * @param \Oru\Bundle\AddressBundle\Entity\LstTerritoire $territoires
     * @return LstRegion
     */
    public function addTerritoire(\Oru\Bundle\AddressBundle\Entity\LstTerritoire $territoires)
    {
        $this->territoires[] = $territoires;

        return $this;
    }

    /**
     * Remove territoires
     *
     * @param \Oru\Bundle\AddressBundle\Entity\LstTerritoire $territoires
     */
    public function removeTerritoire(\Oru\Bundle\AddressBundle\Entity\LstTerritoire $territoires)
    {
        $this->territoires->removeElement($territoires);
    }

    /**
     * Get territoires
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTerritoires()
    {
        return $this->territoires;
    }
}
