<?php

namespace Oru\Bundle\AddressBundle\Update;

use Doctrine\ORM\EntityManager;
use Doctrine\ORM\NoResultException;
use Oru\Bundle\AddressBundle\Entity\LstCodePostal;
use RuntimeException;
use SplFileObject;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Filesystem\Filesystem;

/**
 * Class CpUpdate.
 *
 * @author Michaël VEROUX
 */
class CpUpdate
{
    /**
     * @var OutputInterface
     */
    protected $output;

    /**
     * @var array
     */
    protected $head = array(
        'code_postal' => null,
        'libelle_acheminement' => null,
        'insee' => null,
        'cedex' => null,
    );

    /**
     * @var EntityManager
     */
    protected $em;

    /**
     * @var array
     */
    protected $creationCodes = array();

    /**
     * CpUpdate constructor.
     *
     * @param EntityManager $em
     */
    public function __construct(EntityManager $em)
    {
        $this->em = $em;
    }

    /**
     * @param OutputInterface $output
     *
     * @return $this
     */
    public function setOutput($output)
    {
        $this->output = $output;

        $outputStyle = new OutputFormatterStyle('magenta', 'black', array('bold'));
        $output->getFormatter()->setStyle('warning', $outputStyle);

        return $this;
    }

    /**
     * @param string $filename
     *
     * @author Michaël VEROUX
     */
    public function execute($filename)
    {
        $fileObject = $this->load($filename);

        $this->process($fileObject);
    }

    /**
     * @param string      $message
     * @param string|null $type
     *
     * @author Michaël VEROUX
     */
    private function log($message, $type = null)
    {
        if (!$this->output instanceof OutputInterface) {
            return;
        }

        $pattern = '%s';

        if (null !== $type) {
            $pattern = sprintf('<%1$s>%%s</%1$s>', $type);
        }

        $this->output->writeln(sprintf($pattern, $message));
    }

    /**
     * @param string $filename
     *
     * @return SplFileObject
     *
     * @author Michaël VEROUX
     */
    private function load($filename)
    {
        $filesystem = new Filesystem();

        if (!$filesystem->exists($filename)) {
            throw new RuntimeException(sprintf('File "%s" does not exists!', $filename));
        }

        $fileObject = new SplFileObject($filename, 'r');
        $fileObject->setFlags(SplFileObject::READ_AHEAD | SplFileObject::READ_CSV | SplFileObject::SKIP_EMPTY);

        return $fileObject;
    }

    /**
     * @param SplFileObject $fileObject
     *
     * @author Michaël VEROUX
     */
    private function process(SplFileObject $fileObject)
    {
        $i = 0;
        while ($line = $fileObject->fgetcsv()) {
            if (null === $this->head['code_postal']) {
                $this->processHead($line);

                $codePostalIdx = $this->head['code_postal'];
                $libelleIdx = $this->head['libelle_acheminement'];
                $inseeIdx = $this->head['insee'];
                $cedexIdx = $this->head['cedex'];

                continue;
            }

            $codePostal = $line[$codePostalIdx];
            $libelle = $line[$libelleIdx];
            $insee = $line[$inseeIdx];
            $cedex = (bool) $line[$cedexIdx];

            $lstCodePostal = $this->findByCodePostalAndInsee($codePostal, $insee);
            $commune = $this->findCommuneByInsee($insee);

            if ($lstCodePostal) {
                if (!$lstCodePostal->getCommune() || $lstCodePostal->getCommune()->getCodeAsip() !== $insee) {
                    $this->log(sprintf('Mise à jour de "%s %s"', $codePostal, $libelle), 'warning');
                }
            }

            if (!$lstCodePostal && null !== $commune && !in_array($insee.$codePostal, $this->creationCodes, true)) {
                $this->creationCodes[] = $insee.$codePostal;

                $lstCodePostal = new LstCodePostal();
                $lstCodePostal->setCode($insee.$codePostal);
                $lstCodePostal->setLibelleAcheminement($libelle);
                $lstCodePostal->setLibelle($codePostal);
                $lstCodePostal->setCedex($cedex);

                $this->em->persist($lstCodePostal);

                $this->log(sprintf('Création de "%s %s"', $codePostal, $libelle), 'info');
            }

            if ($lstCodePostal) {
                $lstCodePostal->setCommune($commune);
            }
            if (!$commune) {
                $this->log(sprintf('La commune "%s %s" avec le code INSEE "%s" n\'existe pas.', $codePostal, $libelle, $insee), 'error');
            }
        }

        $this->em->flush();
    }

    /**
     * @param array $keys
     *
     * @author Michaël VEROUX
     */
    private function processHead(array $keys)
    {
        $headKeys = array_keys($this->head);
        foreach ($headKeys as $headKey) {
            $index = array_search($headKey, $keys, true);
            $this->head[$headKey] = $index;
        }

        $badValues = array_intersect(array(false, null), array_values($this->head));

        if (count($badValues)) {
            $missing = array_filter($this->head, function ($value) {
                if ($value) {
                    return false;
                }

                return true;
            });

            throw new RuntimeException('Les colonnes suivantes sont manquantes : '.implode(', ', array_keys($missing)));
        }
    }

    /**
     * @param string $codePostal
     * @param string $insee
     *
     * @return LstCodePostal|null
     *
     * @author Michaël VEROUX
     */
    private function findByCodePostalAndInsee($codePostal, $insee)
    {
        $qb = $this->em->getRepository('OruAddressBundle:LstCodePostal')->createQueryBuilder('cp');
        $qb->where('cp.code = :code');
        $qb->setParameter('code', $insee.$codePostal);

        try {
            $object = $qb->getQuery()->getSingleResult();
        } catch (NoResultException $e) {
            return null;
        }

        return $object;
    }

    /**
     * @param string $insee
     *
     * @return null|object|\Oru\Bundle\AddressBundle\Entity\LstCommune
     *
     * @author Michaël VEROUX
     */
    private function findCommuneByInsee($insee)
    {
        $commune = $this->em->getRepository('OruAddressBundle:LstCommune')->findOneBy(array(
            'codeAsip' => $insee,
        ));

        return $commune;
    }
}
