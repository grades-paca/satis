<?php

namespace Oru\Bundle\AddressBundle\Entity;

use APY\DataGridBundle\Grid\Mapping as GRID;
use JMS\Serializer\Annotation;
use Oru\Bundle\LstBundle\Entity\Lst;

/**
 * LstTypeVoie.
 *
 * @GRID\Source(columns="id, code, libelle, oid, codeAsip")
 * @Annotation\ExclusionPolicy("all")
 */
class LstTypeVoie extends Lst
{
}
