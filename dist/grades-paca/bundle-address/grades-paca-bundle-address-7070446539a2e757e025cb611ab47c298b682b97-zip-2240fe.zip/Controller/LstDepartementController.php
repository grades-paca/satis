<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 23/02/2017
 * Time: 13:56
 */

namespace Oru\Bundle\AddressBundle\Controller;

use Oru\Bundle\AddressBundle\Entity\LstDepartement;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\DependencyInjection\Exception\ParameterNotFoundException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

class LstDepartementController extends Controller
{
    public function searchLstDepartementAction(Request $request, $_format)
    {
        if ($request->get('search') === '') {
            throw new ParameterNotFoundException("Parameter 'search' not found.");
        }

        $page_limit = $request->get('page_limit', 10);
        if (!is_numeric($page_limit) || $page_limit > 100) {
            $page_limit = 10;
        }

        $first = 0;
        if ($request->get('first')) {
            $first = $request->get('first');
        }

        $total = 0;
        if ($request->get('infinite_scroll')) {
            $total = $this->getDoctrine()->getRepository('OruAddressBundle:LstDepartement')->searchByLibelleOrCode($request->get('search'), $page_limit, $first, true);
        }

        $departements = array();
        $entities = $this->getDoctrine()->getRepository('OruAddressBundle:LstDepartement')->searchByLibelleOrCode($request->get('search'), $page_limit, $first);
        /** @var LstDepartement $entity */
        foreach ($entities as $entity) {
            $departements[] = array(
                'id' => $entity->getId(),
                'libelle' => $entity->getLibelle(),
                'code' => $entity->getCode(),
            );
        }

        if ($_format === 'json') {
            return new JsonResponse(array('total' => $total, 'lstdepartements' => $departements));
        }
    }

    public function getLstDepartementsByIdsAction(Request $request, $_ids, $_format)
    {
        $ids = explode(',', $_ids);
        $departements = array();
        $entities = $this->getDoctrine()->getRepository('OruAddressBundle:LstDepartement')->findById($ids);

        foreach ($entities as $entity) {
            if ($entity) {
                $departements[] = array('id' => $entity->getId(), 'libelle' => $entity->__toString());
            }
        }

        if ($_format === 'json') {
            return new JsonResponse($departements);
        }
    }
}
