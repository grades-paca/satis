<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 07/07/2015
 * Time: 09:32
 */

namespace Oru\Bundle\AddressBundle\Command;

use Oru\Bundle\AddressBundle\Entity\Import;
use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class ImportCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    const FILE_COMMUNES = 'v2/communes.csv';
    const FILE_CP = 'v3/codes_postaux.csv';
    const FILE_QUARTIERS = 'v2/quartiers_iris.csv';

    public function AskAndDownloadFile($temp, InputInterface $input, OutputInterface $output)
    {
        $style = new OutputFormatterStyle('red', 'yellow', array('bold', 'blink'));
        $output->getFormatter()->setStyle('fire', $style);

        $src = $input->getArgument('src');
        $user = $input->getArgument('repoUser');
        $password = $input->getArgument('repoPassword');

        $url = $this->makeUrl($user, $password, $src);
        $fakeUrl = 'https://'.$user.':*******@'.$src;
        $output->writeln('<fire>Téléchargement du fichier source (.csv) : '.$fakeUrl.'</fire>');

        $file = null;
        try {
            $file = $this->DownloadFile($url, $temp);
        } catch (\Exception $e) {
            $output->writeln('<error>Erreur lors du téléchargement : '.$e->getMessage().'</error>');
        }

        return $file;
    }

    public function getMaxRunningTimeSec()
    {
        return 500;
    }

    public function isConcurentAllowed()
    {
        return false;
    }

    public function getTypeFieldFromArgumentName($name, &$type = TextType::class, &$options = array())
    {
    }

    protected function configure()
    {
        $this
            ->setName('oru:address:import')
            ->setDescription('Importe les données d\'adresse depuis l\'url d\'imports définie dans le ROR. La tâche est prévue pour être automatisée')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        //Initialisation
        $container = $this->getContainer();
        $em = $container->get('doctrine')->getManager();
        $cartoEnabled = !in_array('OruCartoBundle', $container->getParameter('disabled_bundles'), true);

        //Paramètres d'import
        $url = $container->getParameter('import_url');
        $user = $container->getParameter('import_user');
        $password = $container->getParameter('import_password');
        $realUrl = $this->makeUrl($url, $user, $password);

        //Communes
        $output->writeln('Import des communes : ');
        $cLastHash = $em->getRepository('OruAddressBundle:Import')->findLastImportByFile(self::FILE_COMMUNES);
        if ($cLastHash !== null) {
            $cLastHash = $cLastHash->getHash();
        }
        $cFile = tmpfile();
        $cHash = file_get_contents($this->DownloadFile($realUrl.'/'.self::FILE_COMMUNES.'.md5', $cFile));
        fclose($cFile);

        if ($cHash !== $cLastHash) {
            $cFile = tmpfile();
            $communes = $this->DownloadFile($realUrl.'/'.self::FILE_COMMUNES, $cFile);
            $this->getContainer()->get('oru_address.populate')->importCommunes($communes, $cartoEnabled);
            fclose($cFile);

            $import = new Import(self::FILE_COMMUNES, $cHash);
            $em->persist($import);
            $em->flush();
        } else {
            $output->writeln(' - Tout est à jour');
        }

        //Codes postaux
        $output->writeln('Import des codes postaux : ');
        $cpLastHash = $em->getRepository('OruAddressBundle:Import')->findLastImportByFile(self::FILE_CP);
        if ($cpLastHash !== null) {
            $cpLastHash = $cpLastHash->getHash();
        }
        $cpFile = tmpfile();
        $cpHash = file_get_contents($this->DownloadFile($realUrl.'/'.self::FILE_CP.'.md5', $cpFile));
        fclose($cpFile);

        if ($cpHash !== $cpLastHash) {
            $cpFile = tmpfile();
            $codesPostaux = $this->DownloadFile($realUrl.'/'.self::FILE_CP, $cpFile);
            $this->getContainer()->get('oru_address.populate')->importCodesPostaux($codesPostaux, $cartoEnabled);
            fclose($cpFile);

            $import = new Import(self::FILE_CP, $cpHash);
            $em->persist($import);
            $em->flush();
        } else {
            $output->writeln(' - Tout est à jour');
        }

        //Quartiers
        $output->writeln('Import des quartiers : ');
        $qLastHash = $em->getRepository('OruAddressBundle:Import')->findLastImportByFile(self::FILE_QUARTIERS);
        if ($qLastHash !== null) {
            $qLastHash = $qLastHash->getHash();
        }
        $qFile = tmpfile();
        $qHash = file_get_contents($this->DownloadFile($realUrl.'/'.self::FILE_QUARTIERS.'.md5', $qFile));
        fclose($qFile);

        if ($qHash !== $qLastHash) {
            $qFile = tmpfile();
            $quartiers = $this->DownloadFile($realUrl.'/'.self::FILE_QUARTIERS, $qFile);
            $this->getContainer()->get('oru_address.populate')->importQuartiersIris($quartiers);
            fclose($qFile);

            $import = new Import(self::FILE_QUARTIERS, $qHash);
            $em->persist($import);
            $em->flush();
        } else {
            $output->writeln(' - Tout est à jour');
        }

        //Autres
        $this->getContainer()->get('oru_address.populate')->linkCPToAddresses();
    }

    private function makeUrl($url, $user, $password)
    {
        return 'https://'.$user.':'.$password.'@'.$url;
    }

    private function DownloadFile($url, $temp)
    {
        $data = $this->getContainer()->get('oru_webclient.client')->get($url); //gestion du proxy

        $tempInfo = stream_get_meta_data($temp);
        $tempPath = $tempInfo['uri'];
        fwrite($temp, $data);

        return $tempPath;
    }
}
