<?php

namespace Oru\Bundle\AddressBundle\Entity;

use JMS\Serializer\Annotation;
use Oru\Bundle\LstBundle\Entity\LstAsip;

/**
 * LstDepartement.
 *
 * @Annotation\ExclusionPolicy("all")
 */
class LstDepartement extends LstAsip
{
    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_structure", "search"})
     */
    protected $id;

    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_structure","webservice", "search"})
     */
    protected $libelle;
    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstRegion
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $region;

    /**
     * @var LstCommune
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_communes"})
     */
    private $communes;

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getCode().' - '.$this->getLibelle();
    }

    /**
     * Set region.
     *
     * @param \Oru\Bundle\AddressBundle\Entity\LstRegion $region
     *
     * @return LstDepartement
     */
    public function setRegion(\Oru\Bundle\AddressBundle\Entity\LstRegion $region = null)
    {
        $this->region = $region;

        return $this;
    }

    /**
     * Get region.
     *
     * @return \Oru\Bundle\AddressBundle\Entity\LstRegion
     */
    public function getRegion()
    {
        try {
            if ($this->region) {
                $this->region->getDeleted();
            }
        } catch (\Exception $e) {
            return null;
        }

        return $this->region;
    }

    /**
     * @return mixed
     */
    public function getCompleteLibelle()
    {
        return $this->getCode().' - '.$this->getLibelle();
    }

    /**
     * @return LstCommune
     */
    public function getCommunes()
    {
        return $this->communes;
    }

    /**
     * @param LstCommune $communes
     */
    public function setCommunes($communes)
    {
        $this->communes = $communes;
    }
}
