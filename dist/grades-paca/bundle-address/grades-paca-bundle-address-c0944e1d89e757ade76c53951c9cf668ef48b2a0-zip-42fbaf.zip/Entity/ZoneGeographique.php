<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;

/**
 * ZoneGeographique.
 */
class ZoneGeographique
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var \DateTime
     */
    private $created;

    /**
     * @var \DateTime
     */
    private $updated;

    /**
     * @var ArrayCollection
     */
    private $regions;

    /**
     * @var ArrayCollection
     */
    private $departements;

    /**
     * @var ArrayCollection
     */
    private $communes;

    /**
     * @var ArrayCollection
     */
    private $quartiers;

    /**
     * ZoneGeographique constructor.
     */
    public function __construct()
    {
        $this->clear();
    }

    public function __clone()
    {
        $this->id = null;
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param \DateTime $created
     */
    public function setCreated($created)
    {
        $this->created = $created;
    }

    /**
     * @return \DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * @param \DateTime $updated
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;
    }

    /**
     * @param LstRegion $region
     *
     * @return $this
     */
    public function addRegion(LstRegion $region)
    {
        $this->regions[] = $region;

        return $this;
    }

    /**
     * @param LstRegion $region
     */
    public function removeRegion(LstRegion $region)
    {
        $this->regions->removeElement($region);
    }

    /**
     * @return ArrayCollection
     */
    public function getRegions()
    {
        if ($this->regions) {
            return $this->regions->filter(function ($elm) {
                try {
                    return $elm;
                } catch (\Exception $e) {
                    return false;
                }
            });
        }

        return new ArrayCollection();
    }

    /**
     * @param LstDepartement $departement
     *
     * @return $this
     */
    public function addDepartement(LstDepartement $departement)
    {
        $this->departements[] = $departement;

        return $this;
    }

    /**
     * @param LstDepartement $departement
     */
    public function removeDepartement(LstDepartement $departement)
    {
        $this->departements->removeElement($departement);
    }

    /**
     * @return ArrayCollection
     */
    public function getDepartements()
    {
        if ($this->departements) {
            return $this->departements->filter(function ($elm) {
                try {
                    return $elm;
                } catch (\Exception $e) {
                    return false;
                }
            });
        }

        return new ArrayCollection();
    }

    /**
     * @param LstCommune $commune
     *
     * @return $this
     */
    public function addCommune(LstCommune $commune)
    {
        $this->communes[] = $commune;

        return $this;
    }

    /**
     * @param LstCommune $commune
     */
    public function removeCommune(LstCommune $commune)
    {
        $this->communes->removeElement($commune);
    }

    /**
     * @return ArrayCollection
     */
    public function getCommunes()
    {
        if ($this->communes) {
            return $this->communes->filter(function ($elm) {
                try {
                    return $elm;
                } catch (\Exception $e) {
                    return false;
                }
            });
        }

        return new ArrayCollection();
    }

    /**
     * @param LstQuartierIris $quartier
     *
     * @return $this
     */
    public function addQuartier(LstQuartierIris $quartier)
    {
        $this->quartiers[] = $quartier;

        return $this;
    }

    /**
     * @param LstQuartierIris $quartier
     */
    public function removeQuartier(LstQuartierIris $quartier)
    {
        $this->quartiers->removeElement($quartier);
    }

    /**
     * @return ArrayCollection
     */
    public function getQuartiers()
    {
        if ($this->quartiers) {
            return $this->quartiers->filter(function ($elm) {
                try {
                    return $elm;
                } catch (\Exception $e) {
                    return false;
                }
            });
        }

        return new ArrayCollection();
    }

    /**
     * Vide la sélection de lieux.
     */
    public function clear()
    {
        $this->regions = new ArrayCollection();
        $this->departements = new ArrayCollection();
        $this->communes = new ArrayCollection();
        $this->quartiers = new ArrayCollection();
    }
}
