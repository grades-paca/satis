<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 10/07/2015
 * Time: 10:38
 */

namespace Oru\Bundle\AddressBundle\Entity;

use Oru\Bundle\LstBundle\Entity\LstRepository;

class LstCommuneRepository extends LstRepository
{
    /**
     * Search a commune by his name.
     * Results limited by default to 10.
     *
     * @param string $search the term searched
     * @param int    $limit  Max results
     * @param mixed  $first
     *
     * @return ArrayCollection A collection of OruAddressBundle:LstCommune
     */
    public function searchByName($search, $limit = 10, $first = 0)
    {
        $q = $this
            ->createQueryBuilder('c')
            ->andWhere('c.libelle like :search')
            ->setParameter('search', "%$search%")
            ->setMaxResults($limit)
            ->setFirstResult($first)
        ;

        return $q
            ->getQuery()
            ->getResult();
    }

    /**
     * Search a commune by his name or codePostal.
     * Results limited by default to 10.
     *
     * @param string $search the term searched
     * @param int    $limit  Max results
     * @param mixed  $first
     *
     * @return ArrayCollection A collection of OruAddressBundle:LstCommune
     */
    public function searchByNameCodePostal($search, $limit = 10, $first = 0)
    {
        $q = $this
            ->createQueryBuilder('c')
            ->leftJoin('c.codePostal', 'cp')
            ->andWhere('c.libelle like :search')
            ->orWhere('cp.code like :search')
            ->setParameter('search', "%$search%")
            ->setMaxResults($limit)
            ->setFirstResult($first)
        ;

        return $q
            ->getQuery()
            ->getResult();
    }

    /**
     * Count numbers of communes by her names.
     *
     * @param string $search the term searched
     *
     * @return ArrayCollection A collection of OruAddressBundle:LstCommune
     */
    public function countSearchByName($search)
    {
        $q = $this
            ->createQueryBuilder('c')
            ->select('COUNT(DISTINCT c.id)')
            ->andWhere('c.libelle like :search')
            ->setParameter('search', "%$search%")
        ;

        return $q
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * Count numbers of communes by her names or codePostal.
     *
     * @param string $search the term searched
     *
     * @return ArrayCollection A collection of OruAddressBundle:LstCommune
     */
    public function countSearchByNameCodePostal($search)
    {
        $q = $this
            ->createQueryBuilder("c")
            ->select('COUNT(DISTINCT c.id)')
            ->leftJoin('c.codePostal', 'cp')
            ->andWhere('c.libelle like :search')
            ->orWhere('cp.code like :search')
            ->setParameter('search', "%$search%")
        ;

        return $q
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * Query with relations for serializer.
     *
     * @param mixed $limit
     * @param mixed $offset
     *
     * @return mixed
     */
    public function findAllForSynchro($limit, $offset)
    {
        if ($this->_em->getFilters()->isEnabled('softdeleteable')) {
            $this->_em->getFilters()->disable('softdeleteable');
        }

        $builder = $this
            ->createQueryBuilder('u')
            ->select('u,dep')
            ->leftJoin('u.departement', 'dep')
            ->andWhere('(u.codeDuplicated IS NOT NULL AND u.deleted IS NOT NULL) OR u.deleted IS NULL')
            ->setFirstResult($offset)
            ->setMaxResults($limit)
            ->getQuery()
            ->execute()
        ;
        $this->_em->getFilters()->enable('softdeleteable');

        return $builder;
    }

    /**
     * Query with relations for serializer.
     *
     * @param $code
     *
     * @return mixed
     */
    public function findOneByCodeForSynchro($code)
    {
        return $this
            ->createQueryBuilder('u')
            ->select('u,dep')
            ->leftJoin('u.departement', 'dep')
            ->andWhere('u.code LIKE :code')
            ->setParameter('code', $code)
            ->getQuery()
            ->getSingleResult()
        ;
    }
}
