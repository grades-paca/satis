<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 14/09/2015
 * Time: 10:19
 */

namespace Oru\Bundle\AddressBundle\Entity;

class Import
{
    private $id;
    private $createdAt;
    private $hash;
    private $fileName;

    public function __construct($fileName = null, $hash = null)
    {
        $this->createdAt = new \DateTime();
        $this->fileName = $fileName;
        $this->hash = $hash;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * @param mixed $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    }

    /**
     * @return mixed
     */
    public function getHash()
    {
        return $this->hash;
    }

    /**
     * @param mixed $hash
     */
    public function setHash($hash)
    {
        $this->hash = $hash;
    }

    /**
     * @return mixed
     */
    public function getFileName()
    {
        return $this->fileName;
    }

    /**
     * @param mixed $fileName
     */
    public function setFileName($fileName)
    {
        $this->fileName = $fileName;
    }
}
