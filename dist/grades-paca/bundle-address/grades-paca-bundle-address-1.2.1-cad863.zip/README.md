Bundle OruAddressBundle
======================

Description
-----------

Ce bundle fournit une gestion simplifiée d'adresses. Voici la liste des champs disponibles :
- numero : chaîne de caractère (taille : 10)
- numeroComplement : chaîne de caractère (taille : 10)
- type_voie: liste administrable
- voie: chaîne de caractère (taille : 255)
- code : chaîne de caractère (taille : 20)
- localite : chaîne de caractère (taille : 100)
- commune : chaîne de caractère (taille : 100)
- bassinVie : liste adinistrable
- département : liste administrable

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/address":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\AddressBundle\OruAddressBundle();
```

Dans le routing.yml, ajouter la nouvelle route :

```
oru_address:
    resource: "@OruAddressBundle/Resources/config/routing.xml"
```

Vider le cache de Symfony2

Utilisation
-----------

Il suffit d'embarquer la classe AddressType pour bénéficier du formulaire de saisie d'une adresse.
@todo : remplacer l'appel direct à ce formulaire par un service.

```
$builder
    ...
    ->add('adresse', new AddressType(), array('label' => 'Etablissement.adresse', 'translation_domain' => 'OruEtablissementBundle'))
    ...
;
```

L'affichage de l'adresse peut se faire vi le template show.html.twig :
@todo: remplacer par une fonction twig

```
{% include 'OruAddressBundle:Default:show.html.twig' with {'entity' : entity.getAdresse } %}
```
