<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 06/10/2016
 * Time: 13:49
 */

namespace Oru\Bundle\AddressBundle\Form\DataTransformer;


use Doctrine\Common\Util\Debug;
use Doctrine\ORM\EntityManager;
use Oru\Bundle\AddressBundle\Entity\ZoneGeographique;
use Symfony\Component\Form\DataTransformerInterface;

class ZoneGeographiqueTreeTransformer implements DataTransformerInterface
{
    /**
     * @var EntityManager
     */
    private $em;

    public function __construct(EntityManager $em = null)
    {
        $this->em = $em;
    }

    public function transform($zone)
    {
        /** @var ZoneGeographique $zone */
        if($zone){

            $regions = array();
            foreach($zone->getRegions() as $region){
                $regions[] = $region->getId();
            }

            $departements = array();
            foreach($zone->getDepartements() as $departement){
                $departements[] = $departement->getId();
            }

            $communes = array();
            foreach($zone->getCommunes() as $commune){
                $communes[] = array(
                    'id' => $commune->getId(),
                    'departement' => $commune->getDepartement()->getId()
                );
            }

            $quartiers = array();
            foreach($zone->getQuartiers() as $quartier){
                $quartiers[] = array(
                    'id' => $quartier->getId(),
                    'commune' => $quartier->getCommune()->getId(),
                    'departement' => $quartier->getCommune()->getDepartement()->getId()
                );
            }

            return json_encode(array(
                'id' => $zone->getId(),
                'region' => $regions,
                'departement' => $departements,
                'commune' => $communes,
                'quartier' => $quartiers
            ));
        }

        return '';
    }

    public function reverseTransform($data)
    {
        $zone = null;
        if(!empty($data)){
            $data = json_decode($data);
            $zone = new ZoneGeographique();
            if(!empty($data->id)){
                $zone = $this->em->getRepository('OruAddressBundle:ZoneGeographique')->find($data->id);
            }

            $zone->clear();

            if(!empty($data->region)){
                $regions = array();
                foreach($data->region as $region){
                    $regions[] = $this->em->getReference('OruAddressBundle:LstRegion', $region);
                }
                $zone->setRegions($regions);
            }

            if(!empty($data->departement)){
                $departements = array();
                foreach($data->departement as $departement){
                    $departements[] = $this->em->getReference('OruAddressBundle:LstDepartement', $departement);
                }
                $zone->setDepartements($departements);
            }

            if(!empty($data->commune)){
                $communes = array();
                foreach($data->commune as $commune){
                    $communes[] = $this->em->getReference('OruAddressBundle:LstCommune', $commune);
                }
                $zone->setCommunes($communes);
            }

            if(!empty($data->quartier)){
                $quartiers = array();
                foreach($data->quartier as $quartier){
                    $quartiers[] = $this->em->getReference('OruAddressBundle:LstQuartierIris', $quartier);
                }
                $zone->setQuartiers($quartiers);
            }
        }

        return $zone;
    }
}