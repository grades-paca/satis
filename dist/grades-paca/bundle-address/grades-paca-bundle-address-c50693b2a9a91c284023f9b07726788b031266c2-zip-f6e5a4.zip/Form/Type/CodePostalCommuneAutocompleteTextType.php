<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 29/09/2016
 * Time: 10:43
 */

namespace Oru\Bundle\AddressBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormView;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CodePostalCommuneAutocompleteTextType extends AbstractType
{
    const FOCUS_CODE = 0;
    const FOCUS_COMMUNE = 1;

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefined(array( 'results', 'infinite_scroll', 'minimum', 'allow_clear', 'placeholder', 'closeOnSelect', 'fillCodePostal', 'fillCommune', 'focus'));
        $resolver->setDefaults(array( 'results' => 10, 'infinite_scroll' => true, 'minimum' => 3, 'placeholder' => 'Chercher', 'closeOnSelect' => false, 'compound' => false, 'focus' => self::FOCUS_CODE));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        if(array_key_exists('fillCodePostal', $options)){
            $view->vars['fillCodePostal'] = $options['fillCodePostal'];
        }

        if(array_key_exists('fillCommune', $options)){
            $view->vars['fillCommune'] = $options['fillCommune'];
        }

        $view->vars['focus'] = $options['focus'];

        //Allow Clear Par défaut indexé sur le required, sauf si affectation explicite
        $view->vars['allow_clear'] = ($options['required']) ? 'false' : 'true';
        if(array_key_exists('allow_clear', $options) && $options['allow_clear'] === true){
            $view->vars['allow_clear'] = true;
        }

        $view->vars['results'] = $options['results'];
        $view->vars['infinite_scroll'] = ($options['infinite_scroll']) ? 'true' : 'false';
        $view->vars['minimum'] = $options['minimum'];
        $view->vars['placeholder'] = $options['placeholder'];
        $view->vars['required'] = $options['required'];
        $view->vars['closeOnSelect'] = $options['closeOnSelect'];
    }

    public function getName()
    {
        return 'oru_codepostal_commune_autocomplete_text';
    }
}