<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 23/02/2017
 * Time: 13:49
 */

namespace Oru\Bundle\AddressBundle\Form\Type;

use Oru\Bundle\FormBundle\Form\Type\AutocompleteType;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;

class LstDepartementAutocompleteType extends AutocompleteType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array(
            'class' => 'OruAddressBundle:LstDepartement',
            'placeholder' => 'Chercher un département',
            'results'   => 100,
            'minimum'   => 2
        ));
        $resolver->setDefined(array('fillCodePostal', 'fillCommune'));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        if(array_key_exists('fillCodePostal', $options)){
            $view->vars['fillCodePostal'] = $options['fillCodePostal'];
        }

        if(array_key_exists('fillCommune', $options)){
            $view->vars['fillCommune'] = $options['fillCommune'];
        }
    }

    public function getName()
    {
        return 'oru_lstdepartement_autocomplete';
    }
}