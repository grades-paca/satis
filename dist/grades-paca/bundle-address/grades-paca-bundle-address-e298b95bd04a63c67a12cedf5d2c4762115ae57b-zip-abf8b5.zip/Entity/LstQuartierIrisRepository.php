<?php
/**
 * André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\AddressBundle\Entity;


use Doctrine\ORM\EntityRepository;
use Oru\Bundle\LstBundle\Entity\LstRepository;

class LstQuartierIrisRepository extends LstRepository
{
    /**
     * Query with relations for serializer.
     *
     * @return mixed
     */
    public function findAllForSynchro($limit, $offset)
    {
        if ($this->_em->getFilters()->isEnabled('softdeleteable')) {
            $this->_em->getFilters()->disable('softdeleteable');
        }

        $builder = $this
            ->createQueryBuilder('u')
            ->select('u,com')
            ->leftJoin('u.commune', 'com')
            ->andWhere('(u.codeDuplicated IS NOT NULL AND u.deleted IS NOT NULL) OR u.deleted IS NULL')
            ->setFirstResult($offset)
            ->setMaxResults($limit)
            ->getQuery()
            ->execute()
        ;
        $this->_em->getFilters()->enable('softdeleteable');

        return $builder;
    }

    /**
     * Query with relations for serializer.
     *
     * @param $code
     *
     * @return mixed
     */
    public function findOneByCodeForSynchro($code)
    {
        return $this
            ->createQueryBuilder('u')
            ->select('u,com')
            ->leftJoin('u.commune', 'com')
            ->andWhere('u.code LIKE :code')
            ->setParameter('code', $code)
            ->getQuery()
            ->getSingleResult()
        ;
    }
} 