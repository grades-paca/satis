Bundle OruAddressBundle
======================

Description
-----------

Ce bundle fournit une gestion simplifiée d'adresses. Voici la liste des champs disponibles :
- numero : chaîne de caractère (taille : 10)
- numeroComplement : chaîne de caractère (taille : 10)
- type_voie: liste administrable
- voie: chaîne de caractère (taille : 255)
- code : chaîne de caractère (taille : 20)
- localite : chaîne de caractère (taille : 100)
- commune : chaîne de caractère (taille : 100)
- bassinVie : liste adinistrable
- département : liste administrable

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/address":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\AddressBundle\OruAddressBundle();
```

Dans le routing.yml, ajouter la nouvelle route :

```
oru_address:
    resource: "@OruAddressBundle/Resources/config/routing.xml"
```

Vider le cache de Symfony2

Utilisation
-----------

Il suffit d'embarquer la classe AddressType pour bénéficier du formulaire de saisie d'une adresse.
@todo : remplacer l'appel direct à ce formulaire par un service.

```
$builder
    ...
    ->add('adresse', new AddressType(), array('label' => 'Etablissement.adresse', 'translation_domain' => 'OruEtablissementBundle'))
    ...
;
```

L'affichage de l'adresse peut se faire vi le template show.html.twig :
@todo: remplacer par une fonction twig

```
{% include '@OruAddress/Default/show.html.twig' with {'entity' : entity.getAdresse } %}
```


Champs utiles
------------

Le bundle propose deux champs utiles aux formulaires: la sélection d'un code postal et d'une commune
les champs peuvent être utilisés en étant mappés à l'entité. Dans ce cas l'entité gardera une liaison forte à la valeur via la relation SQL.
Les champs peuvent être utilisés en tant qu'aide à la saisie, sans être mappés. Dans ce cas, la sélection d'une valeur remplira automatiquement un autre champ souhaité du formulaire

Exemple d'utilisation:

```
$builder
    ...
    ->add('codePostalAuto', 'oru_lstcodepostal_autocomplete', array(
                    'mapped' => false,
                    'fillCodePostal' => 'codePostal', //L'option permet de spécifier le champ du formulaire représentant le code postal à remplir automatiquement
                    'fillCommune' => 'commune' //L'option permet de spécifier le champ du formulaire représentant la commune à remplir automatiquement
                ))
    ->add('codePostal', 'text') // Champ code postal en texte, pas de liaison forte
    ->add('commune', 'text') // Champ commune en texte, pas de liaison forte
    ...
;
```

Import et référentiel
------------

+Le mécanisme d'import permet l'import de diverses entités géographiques dans le référentiel, dont:+

* Les communes
* Les quartiers (iris)
* Les codes postaux

L'import s'effectue depuis le référentiel, les instances du ROR se mettent à jour sur le référentiel.
Il est important de noter qu'actuellement l'import ne gère pas les problématiques de fusions de communes, quartiers ou codes postaux.

+L'import se fait sur la base de fichiers CSV (data.gouv.fr généralement), stockés sur un dépôt paramétré dans le portail via les settings:+

* import_url
* import_user
* import_password

+Pour toute nouvelle version des communes, quartiers, codes postaux, il faut à minima:+

* Récupérer et modifier le fichier CSV, pour faire en sorte que l'ordre des colonnes corresponde bien à ce qui est importé via le bundle (vendor/oru/address/Oru/Bundle/AddressBundle/Service/PopulateService.php)
* Créer une nouvelle version si la structure de l'import évolue et que le code est modifié (v1,v2,v3)
* Créer un hash md5 (même nom de fichier .md5) que le fichier csv, et l'envoyer dans le dépôt avec ce dernier. L'import se base sur le md5 pour importer ou non les données
