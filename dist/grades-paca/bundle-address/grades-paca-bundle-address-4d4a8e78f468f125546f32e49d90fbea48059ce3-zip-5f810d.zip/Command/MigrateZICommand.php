<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 09/07/2015
 * Time: 09:48
 */

namespace Oru\Bundle\AddressBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Application;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Input\InputDefinition;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;
use Oru\Bundle\AddressBundle\Command\ImportCommand;

class MigrateZICommand extends ImportCommand
{
    protected function configure()
    {
        $this
            ->setName('oru:address:migrate_zones_intervention')
            ->setDescription('Migre les zones d\'intervention de l\'ancienne table à la table des communes désormais')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->getContainer()->get('oru_address.populate')->migrateZonesIntervention();
    }

}