<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 29/09/2016
 * Time: 10:43
 */

namespace Oru\Bundle\AddressBundle\Form\Type;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\AddressBundle\Form\DataTransformer\ZoneGeographiqueTreeTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormView;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\FormBuilderInterface;

class ZoneGeographiqueTreeType extends AbstractType{

    private $em;
    public function __construct(EntityManager $em)
    {
        $this->em = $em;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array('class' => 'OruAddressBundle:ZoneGeographique', 'compound' => false));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);

        $transformer = new ZoneGeographiqueTreeTransformer($this->em);
        $builder->addModelTransformer($transformer);
    }

    public function getName()
    {
        return 'oru_zone_geographique_tree';
    }
}