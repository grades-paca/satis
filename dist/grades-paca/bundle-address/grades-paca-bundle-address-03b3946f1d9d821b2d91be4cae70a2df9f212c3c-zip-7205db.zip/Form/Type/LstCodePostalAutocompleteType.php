<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 08/03/2016
 * Time: 15:59
 */

namespace Oru\Bundle\AddressBundle\Form\Type;

use Oru\Bundle\FormBundle\Form\Type\AutocompleteType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

class LstCodePostalAutocompleteType extends AutocompleteType {

    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array('class' => 'OruAddressBundle:LstCodePostal', 'placeholder' => 'Chercher une code postal', 'create' => false));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        $view->vars['create'] = $options['create'];
    }

    public function getName()
    {
        return 'oru_lstcodepostal_autocomplete';
    }
} 