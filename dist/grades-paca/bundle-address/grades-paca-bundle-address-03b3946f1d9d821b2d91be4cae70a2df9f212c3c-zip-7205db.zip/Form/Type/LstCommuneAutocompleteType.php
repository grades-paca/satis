<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 09/07/2015
 * Time: 11:25
 */

namespace Oru\Bundle\AddressBundle\Form\Type;

use Oru\Bundle\FormBundle\Form\Type\AutocompleteType;
use Oru\Bundle\AddressBundle\Entity\LstCommune;
use Oru\Bundle\AddressBundle\Form\LstCommuneType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

class LstCommuneAutocompleteType extends  AutocompleteType{
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array('class' => 'OruAddressBundle:LstCommune', 'placeholder' => 'Chercher une commune', 'create' => false));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        $view->vars['create'] = $options['create'];
    }

    public function getName()
    {
        return 'oru_lstcommune_autocomplete';
    }
} 