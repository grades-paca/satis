<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use JMS\Serializer\Annotation;
use APY\DataGridBundle\Grid\Mapping as GRID;

/**
 * LstCodePostal
 * @GRID\Source(columns="id, code, libelle, oid, codeAsip, cedex")
 * @Annotation\ExclusionPolicy("all")
 */
class LstCodePostal extends Lst
{
    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstCommune
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $commune;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $libelleAcheminement;

    /**
     * @var float
     */
    private $lat;

    /**
     * @var float
     */
    private $lng;

    /**
     * @var boolean
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $cedex;

    /**
     * @return LstCommune
     */
    public function getCommune()
    {
        try{
            if($this->commune){
                $this->commune->getDeleted();
            }
        }catch(\Exception $e){
            return null;
        }

        return $this->commune;
    }

    /**
     * @param LstCommune $commune
     */
    public function setCommune(LstCommune $commune)
    {
        $this->commune = $commune;
    }

    /**
     * @return mixed
     */
    public function getLibelleAcheminement()
    {
        return $this->libelleAcheminement;
    }

    /**
     * @param mixed $libelleAcheminement
     */
    public function setLibelleAcheminement($libelleAcheminement)
    {
        $this->libelleAcheminement = $libelleAcheminement;
    }

    /**
     * @return float
     */
    public function getLat()
    {
        return $this->lat;
    }

    /**
     * @param float $lat
     */
    public function setLat($lat)
    {
        $this->lat = $lat;
    }

    /**
     * @return float
     */
    public function getLng()
    {
        return $this->lng;
    }

    /**
     * @param float $lng
     */
    public function setLng($lng)
    {
        $this->lng = $lng;
    }

    /**
     * @return bool
     */
    public function isCedex()
    {
        return $this->cedex;
    }

    /**
     * @param bool $cedex
     */
    public function setCedex($cedex)
    {
        $this->cedex = $cedex;
    }
}
