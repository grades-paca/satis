Bundle OruAddressBundle
======================

Description
-----------

Ce bundle fournit une gestion générique des adresses et des entités associées, notamment:

* Les Régions et départements
* Les communes, codes postaux, quartiers Iris, types de voies, etc.
* Les zones d'intervention, telles qu'elles ont été définies par le GIP (https://docs.google.com/document/d/1jojgKpECa28DNwICHLW9G35qcB5DFVGbCUE0pLvoC48/edit)
* Les territoires

Le bundle gère le référentiel des entités suivantes:

* Régions
* Départements
* Communes
* Quartiers (Iris)
* Codes postaux

C'est le portail ROR référentiel qui tient cette responsabilité en implémentant le bundle. Un mécanisme d'import, vieillissant, est intégré au bundle, et permet le peuplement des données des entités évoquées ci-dessus depuis des fichiers CSV récupérés depuis data.gouv.fr, une rubrique ci-dessous est dédiée aux problématiques liées à l'import et au référentiel.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/address":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\AddressBundle\OruAddressBundle();
```

Dans le routing.yml, ajouter la nouvelle route :

```
oru_address:
    resource: "@OruAddressBundle/Resources/config/routing.xml"
```

Vider le cache de Symfony2

Utilisation du formulaire générique
-----------

Il suffit d'embarquer la classe AddressType pour bénéficier du formulaire de saisie d'une adresse.

```
$builder
    ...
    ->add('adresse', 'oru_address', array('label' => 'Etablissement.adresse', 'translation_domain' => 'OruEtablissementBundle'))
    ...
;
```

L'affichage de l'adresse peut se faire via le template show.html.twig :
@todo: remplacer par une fonction twig

```
{% include '@OruAddress/Default/show.html.twig' with {'entity' : entity.getAdresse } %}
```


Champs utiles
------------

Le bundle propose deux champs utiles aux formulaires: la sélection d'un code postal et d'une commune
les champs peuvent être utilisés en étant mappés à l'entité. Dans ce cas l'entité gardera une liaison forte à la valeur via la relation SQL.
Les champs peuvent être utilisés en tant qu'aide à la saisie, sans être mappés. Dans ce cas, la sélection d'une valeur remplira automatiquement un autre champ souhaité du formulaire

Exemple d'utilisation:

```
$builder
    ...
    ->add('codePostalAuto', 'oru_lstcodepostal_autocomplete', array(
                    'mapped' => false,
                    'fillCodePostal' => 'codePostal', //L'option permet de spécifier le champ du formulaire représentant le code postal à remplir automatiquement
                    'fillCommune' => 'commune' //L'option permet de spécifier le champ du formulaire représentant la commune à remplir automatiquement
                ))
    ->add('codePostal', 'text') // Champ code postal en texte, pas de liaison forte
    ->add('commune', 'text') // Champ commune en texte, pas de liaison forte
    ...
;
```

Import et référentiel
------------

Le mécanisme d'import permet l'import de diverses entités géographiques dans le référentiel, dont:

* Les communes
* Les quartiers (iris)
* Les codes postaux

L'import s'effectue sur le référentiel, les instances du ROR se mettent à jour depuis le référentiel.
Il est important de noter qu'actuellement **l'import ne gère pas les problématiques de fusions de communes, quartiers ou codes postaux**.

L'import se fait sur la base de fichiers CSV (data.gouv.fr généralement), stockés sur un dépôt paramétré dans le portail via les settings:

* import_url
* import_user
* import_password

Pour toute nouvelle version des communes, quartiers, codes postaux, il faut à minima:

* Récupérer et modifier le fichier CSV, pour faire en sorte que l'ordre des colonnes corresponde bien à ce qui est importé via le bundle (vendor/oru/address/Oru/Bundle/AddressBundle/Service/PopulateService.php)
* Créer une nouvelle version si la structure de l'import évolue et que le code est modifié (v1,v2,v3)
* Créer un hash md5 (même nom de fichier .md5) que le fichier csv, et l'envoyer dans le dépôt avec ce dernier. L'import se base sur le md5 pour importer ou non les données

Note importante: cette gestion de l'import via des versions de fichiers csv et md5 (la table oru_address_import contient l'historique des imports) a été prévue à l'origine lorsque chaque portail ROR faisait ses propres imports, elle est obsolète et devrait être revue. Toutefois il est possible d'effectuer l'import depuis le référentiel de cette manière, il faut être très attentif à la structure des CSV, et aux données existantes dans le référentiel, comme évoqué plus haut, l'import n'est pas prévu pour cohexister avec des données déjà utilisées, donc il n'y a pas de fusion de prévue, ou de remplacement, il y a simplement un INSERT IGNORE qui permet de ne pas recréer les codes existants, mais ne peut pas les mettre à jour, il faut tenir compte de toute la problématique de synchronisation au référentiel, et l'utilisation de ces données par les portails ROR qui s'y synchronisent. 

**Attention**, lors d'un import dans la base du référentiel, à toujours vérifier la problématique des "0" en début de codes postaux, qui doivent bien s'importer (le champ doit être reconnu comme un string et pas comme un entier)