<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use APY\DataGridBundle\Grid\Mapping as GRID;
use JMS\Serializer\Annotation;

/**
 * LstDepartement
 */
class LstDepartement extends Lst
{
    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstRegion
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $region;

    /**
     * Set region
     *
     * @param \Oru\Bundle\AddressBundle\Entity\LstRegion $region
     * @return LstDepartement
     */
    public function setRegion(\Oru\Bundle\AddressBundle\Entity\LstRegion $region = null)
    {
        $this->region = $region;
    
        return $this;
    }

    /**
     * Get region
     *
     * @return \Oru\Bundle\AddressBundle\Entity\LstRegion 
     */
    public function getRegion()
    {
        return $this->region;
    }

    /**
     * @return mixed
     */
    public function getCompleteLibelle()
    {
        return $this->getCode()." - ".$this->getLibelle();
    }



}
