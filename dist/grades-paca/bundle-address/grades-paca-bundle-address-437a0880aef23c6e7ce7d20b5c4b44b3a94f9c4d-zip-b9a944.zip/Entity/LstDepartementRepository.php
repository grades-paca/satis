<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 23/02/2017
 * Time: 14:17
 */

namespace Oru\Bundle\AddressBundle\Entity;


use Doctrine\ORM\EntityRepository;
use Oru\Bundle\LstBundle\Entity\LstRepository;

class LstDepartementRepository extends LstRepository
{
    /**
     * @param $search
     * @param int $limit
     * @param int $first
     * @param bool $count
     * @return array
     */
    public function searchByLibelleOrCode($search, $limit = 10, $first = 0, $count = false){
        $q = $this->createQueryBuilder("d");

        if($count){
            $q->select('COUNT(DISTINCT d.id)');
        }

        $q->where("d.libelle like :search")
            ->orWhere("d.code like :search")
            ->setParameter('search', "%$search%")
        ;

        if($count){
            return $q
                ->getQuery()
                ->getSingleScalarResult();
            ;
        }else{
            return $q
                ->setMaxResults($limit)
                ->setFirstResult($first)
                ->getQuery()
                ->getResult()
            ;
        }
    }

    /**
     * Permet de récupérer les listes en doublons
     */
    public function findAllAndDuplicated($limit, $offset)
    {
        if($this->_em->getFilters()->isEnabled('softdeleteable')) {
            $this->_em->getFilters()->disable('softdeleteable');
        }

        $builder = $this->createQueryBuilder('l')
            ->leftJoin('l.region', 'r')
            ->andWhere('(l.codeDuplicated IS NOT NULL AND l.deleted IS NOT NULL) OR l.deleted IS NULL')
            ->andWhere('r.deleted IS NULL')
            ->setFirstResult($offset)
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();

        $this->_em->getFilters()->enable('softdeleteable');

        return $builder;
    }
}