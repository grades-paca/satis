<?php

namespace Oru\Bundle\AddressBundle\Repair;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\AddressBundle\Entity\Address;
use Oru\Bundle\AddressBundle\Entity\LstCodePostal;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class CpLinkRepair.
 *
 * Le service fonctionne de manière à trouver à tout prix une liaison.
 * La liaison la plus juste possible quand les données le permettent.
 *
 * @author Michaël VEROUX
 */
class CpLinkRepair
{
    /**
     * @var EntityManager
     */
    protected $em;

    /**
     * @var OutputInterface
     */
    protected $output;

    /**
     * CpLinkRepair constructor.
     *
     * @param EntityManager $em
     */
    public function __construct(EntityManager $em)
    {
        $this->em = $em;
    }

    /**
     * @param OutputInterface $output
     *
     * @return $this
     */
    public function setOutput(OutputInterface $output)
    {
        $this->output = $output;

        return $this;
    }

    public function execute()
    {
        $entities = $this->findOrphanEntities();

        foreach ($entities as $entity) {
            $codePostal = $this->findCodePostal($entity->getCode());

            // On fait la liaison
            if (1 === count($codePostal)) {
                $item = array_shift($codePostal);
                $this->log($entity->getCode() . ' ' . $entity->getCommune(), 'info');
                $this->log($item->getLibelle() . ' ' .$item->getLibelleAcheminement());

                $entity->setCodePostal($item);
            }

            // On cherche le meilleur match
            if (1 < count($codePostal)) {
                $this->log($entity->getCode() . ' ' . $entity->getCommune(), 'info');

                $item = $this->getBetterCommuneMatch($codePostal, $entity->getCommune());
                if ($item) {
                    $this->log($item->getLibelle() . ' ' .$item->getLibelleAcheminement());

                    $entity->setCodePostal($item);
                } else {
                    $this->log('NULL');
                }
            }

        }

        $this->em->flush();
    }

    /**
     * @param string      $message
     * @param string|null $type
     *
     * @author Michaël VEROUX
     */
    private function log($message, $type = null)
    {
        if (!$this->output instanceof OutputInterface) {
            return;
        }

        $pattern = '%s';

        if ('info' === $type) {
            $pattern = '<info>%s</info>';
        }

        $this->output->writeln(sprintf($pattern, $message));
    }

    /**
     * @param LstCodePostal[] $entities
     * @param string    $commune
     *
     * @return LstCodePostal
     *
     * @author Michaël VEROUX
     */
    private function getBetterCommuneMatch($entities, $commune)
    {
        $commune = strtoupper($commune);
        $commune = preg_replace('#[\'-]#', ' ', $commune);
        $commune = preg_replace('#\bCDX\b#', 'CEDEX', $commune);

        $hasSaint = array_filter($entities, function (LstCodePostal $entity) {
            if (preg_match('#\bSAINTE?\b#', $entity->getLibelleAcheminement())) {
                return true;
            }

            return false;
        });
        if (count($hasSaint)) {
            $commune = preg_replace('#\bST(E?)\b#', 'SAINT$1', $commune);
        }

        $hasSt = array_filter($entities, function (LstCodePostal $entity) {
            if (preg_match('#\bSTE?\b#', $entity->getLibelleAcheminement())) {
                return true;
            }

            return false;
        });
        if (count($hasSt)) {
            $commune = preg_replace('#\bSAINT(E?)\b#', 'ST$1', $commune);
        }

        $communeWords = explode(' ', $commune);

        $betterMatchScore = 0;
        $bestEntity = null;

        foreach ($entities as $entity) {
            $communeRefWords = explode(' ', $entity->getLibelleAcheminement());

            $matches = array_intersect($communeWords, $communeRefWords);
            $matchesCount = count($matches);

            if ($matchesCount === count($communeWords)) {
                return $entity;
            }

            if (0 < $matchesCount && $matchesCount > $betterMatchScore) {
                $betterMatchScore = $matchesCount;
                $bestEntity = $entity;
            }
        }

        if (null === $bestEntity) {
            return array_shift($entities);
        }

        return $bestEntity;
    }

    /**
     * @return Address[]
     *
     * @author Michaël VEROUX
     */
    private function findOrphanEntities()
    {
        $qb = $this->em->getRepository('OruAddressBundle:Address')->createQueryBuilder('a');
        $qb->where('a.codePostal IS NULL');
        $qb->andWhere('a.code IS NOT NULL');
        $qb->andWhere('a.code != :empty');
        $qb->andWhere('a.commune IS NOT NULL');
        $qb->andWhere('a.commune != :empty');

        $qb->setParameter('empty', '');

        $entities = $qb->getQuery()->execute();

        return $entities;
    }

    /**
     * @param string $codePostal
     *
     * @return LstCodePostal[]
     *
     * @author Michaël VEROUX
     */
    private function findCodePostal($codePostal)
    {
        $qb = $this->em->getRepository('OruAddressBundle:LstCodePostal')->createQueryBuilder('c');
        $qb->where('c.libelle = :cp');

        $qb->setParameter('cp', $codePostal);

        $entities = $qb->getQuery()->execute();

        return $entities;
    }
}
