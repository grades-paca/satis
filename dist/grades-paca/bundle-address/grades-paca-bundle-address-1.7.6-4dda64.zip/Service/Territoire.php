<?php
/**
 * Author: Michaël VEROUX
 * Date: 08/09/15
 * Time: 10:53
 */

namespace Oru\Bundle\AddressBundle\Service;

use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\ORM\EntityManager;
use Oru\Bundle\AddressBundle\Entity\LstDepartement;
use Symfony\Component\Yaml\Parser;

/**
 * Class Territoire
 * @package Oru\Bundle\AddressBundle\Service
 * @author Michaël VEROUX
 */
class Territoire
{
    const TERRITOIRE_CONFIG_PATH = '../Resources/config/territoire.yml';

    /**
     * @var array
     */
    protected $departementCorrespondance = array();

    /**
     * @var ObjectManager
     */
    protected $em;

    /**
     * Territoire constructor.
     * @param ObjectManager $em
     */
    public function __construct(ObjectManager $em)
    {
        $this->em = $em;
    }

    /**
     * @author Michaël VEROUX
     */
    private function init()
    {
        $yaml = new Parser();
        $ymlConfig = file_get_contents(__DIR__ . '/' . self::TERRITOIRE_CONFIG_PATH);

        $this->departementCorrespondance = $yaml->parse($ymlConfig);
    }

    /**
     * @param ObjectManager $em
     * @param int $from
     * @return int|null
     * @author Michaël VEROUX
     */
    private function populateDo(ObjectManager $em, $from = 1)
    {
        $etablissements = $em->getRepository('OruRorBundle:Etablissement')->findAllStartLimit($from, 50);

        $currentId = null;
        foreach($etablissements as $etablissement) {
            $departement = $etablissement->getAdresse()->getDepartement();
            if(!$etablissement->getAdresse()->getTerritoire() && $departement instanceof LstDepartement) {
                $code = 10 > $departement->getCode() ? sprintf('0%d', $departement->getCode()) : $departement->getCode();
                if(isset($this->departementCorrespondance[$code])) {
                    $territoire = $em->getRepository('OruAddressBundle:LstTerritoire')->findOneBy(array('code' => $this->departementCorrespondance[$code]));
                    if($territoire) {
                        $etablissement->getAdresse()->setTerritoire($territoire);
                    }
                }
            }
            $currentId = $etablissement->getId();
        }
        $em->flush();
        $em->clear();

        return $currentId;
    }

    /**
     * @throws \Doctrine\ORM\ORMException
     * @author Michaël VEROUX
     */
    public function populate()
    {
        $this->init();

        $from = 1;
        do {
            $emCloned = EntityManager::create(
                $this->em->getConnection(),
                $this->em->getConfiguration()
            );
            $from = $this->populateDo($emCloned, $from);
        } while ($from);
    }
}