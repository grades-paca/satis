<?php

namespace Oru\Bundle\AddressBundle;

use Oru\Bundle\LstBundle\EventListener\LstEvent;
use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Symfony\Component\HttpKernel\Bundle\Bundle;
use Oru\Bundle\AddressBundle\DependencyInjection\Compiler\FormPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class OruAddressBundle extends Bundle
{

    /**
     * OruAddressBundle constructor.
     */
    public function __construct()
    {
        DynamicLoader::addXml('@OruAddressBundle/Resources/config/routing.xml');
    }

    public function build(ContainerBuilder $container)
    {
        parent::build($container);
        $container->addCompilerPass(new FormPass());
    }
}
