<?php
/**
 * André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\AddressBundle\Entity;


use Doctrine\ORM\EntityRepository;
use Oru\Bundle\LstBundle\Entity\LstRepository;

class LstQuartierIrisRepository extends LstRepository  {

    /**
     * Query with relations for serializer.
     *
     * @param $code
     *
     * @return mixed
     */
    public function findOneByCodeForSynchro($code)
    {
        return $this
            ->createQueryBuilder('u')
            ->select('u,com')
            ->leftJoin('u.commune', 'com')
            ->andWhere('u.code LIKE :code')
            ->setParameter('code', $code)
            ->getQuery()
            ->getSingleResult()
        ;
    }
} 