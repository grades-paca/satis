<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 08/03/2016
 * Time: 16:03
 */

namespace Oru\Bundle\AddressBundle\Entity;


use Doctrine\ORM\EntityRepository;
use Oru\Bundle\LstBundle\Entity\LstRepository;

class LstCodePostalRepository extends LstRepository  {

    /**
     * @param $search
     * @param int $limit
     * @param int $first
     * @return array
     */
    public function searchByName($search, $limit = 10, $first = 0)
    {
        $q = $this
            ->createQueryBuilder("c")
            ->andWhere("c.libelle like :search")
            ->setParameter('search', "%$search%")
            ->setMaxResults($limit)
            ->setFirstResult($first)
        ;

        return $q
            ->getQuery()
            ->getResult();
        ;
    }

    /**
     * @param $search
     * @return mixed
     */
    public function countSearchByName($search)
    {
        $q = $this
            ->createQueryBuilder("c")
            ->select('COUNT(DISTINCT c.id)')
            ->andWhere("c.libelle like :search")
            ->setParameter('search', "%$search%")
        ;

        return $q
            ->getQuery()
            ->getSingleScalarResult();
        ;
    }

    /**
     * @param $search
     * @param int $limit
     * @param int $first
     * @return array
     */
    public function searchByNameCommune($search, $limit = 10, $first = 0)
    {
        $q = $this
            ->createQueryBuilder("c")
            ->leftJoin('c.commune', 'commune')
            ->andWhere("commune.libelle like :search")
            ->setParameter('search', "%$search%")
            ->setMaxResults($limit)
            ->setFirstResult($first)
        ;

        return $q
            ->getQuery()
            ->getResult();
        ;
    }

    /**
     * @param $search
     * @param int $limit
     * @param int $first
     * @return array
     */
    public function countSearchByNameCommune($search, $limit = 10, $first = 0)
    {
        $q = $this
            ->createQueryBuilder("c")
            ->select('COUNT(DISTINCT commune.id)')
            ->leftJoin('c.commune', 'commune')
            ->andWhere("commune.libelle like :search")
            ->setParameter('search', "%$search%")
            ->setMaxResults($limit)
            ->setFirstResult($first)
        ;

        return $q
            ->getQuery()
            ->getResult();
        ;
    }

    /**
     * Query with relations for serializer.
     *
     * @param $code
     *
     * @return mixed
     */
    public function findOneByCodeForSynchro($code)
    {
        return $this
            ->createQueryBuilder('u')
            ->select('u,com')
            ->leftJoin('u.commune', 'com')
            ->andWhere('u.code LIKE :code')
            ->setParameter('code', $code)
            ->getQuery()
            ->getSingleResult()
        ;
    }
} 