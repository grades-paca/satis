<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use Oru\Bundle\AddressBundle\Entity\LstCodePostal;
use JMS\Serializer\Annotation;
use APY\DataGridBundle\Grid\Mapping as GRID;

/**
 * LstCommune
 * @GRID\Source(columns="id, code, libelle, oid, codeAsip")
 * @Annotation\ExclusionPolicy("all")
 */
class LstCommune extends Lst
{
    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $oid;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})*
     */
    private $codeAsip;

    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstDepartement
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $departement;

    private $statut;

    private $latChefLieu;

    private $longChefLieu;

    private $latCentroid;

    private $longCentroid;

    private $zMoyen;

    private $superficie;

    private $population;

    private $code_cant;

    private $code_arr;

    private $xChefLieu;

    private $yChefLieu;

    private $xCentroid;

    private $yCentroid;

    /**
     * @var LstCodePostal
     */
    private $codePostal;

    /**
     * @var LstQuartierIris
     */
    protected $quartiers;

    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_communes"})
     */
    protected $id;

    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_communes","webservice"})
     */
    protected $libelle;

    /**
     * @return LstDepartement
     */
    public function getDepartement()
    {
        return $this->departement;
    }

    /**
     * @param LstDepartement $departement
     */
    public function setDepartement(LstDepartement $departement)
    {
        $this->departement = $departement;
    }

    /**
     * @return mixed
     */
    public function getCodeArr()
    {
        return $this->code_arr;
    }

    /**
     * @param mixed $code_arr
     */
    public function setCodeArr($code_arr)
    {
        $this->code_arr = $code_arr;
    }

    /**
     * @return mixed
     */
    public function getCodeCant()
    {
        return $this->code_cant;
    }

    /**
     * @param mixed $code_cant
     */
    public function setCodeCant($code_cant)
    {
        $this->code_cant = $code_cant;
    }

    /**
     * @return mixed
     */
    public function getLatCentroid()
    {
        return $this->latCentroid;
    }

    /**
     * @param mixed $latCentroid
     */
    public function setLatCentroid($latCentroid)
    {
        $this->latCentroid = $latCentroid;
    }

    /**
     * @return mixed
     */
    public function getLatChefLieu()
    {
        return $this->latChefLieu;
    }

    /**
     * @param mixed $latChefLieu
     */
    public function setLatChefLieu($latChefLieu)
    {
        $this->latChefLieu = $latChefLieu;
    }

    /**
     * @return mixed
     */
    public function getLongCentroid()
    {
        return $this->longCentroid;
    }

    /**
     * @param mixed $longCentroid
     */
    public function setLongCentroid($longCentroid)
    {
        $this->longCentroid = $longCentroid;
    }

    /**
     * @return mixed
     */
    public function getLongChefLieu()
    {
        return $this->longChefLieu;
    }

    /**
     * @param mixed $longChefLieu
     */
    public function setLongChefLieu($longChefLieu)
    {
        $this->longChefLieu = $longChefLieu;
    }

    /**
     * @return mixed
     */
    public function getPopulation()
    {
        return $this->population;
    }

    /**
     * @param mixed $population
     */
    public function setPopulation($population)
    {
        $this->population = $population;
    }

    /**
     * @return mixed
     */
    public function getStatut()
    {
        return $this->statut;
    }

    /**
     * @param mixed $statut
     */
    public function setStatut($statut)
    {
        $this->statut = $statut;
    }

    /**
     * @return mixed
     */
    public function getSuperficie()
    {
        return $this->superficie;
    }

    /**
     * @param mixed $superficie
     */
    public function setSuperficie($superficie)
    {
        $this->superficie = $superficie;
    }

    /**
     * @return mixed
     */
    public function getZMoyen()
    {
        return $this->zMoyen;
    }

    /**
     * @param mixed $zMoyen
     */
    public function setZMoyen($zMoyen)
    {
        $this->zMoyen = $zMoyen;
    }

    /**
     * @return mixed
     */
    public function getXCentroid()
    {
        return $this->xCentroid;
    }

    /**
     * @param mixed $xCentroid
     */
    public function setXCentroid($xCentroid)
    {
        $this->xCentroid = $xCentroid;
    }

    /**
     * @return mixed
     */
    public function getXChefLieu()
    {
        return $this->xChefLieu;
    }

    /**
     * @param mixed $xChefLieu
     */
    public function setXChefLieu($xChefLieu)
    {
        $this->xChefLieu = $xChefLieu;
    }

    /**
     * @return mixed
     */
    public function getYCentroid()
    {
        return $this->yCentroid;
    }

    /**
     * @param mixed $yCentroid
     */
    public function setYCentroid($yCentroid)
    {
        $this->yCentroid = $yCentroid;
    }

    /**
     * @return mixed
     */
    public function getYChefLieu()
    {
        return $this->yChefLieu;
    }

    /**
     * @param mixed $yChefLieu
     */
    public function setYChefLieu($yChefLieu)
    {
        $this->yChefLieu = $yChefLieu;
    }

    /**
     * @return \Oru\Bundle\AddressBundle\Entity\LstCodePostal
     */
    public function getCodePostal()
    {
        return $this->codePostal;
    }

    /**
     * @param \Oru\Bundle\AddressBundle\Entity\LstCodePostal $codePostal
     */
    public function setCodePostal(LstCodePostal $codePostal)
    {
        $this->codePostal = $codePostal;
    }

    /**
     * @return LstQuartierIris
     */
    public function getQuartiers()
    {
        return $this->quartiers;
    }

    /**
     * @param LstQuartierIris $quartiers
     */
    public function setQuartiers($quartiers)
    {
        $this->quartiers = $quartiers;
    }
}
