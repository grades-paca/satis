<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 23/02/2017
 * Time: 14:17
 */

namespace Oru\Bundle\AddressBundle\Entity;


use Doctrine\ORM\EntityRepository;
use Oru\Bundle\LstBundle\Entity\LstRepository;

class LstDepartementRepository extends LstRepository
{
    /**
     * @param $search
     * @param int $limit
     * @param int $first
     * @param bool $count
     * @return array
     */
    public function searchByLibelleOrCode($search, $limit = 10, $first = 0, $count = false){
        $q = $this->createQueryBuilder("d");

        if($count){
            $q->select('COUNT(DISTINCT d.id)');
        }

        $q->where("d.libelle like :search")
            ->orWhere("d.code like :search")
            ->setParameter('search', "%$search%")
        ;

        if($count){
            return $q
                ->getQuery()
                ->getSingleScalarResult();
            ;
        }else{
            return $q
                ->setMaxResults($limit)
                ->setFirstResult($first)
                ->getQuery()
                ->getResult()
            ;
        }
    }
}