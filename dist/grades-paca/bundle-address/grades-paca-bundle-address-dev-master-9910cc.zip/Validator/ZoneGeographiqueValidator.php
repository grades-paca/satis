<?php
/**
 * Created by PhpStorm.
 * User: Michaël GONZALEZ
 * Date: 31/07/2019
 * Time: 08:18
 */
namespace Oru\Bundle\AddressBundle\Validator;

use Oru\Bundle\AddressBundle\Entity\ZoneGeographique;
use Oru\Bundle\AddressBundle\Entity\ZoneIntervention;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

class ZoneGeographiqueValidator extends ConstraintValidator
{
    public function validate($value, Constraint $constraint)
    {
        //On gère aussi les entités ZoneIntervention
        if(!$value instanceof ZoneGeographique && !$value instanceof ZoneIntervention){
            return;
        }

        $zoneGeographique = $value;

        //S'il s'agit d'une zone d'intervention, on va rechercher la zone géographique associée
        if($value instanceof ZoneIntervention){
            $zoneGeographique = $value->getZoneGeographique();
        }

        //On vérifie qu'au moins une entité géographique a été renseignée dans la zone
        if($zoneGeographique){
            $hasEntity = (bool) ( //Cast Booléen: Si au moins un compte => on retourne true, sinon false
                  count($zoneGeographique->getRegions())
                + count ($zoneGeographique->getDepartements())
                + count($zoneGeographique->getCommunes())
                + count($zoneGeographique->getQuartiers())
            );

            if(!$hasEntity){
                $this->context
                    ->buildViolation("Au moins une entité géographique doit être renseignée (Région, département, commune ou quartier)")
                    ->atPath("zoneGeographique")
                    ->addViolation()
                ;
            }
        }
    }
}