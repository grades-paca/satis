<?php

namespace Oru\Bundle\AddressBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class CpMajCommand.
 *
 * @author Michaël VEROUX
 */
class CpMajCommand extends ContainerAwareCommand
{
    /**
     * Configures the current command.
     */
    protected function configure()
    {
        $this
            ->setName('oru:address:maj_cp')
            ->addArgument('file',InputArgument::REQUIRED, 'chemin vers le fichier CSV')
            ->setDescription('Importe et met à jour les codes postaux existants le cas échéant à partir du fichier CSV fourni en argument contenant les colonnes "code_postal", "libelle_acheminement", "code_insee" et "cedex"')
        ;
    }

    /**
     * Executes the current command.
     *
     * This method is not abstract because you can use this class
     * as a concrete class. In this case, instead of defining the
     * execute() method, you set the code to execute by passing
     * a Closure to the setCode() method.
     *
     * @return null|int null or 0 if everything went fine, or an error code
     *
     * @throws LogicException When this abstract method is not implemented
     *
     * @see setCode()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $filename = $input->getArgument('file');

        $this->getContainer()->get('oru_address.cp_update')->setOutput($output)->execute($filename);
    }
}
