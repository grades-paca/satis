<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use JMS\Serializer\Annotation;

/**
 * LstCodePostal
 */
class LstCodePostal extends Lst
{
    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstCommune
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $commune;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $libelleAcheminement;

    /**
     * @return LstCommune
     */
    public function getCommune()
    {
        return $this->commune;
    }

    /**
     * @param LstCommune $commune
     */
    public function setCommune(LstCommune $commune)
    {
        $this->commune = $commune;
    }

    /**
     * @return mixed
     */
    public function getLibelleAcheminement()
    {
        return $this->libelleAcheminement;
    }

    /**
     * @param mixed $libelleAcheminement
     */
    public function setLibelleAcheminement($libelleAcheminement)
    {
        $this->libelleAcheminement = $libelleAcheminement;
    }
}
