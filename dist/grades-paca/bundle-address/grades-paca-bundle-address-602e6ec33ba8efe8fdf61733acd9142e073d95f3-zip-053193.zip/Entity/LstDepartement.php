<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use APY\DataGridBundle\Grid\Mapping as GRID;
use JMS\Serializer\Annotation;

/**
 * LstDepartement
 * @GRID\Source(columns="id, code, libelle, oid, codeAsip")
 * @Annotation\ExclusionPolicy("all")
 */
class LstDepartement extends Lst
{
    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstRegion
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $region;

    /**
     * @var LstCommune
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_communes"})
     */
    private $communes;

    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_structure"})
     */
    protected $id;

    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_structure","webservice"})
     */
    protected $libelle;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $oid;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})*
     */
    private $codeAsip;

    /**
     * @return string
     */
    function __toString()
    {
        return $this->getCode() . ' - ' . $this->getLibelle();
    }

    /**
     * Set region
     *
     * @param \Oru\Bundle\AddressBundle\Entity\LstRegion $region
     * @return LstDepartement
     */
    public function setRegion(\Oru\Bundle\AddressBundle\Entity\LstRegion $region = null)
    {
        $this->region = $region;
    
        return $this;
    }

    /**
     * Get region
     *
     * @return \Oru\Bundle\AddressBundle\Entity\LstRegion 
     */
    public function getRegion()
    {
        return $this->region;
    }

    /**
     * @return mixed
     */
    public function getCompleteLibelle()
    {
        return $this->getCode()." - ".$this->getLibelle();
    }

    /**
     * @return LstCommune
     */
    public function getCommunes()
    {
        return $this->communes;
    }

    /**
     * @param LstCommune $communes
     */
    public function setCommunes($communes)
    {
        $this->communes = $communes;
    }

    /**
     * @return string
     */
    public function getOid()
    {
        return $this->oid;
    }

    /**
     * @param string $oid
     */
    public function setOid($oid)
    {
        $this->oid = $oid;
    }

    /**
     * @return string
     */
    public function getCodeAsip()
    {
        return $this->codeAsip;
    }

    /**
     * @param string $codeAsip
     */
    public function setCodeAsip($codeAsip)
    {
        $this->codeAsip = $codeAsip;
    }
}
