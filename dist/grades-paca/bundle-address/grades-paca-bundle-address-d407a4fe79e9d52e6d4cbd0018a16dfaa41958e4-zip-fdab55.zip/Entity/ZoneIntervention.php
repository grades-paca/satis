<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 04/10/2016
 * Time: 15:15
 */

namespace Oru\Bundle\AddressBundle\Entity;


class ZoneIntervention
{
    private $id;

    /**
     * @var ZoneGeographique
     */
    private $zoneGeographique;

    /**
     * @var string
     */
    private $nom;

    /**
     * @var string
     */
    private $description;

    /**
     * @var \DateTime
     */
    private $created;

    /**
     * @var \DateTime
     */
    private $updated;

    /**
     * ZoneIntervention constructor.
     */
    function __construct()
    {
        $this->setZoneGeographique(new ZoneGeographique());
    }

    /**
     * @inheritdoc
     */
    function __toString()
    {
        return (string) $this->nom;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return ZoneGeographique
     */
    public function getZoneGeographique()
    {
        return $this->zoneGeographique;
    }

    /**
     * @param ZoneGeographique $zoneGeographique
     */
    public function setZoneGeographique($zoneGeographique)
    {
        $this->zoneGeographique = $zoneGeographique;
    }

    /**
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * @param string $nom
     */
    public function setNom($nom)
    {
        $this->nom = $nom;
    }

    /**
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param string $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param \DateTime $created
     */
    public function setCreated($created)
    {
        $this->created = $created;
    }

    /**
     * @return \DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * @param \DateTime $updated
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;
    }
}