<?php

namespace Oru\Bundle\AddressBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class CpLinkRepairCommand.
 *
 * @author Michaël VEROUX
 */
class CpLinkRepairCommand extends ContainerAwareCommand
{
    /**
     * Configures the current command.
     */
    protected function configure()
    {
        $this
            ->setName('oru:address:cp_link_repair')
            ->setDescription('Tente de créer les liaisons manquantes avec la table des codes postaux en fonction de la saisie des champs libres.')
        ;
    }

    /**
     * Executes the current command.
     *
     * This method is not abstract because you can use this class
     * as a concrete class. In this case, instead of defining the
     * execute() method, you set the code to execute by passing
     * a Closure to the setCode() method.
     *
     * @return null|int null or 0 if everything went fine, or an error code
     *
     * @throws LogicException When this abstract method is not implemented
     *
     * @see setCode()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->getContainer()->get('oru_address.cp_link_repair')->setOutput($output)->execute();
    }
}
