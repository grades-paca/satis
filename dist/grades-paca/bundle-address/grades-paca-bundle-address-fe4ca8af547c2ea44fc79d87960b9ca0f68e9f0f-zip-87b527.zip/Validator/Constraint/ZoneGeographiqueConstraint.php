<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 31/07/2018
 * Time: 08:10.
 */

namespace Oru\Bundle\AddressBundle\Validator\Constraint;

use Symfony\Component\Validator\Constraint;

class ZoneGeographiqueConstraint extends Constraint
{
    public function validatedBy()
    {
        return 'oru_address.validator.zone_geographique';
    }

    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
