<?php

namespace Oru\Bundle\AddressBundle\Form;

use Oru\Bundle\LstBundle\Form\LstType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class LstCodePostalType extends LstType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);
        $builder->add('codePostal', null, array('required' => true, 'label' => 'Address.code' , 'translation_domain' => 'OruAddressBundle'));
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\AddressBundle\Entity\LstCodePostal'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_addressbundle_lst_code_postal';
    }
}
