<?php

namespace Oru\Bundle\AddressBundle\Form;

use Oru\Bundle\AddressBundle\Entity\Address;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AddressType extends AbstractType
{
    private $disabledBundles;
    private $container;

    /**
     * @var array
     */
    private $preferredDepartements = array();

    /**
     * @var array
     */
    private $preferredTerritoires = array();

    public function __construct($disabledBundles, Container $container) {
        $this->disabledBundles = $disabledBundles;
        $this->container = $container;
        $codeRegion = $this->container->getParameter('code_insee_region');
        $region = $this->container->get('doctrine.orm.entity_manager')->getRepository('OruAddressBundle:LstRegion')->findOneBy(array('code' => $codeRegion));
        if($region) {
            $this->preferredDepartements = $this->container->get('doctrine.orm.entity_manager')->getRepository('OruAddressBundle:LstDepartement')->findBy(array('region' => $region));
            $this->preferredTerritoires = $this->container->get('doctrine.orm.entity_manager')->getRepository('OruAddressBundle:LstTerritoire')->findBy(array('region' => $region));
        }
    }


    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('adresse', null, array('label' => 'Address.adresse', 'translation_domain' => 'OruAddressBundle', 'read_only' => true, 'disabled' => true))
            ->add('numero', null, array('label' => 'Address.numero', 'translation_domain' => 'OruAddressBundle'))
            ->add('numeroComplement', null, array('label' => 'Address.numero_complement', 'translation_domain' => 'OruAddressBundle'))
            ->add('type_voie', null, array('label' => 'Address.type_voie', 'translation_domain' => 'OruAddressBundle', 'attr' => array('placeholder' => '(Obligatoire pour complétion de l\'adresse)', 'class' => 'placeholder_required')))
            ->add('voie', null, array('label' => 'Address.voie', 'translation_domain' => 'OruAddressBundle', 'attr' => array('placeholder' => '(Obligatoire pour complétion de l\'adresse)', 'class' => 'placeholder_required')))
            ->add('adresseComplement', null, array('label' => 'Address.adresse_complement', 'translation_domain' => 'OruAddressBundle'))
            ->add('code', null, array('label' => 'Address.code', 'translation_domain' => 'OruAddressBundle', 'attr' => array('placeholder' => '(Obligatoire pour complétion de l\'adresse)', 'class' => 'placeholder_required', 'pattern' => '.{5,5}')))
            ->add('commune', null, array('label' => 'Address.commune', 'translation_domain' => 'OruAddressBundle', 'attr' => array('placeholder' => '(Obligatoire pour complétion de l\'adresse)', 'class' => 'placeholder_required')))
            ->add('departement', null, array('label' => 'Address.departement', 'translation_domain' => 'OruAddressBundle', 'preferred_choices' => $this->preferredDepartements))
        ;

        if(!isset($options['territoire']) || $options['territoire']) {
            $builder->add('territoire', null, array(
                'label' => 'Address.territoire',
                'translation_domain' => 'OruAddressBundle',
                'preferred_choices' => $this->preferredTerritoires
            ));
        }

        $builder->add('pays', 'country', array('label' => 'Address.pays', 'translation_domain' => 'OruAddressBundle', 'preferred_choices' => array('FR')));

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function(FormEvent $event) {
            $adresse = $event->getData();
            $form = $event->getForm();

            if (!$adresse || trim($adresse->getAdresse()) == '' || $adresse->hasStructuredAddress()) {
                $form->remove('adresse');
            }else if(!empty($adresse)){
                $form->remove('adresse');
                $form->add('adresse', null, array('label' => 'Address.adresseLibre', 'translation_domain' => 'OruAddressBundle', 'read_only' => true, 'disabled' => true, 'position' => 'first'));
            }
        });

        if(in_array('OruCartoBundle', $this->disabledBundles) === FALSE) {
            $builder->addEventSubscriber($this->container->get('oru_carto.listener.carto_type'));
        }
    }
    
    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefined(array('territoire'));
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\AddressBundle\Entity\Address'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_address';
    }
}
