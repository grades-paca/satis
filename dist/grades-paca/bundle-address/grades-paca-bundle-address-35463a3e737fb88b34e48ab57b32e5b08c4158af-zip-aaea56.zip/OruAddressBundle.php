<?php

namespace Oru\Bundle\AddressBundle;

use Oru\Bundle\LstBundle\EventListener\LstEvent;
use Symfony\Component\HttpKernel\Bundle\Bundle;
use Oru\Bundle\AddressBundle\DependencyInjection\Compiler\FormPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class OruAddressBundle extends Bundle
{
    public function boot()
    {
        $collection = $this
            ->container
            ->get('routing.loader')
            ->load(__DIR__.'/Resources/config/routing.xml')
        ;

        $this
            ->container
            ->get('router')
            ->getRouteCollection()
            ->addCollection($collection)
        ;
    }
    public function build(ContainerBuilder $container)
    {
        parent::build($container);
        $container->addCompilerPass(new FormPass());
    }
}
