<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 06/07/2015
 * Time: 09:46
 */

namespace Oru\Bundle\AddressBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Application;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Input\InputDefinition;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;
use Oru\Bundle\AddressBundle\Command\ImportCommand;

class LinkAddressCPCommand extends ImportCommand
{
    protected function configure()
    {
        $this
            ->setName('oru:address:link_cp')
            ->setDescription('Etablit la relation entre un code postal et une adresse depuis le code manuel renseigné dans l\'adresse (VARCHAR)')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->getContainer()->get('oru_address.populate')->linkCPToAddresses();
    }

}