<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 05/10/2016
 * Time: 13:25
 */

namespace Oru\Bundle\AddressBundle\Controller;

use FOS\RestBundle\Context\Context;
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\View as RestView;
use FOS\RestBundle\Request\ParamFetcherInterface;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use JMS\Serializer\Annotation;
use Symfony\Component\Routing\Annotation\Route;

class ZoneGeographiqueRestController extends FOSRestController
{
    /**
     * @RestView(serializerGroups={"ws_zoneGeographique_structure"})
     */
    public function zone_geographique_structureAction()
    {
        $user = $this->container->get('security.token_storage')->getToken()->getUser();
        /*  if (!is_object($user) || !$user instanceof UserInterface) {
              throw new AccessDeniedException('This user does not have access to this section.');
          }*/

        $result = $this->getDoctrine()->getRepository('OruAddressBundle:LstRegion')->findBy(array(), array('libelle' => 'ASC'));
        return $result;
    }

    /**
     * @RestView(serializerGroups={"ws_zoneGeographique_communes"})
     */
    public function zone_geographique_communesAction($departement){
        return $this->getDoctrine()->getRepository('OruAddressBundle:LstCommune')->findByDepartement($departement, array('libelle' => 'ASC'));
    }

    /**
     * @RestView(serializerGroups={"ws_zoneGeographique_quartiers"})
     */
    public function zone_geographique_quartiersAction($commune){
        return  $this->getDoctrine()->getRepository('OruAddressBundle:LstQuartierIris')->findByCommune($commune, array('libelle' => 'ASC'));
    }
}
