<?php

namespace Oru\Bundle\AddressBundle\Entity;

use APY\DataGridBundle\Grid\Mapping as GRID;
use JMS\Serializer\Annotation;
use Oru\Bundle\LstBundle\Entity\LstAsip;

/**
 * LstTerritoire.
 *
 * @GRID\Source(columns="id, code, libelle, oid, codeAsip")
 * @Annotation\ExclusionPolicy("all")
 */
class LstTerritoire extends LstAsip
{
    /**
     * @var LstRegion
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $region;

    /**
     * @return LstRegion
     */
    public function getRegion()
    {
        try {
            if ($this->region) {
                $this->region->getDeleted();
            }
        } catch (\Exception $e) {
            return null;
        }

        return $this->region;
    }

    /**
     * @param LstRegion $region
     */
    public function setRegion(LstRegion $region)
    {
        $this->region = $region;
    }
}
