<?php

namespace Oru\Bundle\AddressBundle\Entity;

use APY\DataGridBundle\Grid\Mapping as GRID;
use JMS\Serializer\Annotation;
use Oru\Bundle\LstBundle\Entity\Lst;

/**
 * LstQuartierIris.
 *
 * @GRID\Source(columns="id, code, libelle, oid, codeAsip")
 * @Annotation\ExclusionPolicy("all")
 */
class LstQuartierIris extends Lst
{
    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_quartiers", "search"})
     */
    protected $id;

    /**
     * @Annotation\Expose
     * @Annotation\Groups({"ws_zoneGeographique_quartiers","webservice", "search"})
     */
    protected $libelle;
    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $iris;

    /**
     * @var string
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $typeIris;

    /**
     * @var \Oru\Bundle\AddressBundle\Entity\LstCommune
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $commune;
    private $origine;

    /**
     * @return mixed
     */
    public function getCommune()
    {
        try {
            if ($this->commune) {
                $this->commune->getDeleted();
            }
        } catch (\Exception $e) {
            return null;
        }

        return $this->commune;
    }

    /**
     * @param mixed $commune
     */
    public function setCommune(LstCommune $commune)
    {
        $this->commune = $commune;
    }

    /**
     * @return mixed
     */
    public function getIris()
    {
        return $this->iris;
    }

    /**
     * @param mixed $iris
     */
    public function setIris($iris)
    {
        $this->iris = $iris;
    }

    /**
     * @return mixed
     */
    public function getOrigine()
    {
        return $this->origine;
    }

    /**
     * @param mixed $origine
     */
    public function setOrigine($origine)
    {
        $this->origine = $origine;
    }

    /**
     * @return mixed
     */
    public function getTypeIris()
    {
        return $this->typeIris;
    }

    /**
     * @param mixed $typeIris
     */
    public function setTypeIris($typeIris)
    {
        $this->typeIris = $typeIris;
    }
}
