<?php

namespace Oru\Bundle\AddressBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\LstBundle\Entity\Lst;
use APY\DataGridBundle\Grid\Mapping as GRID;

use JMS\Serializer\Annotation;

/**
 * LstTerritoire
 * @Annotation\ExclusionPolicy("all")
 */
class LstTerritoire extends Lst
{
    /**
     * @var LstRegion
     * @Annotation\Expose
     * @Annotation\Groups({"webservice"})
     */
    private $region;

    /**
     * @return LstRegion
     */
    public function getRegion()
    {
        try {
            if ($this->region) {
                $this->region->getDeleted();
            }
        } catch (\Exception $e) {
            return null;
        }
        return $this->region;
    }

    /**
     * @param LstRegion $region
     */
    public function setRegion(LstRegion $region)
    {
        $this->region = $region;
    }


}
