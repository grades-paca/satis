<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 07/10/2016
 * Time: 09:56
 */

namespace Oru\Bundle\AddressBundle\Form;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ZoneInterventionType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);
        $builder
            ->add('nom', $options['read_only'] ? 'oru_static' : null, array(
                'label' => 'zoneIntervention.nom',
                'translation_domain' => 'OruAddressBundle'
            ))
            ->add('description', $options['read_only'] ? 'oru_static' : null, array(
                'label' => 'zoneIntervention.description',
                'translation_domain' => 'OruAddressBundle'
            ))
            ->add('zoneGeographique', 'oru_zone_geographique_tree', array(
                'label' => 'zoneIntervention.zoneGeographique',
                'translation_domain' => 'OruAddressBundle',
                'read_only' => $options['read_only']
            ))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\AddressBundle\Entity\ZoneIntervention',
            'translation_domain' => 'OruAddressBundle',
            'required' => false,
            'read_only' => false
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_addressbundle_zone_intervention';
    }
}