<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 05/10/2016
 * Time: 13:25
 */

namespace Oru\Bundle\AddressBundle\Controller;

use FOS\RestBundle\Controller\Annotations\View as RestView;
use FOS\RestBundle\Controller\FOSRestController;
use JMS\Serializer\SerializationContext;

class ZoneGeographiqueRestController extends FOSRestController
{
    /**
     * @RestView(serializerGroups={"Default"})
     */
    public function zone_geographique_structureAction()
    {
        $user = $this->container->get('security.token_storage')->getToken()->getUser();
        /*  if (!is_object($user) || !$user instanceof UserInterface) {
              throw new AccessDeniedException('This user does not have access to this section.');
          }*/

        $result = $this->getDoctrine()->getRepository('OruAddressBundle:LstRegion')->findBy(array(), array('libelle' => 'ASC'));
        $view = $this->view($result);
        $context = SerializationContext::create()->setGroups(array('ws_zoneGeographique_structure', 'webservice'));
        $view->setSerializationContext($context);

        return $this->handleView($view);
    }

    /**
     * @RestView(serializerGroups={"Default"})
     *
     * @param mixed $departement
     */
    public function zone_geographique_communesAction($departement)
    {
        $result = $this->getDoctrine()->getRepository('OruAddressBundle:LstCommune')->findByDepartement($departement, array('libelle' => 'ASC'));
        $view = $this->view($result);
        $context = SerializationContext::create()->setGroups(array('ws_zoneGeographique_communes'));
        $view->setSerializationContext($context);

        return $this->handleView($view);
    }

    /**
     * @RestView(serializerGroups={"Default"})
     *
     * @param mixed $commune
     */
    public function zone_geographique_quartiersAction($commune)
    {
        $result = $this->getDoctrine()->getRepository('OruAddressBundle:LstQuartierIris')->findByCommune($commune, array('libelle' => 'ASC'));
        $view = $this->view($result);
        $context = SerializationContext::create()->setGroups(array('ws_zoneGeographique_quartiers'));
        $view->setSerializationContext($context);

        return $this->handleView($view);
    }
}
