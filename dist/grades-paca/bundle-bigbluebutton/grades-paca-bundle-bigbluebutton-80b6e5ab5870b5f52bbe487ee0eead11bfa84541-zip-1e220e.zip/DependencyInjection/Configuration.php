<?php

namespace Oru\Bundle\BigBlueButtonBundle\DependencyInjection;

use Symfony\Component\Config\Definition\Builder\TreeBuilder;
use Symfony\Component\Config\Definition\ConfigurationInterface;

/**
 * This is the class that validates and merges configuration from your app/config files
 *
 * To learn more see {@link http://symfony.com/doc/current/cookbook/bundles/extension.html#cookbook-bundles-extension-config-class}
 */
class Configuration implements ConfigurationInterface
{
    /**
     * {@inheritDoc}
     */
    public function getConfigTreeBuilder()
    {
        $treeBuilder = new TreeBuilder();
        $rootNode = $treeBuilder
            ->root('oru_big_blue_button')
                ->children()
                    ->arrayNode('provider')
                    ->children()
                        ->scalarNode('security_secret')
                            ->info('Security secret used for enabling 3rd party plug-ins and external applications to access your BigBlueButton.')
                            ->isRequired()
                        ->end()
                        ->scalarNode('server_base_url')
                            ->info('Access URL to the API.')
                            ->isRequired()
                        ->end()
                        ->scalarNode('video_url')
                            ->info('Video download url.')
                            ->defaultValue('/presentation/__meeting_id__/video/webcams.webm')
                        ->end()
                        ->scalarNode('audio_url')
                            ->info('Audio download url.')
                            ->defaultValue('/presentation/__meeting_id__/audio/audio.ogg')
                        ->end()
                    ->end()
                ->end()
                ->scalarNode('welcome_message')
                    ->defaultValue("Bienvenue sur le système de visio-conférence de l'ORUPACA")
                ->end()
                ->scalarNode('logout_route')
                    ->defaultValue("ror_homepage")
                ->end()
                ->scalarNode('duration_max')
                    ->defaultValue("04:00:00")
                ->end()
            ->end()
        ;

        // Here you should define the parameters that are allowed to
        // configure your bundle. See the documentation linked above for
        // more information on that topic.

        return $treeBuilder;
    }
}
