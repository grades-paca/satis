Bundle OruBigBlueButtonBundle
======================

Description
-----------

Bundle de visio-conférence.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/big-blue-button":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\BigBlueButtonBundle\OruBigBlueButtonBundle();
```

Dans le config.yml, ajouter ce bundle aux paramètres imports :

```
imports:
    ...
    - { resource: @OruBigBlueButtonBundle/Resources/config/config.yml }
```

Ajouter les paramètres ```bbb_security_secret``` et ```bbb_base_url``` au fichier parameters.yml.

Vider le cache de Symfony2

Utilisation
-----------

Le service 'oru_bigbluebutton.session.factory' fournit des fonctionnalités permettant de créer et accéder à des sessions de visio-conférences.
Il est aussi possible d'utiliser ce bundle via la route /bigbluebutton_session.