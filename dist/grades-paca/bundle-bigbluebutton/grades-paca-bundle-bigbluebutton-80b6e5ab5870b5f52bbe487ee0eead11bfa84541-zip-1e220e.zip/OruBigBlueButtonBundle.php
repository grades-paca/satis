<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\BigBlueButtonBundle;

use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruBigBlueButtonBundle extends Bundle
{
    public function boot()
    {
        DynamicLoader::addYaml('@OruBigBlueButtonBundle/Resources/config/routing.xml');
    }
}
