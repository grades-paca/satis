<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\BigBlueButtonBundle;

use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruBigBlueButtonBundle extends Bundle
{

    /**
     * OruBigBlueButtonBundle constructor.
     */
    public function __construct()
    {
        DynamicLoader::addXml('@OruBigBlueButtonBundle/Resources/config/routing.xml');
    }
}
