<?php

namespace Oru\Bundle\BigBlueButtonBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class SessionFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('id', 'search', array('required' => false, 'label' => 'session.id', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('name', 'search', array('required' => false, 'label' => 'session.name', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('deleted', 'choice', array('required' => false, 'choices' => array('1' => 'Oui', '0' => 'Non'),'empty_data'  => null, 'label' => 'session.deleted', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('filter', 'submit', array('label' => 'listing.action.filter', 'translation_domain' => 'messages'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\BigBlueButtonBundle\Filter\SessionFilter'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_bigbluebuttonbundle_sessionfilter';
    }
}
