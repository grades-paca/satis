<?php

namespace Oru\Bundle\BigBlueButtonBundle\Filter;

use Oru\Bundle\BigBlueButtonBundle\Entity\Session;


class SessionFilter
{
    protected $id;
    protected $name;
    protected $deleted;

    public function __construct()
    {
        $this->deleted = false;
    }

    /**
     * @param boolean $deleted
     */
    public function setDeleted($deleted)
    {
        $this->deleted = $deleted;
    }

    /**
     * @return boolean
     */
    public function getDeleted()
    {
        return $this->deleted;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }


}