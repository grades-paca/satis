<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\BigBlueButtonBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruBigBlueButtonBundle extends Bundle
{
    public function boot() {
        $collection = $this
            ->container
            ->get('routing.loader')
            ->load(__DIR__.'/Resources/config/routing.xml')
        ;

        $this
            ->container
            ->get('router')
            ->getRouteCollection()
            ->addCollection($collection)
        ;
    }
}
