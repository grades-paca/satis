<?php

namespace Oru\Bundle\BigBlueButtonBundle\Entity;

/**
 * Participant.
 */
class Participant
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var \Symfony\Component\Security\Core\User\UserInterface
     */
    private $user;

    /**
     * @var \Oru\Bundle\BigBlueButtonBundle\Entity\Session
     */
    private $session;

    /**
     * @var bool
     */
    private $connected;

    public function __toString()
    {
        return (string) $this->getUser()->__toString();
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set user.
     *
     * @param \Symfony\Component\Security\Core\User\UserInterface $user
     *
     * @return Participant
     */
    public function setUser(\Symfony\Component\Security\Core\User\UserInterface $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user.
     *
     * @return \Symfony\Component\Security\Core\User\UserInterface
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set session.
     *
     * @param \Oru\Bundle\BigBlueButtonBundle\Entity\Session $session
     *
     * @return Participant
     */
    public function setSession(\Oru\Bundle\BigBlueButtonBundle\Entity\Session $session = null)
    {
        $this->session = $session;

        return $this;
    }

    /**
     * Get session.
     *
     * @return \Oru\Bundle\BigBlueButtonBundle\Entity\Session
     */
    public function getSession()
    {
        return $this->session;
    }

    /**
     * @param bool $connected
     */
    public function setConnected($connected)
    {
        $this->connected = $connected;
    }

    /**
     * @return bool
     */
    public function getConnected()
    {
        return $this->connected;
    }
}
