var $collectionHolder;

// setup an "add a tag" link
var $newLinkLi = $('<div></div>').append($addParticipantLink);

function addParticipantForm($collectionHolder, $newLinkLi) {
    // Get the data-prototype explained earlier
    var prototype = $collectionHolder.data('prototype');

    // get the new index
    var index = $collectionHolder.data('index');

    // Replace '__participant__' in the prototype's HTML to
    // instead be a number based on how many items we have
    var newForm = prototype.replace(/__participant__/g, index);

    // increase the index with one for the next item
    $collectionHolder.data('index', index + 1);

    // Display the form in the page in an li, before the "Add a tag" link li
    var $newFormLi = $(newForm);
    $newLinkLi.before($newFormLi);

    // add a delete link to the new form
    addParticipantFormDeleteLink($newFormLi);
}

function addParticipantFormDeleteLink($pfFormLi) {
    $removeLink = $addParticipantDeleteLink.clone();
    $pfFormLi.append($removeLink);

    $removeLink.on('click', function(e) {
        // prevent the link from creating a "#" on the URL
        e.preventDefault();

        // remove the li for the tag form
        $pfFormLi.remove();
    });
}

jQuery(document).ready(function() {
    // Get the ul that holds the collection of tags
    $collectionHolder = $('.session_participant');

    // add the "add a tag" anchor and li to the tags ul
    $collectionHolder.append($newLinkLi);

    // count the current form inputs we have (e.g. 2), use that as the new
    // index when inserting a new item (e.g. 2)
    $collectionHolder.data('index', $collectionHolder.find(':input').length);

    // add a delete link to all of the existing tag form li elements
    $collectionHolder.children('div.form_row').each(function() {
        addParticipantFormDeleteLink($(this));
    });

    $addParticipantLink.on('click', function(e) {
        // prevent the link from creating a "#" on the URL
        e.preventDefault();

        // add a new tag form (see next code block)
        addParticipantForm($collectionHolder, $newLinkLi);
    });
});