<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 29/04/14
 */

namespace Oru\Bundle\BigBlueButtonBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Valid;

class SessionType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', null, array('label' => 'session.name', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('begin', null, array('label' => 'session.begin', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('duration', null, array('label' => 'session.duration', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('password', null, array('label' => 'session.password', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('moderatorPassword', null, array('label' => 'session.moderatorPassword', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('welcomeMessage', TextareaType::class, array('label' => 'session.welcomeMessage', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('logoutUrl', null, array('label' => 'session.logoutUrl', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('record', null, array('label' => 'session.record', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('mail', CheckboxType::class, array('label' => 'session.mail', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('participants', CollectionType::class, array(
                'entry_type' => new ParticipantType(),
                'allow_add' => true,
                'by_reference' => false,
                'prototype_name' => '__participant__',
                'constraints' => array(new Valid()),
                'label' => 'session.participants',
                'translation_domain' => 'OruBigBlueButtonBundle',
                'error_bubbling' => false,
                'attr' => array('class' => 'session_participant'),
            ))
        ;

        return $this;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\BigBlueButtonBundle\Entity\Session',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_bigbluebuttonbundle_session';
    }
}
