<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 29/04/14
 */

namespace Oru\Bundle\BigBlueButtonBundle\Factory;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\AttachmentBundle\Attachment\AttachmentTool;
use Oru\Bundle\BigBlueButtonBundle\Entity\Participant;
use Oru\Bundle\BigBlueButtonBundle\Entity\Session;
use Oru\Bundle\BigBlueButtonBundle\Filter\SessionFilter;
use Oru\Bundle\BigBlueButtonBundle\Provider\BigBlueButtonProvider;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\Routing\Router;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class SessionFactory
{
    /**
     * @var \Oru\Bundle\BigBlueButtonBundle\Provider\BigBlueButtonProvider
     */
    private $bigBlueButtonProvider;

    /**
     * @var \Doctrine\ORM\EntityManager
     */
    private $manager;

    /**
     * @var \Symfony\Component\Routing\Router
     */
    private $router;

    /**
     * @var \Symfony\Component\Security\Core\User\UserInterface
     */
    private $user;

    /**
     * @var string
     */
    private $defaultWelcomeMessage;

    /**
     * @var string
     */
    private $defaultLogoutUrl;

    private $videoUrl;

    private $audioUrl;

    private $attachment;

    private $macroUrl = '__meeting_id__';

    /**
     * @var int (in hours)
     */
    private $durationMax;

    public function __construct(BigBlueButtonProvider $bigBlueButtonProvider, EntityManager $entityManager, Router $router, TokenStorageInterface $context, AttachmentTool $attachment)
    {
        $this->bigBlueButtonProvider = $bigBlueButtonProvider;
        $this->router = $router;
        $this->user = ($context->getToken()) ? $context->getToken()->getUser() : null;
        $this->manager = $entityManager;
        $this->attachment = $attachment;
    }

    /**
     * @param mixed $defaultLogoutUrl
     * @param mixed $defaultLogoutRoute
     * @param mixed $params
     */
    public function setDefaultLogoutRoute($defaultLogoutRoute, $params = array())
    {
        $this->defaultLogoutUrl = $this->router->generate($defaultLogoutRoute, $params, Router::ABSOLUTE_URL);
    }

    /**
     * @param mixed $defaultWelcomeMessage
     */
    public function setDefaultWelcomeMessage($defaultWelcomeMessage)
    {
        $this->defaultWelcomeMessage = $defaultWelcomeMessage;
    }

    /**
     * @param int $durationMax
     */
    public function setDurationMax($durationMax)
    {
        $str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", '00:$1:$2', $durationMax);
        sscanf($str_time, '%d:%d:%d', $hours, $minutes, $seconds);
        $this->durationMax = $hours * 3600 + $minutes * 60 + $seconds;
    }

    public function setAudioUrl($audioUrl)
    {
        if (strstr($audioUrl, $this->macroUrl) === false) {
            throw new \Exception("Paramètre audioUrl du bundle OruBigBlueButtonBundle ne contient pas le paramètre {$this->$macroUrl}.");
        }
        $this->audioUrl = $audioUrl;
    }

    public function getAudioUrl($meeting)
    {
        return $this->bigBlueButtonProvider->getBbbIpBaseUrl().preg_replace("/$this->macroUrl/", $meeting, $this->audioUrl);
    }

    public function setVideoUrl($videoUrl)
    {
        if (strstr($videoUrl, $this->macroUrl) === false) {
            throw new \Exception("Paramètre videoUrl du bundle OruBigBlueButtonBundle ne contient pas le paramètre {$this->$macroUrl}.");
        }
        $this->videoUrl = $videoUrl;
    }

    public function getVideoUrl($meeting)
    {
        return $this->bigBlueButtonProvider->getBbbIpBaseUrl().preg_replace("/$this->macroUrl/", $meeting, $this->videoUrl);
    }

    public function getNew($name = null, $password = null, $passwordModerator = null, $record = null, $begin = null)
    {
        $session = new Session();
        if ($name) {
            $session->setName($name);
        }
        if ($password) {
            $session->setPassword($password);
        }
        if ($passwordModerator) {
            $session->setModeratorPassword($passwordModerator);
        }
        if ($record) {
            $session->setRecord((bool) $record);
        }
        $session->setWelcomeMessage($this->defaultWelcomeMessage);
        $session->setLogoutUrl($this->defaultLogoutUrl);
        $session->setBegin(($begin) ? $begin : new \DateTime());

        $participant = new Participant();
        $participant->setUser($this->user);
        $session->addParticipant($participant);

        return $session;
    }

    public function getById($id)
    {
        $session = $this->manager->getRepository('OruBigBlueButtonBundle:Session')->find($id);

        $this->load($session);

        return $session;
    }

    public function getSessions(SessionFilter $sessionFilter)
    {
        $sessions = $this->manager->getRepository('OruBigBlueButtonBundle:Session')->findList($sessionFilter);
        if ($sessionFilter->getDeleted() !== null) {
            $dt = new \DateTime();
            if ($sessionFilter->getDeleted()) {
                $dt->setTimestamp(time() - $this->durationMax);
                $sessions->andWhere('u.begin <= :date')->setParameter('date', $dt);
            } else {
                $dt->setTimestamp(time() - $this->durationMax);
                $sessions->andWhere('u.begin >= :date')->setParameter('date', $dt);
            }
        }

        return $sessions;
    }

    public function getJoinSessionUrl(Session $session, $password)
    {
        $user = $this->user;
        $participant = null;

        if (!$this->createSession($session)) {
            throw new \Exception("Impossible de créer la session de visio-conférence : {$session->getId()}.");
        }

        if (!($session->getAccessible() || $session->getRunning())) {
            throw new \Exception("La session de visio-conférence {$session->getId()} n'est pas accessible.");
        }

        if (!$session->getParticipants()->exists(
            function ($key, $element) use ($user, &$participant) {
                if ($element->getUser() && $user && $element->getUser()->getId() === $user->getId()) {
                    $participant = $element;

                    return true;
                }

                return false;
            })) {
            throw new \Exception("Vous n'êtes pas participant de la session de visio-conférence {$session->getId()}.");
        }

        $joinParams = array(
            'meetingId' => $session->getId(),
            'username' => (string) $this->user,
            'password' => $password,
            'createTime' => '',
            'userId' => $participant->getId(),
            'webVoiceConf' => '',
        );

        $participant->setConnected(true);
        $this->manager->persist($participant);
        $this->manager->flush();

        $result = $this->bigBlueButtonProvider->getJoinMeetingURL($joinParams);

        if (!$result) {
            throw new \Exception("Impossible de récupérer l'url pour joindre la session de visio-conférence {$session->getId()}.");
        }

        return $result;
    }

    public function downloadVideoAudio(Session $session)
    {
        if ($session->isEnded() && $session->getRecord()) {
            $endParams = array(
                'meetingId' => $session->getId(),
                'password' => $session->getModeratorPassword(),
            );
            $this->bigBlueButtonProvider->endMeetingWithXmlResponseArray($endParams);

            $joinParams = array(
                'meetingId' => $session->getId(),
            );
            $recordings = $this->bigBlueButtonProvider->getRecordingsWithXmlResponseArray($joinParams);

            if (isset($recordings)) {
                foreach ($recordings as $recording) {
                    if (isset($recording['recordId'])) {
                        // download and link audio
                        $attachment = $this->attachment->createAttachmentFromPath($this->getAudioUrl($recording['recordId']), 'Conférence audio');
                        if ($attachment) {
                            $this->attachment->linkAttachementToEntity($attachment, $session);
                        }

                        // download and link video
                        $attachment = $this->attachment->createAttachmentFromPath($this->getVideoUrl($recording['recordId']), 'Conférence vidéo');
                        if ($attachment) {
                            $this->attachment->linkAttachementToEntity($attachment, $session);
                        }

                        //delete
                        $recordingParams = array(
                            'recordId' => $recording['recordId'],
                        );
                        $this->bigBlueButtonProvider->deleteRecordingsWithXmlResponseArray($recordingParams);
                    }
                }
            }
        }
    }

    public function load(Session $session)
    {
        $session->setAccessible(
            time() >= $session->getBegin()->getTimestamp()
            && time() <= ($session->getBegin()->getTimestamp() + $this->durationMax)
        );

        //$session->setRunning($this->isSessionRunning($session));
    }

    public function isSessionRunning($session)
    {
        $result = $this->bigBlueButtonProvider->isMeetingRunningWithXmlResponseArray($session->getId());

        if (isset($result['running'])) {
            return $result['running'] === 'true';
        }

        return false;
    }

    private function createSession(Session $session)
    {
        $creationParams = array(
            'meetingId' => $session->getId(),
            'meetingName' => $session->getName(),
            'attendeePw' => $session->getPassword(),
            'moderatorPw' => $session->getModeratorPassword(),
            'welcomeMsg' => $session->getWelcomeMessage(),
            'dialNumber' => '',
            'voiceBridge' => '',
            'webVoice' => '',
            'maxParticipants' => -1,
            'logoutUrl' => $session->getLogoutUrl(),
            'record' => $session->getRecord() ? 'true' : 'false',
            'duration' => '0',
            //'meta_category' => '', // Use to pass additional info to BBB server. See API docs.
        );

        // Create the meeting and get back a response:
        $result = $this->bigBlueButtonProvider->createMeetingWithXmlResponseArray($creationParams);
        if ($result === null) {
            // If we get a null response, then we're not getting any XML back from BBB.
            throw new \Exception('Aucune réponse. Il se peut que le serveur de visio-conférence ne soit pas accessible.');
        }

        // We got an XML response, so let's see what it says:
        if ($result['returncode'] === 'SUCCESS' || $result['returncode'] === '') {
            $this->load($session);

            return true;
        }

        throw new Exception("Impossible de créer la session de visio-conférence : {$session->getId()}.");
    }
}
