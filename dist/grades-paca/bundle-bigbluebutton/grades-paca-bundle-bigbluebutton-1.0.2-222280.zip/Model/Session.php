<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\BigBlueButtonBundle\Model;


use FOS\UserBundle\Model\UserInterface;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

class Session {

    /**
     * @var boolean
     */
    protected $mail;

    /**
     * @var \DateTime
     */
    protected $mailed;

    /**
     * @var \Doctrine\Common\Collections\Collection
     */
    protected $participants;

    /**
     * @var boolean
     */
    protected $running;

    /**
     * @var boolean
     */
    protected $deleted;

    /**
     * @var \DateTime
     */
    protected $duration;

    /**
     * @var string
     */
    protected $name;

    /**
     * @var string
     */
    protected $password;

    /**
     * @var string
     */
    protected $moderatorPassword;

    /**
     * @var string
     */
    protected $welcomeMessage;

    /**
     * @var string
     */
    protected $logoutUrl;

    /**
     * @var boolean
     */
    protected $record;

    /**
     * @var \DateTime
     */
    protected $created;

    /**
     * @var integer
     */
    protected $id;

    /**
     * @var \DateTime
     */
    protected $begin;

    protected $accessible;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->participants = new \Doctrine\Common\Collections\ArrayCollection();
        $this->mail = false;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Session
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set password
     *
     * @param string $password
     * @return Session
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get password
     *
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set moderatorPassword
     *
     * @param string $moderatorPassword
     * @return Session
     */
    public function setModeratorPassword($moderatorPassword)
    {
        $this->moderatorPassword = $moderatorPassword;

        return $this;
    }

    /**
     * Get moderatorPassword
     *
     * @return string
     */
    public function getModeratorPassword()
    {
        return $this->moderatorPassword;
    }

    /**
     * Set welcomeMessage
     *
     * @param string $welcomeMessage
     * @return Session
     */
    public function setWelcomeMessage($welcomeMessage)
    {
        $this->welcomeMessage = $welcomeMessage;

        return $this;
    }

    /**
     * Get welcomeMessage
     *
     * @return string
     */
    public function getWelcomeMessage()
    {
        return $this->welcomeMessage;
    }

    /**
     * Set logoutUrl
     *
     * @param string $logoutUrl
     * @return Session
     */
    public function setLogoutUrl($logoutUrl)
    {
        $this->logoutUrl = $logoutUrl;

        return $this;
    }

    /**
     * Get logoutUrl
     *
     * @return string
     */
    public function getLogoutUrl()
    {
        return $this->logoutUrl;
    }

    /**
     * Set record
     *
     * @param boolean $record
     * @return Session
     */
    public function setRecord($record)
    {
        $this->record = $record;

        return $this;
    }

    /**
     * Get record
     *
     * @return boolean
     */
    public function getRecord()
    {
        return $this->record;
    }

    /**
     * Set created
     *
     * @param \DateTime $created
     * @return Session
     */
    public function setCreated($created)
    {
        $this->created = $created;

        return $this;
    }

    /**
     * Get created
     *
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set begin
     *
     * @param \DateTime $begin
     * @return Session
     */
    public function setBegin($begin)
    {
        $this->begin = $begin;

        return $this;
    }

    /**
     * Get begin
     *
     * @return \DateTime
     */
    public function getBegin()
    {
        return $this->begin;
    }

    /**
     * Set duration
     *
     * @param \DateTime $duration
     * @return Session
     */
    public function setDuration($duration)
    {
        $this->duration = $duration;

        return $this;
    }

    /**
     * Get duration
     *
     * @return \DateTime
     */
    public function getDuration($seconds = false)
    {
        if($seconds && $this->duration)
        {
            $str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", "00:$1:$2", $this->duration->format('hh:ii:ss'));
            sscanf($str_time, "%d:%d:%d", $hours, $minutes, $seconds);
            return $hours * 3600 + $minutes * 60 + $seconds;
        }

        return $this->duration;
    }

    /**
     * Set deleted
     *
     * @param \DateTime $deleted
     * @return Session
     */
    public function setDeleted($deleted)
    {
        $this->deleted = $deleted;

        return $this;
    }

    /**
     * Get deleted
     *
     * @return \DateTime
     */
    public function getDeleted()
    {
        return $this->deleted;
    }

    /**
     * Set end
     *
     * @param boolean $end
     * @return Session
     */
    public function setEnd(\DateTime $end)
    {
        $this->end = $end;

        return $this;
    }

    /**
     * Get end
     *
     * @return boolean
     */
    public function getEnd()
    {
        $end = new \DateTime();
        $end->setTimestamp($this->begin->getTimestamp() + $this->getDuration(true));

        return $end;
    }

    /**
     * @param boolean $mail
     */
    public function setMail($mail)
    {
        $this->mail = $mail;
    }

    /**
     * @return boolean
     */
    public function getMail()
    {
        return ($this->mail || $this->getMailed() !== null);
    }

    /**
     * @param \DateTime $mailed
     */
    public function setMailed(\DateTime $mailed)
    {
        $this->mailed = $mailed;
    }

    /**
     * @return \DateTime
     */
    public function getMailed()
    {
        return $this->mailed;
    }

    /**
     * Add participants
     *
     * @param \Oru\Bundle\BigBlueButtonBundle\Entity\Participant $participants
     * @return Session
     */
    public function addParticipant(\Oru\Bundle\BigBlueButtonBundle\Entity\Participant $participants)
    {
        $participants->setSession($this);
        $this->participants[] = $participants;

        return $this;
    }

    /**
     * Remove participants
     *
     * @param \Oru\Bundle\BigBlueButtonBundle\Entity\Participant $participants
     */
    public function removeParticipant(\Oru\Bundle\BigBlueButtonBundle\Entity\Participant $participants)
    {
        $participants->setSession(null);
        $this->participants->removeElement($participants);
    }

    /**
     * Get participants
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getParticipants()
    {
        return $this->participants;
    }

    /**
     * @param UserInterface $user
     * @return bool
     */
    public function hasUser(UserInterface $user)
    {
        return $this->getParticipants()->exists(function ($key, $element) use ($user) { return ($user && $element->getUser() && $user->getId() == $element->getUser()->getId()); });
    }

    /**
     * @param boolean $running
     */
    public function setRunning($running)
    {
        $this->running = $running;
    }

    /**
     * @return boolean
     */
    public function getRunning()
    {
        return $this->running;
    }

    public function isValid(ExecutionContextInterface $context)
    {
        if($this->begin && $this->begin < new \DateTime())
        {
            $context->buildViolation('Date de début invalide : cette date est déjà passée !')->atPath('begin')->addViolation();
            return;
        }
    }

    public function __toString()
    {
        return (string) $this->getName();
    }

    /**
     * @param mixed $accessible
     */
    public function setAccessible($accessible)
    {
        $this->accessible = $accessible;
    }

    /**
     * @return mixed
     */
    public function getAccessible()
    {
        return $this->accessible;
    }

    public function isEnded()
    {
        if($this->getEnd()->getTimestamp() < time() && !$this->getRunning())
        {
            return true;
        }

        return false;
    }
} 