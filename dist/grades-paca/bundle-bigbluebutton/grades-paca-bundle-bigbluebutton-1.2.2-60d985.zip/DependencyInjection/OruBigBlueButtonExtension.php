<?php

namespace Oru\Bundle\BigBlueButtonBundle\DependencyInjection;

use Symfony\Component\Config\FileLocator;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Loader;
use Symfony\Component\HttpKernel\DependencyInjection\Extension;

/**
 * This is the class that loads and manages your bundle configuration.
 *
 * To learn more see {@link http://symfony.com/doc/current/cookbook/bundles/extension.html}
 */
class OruBigBlueButtonExtension extends Extension
{
    /**
     * {@inheritdoc}
     */
    public function load(array $configs, ContainerBuilder $container)
    {
        $configuration = new Configuration();
        $config = $this->processConfiguration($configuration, $configs);

        $loader = new Loader\XmlFileLoader($container, new FileLocator(__DIR__.'/../Resources/config'));
        $loader->load('services.xml');

        $container->setParameter('oru_bigbluebutton.provider.security_secret', $config['provider']['security_secret']);
        $container->setParameter('oru_bigbluebutton.provider.server_base_url', $config['provider']['server_base_url']);
        $container->setParameter('oru_bigbluebutton.provider.video_url', $config['provider']['video_url']);
        $container->setParameter('oru_bigbluebutton.provider.audio_url', $config['provider']['audio_url']);
        $container->setParameter('oru_bigbluebutton.welcome_message', $config['welcome_message']);
        $container->setParameter('oru_bigbluebutton.logout_route', $config['logout_route']);
        $container->setParameter('oru_bigbluebutton.duration_max', $config['duration_max']);
    }
}
