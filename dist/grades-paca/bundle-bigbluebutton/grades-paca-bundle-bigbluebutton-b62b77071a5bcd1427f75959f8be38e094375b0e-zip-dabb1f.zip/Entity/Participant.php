<?php

namespace Oru\Bundle\BigBlueButtonBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Participant
 */
class Participant
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var \Symfony\Component\Security\Core\User\UserInterface
     */
    private $user;

    /**
     * @var \Oru\Bundle\BigBlueButtonBundle\Entity\Session
     */
    private $session;

    /**
     * @var boolean
     */
    private $connected;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set user
     *
     * @param \Symfony\Component\Security\Core\User\UserInterface $user
     * @return Participant
     */
    public function setUser(\Symfony\Component\Security\Core\User\UserInterface $user = null)
    {
        $this->user = $user;
    
        return $this;
    }

    /**
     * Get user
     *
     * @return \Symfony\Component\Security\Core\User\UserInterface 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set session
     *
     * @param \Oru\Bundle\BigBlueButtonBundle\Entity\Session $session
     * @return Participant
     */
    public function setSession(\Oru\Bundle\BigBlueButtonBundle\Entity\Session $session = null)
    {
        $this->session = $session;
    
        return $this;
    }

    /**
     * Get session
     *
     * @return \Oru\Bundle\BigBlueButtonBundle\Entity\Session 
     */
    public function getSession()
    {
        return $this->session;
    }

    /**
     * @param boolean $connected
     */
    public function setConnected($connected)
    {
        $this->connected = $connected;
    }

    /**
     * @return boolean
     */
    public function getConnected()
    {
        return $this->connected;
    }

    public function __toString()
    {
        return $this->getUser()->__toString();
    }


}