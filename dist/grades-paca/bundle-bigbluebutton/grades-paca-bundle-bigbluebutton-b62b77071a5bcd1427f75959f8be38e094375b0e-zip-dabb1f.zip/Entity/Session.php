<?php

namespace Oru\Bundle\BigBlueButtonBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\BigBlueButtonBundle\Model\Session as BaseSession;

/**
 * Session
 */
class Session extends BaseSession
{
}