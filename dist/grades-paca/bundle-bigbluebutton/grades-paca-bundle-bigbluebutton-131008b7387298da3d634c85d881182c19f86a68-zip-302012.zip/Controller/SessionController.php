<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\BigBlueButtonBundle\Controller;

use Oru\Bundle\BigBlueButtonBundle\Filter\SessionFilter;
use Oru\Bundle\BigBlueButtonBundle\Form\SessionJoinType;
use Oru\Bundle\BigBlueButtonBundle\Form\SessionType;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Oru\Bundle\BigBlueButtonBundle\Entity\Session;
use Oru\Bundle\BigBlueButtonBundle\Listing\SessionListingType;
use Oru\Bundle\BigBlueButtonBundle\Form\SessionFilterType;

/**
 * Session controller.
 *
 */
class SessionController extends Controller
{
    /**
     * Lists all Session entities.
     *
     */
    public function indexAction(Request $request)
    {
        if($request->getSession()->has('session.filter'))
            $form = $this->createForm(new SessionFilterType(),new SessionFilter())->submit($request->getSession()->get('session.filter'));
        else $form = $this->createForm(new SessionFilterType(),new SessionFilter());

        $listing = $this->container->get('paginator.factory')->create(
            new SessionListingType(),
            $this->get('oru_bigbluebutton.session.factory')->getSessions($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('@OruBigBlueButton/Session/index.html.twig', array(
            'listing' => $listing,
            'form' => $this->createForm(new SessionFilterType(), $form->getData())->createView()
        ));
    }

    /**
     * Filters Session entities.
     *
     */
    public function filterAction(Request $request)
    {
        $form = $this->createForm(new SessionFilterType(),new SessionFilter())->handleRequest($request);

        if($form->isValid()) {
            $request->getSession()->set('session.filter', $request->get($form->getName()));
            return $this->redirect($this->generateUrl('session'));
        }

        $listing = $this->container->get('paginator.factory')->create(
            new SessionListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruBigBlueButtonBundle:Session')->findList($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('@OruBigBlueButton/Session/index.html.twig', array(
            'listing' => $listing,
            'form' => $form->createView()
        ));
    }

    /**
     * Finds and displays a Session entity.
     *
     */
    public function showAction($id)
    {
        $entity = $this->get('oru_bigbluebutton.session.factory')->getById($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Session entity.');
        }

        if($entity->hasUser($this->get('security.token_storage')->getToken()->getUser())
            && ($entity->getRunning() || $entity->getAccessible())
        ) {
            $form = $this->createJoinForm($entity);
        }

        return $this->render('@OruBigBlueButton/Session/show.html.twig', array(
            'entity'      => $entity,
            'form'        => isset($form) ? $form->createView() : null
        ));
    }

    /**
     * Creates a form to create a Session entity.
     *
     * @param Session $entity The entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createCreateForm(Session $entity)
    {
        $form = $this->createForm(new SessionType(), $entity, array(
            'action' => $this->generateUrl('session_create'),
            'method' => 'POST',
        ));

        return $form;
    }

    /**
     * Displays a form to create a new Session entity.
     *
     */
    public function newAction(Request $request)
    {
        $entity = $this->get('oru_bigbluebutton.session.factory')->getNew();
        $form   = $this->createCreateForm($entity);

        return $this->render('@OruBigBlueButton/Session/new.html.twig', array(
            'entity' => $entity,
            'form'   => $form->createView(),
        ));
    }

    /**
     * Creates a new Session entity.
     *
     */
    public function createAction(Request $request)
    {
        $entity = $this->get('oru_bigbluebutton.session.factory')->getNew();
        $form = $this->createCreateForm($entity);
        $form->handleRequest($request);

        if ($form->isValid())
        {
            $em = $this->getDoctrine()->getManager();
            $em->persist($entity);
            $em->flush();

            return $this->redirect($this->generateUrl('session_show', array('id' => $entity->getId())));
        }

        return $this->render('@OruBigBlueButton/Session/new.html.twig', array(
            'entity' => $entity,
            'form'   => $form->createView(),
        ));
    }

    private function createJoinForm(Session $session)
    {
        return $this->createForm(new SessionJoinType(), null, array(
            'action' => $this->generateUrl('session_join', array('id' => $session->getId())),
            'method' => 'POST',
        ))
        ->add('submit', 'submit', array('label' => ($session->getRunning()) ? 'listing.action.join' : 'listing.action.create', 'translation_domain' => 'OruBigBlueButtonBundle'));
    }

    public function joinAction(Request $request, $id)
    {
        $entity = $this->get('oru_bigbluebutton.session.factory')->getById($id);
        $form = $this->createJoinForm($entity);

        $form->handleRequest($request);
        if ($form->isValid()) {
            $data = $form->getData();
            if($data['password'] == $entity->getPassword() || $data['password'] == $entity->getModeratorPassword()) {
                $redirect = $this->get('oru_bigbluebutton.session.factory')->getJoinSessionUrl($entity, $data['password']);
                if($redirect) {
                    return $this->redirect($redirect);
                }
            } else {
                $form->addError(new FormError('Mot de passe erroné.'));
            }
        }

        return $this->render('@OruBigBlueButton/Session/show.html.twig', array(
            'entity' => $entity,
            'form'   => $form->createView(),
        ));
    }

    /**
     * Creates a new Session entity.
     *
     */
    public function runningAction(Request $request, $id)
    {
        $entity = $this->get('oru_bigbluebutton.session.factory')->getById($id);

        if($this->has('_format') && $this->get('_format') == 'json')
            return new JsonResponse(($entity->getRunning()) ? $this->get('translator')->trans('yes') : $this->get('translator')->trans('no'));

        return $this->render('@OruListing/Listing/Type/listing_checkbox_type.html.twig', array(
            'entity' => $entity,
            'label' => 'running'
        ));
    }

    /**
     * Creates a new Session entity.
     *
     */
    public function downloadAction(Request $request, $id)
    {
        $entity = $this->get('oru_bigbluebutton.session.factory')->getById($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Session entity.');
        }

        $this->get('oru_bigbluebutton.session.factory')->downloadVideoAudio($entity);

        if($entity->hasUser($this->get('security.token_storage')->getToken()->getUser())
            && ($entity->getRunning() || $entity->getAccessible())
        ) {
            $form = $this->createJoinForm($entity);
        }

        return $this->render('@OruBigBlueButton/Session/show.html.twig', array(
            'entity'      => $entity,
            'form'        => isset($form) ? $form->createView() : null
        ));
    }

}
