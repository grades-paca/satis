<?php

namespace Oru\Bundle\BigBlueButtonBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class SessionListingType extends AbstractListingType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('id', null, array('sort' => 'u.id', 'label' => 'listing.id', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('name', null, array('sort' => 'u.name','label' => 'listing.name', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('begin', null, array('sort' => 'u.begin','label' => 'listing.begin', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('duration', null, array('sort' => 'u.duration','label' => 'listing.duration', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('running', null, array('label' => 'listing.running', 'translation_domain' => 'OruBigBlueButtonBundle', 'template' => '@OruBigBlueButton/Session/running.html.twig'))
            ->add('show', 'object_action', array('route' => 'session_show', 'label' => 'listing.action.show', 'translation_domain' => 'OruBigBlueButtonBundle'))
            ->add('new', 'list_action', array('route' => 'session_new', 'label' => 'listing.action.new', 'translation_domain' => 'OruBigBlueButtonBundle'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\BigBlueButtonBundle\Entity\Session'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_bigbluebuttonbundle_sessionlisting';
    }
}
