<?php
/**
 * Created by PhpStorm.
 * User: Michaël GONZALEZ
 * Date: 17/06/2019
 * Time: 08:55
 */

namespace Oru\Bundle\TestBundle\Tests;


use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use Symfony\Component\DependencyInjection\Container;

class ContainerAwareTestCase extends KernelTestCase
{
    /**
     * @var Container
     */
    protected $container;

    public function __construct(string $name = null, array $data = [], string $dataName = '')
    {
        parent::__construct($name, $data, $dataName);

        //Boot du Kernel Symfony
        $kernel = self::createKernel();
        $kernel->boot();

        //Injection du container
        $this->container = $kernel->getContainer();
    }
}