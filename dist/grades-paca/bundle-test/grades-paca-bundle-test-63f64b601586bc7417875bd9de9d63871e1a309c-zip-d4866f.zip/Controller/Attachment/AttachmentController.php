<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 07/01/14
 * Time: 12:09
 */

namespace Oru\Bundle\TestBundle\Controller\Attachment;


use Oru\Bundle\AttachmentBundle\Tests\OruAttachmentBundleTest;
use Oru\Bundle\AttachmentBundle\Tests\Tool\TestFile;
use Oru\Bundle\TestBundle\Entity\ModelObject;
use Oru\Bundle\TestBundle\Form\ModelObjectType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class AttachmentController extends Controller
{
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();

        $entity = new ModelObject();

        $entity->setName('test');
        $entity->setDescription('description');
        $entity->setComment('commentaire');

        $em->persist($entity);
        $em->flush();

        $test_path_absolute = TestFile::PATH . '/' . TestFile::NAME;
        file_put_contents($test_path_absolute, TestFile::CONTENT);

        $uploadedFile = new UploadedFile($test_path_absolute, 'test.txt', 'text/plain', filesize($test_path_absolute));

        $attachment = $this->get('oru_attachment.context')->createAttachmentFromUploadedFile($uploadedFile);

        $em = $this->get('doctrine')->getManager();

        $em->persist($attachment);
        $em->flush();

        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findAll();

        $attachment_array = array();
        /** @var \Oru\Bundle\AttachmentBundle\Entity\Attachment $attachment */
        foreach($attachments as $attachment)
        {
            $attachment_array[$attachment->getId()] = array('description' => 'test');
        }

        $this->get('oru_attachment.context')->linkEntities($attachment_array, $entity);

        return
            $this->render('OruTestBundle:Attachment:index.html.twig',array(
                'entity'    => $entity,
            ));
    }

    public function newFormAction()
    {
        $editForm = $this->createForm(new ModelObjectType(), new ModelObject());

        $em = $this->get('doctrine')->getManager();

        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findAll();

        $attachment_array = array();
        /** @var \Oru\Bundle\AttachmentBundle\Entity\Attachment $attachment */
        foreach($attachments as $attachment)
        {
            $attachment_array[$attachment->getId()] = array('description' => 'test');
        }

        return
            $this->render('OruTestBundle:Attachment:new_form.html.twig',array(
                'attachments'    => $attachment_array,
                'edit_form'      => $editForm->createView(),
            ));
    }
} 