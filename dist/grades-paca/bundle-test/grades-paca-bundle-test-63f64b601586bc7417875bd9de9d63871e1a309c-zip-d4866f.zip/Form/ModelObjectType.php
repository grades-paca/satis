<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 07/01/14
 * Time: 16:12
 */

namespace Oru\Bundle\TestBundle\Form;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ModelObjectType extends AbstractType
{

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_bundle_test_model_object_form';
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\TestBundle\Entity\ModelObject'
        ));
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', null, array('label' => 'ModelObject.libelle', 'translation_domain' => 'OruTestBundle'))
            ->add('description', null, array('label' => 'ModelObject.description', 'translation_domain' => 'OruTestBundle'))
        ;
    }
}