<?php

namespace Oru\Bundle\TestBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruTestBundle extends Bundle
{
}
