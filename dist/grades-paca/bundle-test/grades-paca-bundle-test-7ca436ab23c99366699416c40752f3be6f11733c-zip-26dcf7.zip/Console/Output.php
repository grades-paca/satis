<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 07/01/14
 * Time: 14:13
 */

namespace Oru\Bundle\TestBundle\Console;


use Symfony\Component\Console\Output\Output as BaseOutput;

class Output extends BaseOutput
{
    /**
     * @var string
     */
    protected $output = '';

    /**
     * Writes a message to the output.
     *
     * @param string $message A message to write to the output
     * @param Boolean $newline Whether to add a newline or not
     */
    protected function doWrite($message, $newline)
    {
        $this->output .= $message;
    }

    /**
     * @return string
     */
    public function getOutput()
    {
        return $this->output;
    }
}