<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 08/01/14
 * Time: 11:36
 */

namespace Oru\Bundle\TestBundle\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

class DefaultController extends Controller
{
    public function indexAction()
    {
        $response = new Response();
        $response->setContent('Default');

        return $response;
    }
} 