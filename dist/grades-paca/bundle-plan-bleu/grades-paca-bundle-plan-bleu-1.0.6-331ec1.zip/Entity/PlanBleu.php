<?php

namespace Oru\Bundle\PlanBleuBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use libphonenumber\PhoneNumber;
use libphonenumber\PhoneNumberUtil;
use Symfony\Component\Validator\Context\ExecutionContextInterface;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class PlanBleu
 * @package Oru\Bundle\PlanBleuBundle\Entity
 * @author Michaël VEROUX
 */
class PlanBleu implements GroupSequenceProviderInterface
{
    /**
     * @var phone_number
     */
    private $telInfirmier;

    /**
     * @var phone_number
     */
    private $telMedecin;

    /**
     * @var phone_number
     */
    private $telCriseFilaire;

    /**
     * @var phone_number
     */
    private $telCriseGsm;

    /**
     * @var phone_number
     */
    private $telCriseSat;

    /**
     * @var phone_number
     */
    private $telCriseFax;

    /**
     * @var \DateTime
     */
    private $dernierExercice;

    /**
     * @var \DateTime
     */
    private $dernierPlanBleu;

    /**
     * @var \DateTime
     */
    private $dernierVersionPlanBleu;

    /**
     * @var string
     */
    private $lieuMad;

    /**
     * @var boolean
     */
    private $informatise;

    /**
     * @var boolean
     */
    private $pca;

    /**
     * @var boolean
     */
    private $annuaireCrise;

    /**
     * @var boolean
     */
    private $annuaireCriseMairie;

    /**
     * @var boolean
     */
    private $annuaireCrisePrefecture;

    /**
     * @var boolean
     */
    private $annuaireCriseSdis;

    /**
     * @var boolean
     */
    private $annuaireCriseArs;

    /**
     * @var boolean
     */
    private $annuaireCriseConseilGeneral;

    /**
     * @var boolean
     */
    private $annuaireCriseErdf;

    /**
     * @var boolean
     */
    private $etsAgeLd;

    /**
     * @var boolean
     */
    private $etsAgeDep;

    /**
     * @var boolean
     */
    private $etsAgeFoyer;

    /**
     * @var string
     */
    private $etsHandiMas;

    /**
     * @var string
     */
    private $etsHandiFam;

    /**
     * @var string
     */
    private $etsHandiEsat;

    /**
     * @var string
     */
    private $etsHandiIme;

    /**
     * @var string
     */
    private $etsHandiItep;

    /**
     * @var string
     */
    private $etsHandiEeap;

    /**
     * @var string
     */
    private $etsHandiAutre;

    /**
     * @var integer
     */
    private $capLitLs;

    /**
     * @var integer
     */
    private $capLitPermInt;

    /**
     * @var integer
     */
    private $capLitTmp;

    /**
     * @var integer
     */
    private $capLitPasa;

    /**
     * @var integer
     */
    private $capLitUhr;

    /**
     * @var integer
     */
    private $capLitCantou;

    /**
     * @var integer
     */
    private $capPlaceJourExt;

    /**
     * @var integer
     */
    private $capPlaceJourExtAlz;

    /**
     * @var integer
     */
    private $capLitAutre;

    /**
     * @var string
     */
    private $capLitAutreDetail;

    /**
     * @var integer
     */
    private $capTotale;

    /**
     * @var integer
     */
    private $popuGrabataire;

    /**
     * @var integer
     */
    private $popuMr;

    /**
     * @var integer
     */
    private $popuMobile;

    /**
     * @var float
     */
    private $persTotal;

    /**
     * @var float
     */
    private $persMedical;

    /**
     * @var float
     */
    private $persPara;

    /**
     * @var float
     */
    private $persAdm;

    /**
     * @var float
     */
    private $persLogist;

    /**
     * @var boolean
     */
    private $convEsProx;

    /**
     * @var string
     */
    private $convEsProxYes;

    /**
     * @var boolean
     */
    private $convEsPro;

    /**
     * @var string
     */
    private $convEsProYes;

    /**
     * @var boolean
     */
    private $dosMedUi;

    /**
     * @var boolean
     */
    private $dosMedUi24;

    /**
     * @var boolean
     */
    private $dosMedUiNumerique;

    /**
     * @var integer
     */
    private $eqVehicule;

    /**
     * @var string
     */
    private $eqVehiculeType;

    /**
     * @var string
     */
    private $eqVehiculeUsage;

    /**
     * @var boolean
     */
    private $nrjGroupe;

    /**
     * @var integer
     */
    private $nrjGroupeTps;

    /**
     * @var integer
     */
    private $nrjGroupeTpsDeg;

    /**
     * @var string
     */
    private $nrjGroupeTpsDegTxt;

    /**
     * @var boolean
     */
    private $nrjGroupeLoc;

    /**
     * @var string
     */
    private $nrjGroupeLocYes;

    /**
     * @var boolean
     */
    private $nrjObl;

    /**
     * @var boolean
     */
    private $nrjDoc;

    /**
     * @var boolean
     */
    private $alimFabrication;

    /**
     * @var string
     */
    private $alimFabricationNo;

    /**
     * @var integer
     */
    private $alimTps;

    /**
     * @var boolean
     */
    private $alimReserveEau;

    /**
     * @var boolean
     */
    private $alimReserveSec;

    /**
     * @var integer
     */
    private $med;

    /**
     * @var string
     */
    private $medLivraisonJour;

    /**
     * @var integer
     */
    private $medIndispensable;

    /**
     * @var integer
     */
    private $medIndispensableNot;

    /**
     * @var boolean
     */
    private $secCameras;

    /**
     * @var boolean
     */
    private $secAcces;

    /**
     * @var boolean
     */
    private $secBarriere;

    /**
     * @var integer
     */
    private $eqPiece;

    /**
     * @var boolean
     */
    private $eqFaorConf;

    /**
     * @var boolean
     */
    private $eqFaorEvac;

    /**
     * @var boolean
     */
    private $eqFaorPand;

    /**
     * @var string
     */
    private $eqRepli;

    /**
     * @var boolean
     */
    private $coop;

    /**
     * @var string
     */
    private $coopYes;

    /**
     * @var boolean
     */
    private $dari;

    /**
     * @var boolean
     */
    private $dariPap;

    /**
     * @var boolean
     */
    private $termine = false;

    /**
     * @var integer
     */
    private $id;

    /**
     * @var \Oru\Bundle\PlanBleuBundle\Entity\Identification
     */
    private $identification;

    /**
     * @var \DateTime
     */
    private $created;

    /**
     * @var \DateTime
     */
    private $updated;

    /**
     * @var \DateTime
     */
    private $deleted;

    private $anonymous = false;


    /**
     * Set telInfirmier
     *
     * @param phone_number $telInfirmier
     * @return PlanBleu
     */
    public function setTelInfirmier($telInfirmier)
    {
        if($telInfirmier && !$telInfirmier instanceof PhoneNumber)
            $telInfirmier = PhoneNumberUtil::getInstance()->parse($telInfirmier,'FR');
        elseif(!$telInfirmier)
            $telInfirmier = null;

        $this->telInfirmier = $telInfirmier;
    
        return $this;
    }

    /**
     * Get telInfirmier
     *
     * @return phone_number 
     */
    public function getTelInfirmier()
    {
        return $this->telInfirmier;
    }

    /**
     * Set telMedecin
     *
     * @param phone_number $telMedecin
     * @return PlanBleu
     */
    public function setTelMedecin($telMedecin)
    {
        if($telMedecin && !$telMedecin instanceof PhoneNumber)
            $telMedecin = PhoneNumberUtil::getInstance()->parse($telMedecin,'FR');
        elseif(!$telMedecin)
            $telMedecin = null;

        $this->telMedecin = $telMedecin;
    
        return $this;
    }

    /**
     * Get telMedecin
     *
     * @return phone_number 
     */
    public function getTelMedecin()
    {
        return $this->telMedecin;
    }

    /**
     * Set telCriseFilaire
     *
     * @param phone_number $telCriseFilaire
     * @return PlanBleu
     */
    public function setTelCriseFilaire($telCriseFilaire)
    {
        if($telCriseFilaire && !$telCriseFilaire instanceof PhoneNumber)
            $telCriseFilaire = PhoneNumberUtil::getInstance()->parse($telCriseFilaire,'FR');
        elseif(!$telCriseFilaire)
            $telCriseFilaire = null;

        $this->telCriseFilaire = $telCriseFilaire;
    
        return $this;
    }

    /**
     * Get telCriseFilaire
     *
     * @return phone_number 
     */
    public function getTelCriseFilaire()
    {
        return $this->telCriseFilaire;
    }

    /**
     * Set telCriseGsm
     *
     * @param phone_number $telCriseGsm
     * @return PlanBleu
     */
    public function setTelCriseGsm($telCriseGsm)
    {
        if($telCriseGsm && !$telCriseGsm instanceof PhoneNumber)
            $telCriseGsm = PhoneNumberUtil::getInstance()->parse($telCriseGsm,'FR');
        elseif(!$telCriseGsm)
            $telCriseGsm = null;

        $this->telCriseGsm = $telCriseGsm;
    
        return $this;
    }

    /**
     * Get telCriseGsm
     *
     * @return phone_number 
     */
    public function getTelCriseGsm()
    {
        return $this->telCriseGsm;
    }

    /**
     * Set telCriseSat
     *
     * @param phone_number $telCriseSat
     * @return PlanBleu
     */
    public function setTelCriseSat($telCriseSat)
    {
        if($telCriseSat && !$telCriseSat instanceof PhoneNumber)
            $telCriseSat = PhoneNumberUtil::getInstance()->parse($telCriseSat,'FR');
        elseif(!$telCriseSat)
            $telCriseSat = null;

        $this->telCriseSat = $telCriseSat;
    
        return $this;
    }

    /**
     * Get telCriseSat
     *
     * @return phone_number 
     */
    public function getTelCriseSat()
    {
        return $this->telCriseSat;
    }

    /**
     * Set telCriseFax
     *
     * @param phone_number $telCriseFax
     * @return PlanBleu
     */
    public function setTelCriseFax($telCriseFax)
    {
        if($telCriseFax && !$telCriseFax instanceof PhoneNumber)
            $telCriseFax = PhoneNumberUtil::getInstance()->parse($telCriseFax,'FR');
        elseif(!$telCriseFax)
            $telCriseFax = null;

        $this->telCriseFax = $telCriseFax;
    
        return $this;
    }

    /**
     * Get telCriseFax
     *
     * @return phone_number 
     */
    public function getTelCriseFax()
    {
        return $this->telCriseFax;
    }

    /**
     * Set dernierExercice
     *
     * @param \DateTime $dernierExercice
     * @return PlanBleu
     */
    public function setDernierExercice($dernierExercice)
    {
        if($dernierExercice && !$dernierExercice instanceof \DateTime)
            $dernierExercice = \DateTime::createFromFormat('Y-m-d H:i:s',$dernierExercice);

        $this->dernierExercice = $dernierExercice;
    
        return $this;
    }

    /**
     * Get dernierExercice
     *
     * @return \DateTime 
     */
    public function getDernierExercice()
    {
        return $this->dernierExercice;
    }

    /**
     * Set dernierPlanBleu
     *
     * @param \DateTime $dernierPlanBleu
     * @return PlanBleu
     */
    public function setDernierPlanBleu($dernierPlanBleu)
    {
        if($dernierPlanBleu && !$dernierPlanBleu instanceof \DateTime)
            $dernierPlanBleu = \DateTime::createFromFormat('Y-m-d H:i:s',$dernierPlanBleu);

        $this->dernierPlanBleu = $dernierPlanBleu;
    
        return $this;
    }

    /**
     * Get dernierPlanBleu
     *
     * @return \DateTime 
     */
    public function getDernierPlanBleu()
    {
        return $this->dernierPlanBleu;
    }

    /**
     * Set dernierVersionPlanBleu
     *
     * @param \DateTime $dernierVersionPlanBleu
     * @return PlanBleu
     */
    public function setDernierVersionPlanBleu($dernierVersionPlanBleu)
    {
        if($dernierVersionPlanBleu && !$dernierVersionPlanBleu instanceof \DateTime)
            $dernierVersionPlanBleu = \DateTime::createFromFormat('Y-m-d H:i:s',$dernierVersionPlanBleu);

        $this->dernierVersionPlanBleu = $dernierVersionPlanBleu;
    
        return $this;
    }

    /**
     * Get dernierVersionPlanBleu
     *
     * @return \DateTime 
     */
    public function getDernierVersionPlanBleu()
    {
        return $this->dernierVersionPlanBleu;
    }

    /**
     * Set lieuMad
     *
     * @param string $lieuMad
     * @return PlanBleu
     */
    public function setLieuMad($lieuMad)
    {
        $this->lieuMad = $lieuMad;
    
        return $this;
    }

    /**
     * Get lieuMad
     *
     * @return string 
     */
    public function getLieuMad()
    {
        return $this->lieuMad;
    }

    /**
     * Set informatise
     *
     * @param boolean $informatise
     * @return PlanBleu
     */
    public function setInformatise($informatise)
    {
        $this->informatise = $informatise;
    
        return $this;
    }

    /**
     * Get informatise
     *
     * @return boolean 
     */
    public function getInformatise()
    {
        return $this->informatise;
    }

    /**
     * Set pca
     *
     * @param boolean $pca
     * @return PlanBleu
     */
    public function setPca($pca)
    {
        $this->pca = $pca;
    
        return $this;
    }

    /**
     * Get pca
     *
     * @return boolean 
     */
    public function getPca()
    {
        return $this->pca;
    }

    /**
     * Set annuaireCrise
     *
     * @param boolean $annuaireCrise
     * @return PlanBleu
     */
    public function setAnnuaireCrise($annuaireCrise)
    {
        $this->annuaireCrise = $annuaireCrise;
    
        return $this;
    }

    /**
     * Get annuaireCrise
     *
     * @return boolean 
     */
    public function getAnnuaireCrise()
    {
        return $this->annuaireCrise;
    }

    /**
     * Set annuaireCriseMairie
     *
     * @param boolean $annuaireCriseMairie
     * @return PlanBleu
     */
    public function setAnnuaireCriseMairie($annuaireCriseMairie)
    {
        $this->annuaireCriseMairie = $annuaireCriseMairie;
    
        return $this;
    }

    /**
     * Get annuaireCriseMairie
     *
     * @return boolean 
     */
    public function getAnnuaireCriseMairie()
    {
        return $this->annuaireCriseMairie;
    }

    /**
     * Set annuaireCrisePrefecture
     *
     * @param boolean $annuaireCrisePrefecture
     * @return PlanBleu
     */
    public function setAnnuaireCrisePrefecture($annuaireCrisePrefecture)
    {
        $this->annuaireCrisePrefecture = $annuaireCrisePrefecture;
    
        return $this;
    }

    /**
     * Get annuaireCrisePrefecture
     *
     * @return boolean 
     */
    public function getAnnuaireCrisePrefecture()
    {
        return $this->annuaireCrisePrefecture;
    }

    /**
     * Set annuaireCriseSdis
     *
     * @param boolean $annuaireCriseSdis
     * @return PlanBleu
     */
    public function setAnnuaireCriseSdis($annuaireCriseSdis)
    {
        $this->annuaireCriseSdis = $annuaireCriseSdis;
    
        return $this;
    }

    /**
     * Get annuaireCriseSdis
     *
     * @return boolean 
     */
    public function getAnnuaireCriseSdis()
    {
        return $this->annuaireCriseSdis;
    }

    /**
     * Set annuaireCriseArs
     *
     * @param boolean $annuaireCriseArs
     * @return PlanBleu
     */
    public function setAnnuaireCriseArs($annuaireCriseArs)
    {
        $this->annuaireCriseArs = $annuaireCriseArs;
    
        return $this;
    }

    /**
     * Get annuaireCriseArs
     *
     * @return boolean 
     */
    public function getAnnuaireCriseArs()
    {
        return $this->annuaireCriseArs;
    }

    /**
     * Set annuaireCriseConseilGeneral
     *
     * @param boolean $annuaireCriseConseilGeneral
     * @return PlanBleu
     */
    public function setAnnuaireCriseConseilGeneral($annuaireCriseConseilGeneral)
    {
        $this->annuaireCriseConseilGeneral = $annuaireCriseConseilGeneral;
    
        return $this;
    }

    /**
     * Get annuaireCriseConseilGeneral
     *
     * @return boolean 
     */
    public function getAnnuaireCriseConseilGeneral()
    {
        return $this->annuaireCriseConseilGeneral;
    }

    /**
     * Set annuaireCriseErdf
     *
     * @param boolean $annuaireCriseErdf
     * @return PlanBleu
     */
    public function setAnnuaireCriseErdf($annuaireCriseErdf)
    {
        $this->annuaireCriseErdf = $annuaireCriseErdf;
    
        return $this;
    }

    /**
     * Get annuaireCriseErdf
     *
     * @return boolean 
     */
    public function getAnnuaireCriseErdf()
    {
        return $this->annuaireCriseErdf;
    }

    /**
     * Set etsAgeLd
     *
     * @param boolean $etsAgeLd
     * @return PlanBleu
     */
    public function setEtsAgeLd($etsAgeLd)
    {
        $this->etsAgeLd = $etsAgeLd;
    
        return $this;
    }

    /**
     * Get etsAgeLd
     *
     * @return boolean 
     */
    public function getEtsAgeLd()
    {
        return $this->etsAgeLd;
    }

    /**
     * Set etsAgeDep
     *
     * @param boolean $etsAgeDep
     * @return PlanBleu
     */
    public function setEtsAgeDep($etsAgeDep)
    {
        $this->etsAgeDep = $etsAgeDep;
    
        return $this;
    }

    /**
     * Get etsAgeDep
     *
     * @return boolean 
     */
    public function getEtsAgeDep()
    {
        return $this->etsAgeDep;
    }

    /**
     * Set etsAgeFoyer
     *
     * @param boolean $etsAgeFoyer
     * @return PlanBleu
     */
    public function setEtsAgeFoyer($etsAgeFoyer)
    {
        $this->etsAgeFoyer = $etsAgeFoyer;
    
        return $this;
    }

    /**
     * Get etsAgeFoyer
     *
     * @return boolean 
     */
    public function getEtsAgeFoyer()
    {
        return $this->etsAgeFoyer;
    }

    /**
     * Set etsHandiMas
     *
     * @param string $etsHandiMas
     * @return PlanBleu
     */
    public function setEtsHandiMas($etsHandiMas)
    {
        $this->etsHandiMas = $etsHandiMas;
    
        return $this;
    }

    /**
     * Get etsHandiMas
     *
     * @return string 
     */
    public function getEtsHandiMas()
    {
        return $this->etsHandiMas;
    }

    /**
     * Set etsHandiFam
     *
     * @param string $etsHandiFam
     * @return PlanBleu
     */
    public function setEtsHandiFam($etsHandiFam)
    {
        $this->etsHandiFam = $etsHandiFam;
    
        return $this;
    }

    /**
     * Get etsHandiFam
     *
     * @return string 
     */
    public function getEtsHandiFam()
    {
        return $this->etsHandiFam;
    }

    /**
     * Set etsHandiEsat
     *
     * @param string $etsHandiEsat
     * @return PlanBleu
     */
    public function setEtsHandiEsat($etsHandiEsat)
    {
        $this->etsHandiEsat = $etsHandiEsat;
    
        return $this;
    }

    /**
     * Get etsHandiEsat
     *
     * @return string 
     */
    public function getEtsHandiEsat()
    {
        return $this->etsHandiEsat;
    }

    /**
     * Set etsHandiIme
     *
     * @param string $etsHandiIme
     * @return PlanBleu
     */
    public function setEtsHandiIme($etsHandiIme)
    {
        $this->etsHandiIme = $etsHandiIme;
    
        return $this;
    }

    /**
     * Get etsHandiIme
     *
     * @return string 
     */
    public function getEtsHandiIme()
    {
        return $this->etsHandiIme;
    }

    /**
     * Set etsHandiItep
     *
     * @param string $etsHandiItep
     * @return PlanBleu
     */
    public function setEtsHandiItep($etsHandiItep)
    {
        $this->etsHandiItep = $etsHandiItep;
    
        return $this;
    }

    /**
     * Get etsHandiItep
     *
     * @return string 
     */
    public function getEtsHandiItep()
    {
        return $this->etsHandiItep;
    }

    /**
     * Set etsHandiEeap
     *
     * @param string $etsHandiEeap
     * @return PlanBleu
     */
    public function setEtsHandiEeap($etsHandiEeap)
    {
        $this->etsHandiEeap = $etsHandiEeap;
    
        return $this;
    }

    /**
     * Get etsHandiEeap
     *
     * @return string 
     */
    public function getEtsHandiEeap()
    {
        return $this->etsHandiEeap;
    }

    /**
     * Set etsHandiAutre
     *
     * @param string $etsHandiAutre
     * @return PlanBleu
     */
    public function setEtsHandiAutre($etsHandiAutre)
    {
        $this->etsHandiAutre = $etsHandiAutre;
    
        return $this;
    }

    /**
     * Get etsHandiAutre
     *
     * @return string 
     */
    public function getEtsHandiAutre()
    {
        return $this->etsHandiAutre;
    }

    /**
     * Set capLitLs
     *
     * @param integer $capLitLs
     * @return PlanBleu
     */
    public function setCapLitLs($capLitLs)
    {
        $this->capLitLs = $capLitLs;
    
        return $this;
    }

    /**
     * Get capLitLs
     *
     * @return integer 
     */
    public function getCapLitLs()
    {
        return $this->capLitLs;
    }

    /**
     * Set capLitPermInt
     *
     * @param integer $capLitPermInt
     * @return PlanBleu
     */
    public function setCapLitPermInt($capLitPermInt)
    {
        $this->capLitPermInt = $capLitPermInt;
    
        return $this;
    }

    /**
     * Get capLitPermInt
     *
     * @return integer 
     */
    public function getCapLitPermInt()
    {
        return $this->capLitPermInt;
    }

    /**
     * Set capLitTmp
     *
     * @param integer $capLitTmp
     * @return PlanBleu
     */
    public function setCapLitTmp($capLitTmp)
    {
        $this->capLitTmp = $capLitTmp;
    
        return $this;
    }

    /**
     * Get capLitTmp
     *
     * @return integer 
     */
    public function getCapLitTmp()
    {
        return $this->capLitTmp;
    }

    /**
     * Set capLitPasa
     *
     * @param integer $capLitPasa
     * @return PlanBleu
     */
    public function setCapLitPasa($capLitPasa)
    {
        $this->capLitPasa = $capLitPasa;
    
        return $this;
    }

    /**
     * Get capLitPasa
     *
     * @return integer 
     */
    public function getCapLitPasa()
    {
        return $this->capLitPasa;
    }

    /**
     * Set capLitUhr
     *
     * @param integer $capLitUhr
     * @return PlanBleu
     */
    public function setCapLitUhr($capLitUhr)
    {
        $this->capLitUhr = $capLitUhr;
    
        return $this;
    }

    /**
     * Get capLitUhr
     *
     * @return integer 
     */
    public function getCapLitUhr()
    {
        return $this->capLitUhr;
    }

    /**
     * Set capLitCantou
     *
     * @param integer $capLitCantou
     * @return PlanBleu
     */
    public function setCapLitCantou($capLitCantou)
    {
        $this->capLitCantou = $capLitCantou;
    
        return $this;
    }

    /**
     * Get capLitCantou
     *
     * @return integer 
     */
    public function getCapLitCantou()
    {
        return $this->capLitCantou;
    }

    /**
     * Set capPlaceJourExt
     *
     * @param integer $capPlaceJourExt
     * @return PlanBleu
     */
    public function setCapPlaceJourExt($capPlaceJourExt)
    {
        $this->capPlaceJourExt = $capPlaceJourExt;
    
        return $this;
    }

    /**
     * Get capPlaceJourExt
     *
     * @return integer 
     */
    public function getCapPlaceJourExt()
    {
        return $this->capPlaceJourExt;
    }

    /**
     * Set capPlaceJourExtAlz
     *
     * @param integer $capPlaceJourExtAlz
     * @return PlanBleu
     */
    public function setCapPlaceJourExtAlz($capPlaceJourExtAlz)
    {
        $this->capPlaceJourExtAlz = $capPlaceJourExtAlz;
    
        return $this;
    }

    /**
     * Get capPlaceJourExtAlz
     *
     * @return integer 
     */
    public function getCapPlaceJourExtAlz()
    {
        return $this->capPlaceJourExtAlz;
    }

    /**
     * Set capLitAutre
     *
     * @param integer $capLitAutre
     * @return PlanBleu
     */
    public function setCapLitAutre($capLitAutre)
    {
        $this->capLitAutre = $capLitAutre;
    
        return $this;
    }

    /**
     * Get capLitAutre
     *
     * @return integer 
     */
    public function getCapLitAutre()
    {
        return $this->capLitAutre;
    }

    /**
     * Set capLitAutreDetail
     *
     * @param string $capLitAutreDetail
     * @return PlanBleu
     */
    public function setCapLitAutreDetail($capLitAutreDetail)
    {
        $this->capLitAutreDetail = $capLitAutreDetail;
    
        return $this;
    }

    /**
     * Get capLitAutreDetail
     *
     * @return string 
     */
    public function getCapLitAutreDetail()
    {
        return $this->capLitAutreDetail;
    }

    /**
     * Set capTotale
     *
     * @param integer $capTotale
     * @return PlanBleu
     */
    public function setCapTotale($capTotale)
    {
        $this->capTotale = $capTotale;
    
        return $this;
    }

    /**
     * Get capTotale
     *
     * @return integer 
     */
    public function getCapTotale()
    {
        return $this->capTotale;
    }

    /**
     * Set popuGrabataire
     *
     * @param integer $popuGrabataire
     * @return PlanBleu
     */
    public function setPopuGrabataire($popuGrabataire)
    {
        $this->popuGrabataire = $popuGrabataire;
    
        return $this;
    }

    /**
     * Get popuGrabataire
     *
     * @return integer 
     */
    public function getPopuGrabataire()
    {
        return $this->popuGrabataire;
    }

    /**
     * Set popuMr
     *
     * @param integer $popuMr
     * @return PlanBleu
     */
    public function setPopuMr($popuMr)
    {
        $this->popuMr = $popuMr;
    
        return $this;
    }

    /**
     * Get popuMr
     *
     * @return integer 
     */
    public function getPopuMr()
    {
        return $this->popuMr;
    }

    /**
     * Set popuMobile
     *
     * @param integer $popuMobile
     * @return PlanBleu
     */
    public function setPopuMobile($popuMobile)
    {
        $this->popuMobile = $popuMobile;
    
        return $this;
    }

    /**
     * Get popuMobile
     *
     * @return integer 
     */
    public function getPopuMobile()
    {
        return $this->popuMobile;
    }

    /**
     * Set persTotal
     *
     * @param float $persTotal
     * @return PlanBleu
     */
    public function setPersTotal($persTotal)
    {
        $this->persTotal = $persTotal;
    
        return $this;
    }

    /**
     * Get persTotal
     *
     * @return float 
     */
    public function getPersTotal()
    {
        return $this->persTotal;
    }

    /**
     * Set persMedical
     *
     * @param float $persMedical
     * @return PlanBleu
     */
    public function setPersMedical($persMedical)
    {
        $this->persMedical = $persMedical;
    
        return $this;
    }

    /**
     * Get persMedical
     *
     * @return float 
     */
    public function getPersMedical()
    {
        return $this->persMedical;
    }

    /**
     * Set persPara
     *
     * @param float $persPara
     * @return PlanBleu
     */
    public function setPersPara($persPara)
    {
        $this->persPara = $persPara;
    
        return $this;
    }

    /**
     * Get persPara
     *
     * @return float 
     */
    public function getPersPara()
    {
        return $this->persPara;
    }

    /**
     * Set persAdm
     *
     * @param float $persAdm
     * @return PlanBleu
     */
    public function setPersAdm($persAdm)
    {
        $this->persAdm = $persAdm;
    
        return $this;
    }

    /**
     * Get persAdm
     *
     * @return float 
     */
    public function getPersAdm()
    {
        return $this->persAdm;
    }

    /**
     * @param float $persLogist
     */
    public function setPersLogist($persLogist)
    {
        $this->persLogist = $persLogist;
    }

    /**
     * @return float
     */
    public function getPersLogist()
    {
        return $this->persLogist;
    }

    /**
     * Set convEsProx
     *
     * @param boolean $convEsProx
     * @return PlanBleu
     */
    public function setConvEsProx($convEsProx)
    {
        $this->convEsProx = $convEsProx;
    
        return $this;
    }

    /**
     * Get convEsProx
     *
     * @return boolean 
     */
    public function getConvEsProx()
    {
        return $this->convEsProx;
    }

    /**
     * Set convEsProxYes
     *
     * @param string $convEsProxYes
     * @return PlanBleu
     */
    public function setConvEsProxYes($convEsProxYes)
    {
        $this->convEsProxYes = $convEsProxYes;
    
        return $this;
    }

    /**
     * Get convEsProxYes
     *
     * @return string 
     */
    public function getConvEsProxYes()
    {
        return $this->convEsProxYes;
    }

    /**
     * Set convEsPro
     *
     * @param boolean $convEsPro
     * @return PlanBleu
     */
    public function setConvEsPro($convEsPro)
    {
        $this->convEsPro = $convEsPro;
    
        return $this;
    }

    /**
     * Get convEsPro
     *
     * @return boolean 
     */
    public function getConvEsPro()
    {
        return $this->convEsPro;
    }

    /**
     * Set convEsProYes
     *
     * @param string $convEsProYes
     * @return PlanBleu
     */
    public function setConvEsProYes($convEsProYes)
    {
        $this->convEsProYes = $convEsProYes;
    
        return $this;
    }

    /**
     * Get convEsProYes
     *
     * @return string 
     */
    public function getConvEsProYes()
    {
        return $this->convEsProYes;
    }

    /**
     * Set dosMedUi
     *
     * @param boolean $dosMedUi
     * @return PlanBleu
     */
    public function setDosMedUi($dosMedUi)
    {
        $this->dosMedUi = $dosMedUi;
    
        return $this;
    }

    /**
     * Get dosMedUi
     *
     * @return boolean 
     */
    public function getDosMedUi()
    {
        return $this->dosMedUi;
    }

    /**
     * Set dosMedUi24
     *
     * @param boolean $dosMedUi24
     * @return PlanBleu
     */
    public function setDosMedUi24($dosMedUi24)
    {
        $this->dosMedUi24 = $dosMedUi24;
    
        return $this;
    }

    /**
     * Get dosMedUi24
     *
     * @return boolean 
     */
    public function getDosMedUi24()
    {
        return $this->dosMedUi24;
    }

    /**
     * Set dosMedUiNumerique
     *
     * @param boolean $dosMedUiNumerique
     * @return PlanBleu
     */
    public function setDosMedUiNumerique($dosMedUiNumerique)
    {
        $this->dosMedUiNumerique = $dosMedUiNumerique;
    
        return $this;
    }

    /**
     * Get dosMedUiNumerique
     *
     * @return boolean 
     */
    public function getDosMedUiNumerique()
    {
        return $this->dosMedUiNumerique;
    }

    /**
     * Set eqVehicule
     *
     * @param integer $eqVehicule
     * @return PlanBleu
     */
    public function setEqVehicule($eqVehicule)
    {
        $this->eqVehicule = $eqVehicule;
    
        return $this;
    }

    /**
     * Get eqVehicule
     *
     * @return integer 
     */
    public function getEqVehicule()
    {
        return $this->eqVehicule;
    }

    /**
     * Set eqVehiculeType
     *
     * @param string $eqVehiculeType
     * @return PlanBleu
     */
    public function setEqVehiculeType($eqVehiculeType)
    {
        $this->eqVehiculeType = $eqVehiculeType;
    
        return $this;
    }

    /**
     * Get eqVehiculeType
     *
     * @return string 
     */
    public function getEqVehiculeType()
    {
        return $this->eqVehiculeType;
    }

    /**
     * Set eqVehiculeUsage
     *
     * @param string $eqVehiculeUsage
     * @return PlanBleu
     */
    public function setEqVehiculeUsage($eqVehiculeUsage)
    {
        $this->eqVehiculeUsage = $eqVehiculeUsage;
    
        return $this;
    }

    /**
     * Get eqVehiculeUsage
     *
     * @return string 
     */
    public function getEqVehiculeUsage()
    {
        return $this->eqVehiculeUsage;
    }

    /**
     * Set nrjGroupe
     *
     * @param boolean $nrjGroupe
     * @return PlanBleu
     */
    public function setNrjGroupe($nrjGroupe)
    {
        $this->nrjGroupe = $nrjGroupe;
    
        return $this;
    }

    /**
     * Get nrjGroupe
     *
     * @return boolean 
     */
    public function getNrjGroupe()
    {
        return $this->nrjGroupe;
    }

    /**
     * Set nrjGroupeTps
     *
     * @param integer $nrjGroupeTps
     * @return PlanBleu
     */
    public function setNrjGroupeTps($nrjGroupeTps)
    {
        $this->nrjGroupeTps = $nrjGroupeTps;
    
        return $this;
    }

    /**
     * Get nrjGroupeTps
     *
     * @return integer 
     */
    public function getNrjGroupeTps()
    {
        return $this->nrjGroupeTps;
    }

    /**
     * Set nrjGroupeTpsDeg
     *
     * @param integer $nrjGroupeTpsDeg
     * @return PlanBleu
     */
    public function setNrjGroupeTpsDeg($nrjGroupeTpsDeg)
    {
        $this->nrjGroupeTpsDeg = $nrjGroupeTpsDeg;
    
        return $this;
    }

    /**
     * Get nrjGroupeTpsDeg
     *
     * @return integer 
     */
    public function getNrjGroupeTpsDeg()
    {
        return $this->nrjGroupeTpsDeg;
    }

    /**
     * Set nrjGroupeTpsDegTxt
     *
     * @param string $nrjGroupeTpsDegTxt
     * @return PlanBleu
     */
    public function setNrjGroupeTpsDegTxt($nrjGroupeTpsDegTxt)
    {
        $this->nrjGroupeTpsDegTxt = $nrjGroupeTpsDegTxt;
    
        return $this;
    }

    /**
     * Get nrjGroupeTpsDegTxt
     *
     * @return string 
     */
    public function getNrjGroupeTpsDegTxt()
    {
        return $this->nrjGroupeTpsDegTxt;
    }

    /**
     * Set nrjGroupeLoc
     *
     * @param boolean $nrjGroupeLoc
     * @return PlanBleu
     */
    public function setNrjGroupeLoc($nrjGroupeLoc)
    {
        $this->nrjGroupeLoc = $nrjGroupeLoc;
    
        return $this;
    }

    /**
     * Get nrjGroupeLoc
     *
     * @return boolean 
     */
    public function getNrjGroupeLoc()
    {
        return $this->nrjGroupeLoc;
    }

    /**
     * Set nrjGroupeLocYes
     *
     * @param string $nrjGroupeLocYes
     * @return PlanBleu
     */
    public function setNrjGroupeLocYes($nrjGroupeLocYes)
    {
        $this->nrjGroupeLocYes = $nrjGroupeLocYes;
    
        return $this;
    }

    /**
     * Get nrjGroupeLocYes
     *
     * @return string 
     */
    public function getNrjGroupeLocYes()
    {
        return $this->nrjGroupeLocYes;
    }

    /**
     * Set nrjObl
     *
     * @param boolean $nrjObl
     * @return PlanBleu
     */
    public function setNrjObl($nrjObl)
    {
        $this->nrjObl = $nrjObl;
    
        return $this;
    }

    /**
     * Get nrjObl
     *
     * @return boolean 
     */
    public function getNrjObl()
    {
        return $this->nrjObl;
    }

    /**
     * Set nrjDoc
     *
     * @param boolean $nrjDoc
     * @return PlanBleu
     */
    public function setNrjDoc($nrjDoc)
    {
        $this->nrjDoc = $nrjDoc;
    
        return $this;
    }

    /**
     * Get nrjDoc
     *
     * @return boolean 
     */
    public function getNrjDoc()
    {
        return $this->nrjDoc;
    }

    /**
     * Set alimFabrication
     *
     * @param boolean $alimFabrication
     * @return PlanBleu
     */
    public function setAlimFabrication($alimFabrication)
    {
        $this->alimFabrication = $alimFabrication;
    
        return $this;
    }

    /**
     * Get alimFabrication
     *
     * @return boolean 
     */
    public function getAlimFabrication()
    {
        return $this->alimFabrication;
    }

    /**
     * Set alimFabricationNo
     *
     * @param string $alimFabricationNo
     * @return PlanBleu
     */
    public function setAlimFabricationNo($alimFabricationNo)
    {
        $this->alimFabricationNo = $alimFabricationNo;
    
        return $this;
    }

    /**
     * Get alimFabricationNo
     *
     * @return string 
     */
    public function getAlimFabricationNo()
    {
        return $this->alimFabricationNo;
    }

    /**
     * Set alimTps
     *
     * @param integer $alimTps
     * @return PlanBleu
     */
    public function setAlimTps($alimTps)
    {
        $this->alimTps = $alimTps;
    
        return $this;
    }

    /**
     * Get alimTps
     *
     * @return integer 
     */
    public function getAlimTps()
    {
        return $this->alimTps;
    }

    /**
     * Set alimReserveEau
     *
     * @param boolean $alimReserveEau
     * @return PlanBleu
     */
    public function setAlimReserveEau($alimReserveEau)
    {
        $this->alimReserveEau = $alimReserveEau;
    
        return $this;
    }

    /**
     * Get alimReserveEau
     *
     * @return boolean 
     */
    public function getAlimReserveEau()
    {
        return $this->alimReserveEau;
    }

    /**
     * @param boolean $alimReserveSec
     */
    public function setAlimReserveSec($alimReserveSec)
    {
        $this->alimReserveSec = $alimReserveSec;
    }

    /**
     * @return boolean
     */
    public function getAlimReserveSec()
    {
        return $this->alimReserveSec;
    }

    /**
     * Set med
     *
     * @param integer $med
     * @return PlanBleu
     */
    public function setMed($med)
    {
        $this->med = $med;
    
        return $this;
    }

    /**
     * Get med
     *
     * @return integer 
     */
    public function getMed()
    {
        return $this->med;
    }

    /**
     * @param string $medLivraisonJour
     */
    public function setMedLivraisonJour($medLivraisonJour)
    {
        $this->medLivraisonJour = $medLivraisonJour;
    }

    /**
     * @return string
     */
    public function getMedLivraisonJour()
    {
        return $this->medLivraisonJour;
    }

    /**
     * Set medIndispensable
     *
     * @param integer $medIndispensable
     * @return PlanBleu
     */
    public function setMedIndispensable($medIndispensable)
    {
        $this->medIndispensable = $medIndispensable;
    
        return $this;
    }

    /**
     * Get medIndispensable
     *
     * @return integer 
     */
    public function getMedIndispensable()
    {
        return $this->medIndispensable;
    }

    /**
     * Set medIndispensableNot
     *
     * @param integer $medIndispensableNot
     * @return PlanBleu
     */
    public function setMedIndispensableNot($medIndispensableNot)
    {
        $this->medIndispensableNot = $medIndispensableNot;
    
        return $this;
    }

    /**
     * Get medIndispensableNot
     *
     * @return integer 
     */
    public function getMedIndispensableNot()
    {
        return $this->medIndispensableNot;
    }

    /**
     * Set secCameras
     *
     * @param boolean $secCameras
     * @return PlanBleu
     */
    public function setSecCameras($secCameras)
    {
        $this->secCameras = $secCameras;
    
        return $this;
    }

    /**
     * Get secCameras
     *
     * @return boolean 
     */
    public function getSecCameras()
    {
        return $this->secCameras;
    }

    /**
     * Set secAcces
     *
     * @param boolean $secAcces
     * @return PlanBleu
     */
    public function setSecAcces($secAcces)
    {
        $this->secAcces = $secAcces;
    
        return $this;
    }

    /**
     * Get secAcces
     *
     * @return boolean 
     */
    public function getSecAcces()
    {
        return $this->secAcces;
    }

    /**
     * Set secBarriere
     *
     * @param boolean $secBarriere
     * @return PlanBleu
     */
    public function setSecBarriere($secBarriere)
    {
        $this->secBarriere = $secBarriere;
    
        return $this;
    }

    /**
     * Get secBarriere
     *
     * @return boolean 
     */
    public function getSecBarriere()
    {
        return $this->secBarriere;
    }

    /**
     * Set eqPiece
     *
     * @param integer $eqPiece
     * @return PlanBleu
     */
    public function setEqPiece($eqPiece)
    {
        $this->eqPiece = $eqPiece;
    
        return $this;
    }

    /**
     * Get eqPiece
     *
     * @return integer 
     */
    public function getEqPiece()
    {
        return $this->eqPiece;
    }

    /**
     * Set eqFaorConf
     *
     * @param boolean $eqFaorConf
     * @return PlanBleu
     */
    public function setEqFaorConf($eqFaorConf)
    {
        $this->eqFaorConf = $eqFaorConf;
    
        return $this;
    }

    /**
     * Get eqFaorConf
     *
     * @return boolean 
     */
    public function getEqFaorConf()
    {
        return $this->eqFaorConf;
    }

    /**
     * Set eqFaorEvac
     *
     * @param boolean $eqFaorEvac
     * @return PlanBleu
     */
    public function setEqFaorEvac($eqFaorEvac)
    {
        $this->eqFaorEvac = $eqFaorEvac;
    
        return $this;
    }

    /**
     * Get eqFaorEvac
     *
     * @return boolean 
     */
    public function getEqFaorEvac()
    {
        return $this->eqFaorEvac;
    }

    /**
     * Set eqFaorPand
     *
     * @param boolean $eqFaorPand
     * @return PlanBleu
     */
    public function setEqFaorPand($eqFaorPand)
    {
        $this->eqFaorPand = $eqFaorPand;
    
        return $this;
    }

    /**
     * Get eqFaorPand
     *
     * @return boolean 
     */
    public function getEqFaorPand()
    {
        return $this->eqFaorPand;
    }

    /**
     * Set eqRepli
     *
     * @param string $eqRepli
     * @return PlanBleu
     */
    public function setEqRepli($eqRepli)
    {
        $this->eqRepli = $eqRepli;
    
        return $this;
    }

    /**
     * Get eqRepli
     *
     * @return string 
     */
    public function getEqRepli()
    {
        return $this->eqRepli;
    }

    /**
     * Set coop
     *
     * @param boolean $coop
     * @return PlanBleu
     */
    public function setCoop($coop)
    {
        $this->coop = $coop;
    
        return $this;
    }

    /**
     * Get coop
     *
     * @return boolean 
     */
    public function getCoop()
    {
        return $this->coop;
    }

    /**
     * Set coopYes
     *
     * @param string $coopYes
     * @return PlanBleu
     */
    public function setCoopYes($coopYes)
    {
        $this->coopYes = $coopYes;
    
        return $this;
    }

    /**
     * Get coopYes
     *
     * @return string 
     */
    public function getCoopYes()
    {
        return $this->coopYes;
    }

    /**
     * Set dari
     *
     * @param boolean $dari
     * @return PlanBleu
     */
    public function setDari($dari)
    {
        $this->dari = $dari;
    
        return $this;
    }

    /**
     * Get dari
     *
     * @return boolean 
     */
    public function getDari()
    {
        return $this->dari;
    }

    /**
     * Set dariPap
     *
     * @param boolean $dariPap
     * @return PlanBleu
     */
    public function setDariPap($dariPap)
    {
        $this->dariPap = $dariPap;
    
        return $this;
    }

    /**
     * Get dariPap
     *
     * @return boolean 
     */
    public function getDariPap()
    {
        return $this->dariPap;
    }

    /**
     * Set termine
     *
     * @param boolean $termine
     * @return PlanBleu
     */
    public function setTermine($termine)
    {
        $this->termine = $termine;
    
        return $this;
    }

    /**
     * Get termine
     *
     * @return boolean 
     */
    public function getTermine()
    {
        return $this->termine;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param \Oru\Bundle\PlanBleuBundle\Entity\Identification $identification
     */
    public function setIdentification($identification)
    {
        $this->identification = $identification;
    }

    /**
     * @return \Oru\Bundle\PlanBleuBundle\Entity\Identification
     */
    public function getIdentification()
    {
        return $this->identification;
    }

    /**
     * @param \DateTime $created
     */
    public function setCreated($created)
    {
        $this->created = $created;
    }

    /**
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param \DateTime $updated
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;
    }

    /**
     * @return \DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * @param \DateTime $deleted
     */
    public function setDeleted($deleted)
    {
        $this->deleted = $deleted;
    }

    /**
     * @return \DateTime
     */
    public function getDeleted()
    {
        return $this->deleted;
    }

    /**
     * @param ExecutionContextInterface $executionContext
     * @author Michaël VEROUX
     */
    public function isValid(ExecutionContextInterface $executionContext)
    {
        if($this->getDernierVersionPlanBleu() > new \DateTime('now'))
            $executionContext->buildViolation('La date de la dernière version doit être antérieure ou égale à ce jour.')->atPath('dernierVersionPlanBleu')->addViolation();

        if($this->getDernierExercice() > new \DateTime('now'))
            $executionContext->buildViolation('La date du dernier exercice doit être antérieure ou égale à ce jour.')->atPath('dernierExercice')->addViolation();

        if($this->getDernierPlanBleu() > new \DateTime('now'))
            $executionContext->buildViolation('La date du dernier Plan bleu doit être antérieure ou égale à ce jour.')->atPath('dernierPlanBleu')->addViolation();
    }

    /**
     * @return null|string
     * @author Michaël VEROUX
     */
    public function getFinessEtablissement()
    {
        return $this->getIdentification()->getEtablissement()->getFinessGeographique();
    }

    public function getEtablissement()
    {
        return $this->getIdentification()->getEtablissement();
    }

    public function getCredentialTarget($credential)
    {
        return $this->getEtablissement();
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $groups = array('default');

        if($this->getCapLitAutre())
            $groups[] = 'capLitAutreTrue';

        if($this->getConvEsProx())
            $groups[] = 'convEsProxTrue';

        if($this->getConvEsPro())
            $groups[] = 'convEsProTrue';

        if($this->getCoop())
            $groups[] = 'coopTrue';

        if($this->getNrjGroupe())
            $groups[] = 'nrjGroupeTrue';

        if($this->getNrjGroupeLoc())
            $groups[] = 'nrjGroupeLocTrue';

        return $groups;
    }

    /**
     * @return boolean
     */
    public function isAnonymous()
    {
        return $this->anonymous;
    }

    /**
     * @param boolean $anonymous
     */
    public function setAnonymous($anonymous)
    {
        $this->anonymous = $anonymous;
    }
}
