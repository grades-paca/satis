<?php
/**
 * Author: Michaël VEROUX
 * Date: 27/06/14
 * Time: 10:33
 */

namespace Oru\Bundle\PlanBleuBundle\Entity;

use Oru\Bundle\RorBundle\Entity\Etablissement;

class Identification
{
    /**
     * @var int
     */
    protected $id = null;

    /**
     * @var EtablissementInterface|Etablissement
     */
    protected $etablissement = null;

    /**
     * @var PlanBleu
     */
    protected $planBleu = null;

    protected $handicapType;

    private $anonymous = false;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param \Oru\Bundle\PlanBleuBundle\Entity\EtablissementInterface $etablissement
     */
    public function setEtablissement($etablissement)
    {
        $this->etablissement = $etablissement;
    }

    /**
     * @return \Oru\Bundle\PlanBleuBundle\Entity\EtablissementInterface|Etablissement
     */
    public function getEtablissement()
    {
        return $this->etablissement;
    }

    /**
     * @param \Oru\Bundle\PlanBleuBundle\Entity\PlanBleu $planBleu
     */
    public function setPlanBleu($planBleu)
    {
        $this->planBleu = $planBleu;
    }

    /**
     * @return \Oru\Bundle\PlanBleuBundle\Entity\PlanBleu
     */
    public function getPlanBleu()
    {
        return $this->planBleu;
    }

    /**
     * @param mixed $faxAlerte
     */
    public function setFaxAlerte($faxAlerte)
    {
        $this->etablissement->setAlerteFax($faxAlerte);
    }

    /**
     * @return mixed
     */
    public function getFaxAlerte()
    {
        return $this->etablissement->getAlerteFax();
    }

    /**
     * @param mixed $telAlerte
     */
    public function setTelAlerte($telAlerte)
    {
        $this->etablissement->setAlerteTelephone($telAlerte);
    }

    /**
     * @return mixed
     */
    public function getTelAlerte()
    {
        return $this->etablissement->getAlerteTelephone();
    }

    /**
     * @param mixed $telDirection
     */
    public function setTelDirection($telDirection)
    {
        $this->etablissement->setDirectionTelephone($telDirection);
    }

    /**
     * @return mixed
     */
    public function getTelDirection()
    {
        return $this->etablissement->getDirectionTelephone();
    }

    /**
     * @param mixed $telStandard
     */
    public function setTelStandard($telStandard)
    {
        $this->etablissement->setStandardTelephone($telStandard);
    }

    /**
     * @return mixed
     */
    public function getTelStandard()
    {
        return $this->etablissement->getStandardTelephone();
    }

    /**
     * @param mixed $handicapType
     */
    public function setHandicapType($handicapType)
    {
        $this->handicapType = $handicapType;
    }

    /**
     * @return mixed
     */
    public function getHandicapType()
    {
        return $this->handicapType;
    }

    public function getNom()
    {
        return $this->getEtablissement()->getNom();
    }

    public function setNom($nom)
    {
        return $this->getEtablissement()->setNom($nom);
    }

    public function getFiness()
    {
        return $this->getEtablissement()->getFinessGeographique();
    }

    public function setFiness($finess)
    {
        return $this->getEtablissement()->setFinessGeographique($finess);
    }

    public function getSiret()
    {
        return $this->getEtablissement()->getSiret();
    }

    public function setSiret($siret)
    {
        return $this->getEtablissement()->setSiret($siret);
    }

    public function getStructure()
    {
        return (string)$this->getEtablissement()->getStructure();
    }

    public function setStructure($structure)
    {
        return;
    }

    public function getAdresse()
    {
        return (string)$this->getEtablissement()->getAdresse();
    }

    public function setAdresse($adresse)
    {
        return;
    }

    public function getEmailAlerte()
    {
        return $this->getEtablissement()->getAlerteEmail();
    }

    public function setEmailAlerte($email)
    {
        return $this->getEtablissement()->setAlerteEmail($email);
    }

    /**
     * @return boolean
     */
    public function isAnonymous()
    {
        return $this->anonymous;
    }

    /**
     * @param boolean $anonymous
     */
    public function setAnonymous($anonymous)
    {
        $this->anonymous = $anonymous;
    }
} 