<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 25/02/14
 * Time: 15:28
 */

namespace Oru\Bundle\PlanBleuBundle\Filter;

/**
 * Class PlanBleuFilter
 * @package Oru\Bundle\PlanBleuBundle\Filter
 * @author Michaël VEROUX
 */
class PlanBleuFilter
{
    /**
     * @var array
     */
    protected $departements = array();

    /**
     * @var array
     */
    protected $etablissements = array();

    /**
     * @var string
     */
    protected $finess = '';

    /**
     * @var null|boolean
     */
    protected $termine = null;

    /**
     * @var bool
     */
    protected $deleted = false;

    /**
     * @param array $departement
     */
    public function setDepartements($departements)
    {
        $this->departements = $departements;
    }

    /**
     * @return array
     */
    public function getDepartements()
    {
        return $this->departements;
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    public function getDepartementsIds()
    {
        $ids = array();

        foreach($this->getDepartements() as $departement)
            array_push($ids, $departement->getId());

        return $ids;
    }

    /**
     * @param array $etablissements
     */
    public function setEtablissements($etablissements)
    {
        $this->etablissements = $etablissements;
    }

    /**
     * @return array
     */
    public function getEtablissements()
    {
        return $this->etablissements;
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    public function getEtablissementsIds()
    {
        $ids = array();

        foreach($this->getEtablissements() as $etablissement)
            array_push($ids, $etablissement->getId());

        return $ids;
    }

    /**
     * @param string $finess
     */
    public function setFiness($finess)
    {
        $this->finess = $finess;
    }

    /**
     * @return string
     */
    public function getFiness()
    {
        return $this->finess;
    }

    /**
     * @param null $termine
     */
    public function setTermine($termine)
    {
        $this->termine = $termine;
    }

    /**
     * @return null
     */
    public function getTermine()
    {
        return $this->termine;
    }

    /**
     * @param boolean $deleted
     * @return $this
     */
    public function setDeleted($deleted)
    {
        $this->deleted = (bool)$deleted;

        return $this;
    }

    /**
     * @return boolean
     */
    public function getDeleted()
    {
        return (bool)$this->deleted;
    }
} 