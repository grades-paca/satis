<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 17/03/14
 * Time: 17:19
 */

namespace Oru\Bundle\PlanBleuBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class OruPlanBleuBundle
 * @package Oru\Bundle\PlanBleuBundle
 * @author Michaël VEROUX
 */
class OruPlanBleuBundle extends Bundle
{

} 