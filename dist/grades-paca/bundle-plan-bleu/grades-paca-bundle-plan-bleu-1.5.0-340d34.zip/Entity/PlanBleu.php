<?php

namespace Oru\Bundle\PlanBleuBundle\Entity;

use libphonenumber\PhoneNumber;
use libphonenumber\PhoneNumberUtil;
use Oru\Bundle\RorCredentialsBundle\Entity\Credential;
use Oru\Bundle\RorCredentialsBundle\Interfaces\CredentialSwitchEntityInterface;
use Symfony\Component\Validator\Context\ExecutionContextInterface;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class PlanBleu.
 *
 * @author Michaël VEROUX
 */
class PlanBleu implements GroupSequenceProviderInterface, CredentialSwitchEntityInterface
{
    /**
     * @var phone_number
     */
    private $telInfirmier;

    /**
     * @var phone_number
     */
    private $telMedecin;

    /**
     * @var phone_number
     */
    private $telCriseFilaire;

    /**
     * @var phone_number
     */
    private $telCriseGsm;

    /**
     * @var phone_number
     */
    private $telCriseSat;

    /**
     * @var phone_number
     */
    private $telCriseFax;

    /**
     * @var \DateTime
     */
    private $dernierExercice;

    /**
     * @var \DateTime
     */
    private $dernierPlanBleu;

    /**
     * @var \DateTime
     */
    private $dernierVersionPlanBleu;

    /**
     * @var string
     */
    private $lieuMad;

    /**
     * @var bool
     */
    private $informatise;

    /**
     * @var bool
     */
    private $pca;

    /**
     * @var bool
     */
    private $annuaireCrise;

    /**
     * @var bool
     */
    private $annuaireCriseMairie;

    /**
     * @var bool
     */
    private $annuaireCrisePrefecture;

    /**
     * @var bool
     */
    private $annuaireCriseSdis;

    /**
     * @var bool
     */
    private $annuaireCriseArs;

    /**
     * @var bool
     */
    private $annuaireCriseConseilGeneral;

    /**
     * @var bool
     */
    private $annuaireCriseErdf;

    /**
     * @var bool
     */
    private $etsAgeLd;

    /**
     * @var bool
     */
    private $etsAgeDep;

    /**
     * @var bool
     */
    private $etsAgeFoyer;

    /**
     * @var string
     */
    private $etsHandiMas;

    /**
     * @var string
     */
    private $etsHandiFam;

    /**
     * @var string
     */
    private $etsHandiEsat;

    /**
     * @var string
     */
    private $etsHandiIme;

    /**
     * @var string
     */
    private $etsHandiItep;

    /**
     * @var string
     */
    private $etsHandiEeap;

    /**
     * @var string
     */
    private $etsHandiAutre;

    /**
     * @var int
     */
    private $capLitLs;

    /**
     * @var int
     */
    private $capLitPermInt;

    /**
     * @var int
     */
    private $capLitTmp;

    /**
     * @var int
     */
    private $capLitPasa;

    /**
     * @var int
     */
    private $capLitUhr;

    /**
     * @var int
     */
    private $capLitCantou;

    /**
     * @var int
     */
    private $capPlaceJourExt;

    /**
     * @var int
     */
    private $capPlaceJourExtAlz;

    /**
     * @var int
     */
    private $capLitAutre;

    /**
     * @var string
     */
    private $capLitAutreDetail;

    /**
     * @var int
     */
    private $capTotale;

    /**
     * @var int
     */
    private $popuGrabataire;

    /**
     * @var int
     */
    private $popuMr;

    /**
     * @var int
     */
    private $popuMobile;

    /**
     * @var float
     */
    private $persTotal;

    /**
     * @var float
     */
    private $persMedical;

    /**
     * @var float
     */
    private $persPara;

    /**
     * @var float
     */
    private $persAdm;

    /**
     * @var float
     */
    private $persLogist;

    /**
     * @var bool
     */
    private $convEsProx;

    /**
     * @var string
     */
    private $convEsProxYes;

    /**
     * @var bool
     */
    private $convEsPro;

    /**
     * @var string
     */
    private $convEsProYes;

    /**
     * @var bool
     */
    private $dosMedUi;

    /**
     * @var bool
     */
    private $dosMedUi24;

    /**
     * @var bool
     */
    private $dosMedUiNumerique;

    /**
     * @var int
     */
    private $eqVehicule;

    /**
     * @var string
     */
    private $eqVehiculeType;

    /**
     * @var string
     */
    private $eqVehiculeUsage;

    /**
     * @var bool
     */
    private $nrjGroupe;

    /**
     * @var int
     */
    private $nrjGroupeTps;

    /**
     * @var int
     */
    private $nrjGroupeTpsDeg;

    /**
     * @var string
     */
    private $nrjGroupeTpsDegTxt;

    /**
     * @var bool
     */
    private $nrjGroupeLoc;

    /**
     * @var string
     */
    private $nrjGroupeLocYes;

    /**
     * @var bool
     */
    private $nrjObl;

    /**
     * @var bool
     */
    private $nrjDoc;

    /**
     * @var bool
     */
    private $alimFabrication;

    /**
     * @var string
     */
    private $alimFabricationNo;

    /**
     * @var int
     */
    private $alimTps;

    /**
     * @var bool
     */
    private $alimReserveEau;

    /**
     * @var bool
     */
    private $alimReserveSec;

    /**
     * @var int
     */
    private $med;

    /**
     * @var string
     */
    private $medLivraisonJour;

    /**
     * @var int
     */
    private $medIndispensable;

    /**
     * @var int
     */
    private $medIndispensableNot;

    /**
     * @var bool
     */
    private $secCameras;

    /**
     * @var bool
     */
    private $secAcces;

    /**
     * @var bool
     */
    private $secBarriere;

    /**
     * @var int
     */
    private $eqPiece;

    /**
     * @var bool
     */
    private $eqFaorConf;

    /**
     * @var bool
     */
    private $eqFaorEvac;

    /**
     * @var bool
     */
    private $eqFaorPand;

    /**
     * @var string
     */
    private $eqRepli;

    /**
     * @var bool
     */
    private $coop;

    /**
     * @var string
     */
    private $coopYes;

    /**
     * @var bool
     */
    private $dari;

    /**
     * @var bool
     */
    private $dariPap;

    /**
     * @var bool
     */
    private $termine = false;

    /**
     * @var int
     */
    private $id;

    /**
     * @var \Oru\Bundle\PlanBleuBundle\Entity\Identification
     */
    private $identification;

    /**
     * @var \DateTime
     */
    private $created;

    /**
     * @var \DateTime
     */
    private $updated;

    /**
     * @var \DateTime
     */
    private $deleted;

    private $anonymous = false;

    /**
     * Set telInfirmier.
     *
     * @param phone_number $telInfirmier
     *
     * @return PlanBleu
     */
    public function setTelInfirmier($telInfirmier)
    {
        if ($telInfirmier && !$telInfirmier instanceof PhoneNumber) {
            $telInfirmier = PhoneNumberUtil::getInstance()->parse($telInfirmier, 'FR');
        } elseif (!$telInfirmier) {
            $telInfirmier = null;
        }

        $this->telInfirmier = $telInfirmier;

        return $this;
    }

    /**
     * Get telInfirmier.
     *
     * @return phone_number
     */
    public function getTelInfirmier()
    {
        return $this->telInfirmier;
    }

    /**
     * Set telMedecin.
     *
     * @param phone_number $telMedecin
     *
     * @return PlanBleu
     */
    public function setTelMedecin($telMedecin)
    {
        if ($telMedecin && !$telMedecin instanceof PhoneNumber) {
            $telMedecin = PhoneNumberUtil::getInstance()->parse($telMedecin, 'FR');
        } elseif (!$telMedecin) {
            $telMedecin = null;
        }

        $this->telMedecin = $telMedecin;

        return $this;
    }

    /**
     * Get telMedecin.
     *
     * @return phone_number
     */
    public function getTelMedecin()
    {
        return $this->telMedecin;
    }

    /**
     * Set telCriseFilaire.
     *
     * @param phone_number $telCriseFilaire
     *
     * @return PlanBleu
     */
    public function setTelCriseFilaire($telCriseFilaire)
    {
        if ($telCriseFilaire && !$telCriseFilaire instanceof PhoneNumber) {
            $telCriseFilaire = PhoneNumberUtil::getInstance()->parse($telCriseFilaire, 'FR');
        } elseif (!$telCriseFilaire) {
            $telCriseFilaire = null;
        }

        $this->telCriseFilaire = $telCriseFilaire;

        return $this;
    }

    /**
     * Get telCriseFilaire.
     *
     * @return phone_number
     */
    public function getTelCriseFilaire()
    {
        return $this->telCriseFilaire;
    }

    /**
     * Set telCriseGsm.
     *
     * @param phone_number $telCriseGsm
     *
     * @return PlanBleu
     */
    public function setTelCriseGsm($telCriseGsm)
    {
        if ($telCriseGsm && !$telCriseGsm instanceof PhoneNumber) {
            $telCriseGsm = PhoneNumberUtil::getInstance()->parse($telCriseGsm, 'FR');
        } elseif (!$telCriseGsm) {
            $telCriseGsm = null;
        }

        $this->telCriseGsm = $telCriseGsm;

        return $this;
    }

    /**
     * Get telCriseGsm.
     *
     * @return phone_number
     */
    public function getTelCriseGsm()
    {
        return $this->telCriseGsm;
    }

    /**
     * Set telCriseSat.
     *
     * @param phone_number $telCriseSat
     *
     * @return PlanBleu
     */
    public function setTelCriseSat($telCriseSat)
    {
        if ($telCriseSat && !$telCriseSat instanceof PhoneNumber) {
            $telCriseSat = PhoneNumberUtil::getInstance()->parse($telCriseSat, 'FR');
        } elseif (!$telCriseSat) {
            $telCriseSat = null;
        }

        $this->telCriseSat = $telCriseSat;

        return $this;
    }

    /**
     * Get telCriseSat.
     *
     * @return phone_number
     */
    public function getTelCriseSat()
    {
        return $this->telCriseSat;
    }

    /**
     * Set telCriseFax.
     *
     * @param phone_number $telCriseFax
     *
     * @return PlanBleu
     */
    public function setTelCriseFax($telCriseFax)
    {
        if ($telCriseFax && !$telCriseFax instanceof PhoneNumber) {
            $telCriseFax = PhoneNumberUtil::getInstance()->parse($telCriseFax, 'FR');
        } elseif (!$telCriseFax) {
            $telCriseFax = null;
        }

        $this->telCriseFax = $telCriseFax;

        return $this;
    }

    /**
     * Get telCriseFax.
     *
     * @return phone_number
     */
    public function getTelCriseFax()
    {
        return $this->telCriseFax;
    }

    /**
     * Set dernierExercice.
     *
     * @param \DateTime $dernierExercice
     *
     * @return PlanBleu
     */
    public function setDernierExercice($dernierExercice)
    {
        if ($dernierExercice && !$dernierExercice instanceof \DateTime) {
            $dernierExercice = \DateTime::createFromFormat('Y-m-d H:i:s', $dernierExercice);
        }

        $this->dernierExercice = $dernierExercice;

        return $this;
    }

    /**
     * Get dernierExercice.
     *
     * @return \DateTime
     */
    public function getDernierExercice()
    {
        return $this->dernierExercice;
    }

    /**
     * Set dernierPlanBleu.
     *
     * @param \DateTime $dernierPlanBleu
     *
     * @return PlanBleu
     */
    public function setDernierPlanBleu($dernierPlanBleu)
    {
        if ($dernierPlanBleu && !$dernierPlanBleu instanceof \DateTime) {
            $dernierPlanBleu = \DateTime::createFromFormat('Y-m-d H:i:s', $dernierPlanBleu);
        }

        $this->dernierPlanBleu = $dernierPlanBleu;

        return $this;
    }

    /**
     * Get dernierPlanBleu.
     *
     * @return \DateTime
     */
    public function getDernierPlanBleu()
    {
        return $this->dernierPlanBleu;
    }

    /**
     * Set dernierVersionPlanBleu.
     *
     * @param \DateTime $dernierVersionPlanBleu
     *
     * @return PlanBleu
     */
    public function setDernierVersionPlanBleu($dernierVersionPlanBleu)
    {
        if ($dernierVersionPlanBleu && !$dernierVersionPlanBleu instanceof \DateTime) {
            $dernierVersionPlanBleu = \DateTime::createFromFormat('Y-m-d H:i:s', $dernierVersionPlanBleu);
        }

        $this->dernierVersionPlanBleu = $dernierVersionPlanBleu;

        return $this;
    }

    /**
     * Get dernierVersionPlanBleu.
     *
     * @return \DateTime
     */
    public function getDernierVersionPlanBleu()
    {
        return $this->dernierVersionPlanBleu;
    }

    /**
     * Set lieuMad.
     *
     * @param string $lieuMad
     *
     * @return PlanBleu
     */
    public function setLieuMad($lieuMad)
    {
        $this->lieuMad = $lieuMad;

        return $this;
    }

    /**
     * Get lieuMad.
     *
     * @return string
     */
    public function getLieuMad()
    {
        return $this->lieuMad;
    }

    /**
     * Set informatise.
     *
     * @param bool $informatise
     *
     * @return PlanBleu
     */
    public function setInformatise($informatise)
    {
        $this->informatise = $informatise;

        return $this;
    }

    /**
     * Get informatise.
     *
     * @return bool
     */
    public function getInformatise()
    {
        return $this->informatise;
    }

    /**
     * Set pca.
     *
     * @param bool $pca
     *
     * @return PlanBleu
     */
    public function setPca($pca)
    {
        $this->pca = $pca;

        return $this;
    }

    /**
     * Get pca.
     *
     * @return bool
     */
    public function getPca()
    {
        return $this->pca;
    }

    /**
     * Set annuaireCrise.
     *
     * @param bool $annuaireCrise
     *
     * @return PlanBleu
     */
    public function setAnnuaireCrise($annuaireCrise)
    {
        $this->annuaireCrise = $annuaireCrise;

        return $this;
    }

    /**
     * Get annuaireCrise.
     *
     * @return bool
     */
    public function getAnnuaireCrise()
    {
        return $this->annuaireCrise;
    }

    /**
     * Set annuaireCriseMairie.
     *
     * @param bool $annuaireCriseMairie
     *
     * @return PlanBleu
     */
    public function setAnnuaireCriseMairie($annuaireCriseMairie)
    {
        $this->annuaireCriseMairie = $annuaireCriseMairie;

        return $this;
    }

    /**
     * Get annuaireCriseMairie.
     *
     * @return bool
     */
    public function getAnnuaireCriseMairie()
    {
        return $this->annuaireCriseMairie;
    }

    /**
     * Set annuaireCrisePrefecture.
     *
     * @param bool $annuaireCrisePrefecture
     *
     * @return PlanBleu
     */
    public function setAnnuaireCrisePrefecture($annuaireCrisePrefecture)
    {
        $this->annuaireCrisePrefecture = $annuaireCrisePrefecture;

        return $this;
    }

    /**
     * Get annuaireCrisePrefecture.
     *
     * @return bool
     */
    public function getAnnuaireCrisePrefecture()
    {
        return $this->annuaireCrisePrefecture;
    }

    /**
     * Set annuaireCriseSdis.
     *
     * @param bool $annuaireCriseSdis
     *
     * @return PlanBleu
     */
    public function setAnnuaireCriseSdis($annuaireCriseSdis)
    {
        $this->annuaireCriseSdis = $annuaireCriseSdis;

        return $this;
    }

    /**
     * Get annuaireCriseSdis.
     *
     * @return bool
     */
    public function getAnnuaireCriseSdis()
    {
        return $this->annuaireCriseSdis;
    }

    /**
     * Set annuaireCriseArs.
     *
     * @param bool $annuaireCriseArs
     *
     * @return PlanBleu
     */
    public function setAnnuaireCriseArs($annuaireCriseArs)
    {
        $this->annuaireCriseArs = $annuaireCriseArs;

        return $this;
    }

    /**
     * Get annuaireCriseArs.
     *
     * @return bool
     */
    public function getAnnuaireCriseArs()
    {
        return $this->annuaireCriseArs;
    }

    /**
     * Set annuaireCriseConseilGeneral.
     *
     * @param bool $annuaireCriseConseilGeneral
     *
     * @return PlanBleu
     */
    public function setAnnuaireCriseConseilGeneral($annuaireCriseConseilGeneral)
    {
        $this->annuaireCriseConseilGeneral = $annuaireCriseConseilGeneral;

        return $this;
    }

    /**
     * Get annuaireCriseConseilGeneral.
     *
     * @return bool
     */
    public function getAnnuaireCriseConseilGeneral()
    {
        return $this->annuaireCriseConseilGeneral;
    }

    /**
     * Set annuaireCriseErdf.
     *
     * @param bool $annuaireCriseErdf
     *
     * @return PlanBleu
     */
    public function setAnnuaireCriseErdf($annuaireCriseErdf)
    {
        $this->annuaireCriseErdf = $annuaireCriseErdf;

        return $this;
    }

    /**
     * Get annuaireCriseErdf.
     *
     * @return bool
     */
    public function getAnnuaireCriseErdf()
    {
        return $this->annuaireCriseErdf;
    }

    /**
     * Set etsAgeLd.
     *
     * @param bool $etsAgeLd
     *
     * @return PlanBleu
     */
    public function setEtsAgeLd($etsAgeLd)
    {
        $this->etsAgeLd = $etsAgeLd;

        return $this;
    }

    /**
     * Get etsAgeLd.
     *
     * @return bool
     */
    public function getEtsAgeLd()
    {
        return $this->etsAgeLd;
    }

    /**
     * Set etsAgeDep.
     *
     * @param bool $etsAgeDep
     *
     * @return PlanBleu
     */
    public function setEtsAgeDep($etsAgeDep)
    {
        $this->etsAgeDep = $etsAgeDep;

        return $this;
    }

    /**
     * Get etsAgeDep.
     *
     * @return bool
     */
    public function getEtsAgeDep()
    {
        return $this->etsAgeDep;
    }

    /**
     * Set etsAgeFoyer.
     *
     * @param bool $etsAgeFoyer
     *
     * @return PlanBleu
     */
    public function setEtsAgeFoyer($etsAgeFoyer)
    {
        $this->etsAgeFoyer = $etsAgeFoyer;

        return $this;
    }

    /**
     * Get etsAgeFoyer.
     *
     * @return bool
     */
    public function getEtsAgeFoyer()
    {
        return $this->etsAgeFoyer;
    }

    /**
     * Set etsHandiMas.
     *
     * @param string $etsHandiMas
     *
     * @return PlanBleu
     */
    public function setEtsHandiMas($etsHandiMas)
    {
        $this->etsHandiMas = $etsHandiMas;

        return $this;
    }

    /**
     * Get etsHandiMas.
     *
     * @return string
     */
    public function getEtsHandiMas()
    {
        return $this->etsHandiMas;
    }

    /**
     * Set etsHandiFam.
     *
     * @param string $etsHandiFam
     *
     * @return PlanBleu
     */
    public function setEtsHandiFam($etsHandiFam)
    {
        $this->etsHandiFam = $etsHandiFam;

        return $this;
    }

    /**
     * Get etsHandiFam.
     *
     * @return string
     */
    public function getEtsHandiFam()
    {
        return $this->etsHandiFam;
    }

    /**
     * Set etsHandiEsat.
     *
     * @param string $etsHandiEsat
     *
     * @return PlanBleu
     */
    public function setEtsHandiEsat($etsHandiEsat)
    {
        $this->etsHandiEsat = $etsHandiEsat;

        return $this;
    }

    /**
     * Get etsHandiEsat.
     *
     * @return string
     */
    public function getEtsHandiEsat()
    {
        return $this->etsHandiEsat;
    }

    /**
     * Set etsHandiIme.
     *
     * @param string $etsHandiIme
     *
     * @return PlanBleu
     */
    public function setEtsHandiIme($etsHandiIme)
    {
        $this->etsHandiIme = $etsHandiIme;

        return $this;
    }

    /**
     * Get etsHandiIme.
     *
     * @return string
     */
    public function getEtsHandiIme()
    {
        return $this->etsHandiIme;
    }

    /**
     * Set etsHandiItep.
     *
     * @param string $etsHandiItep
     *
     * @return PlanBleu
     */
    public function setEtsHandiItep($etsHandiItep)
    {
        $this->etsHandiItep = $etsHandiItep;

        return $this;
    }

    /**
     * Get etsHandiItep.
     *
     * @return string
     */
    public function getEtsHandiItep()
    {
        return $this->etsHandiItep;
    }

    /**
     * Set etsHandiEeap.
     *
     * @param string $etsHandiEeap
     *
     * @return PlanBleu
     */
    public function setEtsHandiEeap($etsHandiEeap)
    {
        $this->etsHandiEeap = $etsHandiEeap;

        return $this;
    }

    /**
     * Get etsHandiEeap.
     *
     * @return string
     */
    public function getEtsHandiEeap()
    {
        return $this->etsHandiEeap;
    }

    /**
     * Set etsHandiAutre.
     *
     * @param string $etsHandiAutre
     *
     * @return PlanBleu
     */
    public function setEtsHandiAutre($etsHandiAutre)
    {
        $this->etsHandiAutre = $etsHandiAutre;

        return $this;
    }

    /**
     * Get etsHandiAutre.
     *
     * @return string
     */
    public function getEtsHandiAutre()
    {
        return $this->etsHandiAutre;
    }

    /**
     * Set capLitLs.
     *
     * @param int $capLitLs
     *
     * @return PlanBleu
     */
    public function setCapLitLs($capLitLs)
    {
        $this->capLitLs = $capLitLs;

        return $this;
    }

    /**
     * Get capLitLs.
     *
     * @return int
     */
    public function getCapLitLs()
    {
        return $this->capLitLs;
    }

    /**
     * Set capLitPermInt.
     *
     * @param int $capLitPermInt
     *
     * @return PlanBleu
     */
    public function setCapLitPermInt($capLitPermInt)
    {
        $this->capLitPermInt = $capLitPermInt;

        return $this;
    }

    /**
     * Get capLitPermInt.
     *
     * @return int
     */
    public function getCapLitPermInt()
    {
        return $this->capLitPermInt;
    }

    /**
     * Set capLitTmp.
     *
     * @param int $capLitTmp
     *
     * @return PlanBleu
     */
    public function setCapLitTmp($capLitTmp)
    {
        $this->capLitTmp = $capLitTmp;

        return $this;
    }

    /**
     * Get capLitTmp.
     *
     * @return int
     */
    public function getCapLitTmp()
    {
        return $this->capLitTmp;
    }

    /**
     * Set capLitPasa.
     *
     * @param int $capLitPasa
     *
     * @return PlanBleu
     */
    public function setCapLitPasa($capLitPasa)
    {
        $this->capLitPasa = $capLitPasa;

        return $this;
    }

    /**
     * Get capLitPasa.
     *
     * @return int
     */
    public function getCapLitPasa()
    {
        return $this->capLitPasa;
    }

    /**
     * Set capLitUhr.
     *
     * @param int $capLitUhr
     *
     * @return PlanBleu
     */
    public function setCapLitUhr($capLitUhr)
    {
        $this->capLitUhr = $capLitUhr;

        return $this;
    }

    /**
     * Get capLitUhr.
     *
     * @return int
     */
    public function getCapLitUhr()
    {
        return $this->capLitUhr;
    }

    /**
     * Set capLitCantou.
     *
     * @param int $capLitCantou
     *
     * @return PlanBleu
     */
    public function setCapLitCantou($capLitCantou)
    {
        $this->capLitCantou = $capLitCantou;

        return $this;
    }

    /**
     * Get capLitCantou.
     *
     * @return int
     */
    public function getCapLitCantou()
    {
        return $this->capLitCantou;
    }

    /**
     * Set capPlaceJourExt.
     *
     * @param int $capPlaceJourExt
     *
     * @return PlanBleu
     */
    public function setCapPlaceJourExt($capPlaceJourExt)
    {
        $this->capPlaceJourExt = $capPlaceJourExt;

        return $this;
    }

    /**
     * Get capPlaceJourExt.
     *
     * @return int
     */
    public function getCapPlaceJourExt()
    {
        return $this->capPlaceJourExt;
    }

    /**
     * Set capPlaceJourExtAlz.
     *
     * @param int $capPlaceJourExtAlz
     *
     * @return PlanBleu
     */
    public function setCapPlaceJourExtAlz($capPlaceJourExtAlz)
    {
        $this->capPlaceJourExtAlz = $capPlaceJourExtAlz;

        return $this;
    }

    /**
     * Get capPlaceJourExtAlz.
     *
     * @return int
     */
    public function getCapPlaceJourExtAlz()
    {
        return $this->capPlaceJourExtAlz;
    }

    /**
     * Set capLitAutre.
     *
     * @param int $capLitAutre
     *
     * @return PlanBleu
     */
    public function setCapLitAutre($capLitAutre)
    {
        $this->capLitAutre = $capLitAutre;

        return $this;
    }

    /**
     * Get capLitAutre.
     *
     * @return int
     */
    public function getCapLitAutre()
    {
        return $this->capLitAutre;
    }

    /**
     * Set capLitAutreDetail.
     *
     * @param string $capLitAutreDetail
     *
     * @return PlanBleu
     */
    public function setCapLitAutreDetail($capLitAutreDetail)
    {
        $this->capLitAutreDetail = $capLitAutreDetail;

        return $this;
    }

    /**
     * Get capLitAutreDetail.
     *
     * @return string
     */
    public function getCapLitAutreDetail()
    {
        return $this->capLitAutreDetail;
    }

    /**
     * Set capTotale.
     *
     * @param int $capTotale
     *
     * @return PlanBleu
     */
    public function setCapTotale($capTotale)
    {
        $this->capTotale = $capTotale;

        return $this;
    }

    /**
     * Get capTotale.
     *
     * @return int
     */
    public function getCapTotale()
    {
        return $this->capTotale;
    }

    /**
     * Set popuGrabataire.
     *
     * @param int $popuGrabataire
     *
     * @return PlanBleu
     */
    public function setPopuGrabataire($popuGrabataire)
    {
        $this->popuGrabataire = $popuGrabataire;

        return $this;
    }

    /**
     * Get popuGrabataire.
     *
     * @return int
     */
    public function getPopuGrabataire()
    {
        return $this->popuGrabataire;
    }

    /**
     * Set popuMr.
     *
     * @param int $popuMr
     *
     * @return PlanBleu
     */
    public function setPopuMr($popuMr)
    {
        $this->popuMr = $popuMr;

        return $this;
    }

    /**
     * Get popuMr.
     *
     * @return int
     */
    public function getPopuMr()
    {
        return $this->popuMr;
    }

    /**
     * Set popuMobile.
     *
     * @param int $popuMobile
     *
     * @return PlanBleu
     */
    public function setPopuMobile($popuMobile)
    {
        $this->popuMobile = $popuMobile;

        return $this;
    }

    /**
     * Get popuMobile.
     *
     * @return int
     */
    public function getPopuMobile()
    {
        return $this->popuMobile;
    }

    /**
     * Set persTotal.
     *
     * @param float $persTotal
     *
     * @return PlanBleu
     */
    public function setPersTotal($persTotal)
    {
        $this->persTotal = $persTotal;

        return $this;
    }

    /**
     * Get persTotal.
     *
     * @return float
     */
    public function getPersTotal()
    {
        return $this->persTotal;
    }

    /**
     * Set persMedical.
     *
     * @param float $persMedical
     *
     * @return PlanBleu
     */
    public function setPersMedical($persMedical)
    {
        $this->persMedical = $persMedical;

        return $this;
    }

    /**
     * Get persMedical.
     *
     * @return float
     */
    public function getPersMedical()
    {
        return $this->persMedical;
    }

    /**
     * Set persPara.
     *
     * @param float $persPara
     *
     * @return PlanBleu
     */
    public function setPersPara($persPara)
    {
        $this->persPara = $persPara;

        return $this;
    }

    /**
     * Get persPara.
     *
     * @return float
     */
    public function getPersPara()
    {
        return $this->persPara;
    }

    /**
     * Set persAdm.
     *
     * @param float $persAdm
     *
     * @return PlanBleu
     */
    public function setPersAdm($persAdm)
    {
        $this->persAdm = $persAdm;

        return $this;
    }

    /**
     * Get persAdm.
     *
     * @return float
     */
    public function getPersAdm()
    {
        return $this->persAdm;
    }

    /**
     * @param float $persLogist
     */
    public function setPersLogist($persLogist)
    {
        $this->persLogist = $persLogist;
    }

    /**
     * @return float
     */
    public function getPersLogist()
    {
        return $this->persLogist;
    }

    /**
     * Set convEsProx.
     *
     * @param bool $convEsProx
     *
     * @return PlanBleu
     */
    public function setConvEsProx($convEsProx)
    {
        $this->convEsProx = $convEsProx;

        return $this;
    }

    /**
     * Get convEsProx.
     *
     * @return bool
     */
    public function getConvEsProx()
    {
        return $this->convEsProx;
    }

    /**
     * Set convEsProxYes.
     *
     * @param string $convEsProxYes
     *
     * @return PlanBleu
     */
    public function setConvEsProxYes($convEsProxYes)
    {
        $this->convEsProxYes = $convEsProxYes;

        return $this;
    }

    /**
     * Get convEsProxYes.
     *
     * @return string
     */
    public function getConvEsProxYes()
    {
        return $this->convEsProxYes;
    }

    /**
     * Set convEsPro.
     *
     * @param bool $convEsPro
     *
     * @return PlanBleu
     */
    public function setConvEsPro($convEsPro)
    {
        $this->convEsPro = $convEsPro;

        return $this;
    }

    /**
     * Get convEsPro.
     *
     * @return bool
     */
    public function getConvEsPro()
    {
        return $this->convEsPro;
    }

    /**
     * Set convEsProYes.
     *
     * @param string $convEsProYes
     *
     * @return PlanBleu
     */
    public function setConvEsProYes($convEsProYes)
    {
        $this->convEsProYes = $convEsProYes;

        return $this;
    }

    /**
     * Get convEsProYes.
     *
     * @return string
     */
    public function getConvEsProYes()
    {
        return $this->convEsProYes;
    }

    /**
     * Set dosMedUi.
     *
     * @param bool $dosMedUi
     *
     * @return PlanBleu
     */
    public function setDosMedUi($dosMedUi)
    {
        $this->dosMedUi = $dosMedUi;

        return $this;
    }

    /**
     * Get dosMedUi.
     *
     * @return bool
     */
    public function getDosMedUi()
    {
        return $this->dosMedUi;
    }

    /**
     * Set dosMedUi24.
     *
     * @param bool $dosMedUi24
     *
     * @return PlanBleu
     */
    public function setDosMedUi24($dosMedUi24)
    {
        $this->dosMedUi24 = $dosMedUi24;

        return $this;
    }

    /**
     * Get dosMedUi24.
     *
     * @return bool
     */
    public function getDosMedUi24()
    {
        return $this->dosMedUi24;
    }

    /**
     * Set dosMedUiNumerique.
     *
     * @param bool $dosMedUiNumerique
     *
     * @return PlanBleu
     */
    public function setDosMedUiNumerique($dosMedUiNumerique)
    {
        $this->dosMedUiNumerique = $dosMedUiNumerique;

        return $this;
    }

    /**
     * Get dosMedUiNumerique.
     *
     * @return bool
     */
    public function getDosMedUiNumerique()
    {
        return $this->dosMedUiNumerique;
    }

    /**
     * Set eqVehicule.
     *
     * @param int $eqVehicule
     *
     * @return PlanBleu
     */
    public function setEqVehicule($eqVehicule)
    {
        $this->eqVehicule = $eqVehicule;

        return $this;
    }

    /**
     * Get eqVehicule.
     *
     * @return int
     */
    public function getEqVehicule()
    {
        return $this->eqVehicule;
    }

    /**
     * Set eqVehiculeType.
     *
     * @param string $eqVehiculeType
     *
     * @return PlanBleu
     */
    public function setEqVehiculeType($eqVehiculeType)
    {
        $this->eqVehiculeType = $eqVehiculeType;

        return $this;
    }

    /**
     * Get eqVehiculeType.
     *
     * @return string
     */
    public function getEqVehiculeType()
    {
        return $this->eqVehiculeType;
    }

    /**
     * Set eqVehiculeUsage.
     *
     * @param string $eqVehiculeUsage
     *
     * @return PlanBleu
     */
    public function setEqVehiculeUsage($eqVehiculeUsage)
    {
        $this->eqVehiculeUsage = $eqVehiculeUsage;

        return $this;
    }

    /**
     * Get eqVehiculeUsage.
     *
     * @return string
     */
    public function getEqVehiculeUsage()
    {
        return $this->eqVehiculeUsage;
    }

    /**
     * Set nrjGroupe.
     *
     * @param bool $nrjGroupe
     *
     * @return PlanBleu
     */
    public function setNrjGroupe($nrjGroupe)
    {
        $this->nrjGroupe = $nrjGroupe;

        return $this;
    }

    /**
     * Get nrjGroupe.
     *
     * @return bool
     */
    public function getNrjGroupe()
    {
        return $this->nrjGroupe;
    }

    /**
     * Set nrjGroupeTps.
     *
     * @param int $nrjGroupeTps
     *
     * @return PlanBleu
     */
    public function setNrjGroupeTps($nrjGroupeTps)
    {
        $this->nrjGroupeTps = $nrjGroupeTps;

        return $this;
    }

    /**
     * Get nrjGroupeTps.
     *
     * @return int
     */
    public function getNrjGroupeTps()
    {
        return $this->nrjGroupeTps;
    }

    /**
     * Set nrjGroupeTpsDeg.
     *
     * @param int $nrjGroupeTpsDeg
     *
     * @return PlanBleu
     */
    public function setNrjGroupeTpsDeg($nrjGroupeTpsDeg)
    {
        $this->nrjGroupeTpsDeg = $nrjGroupeTpsDeg;

        return $this;
    }

    /**
     * Get nrjGroupeTpsDeg.
     *
     * @return int
     */
    public function getNrjGroupeTpsDeg()
    {
        return $this->nrjGroupeTpsDeg;
    }

    /**
     * Set nrjGroupeTpsDegTxt.
     *
     * @param string $nrjGroupeTpsDegTxt
     *
     * @return PlanBleu
     */
    public function setNrjGroupeTpsDegTxt($nrjGroupeTpsDegTxt)
    {
        $this->nrjGroupeTpsDegTxt = $nrjGroupeTpsDegTxt;

        return $this;
    }

    /**
     * Get nrjGroupeTpsDegTxt.
     *
     * @return string
     */
    public function getNrjGroupeTpsDegTxt()
    {
        return $this->nrjGroupeTpsDegTxt;
    }

    /**
     * Set nrjGroupeLoc.
     *
     * @param bool $nrjGroupeLoc
     *
     * @return PlanBleu
     */
    public function setNrjGroupeLoc($nrjGroupeLoc)
    {
        $this->nrjGroupeLoc = $nrjGroupeLoc;

        return $this;
    }

    /**
     * Get nrjGroupeLoc.
     *
     * @return bool
     */
    public function getNrjGroupeLoc()
    {
        return $this->nrjGroupeLoc;
    }

    /**
     * Set nrjGroupeLocYes.
     *
     * @param string $nrjGroupeLocYes
     *
     * @return PlanBleu
     */
    public function setNrjGroupeLocYes($nrjGroupeLocYes)
    {
        $this->nrjGroupeLocYes = $nrjGroupeLocYes;

        return $this;
    }

    /**
     * Get nrjGroupeLocYes.
     *
     * @return string
     */
    public function getNrjGroupeLocYes()
    {
        return $this->nrjGroupeLocYes;
    }

    /**
     * Set nrjObl.
     *
     * @param bool $nrjObl
     *
     * @return PlanBleu
     */
    public function setNrjObl($nrjObl)
    {
        $this->nrjObl = $nrjObl;

        return $this;
    }

    /**
     * Get nrjObl.
     *
     * @return bool
     */
    public function getNrjObl()
    {
        return $this->nrjObl;
    }

    /**
     * Set nrjDoc.
     *
     * @param bool $nrjDoc
     *
     * @return PlanBleu
     */
    public function setNrjDoc($nrjDoc)
    {
        $this->nrjDoc = $nrjDoc;

        return $this;
    }

    /**
     * Get nrjDoc.
     *
     * @return bool
     */
    public function getNrjDoc()
    {
        return $this->nrjDoc;
    }

    /**
     * Set alimFabrication.
     *
     * @param bool $alimFabrication
     *
     * @return PlanBleu
     */
    public function setAlimFabrication($alimFabrication)
    {
        $this->alimFabrication = $alimFabrication;

        return $this;
    }

    /**
     * Get alimFabrication.
     *
     * @return bool
     */
    public function getAlimFabrication()
    {
        return $this->alimFabrication;
    }

    /**
     * Set alimFabricationNo.
     *
     * @param string $alimFabricationNo
     *
     * @return PlanBleu
     */
    public function setAlimFabricationNo($alimFabricationNo)
    {
        $this->alimFabricationNo = $alimFabricationNo;

        return $this;
    }

    /**
     * Get alimFabricationNo.
     *
     * @return string
     */
    public function getAlimFabricationNo()
    {
        return $this->alimFabricationNo;
    }

    /**
     * Set alimTps.
     *
     * @param int $alimTps
     *
     * @return PlanBleu
     */
    public function setAlimTps($alimTps)
    {
        $this->alimTps = $alimTps;

        return $this;
    }

    /**
     * Get alimTps.
     *
     * @return int
     */
    public function getAlimTps()
    {
        return $this->alimTps;
    }

    /**
     * Set alimReserveEau.
     *
     * @param bool $alimReserveEau
     *
     * @return PlanBleu
     */
    public function setAlimReserveEau($alimReserveEau)
    {
        $this->alimReserveEau = $alimReserveEau;

        return $this;
    }

    /**
     * Get alimReserveEau.
     *
     * @return bool
     */
    public function getAlimReserveEau()
    {
        return $this->alimReserveEau;
    }

    /**
     * @param bool $alimReserveSec
     */
    public function setAlimReserveSec($alimReserveSec)
    {
        $this->alimReserveSec = $alimReserveSec;
    }

    /**
     * @return bool
     */
    public function getAlimReserveSec()
    {
        return $this->alimReserveSec;
    }

    /**
     * Set med.
     *
     * @param int $med
     *
     * @return PlanBleu
     */
    public function setMed($med)
    {
        $this->med = $med;

        return $this;
    }

    /**
     * Get med.
     *
     * @return int
     */
    public function getMed()
    {
        return $this->med;
    }

    /**
     * @param string $medLivraisonJour
     */
    public function setMedLivraisonJour($medLivraisonJour)
    {
        $this->medLivraisonJour = $medLivraisonJour;
    }

    /**
     * @return string
     */
    public function getMedLivraisonJour()
    {
        return $this->medLivraisonJour;
    }

    /**
     * Set medIndispensable.
     *
     * @param int $medIndispensable
     *
     * @return PlanBleu
     */
    public function setMedIndispensable($medIndispensable)
    {
        $this->medIndispensable = $medIndispensable;

        return $this;
    }

    /**
     * Get medIndispensable.
     *
     * @return int
     */
    public function getMedIndispensable()
    {
        return $this->medIndispensable;
    }

    /**
     * Set medIndispensableNot.
     *
     * @param int $medIndispensableNot
     *
     * @return PlanBleu
     */
    public function setMedIndispensableNot($medIndispensableNot)
    {
        $this->medIndispensableNot = $medIndispensableNot;

        return $this;
    }

    /**
     * Get medIndispensableNot.
     *
     * @return int
     */
    public function getMedIndispensableNot()
    {
        return $this->medIndispensableNot;
    }

    /**
     * Set secCameras.
     *
     * @param bool $secCameras
     *
     * @return PlanBleu
     */
    public function setSecCameras($secCameras)
    {
        $this->secCameras = $secCameras;

        return $this;
    }

    /**
     * Get secCameras.
     *
     * @return bool
     */
    public function getSecCameras()
    {
        return $this->secCameras;
    }

    /**
     * Set secAcces.
     *
     * @param bool $secAcces
     *
     * @return PlanBleu
     */
    public function setSecAcces($secAcces)
    {
        $this->secAcces = $secAcces;

        return $this;
    }

    /**
     * Get secAcces.
     *
     * @return bool
     */
    public function getSecAcces()
    {
        return $this->secAcces;
    }

    /**
     * Set secBarriere.
     *
     * @param bool $secBarriere
     *
     * @return PlanBleu
     */
    public function setSecBarriere($secBarriere)
    {
        $this->secBarriere = $secBarriere;

        return $this;
    }

    /**
     * Get secBarriere.
     *
     * @return bool
     */
    public function getSecBarriere()
    {
        return $this->secBarriere;
    }

    /**
     * Set eqPiece.
     *
     * @param int $eqPiece
     *
     * @return PlanBleu
     */
    public function setEqPiece($eqPiece)
    {
        $this->eqPiece = $eqPiece;

        return $this;
    }

    /**
     * Get eqPiece.
     *
     * @return int
     */
    public function getEqPiece()
    {
        return $this->eqPiece;
    }

    /**
     * Set eqFaorConf.
     *
     * @param bool $eqFaorConf
     *
     * @return PlanBleu
     */
    public function setEqFaorConf($eqFaorConf)
    {
        $this->eqFaorConf = $eqFaorConf;

        return $this;
    }

    /**
     * Get eqFaorConf.
     *
     * @return bool
     */
    public function getEqFaorConf()
    {
        return $this->eqFaorConf;
    }

    /**
     * Set eqFaorEvac.
     *
     * @param bool $eqFaorEvac
     *
     * @return PlanBleu
     */
    public function setEqFaorEvac($eqFaorEvac)
    {
        $this->eqFaorEvac = $eqFaorEvac;

        return $this;
    }

    /**
     * Get eqFaorEvac.
     *
     * @return bool
     */
    public function getEqFaorEvac()
    {
        return $this->eqFaorEvac;
    }

    /**
     * Set eqFaorPand.
     *
     * @param bool $eqFaorPand
     *
     * @return PlanBleu
     */
    public function setEqFaorPand($eqFaorPand)
    {
        $this->eqFaorPand = $eqFaorPand;

        return $this;
    }

    /**
     * Get eqFaorPand.
     *
     * @return bool
     */
    public function getEqFaorPand()
    {
        return $this->eqFaorPand;
    }

    /**
     * Set eqRepli.
     *
     * @param string $eqRepli
     *
     * @return PlanBleu
     */
    public function setEqRepli($eqRepli)
    {
        $this->eqRepli = $eqRepli;

        return $this;
    }

    /**
     * Get eqRepli.
     *
     * @return string
     */
    public function getEqRepli()
    {
        return $this->eqRepli;
    }

    /**
     * Set coop.
     *
     * @param bool $coop
     *
     * @return PlanBleu
     */
    public function setCoop($coop)
    {
        $this->coop = $coop;

        return $this;
    }

    /**
     * Get coop.
     *
     * @return bool
     */
    public function getCoop()
    {
        return $this->coop;
    }

    /**
     * Set coopYes.
     *
     * @param string $coopYes
     *
     * @return PlanBleu
     */
    public function setCoopYes($coopYes)
    {
        $this->coopYes = $coopYes;

        return $this;
    }

    /**
     * Get coopYes.
     *
     * @return string
     */
    public function getCoopYes()
    {
        return $this->coopYes;
    }

    /**
     * Set dari.
     *
     * @param bool $dari
     *
     * @return PlanBleu
     */
    public function setDari($dari)
    {
        $this->dari = $dari;

        return $this;
    }

    /**
     * Get dari.
     *
     * @return bool
     */
    public function getDari()
    {
        return $this->dari;
    }

    /**
     * Set dariPap.
     *
     * @param bool $dariPap
     *
     * @return PlanBleu
     */
    public function setDariPap($dariPap)
    {
        $this->dariPap = $dariPap;

        return $this;
    }

    /**
     * Get dariPap.
     *
     * @return bool
     */
    public function getDariPap()
    {
        return $this->dariPap;
    }

    /**
     * Set termine.
     *
     * @param bool $termine
     *
     * @return PlanBleu
     */
    public function setTermine($termine)
    {
        $this->termine = $termine;

        return $this;
    }

    /**
     * Get termine.
     *
     * @return bool
     */
    public function getTermine()
    {
        return $this->termine;
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param \Oru\Bundle\PlanBleuBundle\Entity\Identification $identification
     */
    public function setIdentification($identification)
    {
        $this->identification = $identification;
    }

    /**
     * @return \Oru\Bundle\PlanBleuBundle\Entity\Identification
     */
    public function getIdentification()
    {
        return $this->identification;
    }

    /**
     * @param \DateTime $created
     */
    public function setCreated($created)
    {
        $this->created = $created;
    }

    /**
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param \DateTime $updated
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;
    }

    /**
     * @return \DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * @param \DateTime $deleted
     */
    public function setDeleted($deleted)
    {
        $this->deleted = $deleted;
    }

    /**
     * @return \DateTime
     */
    public function getDeleted()
    {
        return $this->deleted;
    }

    /**
     * @param ExecutionContextInterface $executionContext
     *
     * @author Michaël VEROUX
     */
    public function isValid(ExecutionContextInterface $executionContext)
    {
        if ($this->getDernierVersionPlanBleu() > new \DateTime('now')) {
            $executionContext->buildViolation('La date de la dernière version doit être antérieure ou égale à ce jour.')->atPath('dernierVersionPlanBleu')->addViolation();
        }

        if ($this->getDernierExercice() > new \DateTime('now')) {
            $executionContext->buildViolation('La date du dernier exercice doit être antérieure ou égale à ce jour.')->atPath('dernierExercice')->addViolation();
        }

        if ($this->getDernierPlanBleu() > new \DateTime('now')) {
            $executionContext->buildViolation('La date du dernier Plan bleu doit être antérieure ou égale à ce jour.')->atPath('dernierPlanBleu')->addViolation();
        }
    }

    /**
     * @return null|string
     *
     * @author Michaël VEROUX
     */
    public function getFinessEtablissement()
    {
        return $this->getIdentification()->getEtablissement()->getFinessGeographique();
    }

    public function getEtablissement()
    {
        return $this->getIdentification()->getEtablissement();
    }

    public function getCredentialTarget(Credential $credential)
    {
        return $this->getEtablissement();
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $groups = array('default');

        if ($this->getCapLitAutre()) {
            $groups[] = 'capLitAutreTrue';
        }

        if ($this->getConvEsProx()) {
            $groups[] = 'convEsProxTrue';
        }

        if ($this->getConvEsPro()) {
            $groups[] = 'convEsProTrue';
        }

        if ($this->getCoop()) {
            $groups[] = 'coopTrue';
        }

        if ($this->getNrjGroupe()) {
            $groups[] = 'nrjGroupeTrue';
        }

        if ($this->getNrjGroupeLoc()) {
            $groups[] = 'nrjGroupeLocTrue';
        }

        return $groups;
    }

    /**
     * @return bool
     */
    public function isAnonymous()
    {
        return $this->anonymous;
    }

    /**
     * @param bool $anonymous
     */
    public function setAnonymous($anonymous)
    {
        $this->anonymous = $anonymous;
    }
}
