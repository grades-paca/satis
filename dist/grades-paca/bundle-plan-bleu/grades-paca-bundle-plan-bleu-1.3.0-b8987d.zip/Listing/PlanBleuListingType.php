<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 21/03/14
 * Time: 14:47
 */

namespace Oru\Bundle\PlanBleuBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class PlanBleuListingType
 * @package Oru\Bundle\PlanBleuBundle\Listing
 * @author Michaël VEROUX
 */
class PlanBleuListingType extends AbstractListingType
{
    /**
     * @var bool
     */
    protected $deleted = false;

    public function __construct($deleted = false)
    {
        $this->deleted = $deleted;
    }

    /**
     * @param ListingBuilderInterface $builder
     * @author Michaël VEROUX
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('etablissement', null, array(
                    'sort'      => 'et.nom',
                    'label'     => 'oru_plan_bleu_type.etablissement',
                    'translation_domain' => 'OruPlanBleuBundle',
                )
            )
            ->add('finessEtablissement', null, array(
                    'sort'      => 'et.finessGeographique',
                    'label'     => 'oru_plan_bleu_type_identification.finess',
                    'translation_domain' => 'OruPlanBleuBundle',
                )
            )
            ->add('termine', null, array(
                    'sort'      => 'p.termine',
                    'label'     => 'oru_plan_bleu_type.termine',
                    'translation_domain' => 'OruPlanBleuBundle',
                )
            );
            if(!$this->deleted) {
                $builder->add('edit', 'object_action', array(
                        'route' => 'oru_plan_bleu_edit',
                        'label' => 'listing.action.edit',
                        'role' => 'ORU_PLAN_BLEU_EDIT',
                    )
                );
            }
            $builder->add('show', 'object_action', array(
                    'route'     => 'oru_plan_bleu_show',
                    'label'     => 'listing.action.show',
                    'role'      => 'ORU_PLAN_BLEU_SHOW',
                )
            )
            ->add('new', 'list_action', array(
                    'route'     => 'oru_plan_bleu_pre_new',
                    'label'     => 'listing.action.new',
                    'attr'      =>  array('id' => 'plan_bleu_new', 'onclick' => 'return false;'),
                    'role'      => 'ORU_PLAN_BLEU_NEW',
                )
            )
        ;

        if($this->deleted)
            $builder
                ->add('restaure', 'object_action', array(
                        'route'     => 'oru_plan_bleu_restaure',
                        'label'     => 'listing.action.desarchive',
                        'role'      => 'ORU_PLAN_BLEU_DELETE',
                        'attr'      => array('class' => 'restaure'),
                    )
                )
            ;
        else
            $builder
                ->add('delete', 'object_action', array(
                        'route'     => 'oru_plan_bleu_delete',
                        'label'     => 'listing.action.archive',
                        'role'      => 'ORU_PLAN_BLEU_DELETE',
                        'attr'      => array('class' => 'delete'),
                    )
                )
            ;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'oru_plan_bleu_listing';
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\PlanBleuBundle\Entity\PlanBleu'
        ));
    }
} 