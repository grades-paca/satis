<?php
/**
 * Author: Michaël VEROUX
 * Date: 21/03/14
 * Time: 15:05
 */

namespace Oru\Bundle\PlanBleuBundle\Form\Filter;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class PlanBleuFilterType
 * @package Oru\Bundle\PlanBleuBundle\Form\Filter
 * @author Michaël VEROUX
 */
class PlanBleuFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('departements', 'entity', array(
                    'required'      =>  false,
                    'class'         =>  'OruAddressBundle:LstDepartement',
                    'expanded'      =>  false,
                    'multiple'      =>  true,
                )
            )
            ->add('etablissements', 'oru_etablissement_autocomplete', array(
                    'required'      =>  false,
                    'multiple'      =>  true,
                )
            )
            ->add('finess', 'search', array(
                    'required'      =>  false,
                )
            )
            ->add('termine', 'plan_bleu_statut', array(
                    'required'      =>  false,
                    'expanded'      =>  false,
                )
            )
            ->add('deleted','oru_oui_non', array(
                'required'      =>  false,
                'expanded' => false
            ))
            ->add('filter', 'submit', array(
                    'label'                 => 'listing.action.filter',
                    'translation_domain'    => 'messages',
                    'attr' => array('class' => 'btn btn-primary')
                )
            )
            ->add('reset', 'submit', array(
                    'label'                 => 'listing.action.reset',
                    'translation_domain'    => 'messages',
                    'attr' => array('class' => 'btn btn-default')
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\PlanBleuBundle\Filter\PlanBleuFilter',
            'csrf_protection' => false,
            'validation_groups' => false,
            'translation_domain'    => 'OruPlanBleuBundle',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_plan_bleu_filter';
    }
} 