/**
 * Created by MGONZALEZ on 15/06/2016.
 */
jQuery(function(){
    jQuery('button[type=submit]:first').before(jQuery('div#oru_plan_bleu_attachments').detach());
});