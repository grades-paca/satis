<?php
/**
 * Author: Michaël VEROUX
 * Date: 24/03/14
 * Time: 12:21
 */

namespace Oru\Bundle\PlanBleuBundle\Provider;

use Doctrine\Common\Persistence\ObjectManager;
use Oru\Bundle\PlanBleuBundle\Entity\Identification;
use Oru\Bundle\PlanBleuBundle\Entity\PlanBleu;
use Oru\Bundle\PlanBleuBundle\Filter\PlanBleuFilter;
use Oru\Bundle\RorBundle\Entity\Etablissement;

/**
 * Class PlanBleuProvider
 * @package Oru\Bundle\PlanBleuBundle\Provider
 * @author Michaël VEROUX
 */
class PlanBleuProvider
{
    /**
     * @var ObjectManager
     */
    protected $entityManager;

    /**
     * @param ObjectManager $entityManager
     */
    public function __construct(ObjectManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param int|string $id
     * @return PlanBleu
     * @author Michaël VEROUX
     */
    public function find($id)
    {
        $planBleu = $this->entityManager->getRepository('OruPlanBleuBundle:PlanBleu')->find($id);

        return $planBleu;
    }

    /**
     * @param Etablissement $etablissement
     * @return PlanBleu
     * @author Michaël VEROUX
     */
    public function findOneByEtablissement(Etablissement $etablissement)
    {
        $planBleu = $this->entityManager->getRepository('OruPlanBleuBundle:PlanBleu')->findOneByEtablissement($etablissement);

        return $planBleu;
    }

    /**
     * @param PlanBleuFilter $planBleuFilter
     * @return \Doctrine\ORM\QueryBuilder
     * @author Michaël VEROUX
     */
    public function findList(PlanBleuFilter $planBleuFilter, $scopeEtabsIds = array())
    {
        return $this->entityManager->getRepository('OruPlanBleuBundle:PlanBleu')->findList($planBleuFilter, $scopeEtabsIds);
    }

    /**
     * @param $finess
     * @return PlanBleu
     * @author Michaël VEROUX
     */
    public function create(Etablissement $etablissement)
    {
        $planBleu = new PlanBleu();

        $identification = new Identification();
        $identification->setEtablissement($etablissement);

        $planBleu->setIdentification($identification);

        return $planBleu;
    }
} 