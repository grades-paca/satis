<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 18/03/14
 * Time: 14:46
 */

namespace Oru\Bundle\PlanBleuBundle\Form;

use libphonenumber\PhoneNumberFormat;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\GroupSequenceProviderInterface;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormEvent;

/**
 * Class PlanBleuType
 * @package Oru\Bundle\PlanBleuBundle\Form
 * @author Michaël VEROUX
 */
class PlanBleuType extends AbstractType
{

    /**
     * @var
     */
    private $IdentificationType;

    /**
     * @param $IdentificationType
     */
    function __construct($IdentificationType)
    {
        $this->IdentificationType = $IdentificationType;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $etsHandiChoices = array(
            0           =>  'non',
            'internat'  =>  'Internat',
            'externat'  =>  'Externat',
        );

        $builder
            ->add('etablissement_section', 'oru_section', array(
                    'label'     => 'Identification de l\'établissement',
                )
            )
            ->add('identification', $this->IdentificationType, array(
                    'attr'      =>  array('class' => 'form_row subForm'),
                    'label'     =>  ' ',
                )
            )
            ->add('coords', 'oru_section'
            )
            ->add('telInfirmier', null, array()
            )
            ->add('telMedecin', null, array()
            )
            ->add('telCriseFilaire', null, array()
            )
            ->add('telCriseGsm', null, array()
            )
            ->add('telCriseSat', null, array()
            )
            ->add('telCriseFax', null, array()
            )

            ->add('general', 'oru_section'
            )
            ->add('dernierVersionPlanBleu'
            )
            ->add('lieuMad'
            )
            ->add('informatise', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('dernierExercice'
            )
            ->add('dernierPlanBleu'
            )
            ->add('pca_section', 'oru_section'
            )
            ->add('pca', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('annuaireCrise', 'oru_conditional', array(
                    'multiple'         =>  false,
                    'expanded'         =>  false,
                    'choices'          =>  array(1 => 'Oui', 0 => 'Non'),
                    'conditionals'     =>  array(
                        1   =>  array(
                            'annuaireCriseMairie',
                            'annuaireCrisePrefecture',
                            'annuaireCriseSdis',
                            'annuaireCriseArs',
                            'annuaireCriseConseilGeneral',
                            'annuaireCriseErdf',
                        ),
                    )
                )
            )
            ->add('annuaireCriseMairie', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('annuaireCrisePrefecture', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('annuaireCriseSdis', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('annuaireCriseArs', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('annuaireCriseConseilGeneral', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('annuaireCriseErdf', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('etsAge', 'oru_section'
            )
            ->add('etsAgeLd', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('etsAgeDep', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('etsAgeFoyer', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('etsHandi', 'oru_section'
            )
            ->add('etsHandiMas', 'choice', array(
                    'placeholder'   =>  '----choix----',
                    'choices'       =>  $etsHandiChoices,
                    'multiple'      =>  false,
                )
            )
            ->add('etsHandiFam', 'choice', array(
                    'placeholder'   =>  '----choix----',
                    'choices'       =>  $etsHandiChoices,
                    'multiple'      =>  false,
                )
            )
            ->add('etsHandiEsat', 'choice', array(
                    'placeholder'   =>  '----choix----',
                    'choices'       =>  $etsHandiChoices,
                    'multiple'      =>  false,
                )
            )
            ->add('etsHandiIme', 'choice', array(
                    'placeholder'   =>  '----choix----',
                    'choices'       =>  $etsHandiChoices,
                    'multiple'      =>  false,
                )
            )
            ->add('etsHandiItep', 'choice', array(
                    'placeholder'   =>  '----choix----',
                    'choices'       =>  $etsHandiChoices,
                    'multiple'      =>  false,
                )
            )
            ->add('etsHandiEeap', 'choice', array(
                    'placeholder'   =>  '----choix----',
                    'choices'       =>  $etsHandiChoices,
                    'multiple'      =>  false,
                )
            )
            ->add('etsHandiAutre'
            )
            ->add('cap', 'oru_section'
            )
            ->add('capLitLs', null, array(
                    'attr'      =>  array(
                        'class'     =>  'cap_sum',
                    ),
                )
            )
            ->add('capLitPermInt', null, array(
                    'attr'      =>  array(
                        'class'     =>  'cap_sum',
                    ),
                )
            )
            ->add('capLitTmp', null, array(
                    'attr'      =>  array(
                        'class'     =>  'cap_sum',
                    ),
                )
            )
            ->add('capLitPasa', null, array(
                    'attr'      =>  array(
                        'class'     =>  'cap_sum',
                    ),
                )
            )
            ->add('capLitUhr', null, array(
                    'attr'      =>  array(
                        'class'     =>  'cap_sum',
                    ),
                )
            )
            ->add('capLitCantou', null, array(
                    'attr'      =>  array(
                        'class'     =>  'cap_sum',
                    ),
                )
            )
            ->add('capPlaceJourExt', null, array(
                    'attr'      =>  array(
                        'class'     =>  'cap_sum',
                    ),
                )
            )
            ->add('capPlaceJourExtAlz', null, array(
                    'attr'      =>  array(
                        'class'     =>  'cap_sum',
                    ),
                )
            )
            ->add('capLitAutre', null, array(
                    'attr'      =>  array(
                        'class'     =>  'cap_sum',
                    ),
                )
            )
            ->add('capLitAutreDetail'
            )
            ->add('capTotale', 'oru_sum', array(
                    'type_class'    =>  'cap_sum',
                    'attr'          => array('readonly' => 'readonly'),
                )
            )
            ->add('popu', 'oru_section'
            )
            ->add('popuGrabataire', 'percent'
            )
            ->add('popuMr', 'percent'
            )
            ->add('popuMobile', 'percent'
            )
            ->add('pers', 'oru_section'
            )
            ->add('persTotal'
            )
            ->add('persMedical'
            )
            ->add('persPara'
            )
            ->add('persAdm'
            )
            ->add('persLogist'
            )
            ->add('conv', 'oru_section'
            )
            ->add('convEsProx', 'oru_oui_non_detail', array(
                    'expanded'      => false,
                    'multiple'      =>  false,
                    'on_no'         =>  false,
                    'detail'        =>  'convEsProxYes',
                )
            )
            ->add('convEsProxYes'
            )
            ->add('convEsPro', 'oru_oui_non_detail', array(
                    'expanded'      => false,
                    'multiple'      =>  false,
                    'on_no'         =>  false,
                    'detail'        =>  'convEsProYes',
                )
            )
            ->add('convEsProYes'
            )
            ->add('dosMed', 'oru_section'
            )
            ->add('dosMedUi', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('dosMedUi24', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('dosMedUiNumerique', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('eq', 'oru_section'
            )
            ->add('eqPiece'
            )
            ->add('eqVehicule'
            )
            ->add('eqVehiculeType'
            )
            ->add('eqVehiculeUsage'
            )
            ->add('nrj', 'oru_section'
            )
            ->add('nrjGroupe', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('nrjGroupeTps'
            )
            ->add('nrjGroupeTpsDeg'
            )
            ->add('nrjGroupeTpsDegTxt'
            )
            ->add('nrjGroupeLoc', 'oru_oui_non_detail', array(
                    'expanded'      => false,
                    'multiple'      =>  false,
                    'on_no'         =>  false,
                    'detail'        =>  'nrjGroupeLocYes',
                )
            )
            ->add('nrjGroupeLocYes'
            )
            ->add('nrjObl', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('nrjDoc', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('alim', 'oru_section'
            )
            ->add('alimFabrication', 'oru_oui_non_detail', array(
                    'expanded'      => false,
                    'multiple'      =>  false,
                    'detail'        =>  'alimFabricationNo',
                )
            )
            ->add('alimFabricationNo'
            )
            ->add('alimTps'
            )
            ->add('alimReserveEau', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('alimReserveSec', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('med_section', 'oru_section'
            )
            ->add('med'
            )
            ->add('medLivraisonJour'
            )
            ->add('medIndispensable'
            )
            ->add('medIndispensableNot'
            )
            ->add('eq_section', 'oru_section'
            )
            ->add('eqFaorConf', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('eqFaorEvac', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('eqFaorPand', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('eqRepli'
            )
            ->add('sec', 'oru_section'
            )
            ->add('secCameras', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('secAcces', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('secBarriere', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('dari_section', 'oru_section'
            )
            ->add('dari', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('dariPap', 'oru_oui_non', array(
                    'placeholder'   => '----choix----',
                    'expanded'      => false,
                )
            )
            ->add('coop_section', 'oru_section'
            )
            ->add('coop', 'oru_oui_non_detail', array(
                    'expanded'      => false,
                    'multiple'      =>  false,
                    'on_no'         =>  false,
                    'detail'        =>  'coopYes',
                )
            )
            ->add('coopYes'
            )
            ->add('save', 'submit', array(
                    'validation_groups'     =>  'integrity',
                    'label'                 =>  'save',
                    'translation_domain'    => 'messages',
                    'attr'                  => array(
                        'class'                 => 'btn btn-primary',
                    ),
                )
            )
            ->add('save definitively', 'submit', array(
                    'label'                 =>  'save_definitively',
                    'attr'                  => array(
                        'class'                 => 'btn btn-primary',
                    ),
                )
            )
        ;


        $builder->addEventListener(FormEvents::POST_SET_DATA, array($this, 'celluleCrise'));
    }

    public function celluleCrise(FormEvent $event)
    {
        $pb = $event->getData();
        $form = $event->getForm();

        if($pb->isAnonymous()){

            $form
                ->remove('telCriseFilaire', null, array()
                )
                ->remove('telCriseGsm', null, array()
                )
                ->remove('telCriseSat', null, array()
                )
                ->remove('telCriseFax', null, array()
                )
            ;
        }
    }
    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\PlanBleuBundle\Entity\PlanBleu',
            'translation_domain'    => 'OruPlanBleuBundle',
            'required' => false,
            'validation_groups' => function(FormInterface $form) {
                    $data = $form->getData();
                    $data->setTermine(true);
                    if($data instanceof GroupSequenceProviderInterface)
                    {
                        return $data->getGroupSequence();
                    }
                },
        ));
    }

    public function getParent()
    {
        return 'oru_recoverable_form';
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_plan_bleu_type';
    }

} 