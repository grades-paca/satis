<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 19/02/14
 * Time: 14:31
 */

namespace Oru\Bundle\PlanBleuBundle\Form;

use libphonenumber\PhoneNumberFormat;
use Misd\PhoneNumberBundle\Form\DataTransformer\PhoneNumberToStringTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class IdentificationType
 * @package Oru\Bundle\PlanBleuBundle\Form
 * @author Michaël VEROUX
 */
class IdentificationType extends AbstractType
{
    /**
     * @var int
     */
    private $phoneNumberFormat;
    /**
     * @var
     */
    private $phoneNumberRegion;

    /**
     * @param $settings
     * @param $phoneNumberRegion
     */
    function __construct($settings, $phoneNumberRegion)
    {
        if($settings->setting('tel_format','OruRorDesignBundle') == 'NATIONAL'){
            $this->phoneNumberFormat =  PhoneNumberFormat::NATIONAL;
        }else{
            $this->phoneNumberFormat =  PhoneNumberFormat::INTERNATIONAL;
        }
        $this->phoneNumberRegion = $phoneNumberRegion;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom', 'oru_static'
            )
            ->add('finess', 'oru_static'
            )
            ->add('siret', 'oru_static'
            )
            ->add('structure', 'oru_static'
            )
            ->add('adresse', 'oru_static'
            )
//            ->add('adresseComplement', 'oru_static'
//            )
//            ->add('codePostal', 'oru_static'
//            )
//            ->add('ville', 'oru_static'
//            )
//            ->add('directeurs', 'oru_static'
//            )
            ->add('telStandard', 'oru_static', array(
                    'view_transformer'      =>  new PhoneNumberToStringTransformer($this->phoneNumberRegion, $this->phoneNumberFormat)
                )
            )
            ->add('telDirection', 'oru_static', array(
                    'view_transformer'      =>  new PhoneNumberToStringTransformer($this->phoneNumberRegion, $this->phoneNumberFormat)
                )
            )
            ->add('telAlerte', 'oru_static', array(
                    'view_transformer'      =>  new PhoneNumberToStringTransformer($this->phoneNumberRegion, $this->phoneNumberFormat)
                )
            )
            ->add('faxAlerte', 'oru_static', array(
                    'view_transformer'      =>  new PhoneNumberToStringTransformer($this->phoneNumberRegion, $this->phoneNumberFormat)
                )
            )
            ->add('emailAlerte', 'oru_static'
            )
//            ->add('type', 'oru_static'
//            )
//            ->add('departement_nom', 'oru_static'
//            )
//            ->add('activites_autorises', 'oru_static'
//            )
            ->add('handicap_type', 'choice', array(
                    'choices'       =>  array(
                        'adultes'       =>  'Adultes',
                        'enfants'       =>  'Enfants',
                    ),
                    'placeholder'   =>  'Non concerné',
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\PlanBleuBundle\Entity\Identification',
            'translation_domain'    => 'OruPlanBleuBundle',
            'required' => false,
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_plan_pleu_identification';
    }
}