Bundle PlanBleuBundle
=====================

Installation
------------

Dans le AppKernel.php, activer ce bundle

    $bundles[] = new Oru\Bundle\PlanBleuBundle\OruPlanBleuBundle();

Dans le routing.yml, ajouter les routes :

    oru_plan_bleu:
        resource: "@OruPlanBleuBundle/Resources/config/routing.xml"
        prefix: /plan-bleu

Dans le config.yml, ajouter ce bundle aux paramètres imports :

    imports:
    ...
    - { resource: @OruPlanBleuBundle/Resources/config/config.yml }

Vider le cache de Symfony

Description
-----------

Bundle des formulaires Plan bleu
