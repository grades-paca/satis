jQuery( document ).ready(function(){
    jQuery('select:visible').each(function(){
        var id = jQuery(this).attr('id');
        if(jQuery(this).children('option:selected').val())
            var value = jQuery(this).children('option:selected').text();
        else
            var value = '---';
        jQuery(this).after('<span>' + value + '</span>');
    });
    jQuery('select:visible, div.select2-container').hide();

    jQuery('input[type=radio]:visible').each(function(){

        if(jQuery(this).hasClass('to_hide')) return;

        var name = jQuery(this).attr('name');
        var value = jQuery('input[name="' + name + '"]:checked').val();
        if(! value)
        {
            jQuery(this).after('<span>---</span>');
        }else{
            var id = jQuery('input[name="' + name + '"]:checked').attr('id');
            jQuery(this).after('<span>' + jQuery('label[for="' + id + '"]').text() + '</span>');
        }

        var mask = new Array();
        jQuery('input[name="' + name + '"]').each(function(){
            var id = jQuery(this).attr('id');
            jQuery('label[for="' + id + '"]').addClass('to_hide');
        });
        jQuery('input[name="' + name + '"]').addClass('to_hide');
    });
    jQuery('.to_hide').hide();

    var inputFields = 'input[type=text]:visible, input[type=number]:visible, input[type=tel]:visible, textarea:visible';

    jQuery(inputFields).each(function(){
        if(jQuery(this).val()){
            var value = jQuery(this).val().replace(/\n/g,'<br />'+' ');
            //Spécifique aux numéro de téléphone
            if(jQuery(this).hasClass('form_indicatif')){
                var phoneNumberDom = jQuery(this).parent().find('.phone_number').not('.form_indicatif');
                if(phoneNumberDom.val() && phoneNumberFormat == "INTERNATIONAL"){
                    value += ' ';
                    phoneNumberDom.val(phoneNumberDom.val().replace(/^0+/, ''))
                }else{
                    value = '';
                }
            }
        }else{
            var value = '---';
        }
        jQuery(this).after('<span>' + value + '</span> ');
    });
    jQuery('input[type=date]:visible').each(function(){
        if(jQuery(this).val())
            var value = jQuery(this).val();
        var myDate = new Date(value);
        var options = {year: "numeric", month: "2-digit", day: "2-digit"};
        jQuery(this).after('<span>' + myDate.toLocaleDateString('fr-FR', options) + '</span>');
    });
    jQuery(inputFields + ', input[type=submit], button[type=submit], input[type=date]:visible').hide();
    jQuery('input:visible').attr('disabled','disabled');
    jQuery('form').append('<button name="print" onclick="window.print();return false;" class="btn btn-default">Imprimer</button>')
    var hash = window.location.href.split('#')[1];
    if('print' == hash)
    {
        window.print();
    }
});