jQuery(function () {
    var allFields = jQuery([]).add('#oru_plan_bleu_etablissement_etablissement'),
        tips = jQuery(".validateTips");

    function updateTips(t) {
        tips
            .text(t)
            .addClass("ui-state-error");
    }

    function checkValue(o) {
        if (!o.val()) {
            updateTips("Vous devez renseigner tous les champs.");
            o.addClass("ui-state-error");
            return false;
        } else {
            return true;
        }
    }

    jQuery('a#plan_bleu_new').click(function () {
        jQuery("#dialog-form").dialog({
            modal: true,
            title: 'Choisissez l\'établissement :',
            width: '700px',
            buttons: {
                Valider: function () {
                    var bValid = true;
                    allFields.removeClass("ui-state-error");

                    bValid = bValid && checkValue(jQuery('#oru_plan_bleu_etablissement_etablissement'));

                    if (bValid) {
                        jQuery('#oru_plan_bleu_etablissement_etablissement').parents('form').submit();
                    }
                },
                Annuler: function () {
                    jQuery(this).dialog("close");
                }
            },
            close: function () {
                allFields.val("").removeClass("ui-state-error");
            }
        });
    });
});