<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 18/03/14
 * Time: 14:46
 */

namespace Oru\Bundle\PlanBleuBundle\Form;

use Oru\Bundle\FormBundle\Form\Type\ConditionalType;
use Oru\Bundle\FormBundle\Form\Type\OuiNonDetailType;
use Oru\Bundle\FormBundle\Form\Type\OuiNonType;
use Oru\Bundle\FormBundle\Form\Type\RecoverableFormType;
use Oru\Bundle\FormBundle\Form\Type\SectionType;
use Oru\Bundle\FormBundle\Form\Type\SumType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\PercentType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class PlanBleuType.
 *
 * @author Michaël VEROUX
 */
class PlanBleuType extends AbstractType
{
    /**
     * @var
     */
    private $IdentificationType;

    /**
     * @param $IdentificationType
     */
    public function __construct($IdentificationType)
    {
        $this->IdentificationType = $IdentificationType;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $etsHandiChoices = array(
            'non' => 0,
            'internat' => 'Internat',
            'externat' => 'Externat',
        );

        $builder
            ->add('etablissement_section', SectionType::class, array(
                    'label' => 'Identification de l\'établissement',
                )
            )
            ->add('identification', $this->IdentificationType, array(
                    'attr' => array('class' => 'form_row subForm'),
                    'label' => ' ',
                )
            )
            ->add('coords', SectionType::class
            )
            ->add('telInfirmier', null, array()
            )
            ->add('telMedecin', null, array()
            )
            ->add('telCriseFilaire', null, array()
            )
            ->add('telCriseGsm', null, array()
            )
            ->add('telCriseSat', null, array()
            )
            ->add('telCriseFax', null, array()
            )

            ->add('general', SectionType::class
            )
            ->add('dernierVersionPlanBleu'
            )
            ->add('lieuMad'
            )
            ->add('informatise', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('dernierExercice'
            )
            ->add('dernierPlanBleu'
            )
            ->add('pca_section', SectionType::class
            )
            ->add('pca', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('annuaireCrise', ConditionalType::class, array(
                                     'choices_as_values' => true,
                    'multiple' => false,
                    'expanded' => false,
                    'choices' => OuiNonType::CHOICES,
                    'conditionals' => array(
                        1 => array(
                            'annuaireCriseMairie',
                            'annuaireCrisePrefecture',
                            'annuaireCriseSdis',
                            'annuaireCriseArs',
                            'annuaireCriseConseilGeneral',
                            'annuaireCriseErdf',
                        ),
                    ),
                )
            )
            ->add('annuaireCriseMairie', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('annuaireCrisePrefecture', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('annuaireCriseSdis', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('annuaireCriseArs', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('annuaireCriseConseilGeneral', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('annuaireCriseErdf', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('etsAge', SectionType::class
            )
            ->add('etsAgeLd', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('etsAgeDep', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('etsAgeFoyer', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('etsHandi', SectionType::class
            )
            ->add('etsHandiMas', ChoiceType::class, array(
                                   'choices_as_values' => true,
                    'placeholder' => '----choix----',
                    'choices' => $etsHandiChoices,
                    'multiple' => false,
                )
            )
            ->add('etsHandiFam', ChoiceType::class, array(
                                   'choices_as_values' => true,
                    'placeholder' => '----choix----',
                    'choices' => $etsHandiChoices,
                    'multiple' => false,
                )
            )
            ->add('etsHandiEsat', ChoiceType::class, array(
                                    'choices_as_values' => true,
                    'placeholder' => '----choix----',
                    'choices' => $etsHandiChoices,
                    'multiple' => false,
                )
            )
            ->add('etsHandiIme', ChoiceType::class, array(
                                   'choices_as_values' => true,
                    'placeholder' => '----choix----',
                    'choices' => $etsHandiChoices,
                    'multiple' => false,
                )
            )
            ->add('etsHandiItep', ChoiceType::class, array(
                                    'choices_as_values' => true,
                    'placeholder' => '----choix----',
                    'choices' => $etsHandiChoices,
                    'multiple' => false,
                )
            )
            ->add('etsHandiEeap', ChoiceType::class, array(
                                    'choices_as_values' => true,
                    'placeholder' => '----choix----',
                    'choices' => $etsHandiChoices,
                    'multiple' => false,
                )
            )
            ->add('etsHandiAutre'
            )
            ->add('cap', SectionType::class
            )
            ->add('capLitLs', null, array(
                    'attr' => array(
                        'class' => 'cap_sum',
                    ),
                )
            )
            ->add('capLitPermInt', null, array(
                    'attr' => array(
                        'class' => 'cap_sum',
                    ),
                )
            )
            ->add('capLitTmp', null, array(
                    'attr' => array(
                        'class' => 'cap_sum',
                    ),
                )
            )
            ->add('capLitPasa', null, array(
                    'attr' => array(
                        'class' => 'cap_sum',
                    ),
                )
            )
            ->add('capLitUhr', null, array(
                    'attr' => array(
                        'class' => 'cap_sum',
                    ),
                )
            )
            ->add('capLitCantou', null, array(
                    'attr' => array(
                        'class' => 'cap_sum',
                    ),
                )
            )
            ->add('capPlaceJourExt', null, array(
                    'attr' => array(
                        'class' => 'cap_sum',
                    ),
                )
            )
            ->add('capPlaceJourExtAlz', null, array(
                    'attr' => array(
                        'class' => 'cap_sum',
                    ),
                )
            )
            ->add('capLitAutre', null, array(
                    'attr' => array(
                        'class' => 'cap_sum',
                    ),
                )
            )
            ->add('capLitAutreDetail'
            )
            ->add('capTotale', SumType::class, array(
                    'type_class' => 'cap_sum',
                    'attr' => array('readonly' => 'readonly'),
                )
            )
            ->add('popu', SectionType::class
            )
            ->add('popuGrabataire', PercentType::class
            )
            ->add('popuMr', PercentType::class
            )
            ->add('popuMobile', PercentType::class
            )
            ->add('pers', SectionType::class
            )
            ->add('persTotal'
            )
            ->add('persMedical'
            )
            ->add('persPara'
            )
            ->add('persAdm'
            )
            ->add('persLogist'
            )
            ->add('conv', SectionType::class
            )
            ->add('convEsProx', OuiNonDetailType::class, array(
                    'expanded' => false,
                    'multiple' => false,
                    'on_no' => false,
                    'detail' => 'convEsProxYes',
                )
            )
            ->add('convEsProxYes'
            )
            ->add('convEsPro', OuiNonDetailType::class, array(
                    'expanded' => false,
                    'multiple' => false,
                    'on_no' => false,
                    'detail' => 'convEsProYes',
                )
            )
            ->add('convEsProYes'
            )
            ->add('dosMed', SectionType::class
            )
            ->add('dosMedUi', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('dosMedUi24', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('dosMedUiNumerique', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('eq', SectionType::class
            )
            ->add('eqPiece'
            )
            ->add('eqVehicule'
            )
            ->add('eqVehiculeType'
            )
            ->add('eqVehiculeUsage'
            )
            ->add('nrj', SectionType::class
            )
            ->add('nrjGroupe', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('nrjGroupeTps'
            )
            ->add('nrjGroupeTpsDeg'
            )
            ->add('nrjGroupeTpsDegTxt'
            )
            ->add('nrjGroupeLoc', OuiNonDetailType::class, array(
                    'expanded' => false,
                    'multiple' => false,
                    'on_no' => false,
                    'detail' => 'nrjGroupeLocYes',
                )
            )
            ->add('nrjGroupeLocYes'
            )
            ->add('nrjObl', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('nrjDoc', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('alim', SectionType::class
            )
            ->add('alimFabrication', OuiNonDetailType::class, array(
                    'expanded' => false,
                    'multiple' => false,
                    'detail' => 'alimFabricationNo',
                )
            )
            ->add('alimFabricationNo'
            )
            ->add('alimTps'
            )
            ->add('alimReserveEau', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('alimReserveSec', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('med_section', SectionType::class
            )
            ->add('med'
            )
            ->add('medLivraisonJour'
            )
            ->add('medIndispensable'
            )
            ->add('medIndispensableNot'
            )
            ->add('eq_section', SectionType::class
            )
            ->add('eqFaorConf', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('eqFaorEvac', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('eqFaorPand', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('eqRepli'
            )
            ->add('sec', SectionType::class
            )
            ->add('secCameras', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('secAcces', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('secBarriere', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('dari_section', SectionType::class
            )
            ->add('dari', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('dariPap', OuiNonType::class, array(
                    'placeholder' => '----choix----',
                    'expanded' => false,
                )
            )
            ->add('coop_section', SectionType::class
            )
            ->add('coop', OuiNonDetailType::class, array(
                    'expanded' => false,
                    'multiple' => false,
                    'on_no' => false,
                    'detail' => 'coopYes',
                )
            )
            ->add('coopYes'
            )
            ->add('save', SubmitType::class, array(
                    'validation_groups' => 'integrity',
                    'label' => 'save',
                    'translation_domain' => 'messages',
                    'attr' => array(
                        'class' => 'btn btn-primary',
                    ),
                )
            )
            ->add('save definitively', SubmitType::class, array(
                    'label' => 'save_definitively',
                    'attr' => array(
                        'class' => 'btn btn-primary',
                    ),
                )
            )
        ;

        $builder->addEventListener(FormEvents::POST_SET_DATA, array($this, 'celluleCrise'));
    }

    public function celluleCrise(FormEvent $event)
    {
        $pb = $event->getData();
        $form = $event->getForm();

        if ($pb->isAnonymous()) {
            $form
                ->remove('telCriseFilaire', null, array()
                )
                ->remove('telCriseGsm', null, array()
                )
                ->remove('telCriseSat', null, array()
                )
                ->remove('telCriseFax', null, array()
                )
            ;
        }
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\PlanBleuBundle\Entity\PlanBleu',
            'translation_domain' => 'OruPlanBleuBundle',
            'required' => false,
            'validation_groups' => function (FormInterface $form) {
                $data = $form->getData();
                $data->setTermine(true);
                if ($data instanceof GroupSequenceProviderInterface) {
                    return $data->getGroupSequence();
                }
            },
        ));
    }

    public function getParent()
    {
        return RecoverableFormType::class;
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_plan_bleu_type';
    }
}
