<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 19/02/14
 * Time: 14:31
 */

namespace Oru\Bundle\PlanBleuBundle\Form;

use libphonenumber\PhoneNumberFormat;
use Misd\PhoneNumberBundle\Form\DataTransformer\PhoneNumberToStringTransformer;
use Oru\Bundle\FormBundle\Form\Type\StaticType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class IdentificationType.
 *
 * @author Michaël VEROUX
 */
class IdentificationType extends AbstractType
{
    /**
     * @var int
     */
    private $phoneNumberFormat;
    /**
     * @var
     */
    private $phoneNumberRegion;

    /**
     * @param $settings
     * @param $phoneNumberRegion
     */
    public function __construct($settings, $phoneNumberRegion)
    {
        if ($settings->setting('tel_format', 'OruRorDesignBundle') === 'NATIONAL') {
            $this->phoneNumberFormat = PhoneNumberFormat::NATIONAL;
        } else {
            $this->phoneNumberFormat = PhoneNumberFormat::INTERNATIONAL;
        }
        $this->phoneNumberRegion = $phoneNumberRegion;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom', StaticType::class
            )
            ->add('finess', StaticType::class
            )
            ->add('siret', StaticType::class
            )
            ->add('structure', StaticType::class
            )
            ->add('adresse', StaticType::class
            )
//            ->add('adresseComplement', StaticType::class
//            )
//            ->add('codePostal', StaticType::class
//            )
//            ->add('ville', StaticType::class
//            )
//            ->add('directeurs', StaticType::class
//            )
            ->add('telStandard', StaticType::class, array(
                    'view_transformer' => new PhoneNumberToStringTransformer($this->phoneNumberRegion, $this->phoneNumberFormat),
                )
            )
            ->add('telDirection', StaticType::class, array(
                    'view_transformer' => new PhoneNumberToStringTransformer($this->phoneNumberRegion, $this->phoneNumberFormat),
                )
            )
            ->add('telAlerte', StaticType::class, array(
                    'view_transformer' => new PhoneNumberToStringTransformer($this->phoneNumberRegion, $this->phoneNumberFormat),
                )
            )
            ->add('faxAlerte', StaticType::class, array(
                    'view_transformer' => new PhoneNumberToStringTransformer($this->phoneNumberRegion, $this->phoneNumberFormat),
                )
            )
            ->add('emailAlerte', StaticType::class
            )
//            ->add('type', StaticType::class
//            )
//            ->add('departement_nom', StaticType::class
//            )
//            ->add('activites_autorises', StaticType::class
//            )
            ->add('handicap_type', ChoiceType::class, array(
                                     'choices_as_values' => true,
                    'choices' => array(
                        'Adultes' => 'adultes',
                        'Enfants' => 'enfants',
                    ),
                    'placeholder' => 'Non concerné',
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\PlanBleuBundle\Entity\Identification',
            'translation_domain' => 'OruPlanBleuBundle',
            'required' => false,
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_plan_pleu_identification';
    }
}
