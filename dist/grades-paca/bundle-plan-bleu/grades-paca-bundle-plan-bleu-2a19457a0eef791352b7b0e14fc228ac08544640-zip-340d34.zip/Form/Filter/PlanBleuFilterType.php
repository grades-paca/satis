<?php
/**
 * Author: Michaël VEROUX
 * Date: 21/03/14
 * Time: 15:05
 */

namespace Oru\Bundle\PlanBleuBundle\Form\Filter;

use Oru\Bundle\FormBundle\Form\Type\OuiNonType;
use Oru\Bundle\PlanBleuBundle\Form\Type\PlanBleuStatutType;
use Oru\Bundle\RorBundle\Form\Type\EtablissementAutocompleteType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class PlanBleuFilterType.
 *
 * @author Michaël VEROUX
 */
class PlanBleuFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('departements', EntityType::class, array(
                    'required' => false,
                    'class' => 'OruAddressBundle:LstDepartement',
                    'expanded' => false,
                    'multiple' => true,
                )
            )
            ->add('etablissements', EtablissementAutocompleteType::class, array(
                    'required' => false,
                    'multiple' => true,
                )
            )
            ->add('finess', SearchType::class, array(
                    'required' => false,
                )
            )
            ->add('termine', PlanBleuStatutType::class, array(
                    'required' => false,
                    'expanded' => false,
                )
            )
            ->add('deleted', OuiNonType::class, array(
                'required' => false,
                'expanded' => false,
            ))
            ->add('filter', SubmitType::class, array(
                    'label' => 'listing.action.filter',
                    'translation_domain' => 'messages',
                    'attr' => array('class' => 'btn btn-primary'),
                )
            )
            ->add('reset', SubmitType::class, array(
                    'label' => 'listing.action.reset',
                    'translation_domain' => 'messages',
                    'attr' => array('class' => 'btn btn-default'),
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\PlanBleuBundle\Filter\PlanBleuFilter',
            'csrf_protection' => false,
            'validation_groups' => false,
            'translation_domain' => 'OruPlanBleuBundle',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_plan_bleu_filter';
    }
}
