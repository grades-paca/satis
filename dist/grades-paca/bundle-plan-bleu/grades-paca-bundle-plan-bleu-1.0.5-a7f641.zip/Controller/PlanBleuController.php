<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 18/03/14
 * Time: 14:33
 */

namespace Oru\Bundle\PlanBleuBundle\Controller;

use Oru\Bundle\DesignBundle\Controller\FlashControllerTrait;
use Oru\Bundle\PlanBleuBundle\Entity\Identification;
use Oru\Bundle\PlanBleuBundle\Form\EtablissementType;
use Oru\Bundle\RorBundle\Entity\Etablissement;
use Oru\Bundle\PlanBleuBundle\Entity\PlanBleu;
use Oru\Bundle\PlanBleuBundle\Form\Filter\PlanBleuFilterType;
use Oru\Bundle\PlanBleuBundle\Form\PlanBleuType;
use Oru\Bundle\PlanBleuBundle\Listing\PlanBleuListingType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * Class PlanBleuController
 * @package Oru\Bundle\PlanBleuBundle\Controller
 * @author Michaël VEROUX
 */
class PlanBleuController extends Controller
{
    use FlashControllerTrait;

    /**
     * @param Request $request
     * @param null $form
     * @return \Symfony\Component\HttpFoundation\Response
     * @author Michaël VEROUX
     */
    public function indexAction(Request $request, $form = null)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_PLAN_BLEU_SHOW')){
            throw new AccessDeniedHttpException();
        }

        try
        {
            $this->getDoctrine()->getManager()->getFilters()->disable('softdeleteable');
        }catch (\InvalidArgumentException $e){ }

        if(null === $form)
        {
            $form = $this->createForm(new PlanBleuFilterType())->submit($request->getSession()->get('oru_plan_bleu.filter'));
        }

        $entities = $this->get('oru_plan_bleu.plan_bleu_provider')->findList($form->getData());

        $listing = $this->container->get('oru_ror_credentials.paginator')->create(
            new PlanBleuListingType($form->getData()->getDeleted()),
            $entities,
            $request->query->get('page', 1)
        );

        $formCreate = $this->createForm(new EtablissementType(), new Identification(), array(
            'action' => $this->generateUrl('oru_plan_bleu_pre_new'),
            'method' => 'POST',
        ));

        return $this->render('OruPlanBleuBundle:PlanBleu:index.html.twig',
            array(
                'listing'   => $listing,
                'form'      => $form->createView(),
                'form_create' => $formCreate->createView(),
            )
        );
    }

    /**
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     * @author Michaël VEROUX
     */
    public function filterAction(Request $request)
    {
        try
        {
            $this->getDoctrine()->getManager()->getFilters()->disable('softdeleteable');
        }catch (\InvalidArgumentException $e){ }

        $form = $this->createForm(new PlanBleuFilterType())->handleRequest($request);

        if ($form->get('reset')->isClicked())
        {
            $request->getSession()->set('oru_plan_bleu.filter', array());

            return $this->redirect($this->generateUrl('oru_plan_bleu'));
        }

        if($form->isValid()) {
            $request->getSession()->set('oru_plan_bleu.filter', $request->get($form->getName()));

            return $this->redirect($this->generateUrl('oru_plan_bleu'));
        }

        return $this->indexAction($request, $form);
    }

    public function preNewAction(Request $request)
    {
        $identification = new Identification();

        $form = $this->createForm(new EtablissementType(), $identification);

        $form->submit($request->request->get($form->getName()));

        if($form->isValid())
        {

            if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_PLAN_BLEU_NEW', $identification->getEtablissement())){
                throw new AccessDeniedHttpException();
            }

            $this->addSessionMessage(sprintf('Vous allez créer un plan bleu sur l\'établissement %s', $identification->getEtablissement()));

            return $this->redirect($this->generateUrl('oru_plan_bleu_new', array('etablissement' => $identification->getEtablissement()->getId())));
        }

        return $this->redirect($this->generateUrl('oru_plan_bleu'));
    }

    /**
     * @param $etablissement
     * @return \Symfony\Component\HttpFoundation\Response
     * @author Michaël VEROUX
     */
    public function newAction(Etablissement $etablissement)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_PLAN_BLEU_NEW', $etablissement)){
            throw new AccessDeniedHttpException();
        }

        $entity = $this->get('oru_plan_bleu.plan_bleu_provider')->create($etablissement);

        $form = $this->createForm($this->container->get('oru_plan_bleu.plan_bleu_type'), $entity);

        return $this->render('OruPlanBleuBundle:PlanBleu:new.html.twig', array(
                'form'      =>  $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     * @param $etablissement
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     * @author Michaël VEROUX
     */
    public function createAction(Request $request, Etablissement $etablissement)
    {
        $entity = $this->get('oru_plan_bleu.plan_bleu_provider')->create($etablissement);

        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_PLAN_BLEU_NEW', $etablissement)){
            throw new AccessDeniedHttpException();
        }

        $form = $this->createForm($this->container->get('oru_plan_bleu.plan_bleu_type'), $entity);

        $form->submit($request->request->get($form->getName()));

        if($form->isValid())
        {
            $em = $this->getDoctrine()->getManager();
            $em->persist($entity);
            $em->flush();
            $this->addSessionMessage('Vos données sont enregistrées.');

            return $this->redirect($this->generateUrl('oru_plan_bleu'));
        }

        $this->addSessionMessage('Le formulaire soumis contient des erreurs...', 'warning');

        return $this->render('OruPlanBleuBundle:PlanBleu:new.html.twig', array(
                'form'      =>  $form->createView(),
            )
        );
    }

    /**
     * @param PlanBleu $planBleu
     * @return \Symfony\Component\HttpFoundation\Response
     * @author Michaël VEROUX
     */
    public function editAction(PlanBleu $planBleu)
    {
        $planBleu = $this->get('oru_plan_bleu.plan_bleu_provider')->find($planBleu->getId());

        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_PLAN_BLEU_EDIT', $planBleu->getEtablissement())){
            throw new AccessDeniedHttpException();
        }

        $form = $this->createForm($this->container->get('oru_plan_bleu.plan_bleu_type'), $planBleu);

        return $this->render('OruPlanBleuBundle:PlanBleu:edit.html.twig', array(
                'form'      =>  $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     * @param PlanBleu $planBleu
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     * @author Michaël VEROUX
     */
    public function updateAction(Request $request, PlanBleu $planBleu)
    {
        $planBleu = $this->get('oru_plan_bleu.plan_bleu_provider')->find($planBleu->getId());

        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_PLAN_BLEU_EDIT', $planBleu->getEtablissement())){
            throw new AccessDeniedHttpException();
        }

        $form = $this->createForm($this->container->get('oru_plan_bleu.plan_bleu_type'), $planBleu);

        $form->submit($request->request->get($form->getName()));

        if($form->isValid())
        {
            $em = $this->getDoctrine()->getManager();
            $em->persist($planBleu);
            $em->flush();
            $this->addSessionMessage('Vos données sont enregistrées.');

            return $this->redirect($this->generateUrl('oru_plan_bleu_show', array('id' => $planBleu->getId())));
        }

        $this->addSessionMessage('Le formulaire soumis contient des erreurs...', 'warning');

        return $this->render('OruPlanBleuBundle:PlanBleu:edit.html.twig', array(
                'form'      =>  $form->createView(),
            )
        );
    }

    /**
     * @param PlanBleu $planBleu
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function showAction($id)
    {
        $planBleu = $this->get('oru_plan_bleu.plan_bleu_provider')->find($id);

        //Anonymisation si pas les droits
        $planBleu->setAnonymous(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_PLAN_BLEU_SHOW'));

        $form = $this->createForm(
            $this->container->get('oru_plan_bleu.plan_bleu_type'),
            $planBleu
        );

        return $this->render('OruPlanBleuBundle:PlanBleu:show.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param string $id
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws \Symfony\Component\HttpKernel\Exception\NotFoundHttpException
     */
    public function accessAction(Etablissement $etablissement)
    {
        $planBleu = $this->get('oru_plan_bleu.plan_bleu_provider')->findOneByEtablissement($etablissement);

        if(!$planBleu)
            return $this->newAction($etablissement);

        return $this->editAction($planBleu);
    }

    /**
     * @param Etablissement $etablissement
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws \Symfony\Component\HttpKernel\Exception\NotFoundHttpException
     */
    public function accessShowAction(Etablissement $etablissement)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_PLAN_BLEU_SHOW')){
            throw new AccessDeniedHttpException();
        }

        $planBleu = $this->get('oru_plan_bleu.plan_bleu_provider')->findOneByEtablissement($etablissement);

        if(!$planBleu)
        {
            $this->addSessionMessage('Aucun formulaire rempli pour cet Établissement !', 'error');
            $url = $this->generateUrl('oru_plan_bleu_access',array('etablissement' => $etablissement->getId()));
            $this->addSessionMessage(sprintf('Essayez de <a href="%s">remplir le formulaire ici.</a>',$url), 'notice');
            return $this->failedAction();
        }

        return $this->showAction($planBleu);
    }

    /**
     * @return \Symfony\Component\HttpFoundation\Response
     * @author Michaël VEROUX
     */
    public function failedAction()
    {
        return $this->render('OruPlanBleuBundle:PlanBleu:failed.html.twig'
        );
    }

    public function deleteAction(Request $request, PlanBleu $entity)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_PLAN_BLEU_DELETE', $entity))
        {
            $this->addSessionMessage('Vos droits sont insuffisants !', 'error');
            throw new AccessDeniedHttpException();
        }

        $this->getDoctrine()->getManager()->remove($entity);
        $this->getDoctrine()->getManager()->flush();

        return new Response();
    }

    public function restaureAction(Request $request, $id)
    {
        try
        {
            $this->getDoctrine()->getManager()->getFilters()->disable('softdeleteable');
        }catch (\InvalidArgumentException $e){ }

        $entity = $this->get('oru_plan_bleu.plan_bleu_provider')->find($id);

        if(!$this->get('oru_setting.dynamic_security')->isGranted('ORU_PLAN_BLEU_DELETE', $entity))
        {
            $this->addSessionMessage('Vos droits sont insuffisants !', 'error');
            throw new AccessDeniedHttpException();
        }

        $entity->setDeleted(null);

        $this->getDoctrine()->getManager()->flush();

        return new Response();
    }
}