<?php

namespace Oru\Bundle\PrivacyBannerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruPrivacyBannerBundle extends Bundle
{
}
