<?php
/**
 * Author: Michaël VEROUX
 * Date: 16/07/14
 * Time: 12:42
 */

namespace Oru\Bundle\SettingBundle\Setting;

class DateTime extends \DateTime
{
    public function __toString()
    {
        return $this->format('Y-m-d H:i:s');
    }
} 