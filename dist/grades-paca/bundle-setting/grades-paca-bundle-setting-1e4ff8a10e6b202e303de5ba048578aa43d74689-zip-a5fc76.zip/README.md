OruSettingBundle
================

Description
-----------

Ce bundle fournit une interface de gestion des paramètres stockés en base de données.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/setting":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\SettingBundle\OruSettingBundle();
```

Veiller à ce que ce bundle soit activé, l'ajouter si nécessaire

``` php
$bundles[] = new Ivory\OrderedFormBundle\IvoryOrderedFormBundle();
```

Dans le fichier parameters.yml renseigner de quelle région il s'agit

``` yml
parameters:
    ...
    region: paca
```

Dans le config.yml, ajouter l'import de la config

``` yml
imports:
    ...
    - { resource: @OruSettingBundle/Resources/config/config.yml }
```

Dans le routing, ajouter une entrée pour activer l'interface de ce bundle

``` yml
oru_setting:
    resource: "@OruSettingBundle/Resources/config/routing.xml"
    prefix:  /setting
```

Vider le cache de Symfony2

Utilisation
-----------

Pour que le nom du Bundle qui utilise ce genre de paramètre soit user friendly dans l'interface, étendre de la classe "Oru\Bundle\SettingBundle\Bundle\OruBundle" au lieu de "Symfony\Component\HttpKernel\Bundle\Bundle".
Renseigner les méthodes obligatoires "getFriendlyName", "getDescription".

Les paramètres se déclarent dans un fichier dont le nom est sous la forme "domaine.region.orm", ex : "app.generic.orm", "OruTelemedecineBundle.paca.orm"
Ces fichiers doivent se trouver dans les répertoires "Resources/settings".
Le fichier est renseigné sous la forme :

```yaml
string:
    myParam:
        value: "Your string value"
        description: "What your param is for..."
        role: ROLE_SETTING_BASIC
    myTechnicalOrSensitiveParam:
        value: "Your string sensitive value"
        description: "What your sensitive param is for..."
        role: ROLE_SETTING_ADMIN
array:
    myParamIndexedArray:
        value:
            firstCase: "My value"
            secondCase: "My another value"
        description: "What your param is for..."
        role: ROLE_SETTING_BASIC
    myParamArray:
        value:
            - "My value"
            - "My another value"
        description: "What your param is for..."
        role: ROLE_SETTING_BASIC
```

Il est nécessaire d'éxécuter la commande suivante pour alimenter la base de données à partir des fichiers présents dans les différents bundles.

```
app/console oru:setting:dump
```


Un service "oru_setting" permet d'accéder à la valeur d'un paramètre, il s'utilise de la manière suivante :
Par défaut, le paramètre est supposé du domaine "app", s'il s'agit d'un paramètre du domaine d'un bundle, il faut le préciser comme dans l'exemple suivant.

``` php
$paramLang = $this->get('oru_setting')->setting('lang');
```

``` php
$paramLang = $this->get('oru_setting')->setting('lang', 'OruLangBundle');
```

On peut aussi, le cas échéant, préciser la région. Par défaut, il s'agit de celle qui est configurée dans parameters.yml
Lorsqu'un paramètre n'est pas défini dans la région courante, celui de generic est renvoyé s'il existe.

``` php
$paramLang = $this->get('oru_setting')->setting('lang', 'OruLangBundle', 'paca');
```

Dans une vue, l'extension twig setting() fonctionne de la même manière. (Attention au type reçu !)