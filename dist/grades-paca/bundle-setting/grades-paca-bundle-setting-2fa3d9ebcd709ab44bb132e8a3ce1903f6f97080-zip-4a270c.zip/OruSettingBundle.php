<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 09/01/14
 * Time: 09:38
 */

namespace Oru\Bundle\SettingBundle;

use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Oru\Bundle\SettingBundle\DependencyInjection\Compiler\SettingCompilerPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;

/**
 * Class OruSettingBundle.
 */
class OruSettingBundle extends OruBundle
{
    /**
     * @param ContainerBuilder $container
     */
    public function build(ContainerBuilder $container)
    {
        parent::build($container);

        $container->addCompilerPass(new SettingCompilerPass());
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public static function getFriendlyName()
    {
        return 'Module paramètres du ROR';
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public static function getDescription()
    {
        return 'Permet de définir des paramètres applicatifs avec des valeurs par défaut par région. Les valeurs des paramètres sont modifiables dans l\'application.';
    }
}
