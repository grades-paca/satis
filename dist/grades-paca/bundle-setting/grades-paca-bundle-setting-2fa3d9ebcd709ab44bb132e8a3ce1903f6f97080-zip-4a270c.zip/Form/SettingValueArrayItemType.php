<?php
/**
 * Author: Michaël VEROUX
 * Date: 28/04/14
 * Time: 11:28
 */

namespace Oru\Bundle\SettingBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class SettingValueArrayItemType.
 *
 * @author Michaël VEROUX
 */
class SettingValueArrayItemType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('key', TextType::class
            )
            ->add('value', TextType::class, array(
                    'required' => false,
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\SettingBundle\Entity\SettingValueArrayItem',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_setting_value_array_item';
    }
}
