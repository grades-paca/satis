<?php
/**
 * Author: Michaël VEROUX
 * Date: 23/04/14
 * Time: 10:17
 */

namespace Oru\Bundle\SettingBundle\Controller;

use Oru\Bundle\DesignBundle\Controller\FlashControllerTrait;
use Oru\Bundle\SettingBundle\Entity\Setting;
use Oru\Bundle\SettingBundle\Filter\SettingFilter;
use Oru\Bundle\SettingBundle\Form\Filter\SettingFilterType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Oru\Bundle\SettingBundle\Setting\Setting as SettingService;

/**
 * Class SettingController
 * @package Oru\Bundle\SettingBundle\Controller
 * @author Michaël VEROUX
 */
class SettingController extends Controller
{
    use FlashControllerTrait;

    /**
     * @param Request $request
     * @param SettingFilterType $form
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws AccessDeniedHttpException
     * @author Michaël VEROUX
     */
    public function indexAction(Request $request, SettingFilterType $form = null)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted(SettingService::ROLE_BASIC))
            throw new AccessDeniedHttpException();

        if(null === $form)
        {
            $form = $this->createForm(
                'oru_setting_filter',
                new SettingFilter())->submit($request->getSession()->get('oru_setting.filter')
            );
        }

        $em = $this->getDoctrine()->getManager();

        $entities = $em->getRepository('OruSettingBundle:Setting')->findList($form->getData(), $this->get('oru_setting')->getRegion());

        $this->get('oru_setting')->filter($entities);

        $listing = $this->container->get('listing.factory')->create(
            $this->get('oru_setting.listing'),
            $entities->getQuery()->execute()
        );

        return $this->render('OruSettingBundle:Setting:index.html.twig',
            array(
                'listing'   => $listing,
                'form'      => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     * @throws AccessDeniedHttpException
     * @author Michaël VEROUX
     */
    public function filterAction(Request $request)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted(SettingService::ROLE_BASIC))
            throw new AccessDeniedHttpException();

        $form = $this->createForm('oru_setting_filter')->handleRequest($request);

        if ($form->get('reset')->isClicked())
        {
            $request->getSession()->set('oru_setting.filter', array());

            return $this->redirect($this->generateUrl('oru_setting'));
        }

        if($form->isValid()) {
            $request->getSession()->set('oru_setting.filter', $request->get($form->getName()));

            return $this->redirect($this->generateUrl('oru_setting'));
        }

        return $this->indexAction($request, $form);
    }


    /**
     * @param Setting $entity
     * @return Response
     * @throws AccessDeniedHttpException
     * @author Michaël VEROUX
     */
    public function editAction(Setting $entity)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted($entity->getRole(), $entity))
            throw new AccessDeniedHttpException();

        $form = $this->container->get('form.factory')->create(
            $this->get('oru_setting.form'),
            $entity
        );

        return $this->render('OruSettingBundle:Setting:edit.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     * @param Setting $entity
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
     * @throws AccessDeniedHttpException
     * @author Michaël VEROUX
     */
    public function updateAction(Request $request, Setting $entity)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted($entity->getRole(), $entity))
            throw new AccessDeniedHttpException();

        $form = $this->container->get('form.factory')->create(
            $this->get('oru_setting.form'),
            $entity
        );

        $form->handleRequest($request);

        if($form->isValid())
        {
            $em = $this->getDoctrine()->getManager();
            $em->flush();
            $cacheState = $this->get('oru_setting.cache_refresh')->now($entity->getRegion());
            if (!$cacheState) {
                $this->addSessionMessage('Une erreur est survenue lors de l\'invalidation du cache.', 'error');
            }

            $this->addSessionMessage('Vos données sont enregistrées.');

            return $this->redirect($this->generateUrl('oru_setting_edit', array('id' => $entity->getId())));
        }

        $this->addSessionMessage('Le formulaire soumis contient des erreurs...', 'warning');

        return $this->render('OruSettingBundle:Setting:edit.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws AccessDeniedHttpException
     * @author Michaël VEROUX
     */
    public function newAction(Request $request)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted(SettingService::ROLE_ADMIN))
            throw new AccessDeniedHttpException();

        $form = $this->container->get('form.factory')->create(
            $this->get('oru_setting.form')->setFullEditable(true),
            new Setting()
        );

        return $this->render('OruSettingBundle:Setting:new.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     * @throws AccessDeniedHttpException
     * @author Michaël VEROUX
     */
    public function createAction(Request $request)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted(SettingService::ROLE_ADMIN))
            throw new AccessDeniedHttpException();

        $setting = new Setting();

        $form = $this->container->get('form.factory')->create(
            $this->get('oru_setting.form')->setFullEditable(true),
            $setting
        );

        $form->handleRequest($request);

        if($form->isValid())
        {
            $setting->setDefaultValue('');
            $em = $this->getDoctrine()->getManager();
            $em->persist($setting);
            $em->flush();
            $cacheState = $this->get('oru_setting.cache_refresh')->now($setting->getRegion());
            if (!$cacheState) {
                $this->addSessionMessage('Une erreur est survenue lors de l\'invalidation du cache.', 'error');
            }

            $this->addSessionMessage('Vos données sont enregistrées.');

            return $this->redirect($this->generateUrl('oru_setting_edit', array('id' => $setting->getId())));
        }

        $this->addSessionMessage('Le formulaire soumis contient des erreurs...', 'warning');

        return $this->render('OruSettingBundle:Setting:new.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     * @param Setting $setting
     * @return Response
     * @throws InvalidCsrfTokenException
     * @throws AccessDeniedHttpException
     * @author Michaël VEROUX
     */
    public function deleteAction(Request $request, Setting $setting)
    {
        if(!$this->get('oru_setting.dynamic_security')->isGranted(SettingService::ROLE_DELETE))
            throw new AccessDeniedHttpException();

        $em = $this->getDoctrine()->getManager();
        $em->remove($setting);
        $em->flush();
        $cacheState = $this->get('oru_setting.cache_refresh')->now($setting->getRegion());
        if (!$cacheState) {
            $this->addSessionMessage('Une erreur est survenue lors de l\'invalidation du cache.', 'error');
        }

        $this->addSessionMessage('L\'élément à été supprimé.');

        $response = new Response();

        $response->setContent(json_encode(array(
            'redirect' => $this->generateUrl('oru_setting'),
        )));
        $response->headers->set('Content-Type', 'application/json');

        return $response;
    }
} 