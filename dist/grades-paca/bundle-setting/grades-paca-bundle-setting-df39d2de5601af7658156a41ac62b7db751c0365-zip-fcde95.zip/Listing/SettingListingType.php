<?php
/**
 * Author: Michaël VEROUX
 * Date: 23/04/14
 * Time: 10:31
 */

namespace Oru\Bundle\SettingBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Symfony\Component\Security\Csrf\CsrfTokenManagerInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class SettingListingType
 * @package Oru\Bundle\SettingBundle\Listing
 * @author Michaël VEROUX
 */
class SettingListingType extends AbstractListingType
{
    /**
     * @var CsrfTokenManagerInterface
     */
    protected $csrfProvider;

    /**
     * @param CsrfTokenManagerInterface $csrfProvider
     */
    function __construct(CsrfTokenManagerInterface $csrfProvider)
    {
        $this->csrfProvider = $csrfProvider;
    }

    /**
     * @param ListingBuilderInterface $builder
     * @author Michaël VEROUX
     */
    public function buildListing(ListingBuilderInterface $builder)
    {

        $builder
            ->add('name', null, array(
                    'label'         =>  'oru_setting.name',
                    'translation_domain'    => 'OruSettingBundle',
                )
            )
            ->add('description', null, array(
                    'label'         =>  'oru_setting.description',
                    'translation_domain'    => 'OruSettingBundle',
                )
            )
            ->add('valueAsString', null, array(
                    'label'         =>  'oru_setting.value',
                    'translation_domain'    => 'OruSettingBundle',
                )
            )
            ->add('edit', 'object_action', array(
                    'route'     => 'oru_setting_edit',
                    'label'     => 'listing.action.edit',
                    'role'      => Setting::ROLE_ACCESS,
                )
            )
            ->add('delete', 'object_action', array(
                    'route'     => 'oru_setting_delete',
                    'label'     => 'listing.action.delete',
                    'role'      => Setting::ROLE_DELETE,
                    'route_parameters'  =>  array(
                        '_method'           =>  'DELETE',
                        'token'             =>  $this->csrfProvider->getToken('delete'),
                    ),
                )
            )
        ;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'oru_setting_listing';
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\SettingBundle\Entity\Setting',
        ));
    }

} 