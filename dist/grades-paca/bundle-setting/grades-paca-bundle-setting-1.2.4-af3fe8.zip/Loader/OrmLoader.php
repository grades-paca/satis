<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 20/11/13
 * Time: 10:12
 */

namespace Oru\Bundle\SettingBundle\Loader;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\SettingBundle\Setting\SettingCatalogue;
use Symfony\Component\Config\Resource\FileResource;

/**
 * Class OrmLoader.
 */
class OrmLoader implements LoaderInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    private $entityManager;

    /**
     * @param EntityManager $entityManager
     */
    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param $resource
     * @param string $region
     * @param string $prefix
     *
     * @return SettingCatalogue
     *
     * @author Michaël VEROUX
     */
    public function load($resource, $region, $prefix = 'app')
    {
        $query = $this->entityManager->getRepository('OruSettingBundle:Setting')
            ->createQueryBuilder('s')
            ->where('s.prefix = :prefix AND s.region = :region')
            ->setParameter('prefix', $prefix)
            ->setParameter('region', $region)
            ->getQuery()
        ;

        $catalogue = new SettingCatalogue($region);

        // add first ressource to catalogue
        $catalogue->addResource(new FileResource($resource));

        /** @var \Oru\Bundle\SettingBundle\Entity\Setting $objSetting */
        foreach ($query->getResult() as $objSetting) {
            $catalogue->set($objSetting->getName(), $objSetting);
        }

        return $catalogue;
    }
}
