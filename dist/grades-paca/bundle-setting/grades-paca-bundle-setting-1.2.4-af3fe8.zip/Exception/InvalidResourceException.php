<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 13/01/14
 * Time: 14:02
 */

namespace Oru\Bundle\SettingBundle\Exception;

/**
 * Class InvalidResourceException.
 *
 * @author Michaël VEROUX
 */
class InvalidResourceException extends \InvalidArgumentException
{
}
