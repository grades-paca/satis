<?php
/**
 * Author: Michaël VEROUX
 * Date: 28/04/14
 * Time: 16:52
 */

namespace Oru\Bundle\SettingBundle\Doctrine;

use Doctrine\DBAL\Platforms\AbstractPlatform;
use Doctrine\DBAL\Types\Type;
use Oru\Bundle\SettingBundle\Setting\DateTime;
use Oru\Bundle\SettingBundle\Type\Image;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * Class DynamicType.
 *
 * @author Michaël VEROUX
 */
class DynamicType extends Type
{
    const DYNAMIC = 'oru_setting_dynamic';

    /**
     * Gets the SQL declaration snippet for a field of this type.
     *
     * @param array            $fieldDeclaration the field declaration
     * @param AbstractPlatform $platform         the currently used database platform
     */
    public function getSQLDeclaration(array $fieldDeclaration, AbstractPlatform $platform)
    {
        return $platform->getClobTypeDeclarationSQL($fieldDeclaration);
    }

    /**
     * @param mixed            $value
     * @param AbstractPlatform $platform
     *
     * @return mixed|string
     *
     * @author Michaël VEROUX
     */
    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
        if (is_array($value)) {
            return serialize($value);
        }
        if ($value instanceof \DateTime) {
            return $value->format('Y-m-d H:i:s');
        }
        if ($value instanceof UploadedFile) {
            $imageObject = Image::createFromUploadedFile($value);

            return @serialize($imageObject);
        }

        if ($value instanceof Image) {
            return @serialize($value);
        }

        return $value;
    }

    /**
     * @param mixed            $value
     * @param AbstractPlatform $platform
     *
     * @return mixed|null|string
     *
     * @author Michaël VEROUX
     */
    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        if ($value === null) {
            return null;
        }

        $value = (is_resource($value)) ? stream_get_contents($value) : $value;
        $val = @unserialize($value);

        if ($val === false) {
            $date = array();
            if (preg_match('#^(?<year>[0-9]{4})-(?<month>[0-9]{2})-(?<day>[0-9]{2})(?: (?<hour>[0-9]{2}):(?<minute>[0-9]{2}):?(?<second>[0-9]{2})?)?$#', $value, $date)) {
                $dateDefault = array(
                    'year' => '1970',
                    'month' => '01',
                    'day' => '01',
                    'hour' => '00',
                    'minute' => '00',
                    'second' => '00',
                );

                $date = array_merge($dateDefault, $date);
                $dateTime = new DateTime();
                $dateTime->setDate($date['year'], $date['month'], $date['day']);
                $dateTime->setTime($date['hour'], $date['minute'], $date['second']);

                return $dateTime;
            }

            return $value;
        }

        return $val;
    }

    /**
     * Gets the name of this type.
     *
     * @return string
     */
    public function getName()
    {
        return self::DYNAMIC;
    }

    public function requiresSQLCommentHint(AbstractPlatform $platform)
    {
        return true;
    }
}
