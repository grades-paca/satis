<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 13/01/14
 * Time: 11:22
 */

namespace Oru\Bundle\SettingBundle\Command;

use Oru\Bundle\SettingBundle\Exception\MissingParameterException;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class SettingDumpCommand.
 *
 * @author Michaël VEROUX
 */
class SettingDumpCommand extends ContainerAwareCommand
{
    /**
     * @author Michaël VEROUX
     */
    protected function configure()
    {
        $this
            ->setName('oru:setting:dump')
            ->setDescription('Dump settings in database')
        ;
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     *
     * @author Michaël VEROUX
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        if (!$this->getContainer()->hasParameter('region')) {
            throw new MissingParameterException('Le paramètre region n\'est pas renseigné dans parameters.yml !');
        }
        $this->getContainer()->get('oru_setting.dumper')->dump($output);
        $this->getContainer()->get('oru_setting.cache_refresh')->now();
    }
}
