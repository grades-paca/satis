<?php

namespace Oru\Bundle\SettingBundle\DependencyInjection;

use Symfony\Component\Config\Resource\DirectoryResource;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\Finder\Finder;
use Symfony\Component\HttpKernel\DependencyInjection\Extension;
use Symfony\Component\DependencyInjection\Loader;

/**
 * This is the class that loads and manages your bundle configuration
 *
 * To learn more see {@link http://symfony.com/doc/current/cookbook/bundles/extension.html}
 */
class OruSettingExtension extends Extension
{
    /**
     * {@inheritDoc}
     */
    public function load(array $configs, ContainerBuilder $container)
    {
        $configuration = new Configuration();
        $config = $this->processConfiguration($configuration, $configs);

        $loader = new Loader\XmlFileLoader($container, new FileLocator(__DIR__.'/../Resources/config'));
        $loader->load('services.xml');

        $this->registerSettingConfiguration($config, $container);
    }

    private function registerSettingConfiguration(array $config, ContainerBuilder $container)
    {
        $serviceSetting = $container->findDefinition('oru_setting');
        if (!is_array($config['fallback'])) {
            $config['fallback'] = array($config['fallback']);
        }
        $serviceSetting->addMethodCall('setFallbackRegions', array($config['fallback']));

        $dirs = array();
        $overridePath = $container->getParameter('kernel.root_dir').'/Resources/%s/settings';
        foreach ($container->getParameter('kernel.bundles') as $bundle => $class) {
            $reflection = new \ReflectionClass($class);
            if (is_dir($dir = dirname($reflection->getFilename()).'/Resources/settings')) {
                $dirs[] = $dir;
            }
            if (is_dir($dir = sprintf($overridePath, $bundle))) {
                $dirs[] = $dir;
            }
        }

        if (is_dir($dir = $container->getParameter('kernel.root_dir').'/Resources/settings')) {
            $dirs[] = $dir;
        }

        if ($dirs) {
            foreach ($dirs as $dir) {
                $container->addResource(new DirectoryResource($dir));
            }
            $finder = Finder::create()
                ->files()
                ->filter(function (\SplFileInfo $file) {
                    return 2 === substr_count($file->getBasename(), '.') && preg_match('/\.\w+$/', $file->getBasename());
                })
                ->in($dirs)
            ;

            foreach ($finder as $file) {
                // filename is prefix.region.format
                list($prefix, $region, $format) = explode('.', $file->getBasename(), 3);
                $serviceSetting->addMethodCall('addResource', array($format, (string) $file, $region, $prefix));
            }
        }
    }
}
