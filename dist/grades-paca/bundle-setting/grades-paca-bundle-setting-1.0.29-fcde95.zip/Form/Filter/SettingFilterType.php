<?php
/**
 * Author: Michaël VEROUX
 * Date: 23/04/14
 * Time: 10:22
 */

namespace Oru\Bundle\SettingBundle\Form\Filter;

use Doctrine\Common\Persistence\ObjectManager;
use Oru\Bundle\SettingBundle\Bundle\Registered;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class SettingFilterType
 * @package Oru\Bundle\SettingBundle\Form\Filter
 * @author Michaël VEROUX
 */
class SettingFilterType extends AbstractType
{
    /**
     * @var null|\Oru\Bundle\SettingBundle\Bundle\Registered
     */
    protected $registeredBundles = null;

    /**
     * @var null|\Doctrine\Common\Persistence\ObjectManager
     */
    protected $em = null;

    public function __construct(Registered $registeredBundles, ObjectManager $objectManager)
    {
        $this->registeredBundles = $registeredBundles;
        $this->em = $objectManager;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $prefixes = array_merge(
            array_combine(
                $this->em->getRepository('OruSettingBundle:Setting')->getPrefixes(),
                $this->em->getRepository('OruSettingBundle:Setting')->getPrefixes()
            ),
            $this->registeredBundles->toArray()
        );
        asort($prefixes);

        $builder
            ->add('name', 'search', array(
                    'label'         =>  'oru_setting.name',
                )
            )
            ->add('prefix', 'choice', array(
                    'label'         =>  'oru_setting.prefix',
                    'choices'       =>  $prefixes,
                    'placeholder'   =>  'Tous',
                )
            )
            ->add('value', 'search', array(
                            'label'         =>  'oru_setting.value',
                        )
            )
            ->add('filter', 'submit', array(
                    'label'                 => 'listing.action.filter',
                    'translation_domain'    => 'messages',
                    'attr' => array('class' => 'btn btn-primary')
                )
            )
            ->add('reset', 'submit', array(
                    'label'                 => 'listing.action.reset',
                    'translation_domain'    => 'messages',
                    'attr' => array('class' => 'btn btn-default')
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\SettingBundle\Filter\SettingFilter',
            'csrf_protection' => false,
            'validation_groups' => false,
            'required' => false,
            'translation_domain'    => 'OruSettingBundle',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_setting_filter';
    }
} 