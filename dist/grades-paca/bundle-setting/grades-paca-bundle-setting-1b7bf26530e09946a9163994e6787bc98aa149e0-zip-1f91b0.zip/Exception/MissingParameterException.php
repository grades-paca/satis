<?php
/**
 * Author: Michaël VEROUX
 * Date: 25/04/14
 * Time: 15:02
 */

namespace Oru\Bundle\SettingBundle\Exception;

/**
 * Class MissingParameterException
 * @package Oru\Bundle\SettingBundle\Exception
 * @author Michaël VEROUX
 */
class MissingParameterException extends \InvalidArgumentException
{

} 