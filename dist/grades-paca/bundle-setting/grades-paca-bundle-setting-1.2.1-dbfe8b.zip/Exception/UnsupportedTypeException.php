<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 10/01/14
 * Time: 16:31
 */

namespace Oru\Bundle\SettingBundle\Exception;

/**
 * Class UnsupportedTypeException.
 *
 * @author Michaël VEROUX
 */
class UnsupportedTypeException extends \InvalidArgumentException
{
}
