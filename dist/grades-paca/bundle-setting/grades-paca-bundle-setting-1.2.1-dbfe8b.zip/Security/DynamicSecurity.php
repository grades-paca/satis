<?php
/**
 * Author: Michaël VEROUX
 * Date: 03/07/14
 * Time: 11:56
 */

namespace Oru\Bundle\SettingBundle\Security;

use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

class DynamicSecurity
{
    protected $securityContext;

    /** @var \Oru\Bundle\RorCredentialsBundle\OruRorCredentialsChecker|null */
    protected $alternativContext = null;

    public function __construct(AuthorizationCheckerInterface $securityContext)
    {
        $this->securityContext = $securityContext;
    }

    /**
     * @param null $alternativContext
     */
    public function setAlternativContext($alternativContext)
    {
        $this->alternativContext = $alternativContext;
    }

    public function isGranted($role, $entity = null)
    {
        if (null !== $this->alternativContext) {
            try {
                return $this->alternativContext->checkCurrentUser($this->transRole($role), $entity);
            } catch (\Exception $e) {
                return $this->alternativContext->checkCurrentUser($this->transRole($role));
            }
        }

        return $this->securityContext->isGranted($role, $entity);
    }

    public function getIdEtabsFromCredentialUser($nameCredential)
    {
        if (null !== $this->alternativContext) {
            return $this->alternativContext->getIdEtabsFromCredentialUser($nameCredential);
        }

        return array();
    }

    protected function transRole($role)
    {
        $alternativRoles = array(
            'ROLE_ADMIN' => 'ORU_ROR_ADMIN',
            'ROLE_SUPER_ADMIN' => 'ORU_ROR_SUPER_ADMIN',
        );

        if (null === $this->alternativContext) {
            return $role;
        }
        if (isset($alternativRoles[$role])) {
            return $alternativRoles[$role];
        }
        return $role;
    }
}
