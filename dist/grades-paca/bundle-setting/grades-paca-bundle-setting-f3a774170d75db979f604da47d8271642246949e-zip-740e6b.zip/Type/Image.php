<?php

namespace Oru\Bundle\SettingBundle\Type;

use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\HttpFoundation\File\File as FileObject;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * Class Image
 *
 * @package Oru\Bundle\SettingBundle\Type
 * @author Michaël VEROUX
 */
class Image
{
    /**
     * @var string
     */
    protected $name;

    /**
     * @var string
     */
    protected $mimeType;

    /**
     * @var string
     */
    protected $base64Data;

    /**
     * @param string $filename
     *
     * @return Image
     * @author Michaël VEROUX
     */
    static public function createFromFile($filename)
    {
        $fileSystem = new Filesystem();
        if ($fileSystem->exists($filename)) {
            $imageObject = new self();
            $file = new FileObject($filename);
            $imageObject->setMimeType($file->getMimeType());
            $imageObject->setName($file->getBasename());
            $imageObject->setBase64Data(base64_encode(file_get_contents($filename)));

            return $imageObject;
        }

        throw new FileException();
    }

    /**
     * @param UploadedFile $file
     *
     * @return Image
     * @author Michaël VEROUX
     */
    static public function createFromUploadedFile(UploadedFile $file)
    {
        $imageObject = self::createFromFile($file->getPathname());
        $imageObject->setName($file->getClientOriginalName());

        return $imageObject;
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     *
     * @return $this
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * @return string
     */
    public function getMimeType()
    {
        return $this->mimeType;
    }

    /**
     * @param string $mimeType
     *
     * @return $this
     */
    public function setMimeType($mimeType)
    {
        $this->mimeType = $mimeType;

        return $this;
    }

    /**
     * @return string
     */
    public function getBase64Data()
    {
        return $this->base64Data;
    }

    /**
     * @param string $base64Data
     *
     * @return $this
     */
    public function setBase64Data($base64Data)
    {
        $this->base64Data = $base64Data;

        return $this;
    }

    /**
     * The __toString method allows a class to decide how it will react when it is converted to a string.
     *
     * @return string
     * @link http://php.net/manual/en/language.oop5.magic.php#language.oop5.magic.tostring
     */
    public function __toString()
    {
        $srcData = sprintf('data:%s;base64,%s', $this->mimeType, $this->base64Data);

        return $srcData;
    }
}
