<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 09/01/14
 * Time: 11:02
 */

namespace Oru\Bundle\SettingBundle\Setting;


/**
 * Interface SettingCatalogueInterface
 * @package Oru\Bundle\SettingBundle\Setting
 * @author Michaël VEROUX
 */
interface SettingCatalogueInterface
{
    /**
     * @return mixed
     * @author Michaël VEROUX
     */
    public function getRegion();

    /**
     * @return mixed
     * @author Michaël VEROUX
     */
    public function all();

    /**
     * @return mixed
     * @author Michaël VEROUX
     */
    public function getResources();
} 