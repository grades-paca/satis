<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 09/01/14
 * Time: 10:42
 */

namespace Oru\Bundle\SettingBundle\Setting;


use Oru\Bundle\SettingBundle\Entity\Setting as EntitySetting;
use Symfony\Component\Config\Resource\ResourceInterface;

/**
 * Class SettingCatalogue
 * @package Oru\Bundle\SettingBundle\Setting
 * @author Michaël VEROUX
 */
class SettingCatalogue implements SettingCatalogueInterface
{
    /**
     * @var null|string
     */
    private $region = null;

    /**
     * @var array
     */
    private $param_values = array();
    /**
     * @var array
     */
    private $resources = array();
    /**
     * @var
     */
    private $parent;
    /**
     * @var string
     */
    private $fallbackCatalogue;

    /**
     * @param string $region
     * @param array $param_values
     */
    public function __construct($region, array $param_values = array())
    {
        $this->param_values = $param_values;
        $this->region = $region;
    }

    /**
     * @param string|null $region
     */
    public function setRegion($region)
    {
        $this->region = $region;
    }

    /**
     * @return string|null
     */
    public function getRegion()
    {
        return $this->region;
    }

    /**
     * @param string $id
     * @param EntitySetting $objSetting
     * @author Michaël VEROUX
     */
    public function add($id, EntitySetting $objSetting)
    {
        if (!isset($this->param_values[$objSetting->getPrefix()])) {
            $this->param_values[$objSetting->getPrefix()] = array($id => $objSetting);
        } else {
            $this->param_values[$objSetting->getPrefix()] = array_replace($this->param_values[$objSetting->getPrefix()], array($id => $objSetting));
        }
    }

    /**
     * @param SettingCatalogueInterface $catalogue
     * @throws \LogicException
     * @author Michaël VEROUX
     */
    public function addCatalogue(SettingCatalogueInterface $catalogue)
    {
        if ($catalogue->getRegion() !== $this->region) {
            throw new \LogicException(sprintf('Cannot add a catalogue for region "%s" as the current region for this catalogue is "%s"', $catalogue->getRegion(), $this->region));
        }

        foreach ($catalogue->all() as $prefix => $param_values) {
            foreach($param_values as $key => $param_value)
            {
                $this->add($key, $param_value);
            }
        }

        foreach ($catalogue->getResources() as $resource) {
            $this->addResource($resource);
        }

        if ($catalogue instanceof MetadataAwareInterface) {
            $metadata = $catalogue->getMetadata('', '');
            $this->addMetadata($metadata);
        }
    }

    /**
     * @param ResourceInterface $resource
     * @author Michaël VEROUX
     */
    public function addResource(ResourceInterface $resource)
    {
        $this->resources[$resource->__toString()] = $resource;
    }

    /**
     * @param SettingCatalogueInterface $catalogue
     * @throws \LogicException
     * @author Michaël VEROUX
     */
    public function addFallbackCatalogue(SettingCatalogueInterface $catalogue)
    {
        // detect circular references
        $c = $this;
        do {
            if ($c->getRegion() === $catalogue->getRegion()) {
                throw new \LogicException(sprintf('Circular reference detected when adding a fallback catalogue for region "%s".', $catalogue->getRegion()));
            }
        } while ($c = $c->parent);

        $catalogue->parent = $this;
        $this->fallbackCatalogue = $catalogue;

        foreach ($catalogue->getResources() as $resource) {
            $this->addResource($resource);
        }
    }

    /**
     * @return mixed
     * @author Michaël VEROUX
     */
    public function getFallbackCatalogue()
    {
        return $this->fallbackCatalogue;
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    public function getResources()
    {
        return array_values($this->resources);
    }

    /**
     * @param string $id
     * @param string $prefix
     * @return null|mixed
     * @author Michaël VEROUX
     */
    public function get($id, $prefix = 'app')
    {
        if (isset($this->param_values[$prefix][$id])) {
            if(!is_object($this->param_values[$prefix][$id]))
                $this->param_values[$prefix][$id] = unserialize($this->param_values[$prefix][$id]);

            return $this->getTypedValue( $this->param_values[$prefix][$id] );
        }

        if (null !== $this->fallbackCatalogue) {
            return $this->fallbackCatalogue->get($id, $prefix);
        }

        return null;
    }

    protected function getTypedValue(EntitySetting $setting)
    {
        switch($setting->getType())
        {
            case 'integer':
                return intval($setting->getValue());
            case 'float':
                return floatval($setting->getValue());
            case 'boolean':
                return (bool)$setting->getValue();
            case 'array':
                return (array)$setting->getValue();
            case 'datetime':
                if($setting->getValue() instanceof \DateTime)
                    return $setting->getValue();
            default:
                return (string)$setting->getValue();
        }
    }

    /**
     * @param string $prefix
     * @return array
     * @author Michaël VEROUX
     */
    public function all($prefix = 'app')
    {
        if ('app' === $prefix) {
            return $this->param_values;
        }

        return isset($this->param_values[$prefix]) ? $this->param_values[$prefix] : array();
    }

    /**
     * @param string $id
     * @param EntitySetting $objSetting
     * @author Michaël VEROUX
     */
    public function set($id, EntitySetting $objSetting)
    {
        $this->add($id, $objSetting);
    }
} 