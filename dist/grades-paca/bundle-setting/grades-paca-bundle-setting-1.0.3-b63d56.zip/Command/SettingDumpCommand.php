<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 13/01/14
 * Time: 11:22
 */

namespace Oru\Bundle\SettingBundle\Command;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Criteria;
use Oru\Bundle\SettingBundle\Entity\Setting;
use Oru\Bundle\SettingBundle\Exception\InvalidResourceException;
use Oru\Bundle\SettingBundle\Exception\MissingParameterException;
use Oru\Bundle\SettingBundle\Exception\NotFoundResourceException;
use Oru\Bundle\SettingBundle\Exception\UnsupportedTypeException;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Yaml\Parser as YamlParser;

/**
 * Class SettingDumpCommand
 * @package Oru\Bundle\SettingBundle\Command
 * @author Michaël VEROUX
 */
class SettingDumpCommand extends ContainerAwareCommand
{
    /**
     * @var array
     */
    private $acceptedKeys = array('value', 'description', 'role');

    /**
     * @var null|YamlParser
     */
    private $yamlParser = null;

    /**
     * @var array
     */
    private $settingIds = array();

    /**
     * @author Michaël VEROUX
     */
    protected function configure()
    {
        $this
            ->setName('oru:setting:dump')
            ->setDescription('Dump settings in database')
        ;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @throws \Oru\Bundle\SettingBundle\Exception\MissingParameterException
     * @author Michaël VEROUX
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        if(!$this->getContainer()->hasParameter('region'))
            throw new MissingParameterException('Le paramètre region n\'est pas renseigné dans parameters.yml !');

        /** @var \Oru\Bundle\SettingBundle\Setting\Setting $oruSetting */
        $oruSetting = $this->getContainer()->get('oru_setting');

        foreach($oruSetting->getResources() as $region => $resources)
        {
            foreach($resources as $resource)
            {
                $file = $resource[1];
                $prefix = $resource[2];

                $param_values = $this->getYamlSettingsAsArray($file);

                $this->persistSettings($param_values, $region, $prefix);
            }
        }

        $settings = $this->getContainer()->get('doctrine.orm.default_entity_manager')
            ->getRepository('OruSettingBundle:Setting')->getDiffFormIds($this->settingIds);

        $cacheFilename = sprintf('%s/settings/diff.php', $this->getContainer()->getParameter('kernel.cache_dir'));
        file_put_contents($cacheFilename, "<?php\nreturn array(\n");
        foreach ($settings as $setting) {
            file_put_contents($cacheFilename, sprintf("\t%d\t=> '[%s][%s] %s',\n", $setting->getId(), $setting->getRegion(), $setting->getPrefix(), $setting->getName()), FILE_APPEND);
        }
        file_put_contents($cacheFilename, ");\n", FILE_APPEND);
    }

    /**
     * @param $file
     * @return array|bool|float|int|mixed|null|number|string
     * @throws \Oru\Bundle\SettingBundle\Exception\InvalidResourceException
     * @throws \Oru\Bundle\SettingBundle\Exception\NotFoundResourceException
     * @throws \Oru\Bundle\SettingBundle\Exception\UnsupportedTypeException
     * @author Michaël VEROUX
     */
    protected function getYamlSettingsAsArray($file)
    {
        if (!stream_is_local($file)) {
            throw new InvalidResourceException(sprintf('This is not a local file "%s".', $file));
        }

        if (!file_exists($file)) {
            throw new NotFoundResourceException(sprintf('File "%s" not found.', $file));
        }

        if (null === $this->yamlParser) {
            $this->yamlParser = new YamlParser();
        }

        try {
            $param_values = $this->yamlParser->parse(file_get_contents($file));
        } catch (ParseException $e) {
            throw new InvalidResourceException('Error parsing YAML.', 0, $e);
        }

        $diff_types = array_diff(array_keys($param_values), Setting::supportedTypes());
        if($diff_types)
            throw new UnsupportedTypeException(
                sprintf('%s type%s %s unsupported!',
                    implode(',',$diff_types),
                    count($diff_types) > 1 ? 's' : '',
                    count($diff_types) > 1 ? 'are' : 'is'
                )
            );

        return $param_values;
    }

    /**
     * @param $param_values
     * @param $region
     * @param $prefix
     * @author Michaël VEROUX
     */
    protected function persistSettings($param_values, $region, $prefix)
    {
        $entityManager = $this->getContainer()->get('doctrine')->getManager();

        foreach($param_values as $type => $param_values_type)
        {
            // empty file
            if (null === $param_values_type) {
                $param_values_type = array();
            }

            if(!empty($param_values_type))
            {
                $settings = $entityManager->getRepository('OruSettingBundle:Setting')
                    ->createQueryBuilder('s')
                    ->where('s.name IN (:name) AND s.region = :region AND s.prefix = :prefix')
                    ->setParameters(array(
                        'name'      =>  array_keys($param_values_type),
                        'region'    =>  $region,
                        'prefix'    =>  $prefix,
                    ))
                    ->getQuery()
                    ->getResult();

                $settingNewCollection = new ArrayCollection();
                foreach($param_values_type as $key => $param_value)
                {
                    $this->integrityControl($param_value);

                    if(count($settings))
                    {
                        if(! $settings instanceof ArrayCollection)
                            $settings = new ArrayCollection($settings);

                        $setting = $settings->matching(
                            Criteria::create()->where(
                                Criteria::expr()->andX(
                                    Criteria::expr()->contains('name', $key),
                                    Criteria::expr()->contains('prefix', $prefix),
                                    Criteria::expr()->contains('region', $region)
                                )
                            )
                        )->first();
                        $this->settingIds[] = $setting->getId();
                    }
                    else
                        $setting = null;

                    if(! $setting instanceof Setting)
                    {
                        $setting = new Setting();
                        $setting
                            ->setName($key)
                            ->setPrefix($prefix)
                            ->setRegion($region)
                            ->setType($type)
                        ;
                        $entityManager->persist($setting);
                        $settingNewCollection->add($setting);
                    }

                    if(is_array($param_value['value']))
                        $setting->setDefaultValue(serialize($param_value['value']));
                    else
                        $setting->setDefaultValue($param_value['value']);

                    if(isset($param_value['description']))
                        $setting->setDescription($param_value['description']);

                    if(isset($param_value['role']))
                        $setting->setRole($param_value['role']);
                }
                $entityManager->flush();
                $newIds = $settingNewCollection->map(function ($setting) {
                    return $setting->getId();
                })->toArray();
                $this->settingIds = array_merge($this->settingIds, $newIds);
            }
        }
    }

    /**
     * @param $array
     * @return bool
     * @throws \Oru\Bundle\SettingBundle\Exception\InvalidResourceException
     * @author Michaël VEROUX
     */
    private function integrityControl($array)
    {
        $unknownKeys = array_diff(array_keys($array), $this->acceptedKeys);
        if(count($unknownKeys))
        {
            $pluralThis = count($unknownKeys) > 1 ? 'These': 'This';
            $pluralKey = count($unknownKeys) > 1 ? 's': '';
            $pluralIs = count($unknownKeys) > 1 ? 'are': 'is';
            throw new InvalidResourceException(
                sprintf('%s key%s %s unknown : %s',
                    $pluralThis,
                    $pluralKey,
                    $pluralIs,
                    implode(', ',$unknownKeys)
                )
            );
        }

        if(!isset($array['value']))
        {
            throw new InvalidResourceException('Key "value" is mandatory!');
        }

        return true;
    }
} 