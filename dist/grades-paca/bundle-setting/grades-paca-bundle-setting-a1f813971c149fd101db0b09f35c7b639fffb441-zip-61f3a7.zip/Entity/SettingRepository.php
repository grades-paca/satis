<?php
/**
 * Author: Michaël VEROUX
 * Date: 23/04/14
 * Time: 10:28
 */

namespace Oru\Bundle\SettingBundle\Entity;

use Doctrine\Common\Inflector\Inflector;
use Doctrine\ORM\EntityRepository;
use Oru\Bundle\SettingBundle\Filter\SettingFilter;

/**
 * Class SettingRepository
 * @package Oru\Bundle\SettingBundle\Entity
 * @author Michaël VEROUX
 */
class SettingRepository extends EntityRepository
{
    /**
     * @param SettingFilter $settingFilter
     * @param string        $region
     *
     * @return \Doctrine\ORM\QueryBuilder
     * @author Michaël VEROUX
     */
    public function findList(SettingFilter $settingFilter, $region = 'generic')
    {
        $builder = $this->createQueryBuilder("s");

        $overrided = array();
        if ('generic' !== $region) {
            $builder
                ->select('s.name')
                ->where('s.region = :region')
                ->setParameter('region', $region)
            ;
            $overrided = $builder->getQuery()->getArrayResult();
            $overrided = array_map('current', $overrided);
        }
        $builder = $this->createQueryBuilder("s");

        $searchFields = array('name', 'prefix', 'value');

        foreach($searchFields as $field)
        {
            $method = 'get' . Inflector::camelize($field);

            $builder
                ->andWhere(sprintf('s.%1$s LIKE :%1$s', $field))
                ->setParameter($field, sprintf('%%%s%%', $settingFilter->$method()))
            ;
        }

        if (count($overrided)) {
            $builder->andWhere('(s.region = :region AND s.name IN (:overrided)) OR (s.region = \'generic\' AND s.name NOT IN (:overrided))');
            $builder->setParameter('region', $region);
            $builder->setParameter('overrided', $overrided);
        } else {
            $builder->andWhere('s.region = \'generic\'');
        }

        $builder
            ->addOrderBy('s.prefix')
            ->addOrderBy('s.name')
        ;

        return $builder;
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    public function getRegions()
    {
        $builder = $this->createQueryBuilder('s');

        $result = $builder
            ->select('s.region')
            ->addGroupBy('s.region')
            ->getQuery()
            ->getArrayResult()
        ;

        $result = array_map(function($value){ return $value['region']; }, $result);

        return array_combine($result, $result);
    }

    /**
     * @param $region
     * @return array
     * @author Michaël VEROUX
     */
    public function getPrefixesByRegion($region)
    {
        $builder = $this->createQueryBuilder('s');

        $result = $builder
            ->select('s.prefix')
            ->andWhere('s.region = :region')
            ->addGroupBy('s.prefix')
            ->setParameter('region', $region)
            ->getQuery()
            ->getArrayResult()
        ;

        return array_map(function($value){ return $value['prefix']; }, $result);
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    public function getPrefixes()
    {
        $builder = $this->createQueryBuilder('s');

        $result = $builder
            ->select('s.prefix')
            ->addGroupBy('s.prefix')
            ->getQuery()
            ->getArrayResult()
        ;

        return array_map(function($value){ return $value['prefix']; }, $result);
    }

    /**
     * @param $region
     * @param $prefixesNot
     * @return array
     * @author Michaël VEROUX
     */
    public function findByRegionAndPrefixNotIn($region, $prefixesNot)
    {
        $builder = $this->createQueryBuilder('s');

        $result = $builder
            ->select('s.prefix')
            ->andWhere('s.region = :region')
            ->andWhere('s.prefix NOT IN (:prefixes)')
            ->setParameter('region', $region)
            ->setParameter('prefixes', $prefixesNot)
            ->getQuery()
        ;

        return $result->getArrayResult();
    }

    /**
     * @param array $ids
     *
     * @return Setting[]
     * @author Michaël VEROUX
     */
    public function getDiffFormIds(array $ids)
    {
        $builder = $this->createQueryBuilder('s');
        $builder->where('s.id NOT IN (:ids)');
        $builder->setParameter('ids', $ids);

        return $builder->getQuery()->execute();
    }

    /**
     * @param array $ids
     *
     * @return mixed
     * @author Michaël VEROUX
     */
    public function delete(array $ids)
    {
        $buider = $this->createQueryBuilder('s');
        $buider->delete()->where('s.id IN (:ids)');
        $buider->setParameter('ids', $ids);

        return $buider->getQuery()->execute();
    }
} 