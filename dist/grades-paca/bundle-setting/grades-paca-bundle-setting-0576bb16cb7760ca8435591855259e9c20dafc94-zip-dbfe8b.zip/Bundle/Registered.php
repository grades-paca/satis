<?php
/**
 * Author: Michaël VEROUX
 * Date: 12/05/14
 * Time: 11:24
 */

namespace Oru\Bundle\SettingBundle\Bundle;

/**
 * Class Registered.
 *
 * @author Michaël VEROUX
 */
class Registered
{
    /**
     * @var array
     */
    protected $bundles = array(
        'app' => array(
            'name' => 'Général',
            'definition' => 'Paramètres du niveau application',
        ),
    );

    /**
     * @param $name
     * @param $internalName
     * @param $definition
     *
     * @author Michaël VEROUX
     */
    public function addBundle($name, $internalName, $definition)
    {
        $this->bundles[$internalName] = array(
            'name' => $name,
            'definition' => $definition,
        );
    }

    /**
     * @param $internalName
     *
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getFriendlyName($internalName)
    {
        if (isset($this->bundles[$internalName]) && isset($this->bundles[$internalName]['name'])) {
            return $this->bundles[$internalName]['name'];
        }
        return sprintf('undefined (%s)', $internalName);
    }

    /**
     * @param $internalName
     *
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getDefinition($internalName)
    {
        if (isset($this->bundles[$internalName]) && isset($this->bundles[$internalName]['definition'])) {
            return $this->bundles[$internalName]['definition'];
        }
        return '';
    }

    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function toArray()
    {
        return array_map(function ($value) { return $value['name']; }, $this->bundles);
    }
}
