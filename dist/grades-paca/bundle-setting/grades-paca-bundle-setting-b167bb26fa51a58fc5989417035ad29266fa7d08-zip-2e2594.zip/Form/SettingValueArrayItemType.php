<?php
/**
 * Author: Michaël VEROUX
 * Date: 28/04/14
 * Time: 11:28
 */

namespace Oru\Bundle\SettingBundle\Form;

use Oru\Bundle\SettingBundle\Entity\SettingArrayItem;
use Oru\Bundle\SettingBundle\Form\DataTransformer\StringToArrayItemTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class SettingValueArrayItemType
 * @package Oru\Bundle\SettingBundle\Form
 * @author Michaël VEROUX
 */
class SettingValueArrayItemType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('key', 'text'
            )
            ->add('value', 'text', array(
                    'required'          =>  false,
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\SettingBundle\Entity\SettingValueArrayItem'
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_setting_value_array_item';
    }
}