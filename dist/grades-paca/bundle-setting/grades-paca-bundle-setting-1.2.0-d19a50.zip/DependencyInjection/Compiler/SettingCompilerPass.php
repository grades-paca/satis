<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 09/01/14
 * Time: 10:07
 */

namespace Oru\Bundle\SettingBundle\DependencyInjection\Compiler;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Reference;

/**
 * Class SettingCompilerPass.
 *
 * @author Michaël VEROUX
 */
class SettingCompilerPass implements CompilerPassInterface
{
    /**
     * You can modify the container here before it is dumped to PHP code.
     *
     * @param ContainerBuilder $container
     *
     * @api
     */
    public function process(ContainerBuilder $container)
    {
        $loaders = array();
        foreach ($container->findTaggedServiceIds('oru.setting.loader') as $id => $attributes) {
            $loaders[$id][] = $attributes[0]['alias'];
        }

        if ($container->hasDefinition('oru.setting.loader')) {
            $definition = $container->getDefinition('oru.setting.loader');
            foreach ($loaders as $id => $formats) {
                foreach ($formats as $format) {
                    $definition->addMethodCall('addLoader', array($format, new Reference($id)));
                }
            }
        }

        if (
            $container->hasDefinition('oru_setting.dynamic_security')
            && $container->hasDefinition('oru_ror_credentials.credentials_checker')
        ) {
            $definition = $container->getDefinition('oru_setting.dynamic_security');
            $definition->addMethodCall('setAlternativContext', array(new Reference('oru_ror_credentials.credentials_checker')));
        }

        $container->findDefinition('oru_setting')->replaceArgument(1, $loaders);
    }
}
