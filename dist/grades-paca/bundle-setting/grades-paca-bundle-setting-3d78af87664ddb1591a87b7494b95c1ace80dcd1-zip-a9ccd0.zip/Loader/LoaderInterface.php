<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 09/01/14
 * Time: 10:32
 */

namespace Oru\Bundle\SettingBundle\Loader;


/**
 * Interface LoaderInterface
 * @package Oru\Bundle\SettingBundle\Loader
 * @author Michaël VEROUX
 */
interface LoaderInterface
{
    /**
     * @param $resource
     * @param string $region
     * @param string $prefix
     * @return \Oru\Bundle\SettingBundle\Setting\SettingCatalogueInterface
     * @author Michaël VEROUX
     */
    public function load($resource, $region, $prefix = 'app');
} 