<?php
/**
 * Author: Michaël VEROUX
 * Date: 23/04/14
 * Time: 10:17
 */

namespace Oru\Bundle\SettingBundle\Controller;

use Oru\Bundle\AlertBundle\Event\Events;
use Oru\Bundle\AlertBundle\Event\SensibleChangeEvent;
use Oru\Bundle\DesignBundle\Controller\FlashControllerTrait;
use Oru\Bundle\SettingBundle\Entity\Setting;
use Oru\Bundle\SettingBundle\Filter\SettingFilter;
use Oru\Bundle\SettingBundle\Form\Filter\SettingFilterType;
use Oru\Bundle\SettingBundle\Form\SettingType;
use Oru\Bundle\SettingBundle\Setting\Setting as SettingService;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * Class SettingController.
 *
 * @author Michaël VEROUX
 */
class SettingController extends Controller
{
    use FlashControllerTrait;

    /**
     * @param Request           $request
     * @param SettingFilterType $form
     *
     * @throws AccessDeniedHttpException
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function indexAction(Request $request, SettingFilterType $form = null)
    {
        if (!$this->get('oru_setting.dynamic_security')->isGranted(SettingService::ROLE_BASIC)) {
            if (!$this->get('oru_setting.dynamic_security')->isGranted(SettingService::ROLE_ACCESS)) {
                throw new AccessDeniedHttpException();
            }
        }

        if (null === $form) {
            $form = $this->createForm(
                SettingFilterType::class,
                new SettingFilter())->submit($request->getSession()->get('oru_setting.filter')
            );
        }

        $em = $this->getDoctrine()->getManager();

        $entities = $em->getRepository('OruSettingBundle:Setting')->findList($form->getData(), $this->get('oru_setting')->getRegion());

        $this->get('oru_setting')->filter($entities);

        $listing = $this->container->get('listing.factory')->create(
            $this->get('oru_setting.listing'),
            $entities->getQuery()->execute()
        );

        return $this->render('@OruSetting/Setting/index.html.twig',
            array(
                'listing' => $listing,
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     *
     * @throws AccessDeniedHttpException
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function filterAction(Request $request)
    {
        if (!$this->get('oru_setting.dynamic_security')->isGranted(SettingService::ROLE_BASIC)) {
            if (!$this->get('oru_setting.dynamic_security')->isGranted(SettingService::ROLE_ACCESS)) {
                throw new AccessDeniedHttpException();
            }
        }

        $form = $this->createForm(SettingFilterType::class)->handleRequest($request);

        if ($form->get('reset')->isClicked()) {
            $request->getSession()->set('oru_setting.filter', array());

            return $this->redirect($this->generateUrl('oru_setting'));
        }

        if ($form->isValid()) {
            $request->getSession()->set('oru_setting.filter', $request->get($form->getName()));

            return $this->redirect($this->generateUrl('oru_setting'));
        }

        return $this->indexAction($request, $form);
    }

    /**
     * @param Setting $entity
     *
     * @throws AccessDeniedHttpException
     *
     * @return Response
     *
     * @author Michaël VEROUX
     */
    public function editAction(Setting $entity)
    {
        if (!$this->get('oru_setting.dynamic_security')->isGranted($entity->getRole(), $entity)) {
            throw new AccessDeniedHttpException();
        }
        $form = $this->container->get('form.factory')->create(
            SettingType::class,
            $entity
        );

        return $this->render('@OruSetting/Setting/edit.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     * @param Setting $entity
     *
     * @throws AccessDeniedHttpException
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
     *
     * @author Michaël VEROUX
     */
    public function updateAction(Request $request, Setting $entity)
    {
        if (!$this->get('oru_setting.dynamic_security')->isGranted($entity->getRole(), $entity)) {
            throw new AccessDeniedHttpException();
        }
        $oldValue = $entity->getValueAsString();
        $form = $this->container->get('form.factory')->create(
            SettingType::class,
            $entity
        );

        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->flush();

            $watchedName = sprintf('%s:%s:%s', $entity->getFriendlyPrefix(), $entity->getRegion(), $entity->getName());
            $event = new SensibleChangeEvent();
            $event->setWatchedElement('Paramètres');
            $event->setBefore($oldValue);
            $event->setAfter($entity->getValueAsString());
            $event->setWatchedName($watchedName);
            $this->get('event_dispatcher')->dispatch(Events::SENSIBLE_CHANGE, $event);

            $cacheState = $this->get('oru_setting.cache_refresh')->now($entity->getRegion());
            if (!$cacheState) {
                $this->addSessionMessage('Une erreur est survenue lors de l\'invalidation du cache.', 'error');
            }

            $this->addSessionMessage('Vos données sont enregistrées.');

            return $this->redirect($this->generateUrl('oru_setting_edit', array('id' => $entity->getId())));
        }

        $this->addSessionMessage('Le formulaire soumis contient des erreurs...', 'warning');

        return $this->render('@OruSetting/Setting/edit.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     *
     * @throws AccessDeniedHttpException
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function newAction(Request $request)
    {
        if (!$this->get('oru_setting.dynamic_security')->isGranted(SettingService::ROLE_ADMIN)) {
            throw new AccessDeniedHttpException();
        }
        $form = $this->container->get('form.factory')->create(
            SettingType::class,
            new Setting(),
            array('fullEditable' => true)
        );

        return $this->render('@OruSetting/Setting/new.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     *
     * @throws AccessDeniedHttpException
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function createAction(Request $request)
    {
        if (!$this->get('oru_setting.dynamic_security')->isGranted(SettingService::ROLE_ADMIN)) {
            throw new AccessDeniedHttpException();
        }
        $setting = new Setting();

        $form = $this->container->get('form.factory')->create(
            SettingType::class,
            $setting,
            array('fullEditable' => true)
        );

        $form->handleRequest($request);

        if ($form->isValid()) {
            $setting->setDefaultValue('');
            $em = $this->getDoctrine()->getManager();
            $em->persist($setting);
            $em->flush();
            $cacheState = $this->get('oru_setting.cache_refresh')->now($setting->getRegion());
            if (!$cacheState) {
                $this->addSessionMessage('Une erreur est survenue lors de l\'invalidation du cache.', 'error');
            }

            $this->addSessionMessage('Vos données sont enregistrées.');

            return $this->redirect($this->generateUrl('oru_setting_edit', array('id' => $setting->getId())));
        }

        $this->addSessionMessage('Le formulaire soumis contient des erreurs...', 'warning');

        return $this->render('@OruSetting/Setting/new.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     * @param Setting $setting
     *
     * @throws InvalidCsrfTokenException
     * @throws AccessDeniedHttpException
     *
     * @return Response
     *
     * @author Michaël VEROUX
     */
    public function deleteAction(Request $request, Setting $setting)
    {
        if (!$this->get('oru_setting.dynamic_security')->isGranted(SettingService::ROLE_DELETE)) {
            throw new AccessDeniedHttpException();
        }
        $em = $this->getDoctrine()->getManager();
        $em->remove($setting);
        $em->flush();
        $cacheState = $this->get('oru_setting.cache_refresh')->now($setting->getRegion());
        if (!$cacheState) {
            $this->addSessionMessage('Une erreur est survenue lors de l\'invalidation du cache.', 'error');
        }

        $this->addSessionMessage('L\'élément à été supprimé.');

        $response = new Response();

        $response->setContent(json_encode(array(
            'redirect' => $this->generateUrl('oru_setting'),
        )));
        $response->headers->set('Content-Type', 'application/json');

        return $response;
    }
}
