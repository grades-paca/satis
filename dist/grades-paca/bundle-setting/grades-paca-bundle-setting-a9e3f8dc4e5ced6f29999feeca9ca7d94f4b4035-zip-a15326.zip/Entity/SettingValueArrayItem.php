<?php
/**
 * Author: Michaël VEROUX
 * Date: 28/04/14
 * Time: 17:17
 */

namespace Oru\Bundle\SettingBundle\Entity;

/**
 * Class SettingValueArrayItem.
 *
 * @author Michaël VEROUX
 */
class SettingValueArrayItem
{
    /**
     * @var null
     */
    protected $key;

    /**
     * @var null
     */
    protected $value;

    /**
     * @param null $key
     * @param null $value
     */
    public function __construct($key = null, $value = null)
    {
        $this->key = $key;
        $this->value = $value;
    }

    /**
     * @return mixed
     *
     * @author Michaël VEROUX
     */
    public function __toString()
    {
        return (string) $this->getValue();
    }

    /**
     * @param $key
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function setKey($key)
    {
        $this->key = $key;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getKey()
    {
        return $this->key;
    }

    /**
     * @param $value
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function toArray()
    {
        return array($this->key => $this->value);
    }
}
