<?php

namespace Oru\Bundle\SettingBundle\Setting;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Criteria;
use Oru\Bundle\SettingBundle\Entity\Setting as SettingEntity;
use Oru\Bundle\SettingBundle\Exception\InvalidResourceException;
use Oru\Bundle\SettingBundle\Exception\NotFoundResourceException;
use Oru\Bundle\SettingBundle\Exception\UnsupportedTypeException;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Yaml\Exception\ParseException;
use Symfony\Component\Yaml\Parser as YamlParser;

/**
 * Class Dumper
 *
 * @package Oru\Bundle\SettingBundle\Setting
 * @author Michaël VEROUX
 */
class Dumper
{
    const RELATIVE_CACHE_DIFF_PATH = 'settings/diff.php';

    /**
     * @var Setting
     */
    protected $setting;

    /**
     * @var YamlParser
     */
    protected $yamlParser;

    /**
     * @var array
     */
    protected $settingIds = array();

    /**
     * @var string
     */
    protected $cacheDir = '';

    /**
     * @var OutputInterface
     */
    protected $output;

    /**
     * @var array
     */
    private $acceptedKeys = array('value', 'description', 'role', 'choices');

    /**
     * Dumper constructor.
     *
     * @param Setting $setting
     */
    public function __construct(Setting $setting, $cacheDir)
    {
        $this->setting = $setting;
        $this->cacheDir = $cacheDir;
    }

    /**
     * @return void
     * @author Michaël VEROUX
     */
    public function dump($output = null)
    {
        $this->output = $output;

        foreach ($this->setting->getResources() as $region => $resources) {
            foreach ($resources as $resource) {
                $file = $resource[1];
                $prefix = $resource[2];

                $param_values = $this->getYamlSettingsAsArray($file);

                $this->persistSettings($param_values, $region, $prefix);
            }
        }

        $this->writeDiffToCache();
    }

    /**
     * @return void
     * @author Michaël VEROUX
     */
    protected function writeDiffToCache()
    {
        $pathCacheFilename = sprintf('%s/%s', $this->cacheDir, static::RELATIVE_CACHE_DIFF_PATH);
        $this->setting->setting('default'); // To initialize cache.
        $settings = $this->setting->getEntityManager()
            ->getRepository('OruSettingBundle:Setting')->getDiffFormIds($this->settingIds);

        file_put_contents($pathCacheFilename, "<?php\nreturn array(\n");
        foreach ($settings as $setting) {
            file_put_contents($pathCacheFilename, sprintf("\t%d\t=> '[%s][%s] %s',\n", $setting->getId(), $setting->getRegion(), $setting->getPrefix(), $setting->getName()), FILE_APPEND);
        }
        file_put_contents($pathCacheFilename, ");\n", FILE_APPEND);
    }

    /**
     * @param $file
     *
     * @return array|bool|float|int|mixed|null|number|string
     * @throws InvalidResourceException
     * @throws NotFoundResourceException
     * @throws UnsupportedTypeException
     * @author Michaël VEROUX
     */
    protected function getYamlSettingsAsArray($file)
    {
        if (!stream_is_local($file)) {
            throw new InvalidResourceException(sprintf('This is not a local file "%s".', $file));
        }

        if (!file_exists($file)) {
            throw new NotFoundResourceException(sprintf('File "%s" not found.', $file));
        }

        if (null === $this->yamlParser) {
            $this->yamlParser = new YamlParser();
        }

        try {
            $param_values = $this->yamlParser->parse(file_get_contents($file));
        } catch (ParseException $e) {
            throw new InvalidResourceException('Error parsing YAML.', 0, $e);
        }

        $diff_types = array_diff(array_keys($param_values), SettingEntity::supportedTypes());
        if ($diff_types) {
            throw new UnsupportedTypeException(
                sprintf('%s type%s %s unsupported!',
                        implode(',', $diff_types),
                        count($diff_types) > 1 ? 's' : '',
                        count($diff_types) > 1 ? 'are' : 'is'
                )
            );
        }

        return $param_values;
    }

    /**
     * @param $param_values
     * @param $region
     * @param $prefix
     *
     * @author Michaël VEROUX
     */
    protected function persistSettings($param_values, $region, $prefix)
    {
        foreach ($param_values as $type => $param_values_type) {
            // empty file
            if (null === $param_values_type) {
                $param_values_type = array();
            }

            if (!empty($param_values_type)) {
                $settings = $this->setting->getEntityManager()->getRepository('OruSettingBundle:Setting')
                    ->createQueryBuilder('s')
                    ->where('s.name IN (:name) AND s.region = :region AND s.prefix = :prefix')
                    ->setParameters(array(
                                        'name'   => array_keys($param_values_type),
                                        'region' => $region,
                                        'prefix' => $prefix,
                                    ))
                    ->getQuery()
                    ->getResult();

                $settingNewCollection = new ArrayCollection();
                foreach ($param_values_type as $key => $param_value) {
                    $this->integrityControl($param_value);

                    if (count($settings)) {
                        if (!$settings instanceof ArrayCollection) {
                            $settings = new ArrayCollection($settings);
                        }

                        $setting = $settings->matching(
                            Criteria::create()->where(
                                Criteria::expr()->andX(
                                    Criteria::expr()->contains('name', $key),
                                    Criteria::expr()->contains('prefix', $prefix),
                                    Criteria::expr()->contains('region', $region)
                                )
                            )
                        )->first();
                    } else {
                        $setting = null;
                    }

                    if (!$setting instanceof SettingEntity) {
                        $setting = new SettingEntity();
                        $setting
                            ->setName($key)
                            ->setPrefix($prefix)
                            ->setRegion($region)
                            ->setType($type);
                        $this->setting->getEntityManager()->persist($setting);
                        $settingNewCollection->add($setting);
                    } else {
                        $this->settingIds[] = $setting->getId();
                    }

                    if (is_array($param_value['value'])) {
                        $setting->setDefaultValue(serialize($param_value['value']));
                    } else {
                        $setting->setDefaultValue($param_value['value']);
                    }

                    if (isset($param_value['description'])) {
                        $setting->setDescription($param_value['description']);
                    }

                    if (isset($param_value['role'])) {
                        $setting->setRole($param_value['role']);
                    }

                    if (isset($param_value['choices']) && $setting->getType() === 'choice') {
                        $setting->setChoices($param_value['choices']);
                    }elseif(isset($param_value['choices'])){
                        $this->output->writeln(sprintf("<error>Paramètre %s : L'option 'choices' ne peut être définie que pour le type 'choice'</error>", $setting->getName()));
                    }

                    if ($setting->getType() !== $type && $setting->getValue() != $setting->getDefaultValue()) {
                        $currentValue = $setting->getValue();
                        $setting->setType($type);
                        if ($setting->getValue() != $currentValue) {
                            $executionContext = $this->setting->getExecutionContext($setting);
                            $setting->isValid($executionContext, $currentValue);

                            if ($executionContext->getViolations()->count()) {
                                if ($this->output instanceof OutputInterface) {
                                    $this->output->writeln(sprintf('<error>La valeur surchargée du paramètre "%s" ne supporte pas le nouveau type "%s"</error>', $setting->getName(), $setting->getType()));
                                }
                            }
                        }
                    }
                }
                $this->setting->getEntityManager()->flush();
                $newIds = $settingNewCollection->map(function (SettingEntity $setting) {
                    return $setting->getId();
                })->toArray();
                $this->settingIds = array_merge($this->settingIds, $newIds);
            }
        }
    }

    /**
     * @param $array
     *
     * @return bool
     * @throws \Oru\Bundle\SettingBundle\Exception\InvalidResourceException
     * @author Michaël VEROUX
     */
    private function integrityControl($array)
    {
        $unknownKeys = array_diff(array_keys($array), $this->acceptedKeys);
        if (count($unknownKeys)) {
            $pluralThis = count($unknownKeys) > 1 ? 'These' : 'This';
            $pluralKey = count($unknownKeys) > 1 ? 's' : '';
            $pluralIs = count($unknownKeys) > 1 ? 'are' : 'is';
            throw new InvalidResourceException(
                sprintf('%s key%s %s unknown : %s',
                        $pluralThis,
                        $pluralKey,
                        $pluralIs,
                        implode(', ', $unknownKeys)
                )
            );
        }

        if (!isset($array['value'])) {
            throw new InvalidResourceException('Key "value" is mandatory!');
        }

        return true;
    }
}
