<?php
/**
 * Author: Michaël VEROUX
 * Date: 12/05/14
 * Time: 10:46
 */

namespace Oru\Bundle\SettingBundle\Bundle;

/**
 * Interface OruBundleInterface
 * @package Oru\Bundle\SettingBundle\Bundle
 * @author Michaël VEROUX
 */
interface OruBundleInterface
{
    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getFriendlyName();

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getDescription();
} 