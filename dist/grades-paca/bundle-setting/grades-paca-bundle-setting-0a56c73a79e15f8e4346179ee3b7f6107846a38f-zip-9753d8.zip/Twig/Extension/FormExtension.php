<?php
/**
 * Author: Michaël VEROUX
 * Date: 30/04/14
 * Time: 14:39
 */

namespace Oru\Bundle\SettingBundle\Twig\Extension;

class FormExtension extends \Twig_Extension
{

    /**
     * {@inheritdoc}
     */
    public function getFunctions()
    {
        return array(
            new \Twig_SimpleFunction('value_row', array('Symfony\Bridge\Twig\Node\SearchAndRenderBlockNode'), array('is_safe' => array('html'))),
        );
    }

    /**
     * Returns the name of the extension.
     *
     * @return string The extension name
     */
    public function getName()
    {
        return 'oru_setting.twig.extension.form';
    }
}