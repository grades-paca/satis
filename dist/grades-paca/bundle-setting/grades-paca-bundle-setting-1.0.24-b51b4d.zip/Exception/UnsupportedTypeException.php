<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 10/01/14
 * Time: 16:31
 */

namespace Oru\Bundle\SettingBundle\Exception;

/**
 * Class UnsupportedTypeException
 * @package Oru\Bundle\SettingBundle\Exception
 * @author Michaël VEROUX
 */
class UnsupportedTypeException extends \InvalidArgumentException
{

} 