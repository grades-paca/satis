<?php
/**
 * Author: Michaël VEROUX
 * Date: 30/04/14
 * Time: 11:50
 */

namespace Oru\Bundle\SettingBundle\Form\Subscriber;

use Oru\Bundle\SettingBundle\Entity\SettingValueArrayItem;
use Oru\Bundle\SettingBundle\Form\DataTransformer\ImageTransformer;
use Oru\Bundle\SettingBundle\Form\DataTransformer\SettingValueArrayFormTransformer;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormFactoryInterface;

/**
 * Class SettingValueTypeSubscriber
 * @package Oru\Bundle\SettingBundle\Form\Subscriber
 * @author Michaël VEROUX
 */
class SettingValueTypeSubscriber implements EventSubscriberInterface
{
    /**
     * @var null|\Symfony\Component\Form\FormFactoryInterface
     */
    protected $formFactory = null;


    /**
     * @param FormFactoryInterface $formFactory
     */
    public function __construct(FormFactoryInterface $formFactory)
    {
        $this->formFactory = $formFactory;
    }

    /**
     * Returns an array of event names this subscriber wants to listen to.
     *
     * The array keys are event names and the value can be:
     *
     *  * The method name to call (priority defaults to 0)
     *  * An array composed of the method name to call and the priority
     *  * An array of arrays composed of the method names to call and respective
     *    priorities, or 0 if unset
     *
     * For instance:
     *
     *  * array('eventName' => 'methodName')
     *  * array('eventName' => array('methodName', $priority))
     *  * array('eventName' => array(array('methodName1', $priority), array('methodName2'))
     *
     * @return array The event names to listen to
     *
     * @api
     */
    public static function getSubscribedEvents()
    {
        return [FormEvents::PRE_SET_DATA => ['preSetData', -255] ];
    }

    /**
     * @param FormEvent $event
     * @author Michaël VEROUX
     */
    public function preSetData(FormEvent $event)
    {
        $form = $event->getForm();
        $data = $event->getData();

        if('array' === $data->getType())
        {
            $dataValue = (array)$data->getValue();
            $dataValue = !count($dataValue) ? array('') : $dataValue;
            $form->add(
                $this->formFactory->createNamedBuilder('value', 'collection', $dataValue, array(
                        'auto_initialize'   =>  false,
                        'type'              =>  'oru_setting_value_array_item',
                        'allow_add'         => true,
                        'allow_delete'      => true,
                        'by_reference'      => false,
                        'position'          =>  array('after' => 'description'),
                    )
                )
                ->addModelTransformer(new SettingValueArrayFormTransformer())
                ->addEventListener(FormEvents::PRE_SET_DATA, function(FormEvent $event) {
                    $form = $event->getForm();
                    $data = $event->getData();

                    $result = array();
                    if ($data) {
                        foreach ($data as $key => $value) {
                            if(! $value instanceof SettingValueArrayItem)
                                $value = new SettingValueArrayItem($key, $value);

                            $result[] = $value;
                        }
                    }

                    $event->setData($result);
                }, 1)
                ->getForm()
            );
        }elseif('choice' === $data->getType()){
            $dataValue = $data->getValue();
            $dataChoice = (array) $data->getChoices();
            $form->add('value', 'choice',array(
                'choices'   => $dataChoice,
                'data'      => $dataValue,
                'position'  =>  array('after' => 'description'),
            ));
            $form->remove('type');
            $form->add('type', 'oru_static', array(
                    'disabled'  => true,
                    'position'  =>  array('after' => 'region'),
                )
            );
        }
        elseif('boolean' === $data->getType())
        {
            $form->add(
                $this->formFactory->createNamed('value', 'oru_oui_non', $data->getValue(), array(
                        'expanded'          =>  false,
                        'auto_initialize'   =>  false,
                        'position'          =>  array('after' => 'description'),
                        'required'          =>  false,
                    )
                )
            );
        }
        elseif('text' === $data->getType()){
            $form->add(
                $this->formFactory->createNamed('value', 'textarea', $data->getValue(), array(
                        'auto_initialize'   =>  false,
                        'position'          =>  array('after' => 'description'),
                        'required'          =>  false,
                    )
                )
            );
        }
        elseif('html' === $data->getType()){
            $form->add(
                $this->formFactory->createNamed('value', 'ckeditor', $data->getValue(), array(
                        'auto_initialize'   =>  false,
                        'position'          =>  array('after' => 'description'),
                        'required'          =>  false,
                    )
                )
            );
        }
        elseif('image' === $data->getType()){
            $form->add(
                $this->formFactory->createNamedBuilder('value', 'file', null, array(
                        'auto_initialize'   =>  false,
                        'position'          =>  array('after' => 'description'),
                        'required'          =>  false,
                    )
                )
                ->addModelTransformer(new ImageTransformer())
                ->getForm()
            );
        }
        else
        {
            $form->add(
                $this->formFactory->createNamed('value', 'text', $data->getValue(), array(
                        'auto_initialize'   =>  false,
                        'position'          =>  array('after' => 'description'),
                        'required'          =>  false,
                    )
                )
            );
        }
    }
}