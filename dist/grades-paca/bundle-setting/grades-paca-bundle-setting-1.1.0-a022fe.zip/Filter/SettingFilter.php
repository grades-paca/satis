<?php
/**
 * Author: Michaël VEROUX
 * Date: 23/04/14
 * Time: 10:19
 */

namespace Oru\Bundle\SettingBundle\Filter;

/**
 * Class SettingFilter
 * @package Oru\Bundle\SettingBundle\Filter
 * @author Michaël VEROUX
 */
class SettingFilter
{
    /**
     * @var string
     */
    private $prefix;

    /**
     * @var string
     */
    private $region;

    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $value;

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $prefix
     */
    public function setPrefix($prefix)
    {
        $this->prefix = $prefix;
    }

    /**
     * @return string
     */
    public function getPrefix()
    {
        return $this->prefix;
    }

    /**
     * @param string $region
     */
    public function setRegion($region)
    {
        $this->region = $region;
    }

    /**
     * @return string
     */
    public function getRegion()
    {
        return $this->region;
    }

    /**
     * @return string
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @param string $value
     *
     * @return $this
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }
} 