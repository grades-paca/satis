<?php
/**
 * Author: Michaël VEROUX
 * Date: 23/04/14
 * Time: 13:37
 */

namespace Oru\Bundle\SettingBundle\Voter;

use Oru\Bundle\SettingBundle\Entity\Setting;
use Psr\Log\LoggerInterface;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Authorization\Voter\VoterInterface;

/**
 * Class DeleteVoter.
 *
 * @author Michaël VEROUX
 */
class DeleteVoter implements VoterInterface
{
    /** @var LoggerInterface */
    protected $logger;

    /**
     * @param LoggerInterface $logger
     */
    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    /**
     * Checks if the voter supports the given attribute.
     *
     * @param string $attribute An attribute
     *
     * @return bool true if this Voter supports the attribute, false otherwise
     */
    public function supportsAttribute($attribute)
    {
        if (\Oru\Bundle\SettingBundle\Setting\Setting::ROLE_DELETE !== $attribute) {
            return true;
        }
        return false;
    }

    /**
     * Checks if the voter supports the given class.
     *
     * @param string $class A class name
     *
     * @return bool true if this Voter can process the class
     */
    public function supportsClass($class)
    {
        return true;
    }

    /**
     * Returns the vote for the given parameters.
     *
     * This method must return one of the following constants:
     * ACCESS_GRANTED, ACCESS_DENIED, or ACCESS_ABSTAIN.
     *
     * @param TokenInterface $token      A TokenInterface instance
     * @param object         $object     The object to secure
     * @param array          $attributes An array of attributes associated with the method being invoked
     *
     * @return int either ACCESS_GRANTED, ACCESS_ABSTAIN, or ACCESS_DENIED
     */
    public function vote(TokenInterface $token, $object, array $attributes)
    {
        if (!in_array(\Oru\Bundle\SettingBundle\Setting\Setting::ROLE_DELETE, $attributes, true)) {
            return VoterInterface::ACCESS_ABSTAIN;
        }
        if ($object instanceof Setting) {
            if ($object->getDefaultValue() !== '' && !('array' === $object->getType() && array('') === $object->getDefaultValue())) {
                $this->logger->warning(sprintf('Access denied by %s line %s', __CLASS__, __LINE__));

                return VoterInterface::ACCESS_DENIED;
            }
        }

        return VoterInterface::ACCESS_ABSTAIN;
    }
}
