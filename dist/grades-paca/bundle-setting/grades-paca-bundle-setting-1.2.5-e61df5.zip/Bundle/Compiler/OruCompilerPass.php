<?php
/**
 * Author: Michaël VEROUX
 * Date: 12/05/14
 * Time: 11:14
 */

namespace Oru\Bundle\SettingBundle\Bundle\Compiler;

use Oru\Bundle\SettingBundle\Bundle\OruBundleInterface;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

/**
 * Class OruCompilerPass.
 *
 * @author Michaël VEROUX
 */
class OruCompilerPass implements CompilerPassInterface
{
    /**
     * @var \Oru\Bundle\SettingBundle\Bundle\OruBundleInterface
     */
    protected $bundle;

    /**
     * @param OruBundleInterface $bundle
     */
    public function __construct(OruBundleInterface $bundle)
    {
        $this->bundle = $bundle;
    }

    /**
     * You can modify the container here before it is dumped to PHP code.
     *
     * @param ContainerBuilder $container
     *
     * @api
     */
    public function process(ContainerBuilder $container)
    {
        if ($container->hasDefinition('oru_setting.registered_bundles')) {
            $definition = $container->getDefinition('oru_setting.registered_bundles');
            $name = call_user_func(array($this->bundle, 'getFriendlyName'));
            $description = call_user_func(array($this->bundle, 'getDescription'));
            $definition->addMethodCall('addBundle', array($name, $this->bundle->getName(), $description));
        }

        $resources = $container->getParameter('security.role_hierarchy.roles');
        foreach ($resources as $key => $resource) {
            if ('ROLE_ADMIN' === $key) {
                $resources[$key][] = Setting::ROLE_BASIC;
            } elseif ('ROLE_SUPER_ADMIN' === $key) {
                $resources[$key][] = Setting::ROLE_ADMIN;
            }
        }
        $resources[Setting::ROLE_ADMIN] = array(Setting::ROLE_BASIC, Setting::ROLE_DELETE);

        $container->setParameter('security.role_hierarchy.roles', $resources);
    }
}
