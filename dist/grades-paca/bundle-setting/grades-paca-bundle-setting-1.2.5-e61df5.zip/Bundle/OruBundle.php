<?php
/**
 * Author: Michaël VEROUX
 * Date: 12/05/14
 * Time: 11:04
 */

namespace Oru\Bundle\SettingBundle\Bundle;

use Oru\Bundle\SettingBundle\Bundle\Compiler\OruCompilerPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class OruBundle.
 *
 * @author Michaël VEROUX
 */
abstract class OruBundle extends Bundle implements OruBundleInterface
{
    /**
     * @param ContainerBuilder $container
     */
    public function build(ContainerBuilder $container)
    {
        parent::build($container);

        $container->addCompilerPass(new OruCompilerPass($this));
    }
}
