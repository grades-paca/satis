<?php
/**
 * Author: Michaël VEROUX
 * Date: 08/02/16
 * Time: 10:52
 */

namespace Oru\Bundle\SettingBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Question\ConfirmationQuestion;
use Symfony\Component\Console\Question\Question;
use Symfony\Component\Filesystem\Filesystem;

/**
 * Class SettingPurgeCommand.
 *
 * @author Michaël VEROUX
 */
class SettingPurgeCommand extends ContainerAwareCommand
{
    /**
     * @author Michaël VEROUX
     */
    protected function configure()
    {
        $this
            ->setName('oru:setting:purge')
            ->setDescription('Purge settings from database')
        ;
    }

    /**
     * Executes the current command.
     *
     * This method is not abstract because you can use this class
     * as a concrete class. In this case, instead of defining the
     * execute() method, you set the code to execute by passing
     * a Closure to the setCode() method.
     *
     * @param InputInterface  $input  An InputInterface instance
     * @param OutputInterface $output An OutputInterface instance
     *
     * @throws \LogicException When this abstract method is not implemented
     *
     * @return null|int null or 0 if everything went fine, or an error code
     *
     * @see setCode()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln('<info>Dump settings...</info>');
        $command = $this->getApplication()->find('oru:setting:dump');

        $arguments = array(
            'command' => 'oru:setting:dump',
        );

        $inputSub = new ArrayInput($arguments);
        $returnCode = $command->run($inputSub, $output);
        $output->writeln('Done.');

        $output->writeln('<info>Purge settings...</info>');
        $cacheFilename = sprintf('%s/settings/diff.php', $this->getContainer()->getParameter('kernel.cache_dir'));
        $filesystem = new Filesystem();
        if (!$filesystem->exists($cacheFilename)) {
            $output->writeln('Nothing to do!');

            return;
        }
        $diff = include $cacheFilename;
        if (!count($diff)) {
            $output->writeln('Nothing to do!');

            return;
        }

        $output->writeln(implode(PHP_EOL, $diff));
        $output->writeln('These settings was found to purge.');
        $dialog = $this->getHelper('question');
        $question = new Question(sprintf('<question>Do you want to purge All[A]? Confirm individual[I]? Or discard purge[N]? [a/i/N]</question> ', 'N'));
        $answer = $dialog->ask(
            $input,
            $output,
            $question
        );
        if ('N' === strtoupper($answer)) {
            return;
        }
        $settingRepos = $this->getContainer()->get('doctrine.orm.default_entity_manager')->getRepository('OruSettingBundle:Setting');
        if ('A' === strtoupper($answer)) {
            $settingRepos->delete(array_keys($diff));
            $output->writeln('<info>Settings deleted.</info>');

            return;
        }
        if ('I' === strtoupper($answer)) {
            foreach ($diff as $id => $name) {
                $question = new ConfirmationQuestion(sprintf('<question>delete %s ? [y/N]</question> ', $name), false);
                if ($dialog->ask($input, $output, $question)) {
                    $settingRepos->delete(array($id));
                }
            }

            return;
        }

        $output->writeln('<error>Unknown answer, abort!</error>');
    }
}
