<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 10/01/14
 * Time: 15:01
 */

namespace Oru\Bundle\SettingBundle\Tests;

use Oru\Bundle\TestBundle\Tests\ModelTestCase;

class TestCase extends ModelTestCase
{
}
