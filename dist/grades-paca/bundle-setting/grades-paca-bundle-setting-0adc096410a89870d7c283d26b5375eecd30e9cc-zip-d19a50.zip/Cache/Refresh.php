<?php
/**
 * Author: Michaël VEROUX
 * Date: 07/04/14
 * Time: 15:48
 */

namespace Oru\Bundle\SettingBundle\Cache;

use Doctrine\Common\Persistence\ObjectManager;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Psr\Log\LoggerInterface;
use Symfony\Component\Filesystem\Exception\IOException;
use Symfony\Component\Filesystem\Filesystem;

/**
 * Class Refresh.
 *
 * @author Michaël VEROUX
 */
class Refresh
{
    /**
     * @var Filesystem
     */
    protected $filesystem;

    /**
     * @var ObjectManager
     */
    protected $em;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var string
     */
    protected $cacheDir;

    /**
     * @var string
     */
    protected $currentRegion = Setting::REGION_DEFAULT;

    /**
     * @param Filesystem $filesystem
     * @param $cacheDir
     */
    public function __construct(Filesystem $filesystem, ObjectManager $em, LoggerInterface $logger, $cacheDir)
    {
        $this->filesystem = $filesystem;
        $this->em = $em;
        $this->logger = $logger;
        $this->cacheDir = $cacheDir;
    }

    /**
     * @param string $region
     *
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function now($region = Setting::REGION_DEFAULT)
    {
        $fileMeta = array();
        $cachePathFilePattern = $this->cacheDir.'/catalogue.%s.php';

        if (Setting::REGION_DEFAULT === $region) {
            $regions = $this->em->getRepository('OruSettingBundle:Setting')->getRegions();
            if (false === in_array($this->getCurrentRegion(), $regions, true)) {
                $regions[] = $this->getCurrentRegion();
            }

            foreach ($regions as $regionBdd) {
                $fileMeta[] = sprintf($cachePathFilePattern, $regionBdd);
            }
        } else {
            $fileMeta[] = sprintf($cachePathFilePattern, $region);
        }

        try {
            $this->filesystem->remove($fileMeta);
        } catch (IOException $e) {
            $this->logger->error($e->getMessage());

            return false;
        }

        return true;
    }

    /**
     * @param string $currentRegion
     */
    public function setCurrentRegion($currentRegion)
    {
        $this->currentRegion = strtolower($currentRegion);
    }

    /**
     * @return string
     */
    public function getCurrentRegion()
    {
        return $this->currentRegion;
    }
}
