<?php
/**
 * Author: Michaël VEROUX
 * Date: 23/04/14
 * Time: 10:58
 */

namespace Oru\Bundle\SettingBundle\Form;

use Oru\Bundle\FormBundle\Form\Type\StaticType;
use Oru\Bundle\SettingBundle\Entity\Setting;
use Oru\Bundle\SettingBundle\Form\Subscriber\SettingValueTypeSubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class SettingType.
 *
 * @author Michaël VEROUX
 */
class SettingType extends AbstractType
{
    protected $settingValueTypeSubscriber;

    protected $fullEditable = false;

    public function __construct(SettingValueTypeSubscriber $settingValueTypeSubscriber)
    {
        $this->settingValueTypeSubscriber = $settingValueTypeSubscriber;
    }

    /**
     * @param bool $fullEditable
     */
    public function setFullEditable($fullEditable)
    {
        $this->fullEditable = $fullEditable;

        return $this;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        if ($this->fullEditable) {
            $builder
                ->add('name'
                )
            ;
        } else {
            $builder
                ->add('name', StaticType::class, array(
                        'disabled' => true,
                    )
                )
            ;
        }

        $builder
            ->add('description'
            )
        ;

        if ($this->fullEditable) {
            $builder
                ->add('prefix'
                )
                ->add('region'
                )
            ;
        } else {
            $builder
                ->add('prefix', StaticType::class, array(
                        'disabled' => true,
                    )
                )
                ->add('region', StaticType::class, array(
                        'disabled' => true,
                    )
                )
            ;
        }

        $builder
            ->add('type', ChoiceType::class, array(
                    'choices' => array_combine(Setting::supportedTypes(), Setting::supportedTypes()),
                )
            )
            ->add('save', SubmitType::class, array(
                    'label' => 'save',
                    'translation_domain' => 'messages',
                    'attr' => array(
                        'class' => 'btn btn-primary',
                    ),
                )
            )
        ;

        $builder->addEventSubscriber($this->settingValueTypeSubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\SettingBundle\Entity\Setting',
            'translation_domain' => 'OruSettingBundle',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_setting';
    }
}
