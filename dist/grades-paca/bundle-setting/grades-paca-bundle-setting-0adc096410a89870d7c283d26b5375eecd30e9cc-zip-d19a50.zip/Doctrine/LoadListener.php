<?php
/**
 * Author: Michaël VEROUX
 * Date: 12/05/14
 * Time: 11:58
 */

namespace Oru\Bundle\SettingBundle\Doctrine;

use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\LifecycleEventArgs;
use Oru\Bundle\SettingBundle\Bundle\Registered;
use Oru\Bundle\SettingBundle\Entity\Setting;

/**
 * Class LoadListener.
 *
 * @author Michaël VEROUX
 */
class LoadListener implements EventSubscriber
{
    /**
     * @var null|\Oru\Bundle\SettingBundle\Bundle\Registered
     */
    protected $registeredBundles = null;

    /**
     * @param Registered $registeredBundles
     */
    public function __construct(Registered $registeredBundles)
    {
        $this->registeredBundles = $registeredBundles;
    }

    /**
     * Returns an array of events this subscriber wants to listen to.
     *
     * @return array
     */
    public function getSubscribedEvents()
    {
        return array(
            'postLoad',
        );
    }

    /**
     * @param LifecycleEventArgs $args
     *
     * @author Michaël VEROUX
     */
    public function postLoad(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();

        if ($entity instanceof Setting) {
            $entity->setFriendlyPrefix($this->registeredBundles->getFriendlyName($entity->getPrefix()));
        }
    }
}
