<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 10/01/14
 * Time: 15:02
 */

namespace Oru\Bundle\SettingBundle\Tests;


class OruSettingBundleTest// extends TestCase
{

} 