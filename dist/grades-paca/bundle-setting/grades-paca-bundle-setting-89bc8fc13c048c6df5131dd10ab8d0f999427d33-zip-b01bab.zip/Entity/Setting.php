<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 09/01/14
 * Time: 11:21
 */

namespace Oru\Bundle\SettingBundle\Entity;


use Oru\Bundle\SettingBundle\Exception\UnsupportedTypeException;
use Oru\Bundle\SettingBundle\Type\Image;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Validator\Constraints\DateTime;
use Symfony\Component\Validator\Constraints\File;
use Symfony\Component\Validator\Constraints\Type;
use Symfony\Component\Validator\ConstraintViolation;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

/**
 * Class Setting
 * @package Oru\Bundle\SettingBundle\Entity
 * @author Michaël VEROUX
 */
class Setting
{

    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $prefix;

    /**
     * @var string
     */
    private $region;

    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $value;

    /**
     * @var string
     */
    private $defaultValue;

    /**
     * @var string
     */
    private $type;

    /**
     * @var string
     */
    private $description;

    /**
     * @var string
     */
    private $friendlyPrefix;

    /**
     * @var string
     */
    private $role = \Oru\Bundle\SettingBundle\Setting\Setting::ROLE_BASIC;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set prefix
     *
     * @param string $prefix
     * @return Setting
     */
    public function setPrefix($prefix)
    {
        $this->prefix = $prefix;
    
        return $this;
    }

    /**
     * Get prefix
     *
     * @return string 
     */
    public function getPrefix()
    {
        return $this->prefix;
    }

    /**
     * Set region
     *
     * @param string $region
     * @return Setting
     */
    public function setRegion($region)
    {
        $this->region = $region;
    
        return $this;
    }

    /**
     * Get region
     *
     * @return string 
     */
    public function getRegion()
    {
        return $this->region;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Setting
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param $value
     * @return bool|float|int|mixed
     * @author Michaël VEROUX
     */
    protected function getExpectedTypeValue($value)
    {
        switch($this->type)
        {
            case 'integer':
                return (int)$value;
            case 'boolean':
                return (boolean)$value;
            case 'float':
                return (float)$value;
            case 'array':
                return (array)$value;
            case 'datetime':
                return $value;
            case 'text':
                return $value;
            case 'image':
                if ($value instanceof UploadedFile) {
                    $imageObject = Image::createFromUploadedFile($value);

                    return $imageObject;
                }
                if ($value instanceof Image) {
                    return $value;
                }

                return null;
            default:
                if(is_array($value))
                    return reset($value);

                return (string)$value;
        }
    }

    /**
     * Set value
     *
     * @param string $value
     * @return Setting
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * Get value
     *
     * @return mixed
     */
    public function getValue()
    {
        return $this->getExpectedTypeValue($this->value);
    }

    public function getValueAsString()
    {
        if (is_array($this->value)) {
            if (count(array_filter(array_keys($this->value), 'is_string'))) {
                return substr(var_export($this->value, true), 5);
            } else {
                return implode(', ', $this->value);
            }
        }

        if ('boolean' === $this->type) {
            return $this->value ? 'Oui' : 'Non';
        }

        if ($this->value instanceof \Oru\Bundle\SettingBundle\Setting\DateTime) {
            return $this->value->format('d/m/Y H:i:s');
        }

        if ($this->value instanceof Image) {
            return sprintf('Image "%s" de type %s', $this->value->getName(), $this->value->getMimeType());
        }

        if (is_string($this->value)) {
            return $this->value;
        }

        return var_export($this->value, true);
    }

    /**
     * Set defaultValue
     *
     * @param string $defaultValue
     * @return Setting
     */
    public function setDefaultValue($defaultValue)
    {
        if(null === $this->value || $this->value === $this->defaultValue)
            $this->value = $defaultValue;

        $this->defaultValue = $defaultValue;

        return $this;
    }

    /**
     * Get defaultValue
     *
     * @return string
     */
    public function getDefaultValue()
    {
        return $this->getExpectedTypeValue($this->defaultValue);
    }

    /**
     * @param string $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param string $role
     */
    public function setRole($role)
    {
        if(null !== $role)
            $this->role = $role;
    }

    /**
     * @return string
     */
    public function getRole()
    {
        if(!$this->role)
            return \Oru\Bundle\SettingBundle\Setting\Setting::ROLE_ADMIN;

        return $this->role;
    }

    /**
     * @param string $friendlyPrefix
     */
    public function setFriendlyPrefix($friendlyPrefix)
    {
        $this->friendlyPrefix = $friendlyPrefix;
    }

    /**
     * @return string
     */
    public function getFriendlyPrefix()
    {
        return $this->friendlyPrefix;
    }

    /**
     * @param $type
     * @return $this
     * @throws \Oru\Bundle\SettingBundle\Exception\UnsupportedTypeException
     * @author Michaël VEROUX
     */
    public function setType($type)
    {
        $type = strtolower($type);

        if(!in_array($type, self::supportedTypes()))
            throw new UnsupportedTypeException('%s type is not yet supported!',$type);

        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    public function isValid(ExecutionContextInterface $context, $value = null)
    {
        if (null === $value) {
            $value = $this->getValue();
        }

        if(null !== $this->getValue())
        {
            switch($this->getType())
            {
                case 'datetime':
                    $violations = $context->getValidator()->validate(
                        $value,
                        array(new DateTime())
                    );
                break;
                case 'image':
                    if (null !== $value) {
                        if (!$value instanceof Image) {
                            $context->buildViolation('Image invalide !')
                                ->atPath('value')
                                ->setInvalidValue($value)
                                ->addViolation();
                        }
                    }
                break;
                case 'text':
                    $violations = $context->getValidator()->validate(
                        $value,
                        array(
                            new Type(array(
                                    'type' => 'string',
                                )
                            )
                        ));
                    break;
                case 'html':
                    $violations = $context->getValidator()->validate(
                        $value,
                        array(
                            new Type(array(
                                    'type' => 'string',
                                )
                            )
                        ));
                    break;
                default:
                    $violations = $context->getValidator()->validate(
                        $value,
                        array(
                            new Type(array(
                                    'type' => $this->getType(),
                                )
                            )
                        ));
            }
            if (isset($violations) && $violations->count()) {
                $violation = $violations->get(0);
                $message = (string)$violations;
                $context->setConstraint($violation->getConstraint());
                $context
                    ->buildViolation($message)
                    ->atPath('value')
                    ->setInvalidValue($value)
                    ->addViolation();
            }
        }
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    public static function supportedTypes()
    {
        return array(
            'string',
            'integer',
            'float',
            'boolean',
            'array',
            'datetime',
            'text',
            'html',
            'image',
        );
    }
}