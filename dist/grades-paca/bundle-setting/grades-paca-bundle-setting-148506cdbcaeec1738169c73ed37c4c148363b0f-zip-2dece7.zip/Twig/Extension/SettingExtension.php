<?php
/**
 * Author: Michaël VEROUX
 * Date: 18/06/14
 * Time: 13:49
 */

namespace Oru\Bundle\SettingBundle\Twig\Extension;

use Oru\Bundle\SettingBundle\Setting\Setting;

class SettingExtension extends \Twig_Extension
{
    /**
     * @var Setting
     */
    protected $setting = null;

    public function __construct(Setting $setting)
    {
        $this->setting = $setting;
    }

    /**
     * {@inheritdoc}
     */
    public function getFunctions()
    {
        return array(
            'setting' => new \Twig_Function_Method($this, 'renderSetting', array('is_safe' => array('html'))),
        );
    }

    public function renderSetting($id, $prefix = 'app', $region = null)
    {
        return $this->setting->setting($id, $prefix, $region);
    }

    public function getName()
    {
        return 'oru_setting.twig.extension.setting';
    }
}