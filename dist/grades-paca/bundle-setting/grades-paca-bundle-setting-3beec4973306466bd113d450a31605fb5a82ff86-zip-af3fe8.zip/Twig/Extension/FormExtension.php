<?php
/**
 * Author: Michaël VEROUX
 * Date: 30/04/14
 * Time: 14:39
 */

namespace Oru\Bundle\SettingBundle\Twig\Extension;

use Symfony\Component\Form\FormRendererInterface;
use Symfony\Component\Form\FormView;

class FormExtension extends \Twig_Extension
{
    /**
     * This property is public so that it can be accessed directly from compiled
     * templates without having to call a getter, which slightly decreases performance.
     *
     * @var \Symfony\Component\Form\FormRendererInterface
     */
    public $renderer;

    public function __construct(FormRendererInterface $renderer)
    {
        $this->renderer = $renderer;
    }

    /**
     * {@inheritdoc}
     */
    public function getFunctions()
    {
        return array(
            new \Twig_SimpleFunction('value_row', array($this, 'renderValue'), array('is_safe' => array('html'))),
        );
    }

    /**
     * Render form field value.
     *
     * @param FormView $view
     *
     * @return string
     */
    public function renderValue(FormView $view)
    {
        return $this->renderer->searchAndRenderBlock($view, 'row');
    }

    /**
     * Returns the name of the extension.
     *
     * @return string The extension name
     */
    public function getName()
    {
        return 'oru_setting.twig.extension.form';
    }
}
