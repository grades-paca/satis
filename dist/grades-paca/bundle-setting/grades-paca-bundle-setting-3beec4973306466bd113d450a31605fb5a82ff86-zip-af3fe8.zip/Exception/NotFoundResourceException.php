<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 13/01/14
 * Time: 14:03
 */

namespace Oru\Bundle\SettingBundle\Exception;

/**
 * Class NotFoundResourceException.
 *
 * @author Michaël VEROUX
 */
class NotFoundResourceException extends \InvalidArgumentException
{
}
