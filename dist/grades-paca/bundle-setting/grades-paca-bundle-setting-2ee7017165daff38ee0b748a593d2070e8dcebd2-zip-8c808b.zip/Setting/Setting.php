<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 09/01/14
 * Time: 11:44
 */

namespace Oru\Bundle\SettingBundle\Setting;


use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Criteria;
use Doctrine\ORM\QueryBuilder;
use Oru\Bundle\SettingBundle\Loader\LoaderInterface;
use Symfony\Component\Config\ConfigCache;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Validator\Context\ExecutionContextFactory;
use Symfony\Component\Yaml\Dumper as YamlDumper;

/**
 * Class Setting
 * @package Oru\Bundle\SettingBundle\Setting
 * @author Michaël VEROUX
 */
class Setting
{
    const ROLE_ACCESS = 'ROLE_SETTING';

    const ROLE_BASIC = 'ROLE_SETTING_BASIC';

    const ROLE_ADMIN = 'ROLE_SETTING_ADMIN';

    const ROLE_DELETE = 'ROLE_SETTING_DELETE';

    const REGION_DEFAULT = 'generic';

    /**
     * @var \Symfony\Component\DependencyInjection\ContainerInterface
     */
    private $container;
    /**
     * @var array
     */
    private $options;
    /**
     * @var array
     */
    private $loaderIds;
    /**
     * @var null|string
     */
    private $region = null;
    /**
     * @var array
     */
    private $fallbackRegions;
    /**
     * @var array
     */
    private $loaders = array();
    /**
     * @var array
     */
    private $resources = array();
    /**
     * @var SettingCatalogueInterface[]
     */
    private $catalogues = array();

    /**
     * Constructor.
     *
     * Available options:
     *
     *   * cache_dir: The cache directory (or null to disable caching)
     *   * debug:     Whether to enable debugging or not (false by default)
     *
     * @param ContainerInterface $container A ContainerInterface instance
     * @param array              $loaderIds An array of loader Ids
     * @param array              $options   An array of options
     *
     * @throws \InvalidArgumentException
     */
    public function __construct(ContainerInterface $container, $loaderIds = array(), array $options = array())
    {
        $this->container = $container;
        $this->loaderIds = $loaderIds;

        $this->options = array(
            'cache_dir' => null,
            'debug'     => false,
        );

        // check option names
        if ($diff = array_diff(array_keys($options), array_keys($this->options))) {
            throw new \InvalidArgumentException(sprintf('The Setting does not support the following options: \'%s\'.', implode('\', \'', $diff)));
        }

        $this->options = array_merge($this->options, $options);
    }

    /**
     * @return \Doctrine\ORM\EntityManager
     * @author Michaël VEROUX
     */
    public function getEntityManager()
    {
        return $this->container->get('doctrine.orm.default_entity_manager');
    }

    /**
     * @return \Symfony\Component\Validator\Validator\ValidatorInterface
     * @author Michaël VEROUX
     */
    public function getValidator()
    {
        return $this->container->get('validator');
    }

    /**
     * @param $entity
     *
     * @return \Symfony\Component\Validator\Context\ExecutionContext|\Symfony\Component\Validator\Context\ExecutionContextInterface
     * @author Michaël VEROUX
     */
    public function getExecutionContext($entity)
    {
        $contextFactory = new ExecutionContextFactory($this->container->get('translator'));

        return $contextFactory->createContext($this->getValidator(), $entity);
    }

    /**
     * @param string $format
     * @param $resource
     * @param string $region
     * @param string $prefix
     * @author Michaël VEROUX
     */
    public function addResource($format, $resource, $region, $prefix = 'app')
    {
        $this->resources[$region][] = array($format, $resource, $prefix);

        if (in_array($region, $this->fallbackRegions)) {
            $this->catalogues = array();
        } else {
            unset($this->catalogues[$region]);
        }
    }

    /**
     * @param string $format
     * @param LoaderInterface $loader
     * @author Michaël VEROUX
     */
    public function addLoader($format, LoaderInterface $loader)
    {
        $this->loaders[$format] = $loader;
    }

    /**
     * @return mixed|null
     * @author Michaël VEROUX
     */
    public function getRegion()
    {
        if (null === $this->region) {
            $this->region = strtolower( $this->container->getParameter('region') );
        }

        return $this->region;
    }

    /**
     * @param string $region
     * @author Michaël VEROUX
     */
    protected function loadCatalogue($region)
    {
        if (isset($this->catalogues[$region])) {
            return;
        }

        if (null === $this->options['cache_dir']) {
            $this->initialize();
            $this->doLoadCatalogue($region);

            return;
        }

        $cache = new ConfigCache($this->options['cache_dir'].'/catalogue.'.$region.'.php', $this->options['debug']);
        if (!$cache->isFresh()) {
            $this->initialize();

            $this->doLoadCatalogue($region);

            $fallbackContent = '';
            $current = '';
            $cacheSerialize = array();
            foreach($this->catalogues[$region]->all() as $key => $catalogueRegion)
            {
                $cacheSerialize[$key] = array_map(function($value){ return serialize($value); },$catalogueRegion);
            }

            foreach ($this->computeFallbackRegions($region) as $fallback) {
                $fallbackSuffix = ucfirst(str_replace('-', '_', $fallback));
                $cacheSerializeFallback = array();
                foreach($this->catalogues[$fallback]->all() as $key => $catalogueRegion)
                {
                    $cacheSerializeFallback[$key] = array_map(function($value){ return serialize($value); },$catalogueRegion);
                }

                $fallbackContent .= sprintf(<<<EOF
\$catalogue%s = new SettingCatalogue('%s', %s);
\$catalogue%s->addFallbackCatalogue(\$catalogue%s);


EOF
                    ,
                    $fallbackSuffix,
                    $fallback,
                    var_export($cacheSerializeFallback, true),
                    ucfirst(str_replace('-', '_', $current)),
                    $fallbackSuffix
                );
                $current = $fallback;
            }

            $content = sprintf(<<<EOF
<?php

use Oru\Bundle\SettingBundle\Setting\SettingCatalogue;

\$catalogue = new SettingCatalogue('%s', %s);

%s
return \$catalogue;

EOF
                ,
                $region,
                var_export($cacheSerialize, true),
                $fallbackContent
            );

            $cache->write($content, $this->catalogues[$region]->getResources());

            return;
        }

        $this->catalogues[$region] = include $cache;
    }

    /**
     * @param array $regions
     * @author Michaël VEROUX
     */
    public function setFallbackRegions(array $regions)
    {
        $this->catalogues = array();

        $this->fallbackRegions = $regions;
    }

    /**
     * @param string $region
     * @return array
     * @author Michaël VEROUX
     */
    protected function computeFallbackRegions($region)
    {
        $regions = array();
        foreach ($this->fallbackRegions as $fallback) {
            if ($fallback === $region) {
                continue;
            }

            $regions[] = $fallback;
        }

        return array_unique($regions);
    }

    /**
     * @param string $region
     * @throws \RuntimeException
     * @author Michaël VEROUX
     */
    private function doLoadCatalogue($region)
    {
        if(!isset($this->resources[$region]))
        {
            $prefixes = $this->getEntityManager()->getRepository('OruSettingBundle:Setting')->getPrefixesByRegion($region);

            foreach($prefixes as $prefix)
            {
                $cacheResource = $this->writeAdditionalParameters($region, $prefix);

                $this->addResource('orm', $cacheResource, $region, $prefix);
            }
        }

        $this->catalogues[$region] = new SettingCatalogue($region);

        if (isset($this->resources[$region])) {
            $filePrefixes = array();
            foreach ($this->resources[$region] as $resource) {
                if (!isset($this->loaders[$resource[0]])) {
                    throw new \RuntimeException(sprintf('The "%s" setting loader is not registered.', $resource[0]));
                }
                $filePrefixes[] = $resource[2];
                $catalogue = $this->loaders[$resource[0]]->load($resource[1], $region, $resource[2]);
                $this->catalogues[$region]->addCatalogue($catalogue);
            }

            $missingPrefixed = $this->container->get('doctrine.orm.default_entity_manager')->getRepository('OruSettingBundle:Setting')->findByRegionAndPrefixNotIn($region, $filePrefixes);

            foreach($missingPrefixed as $missing)
            {
                $cacheResource = $this->writeAdditionalParameters($region, $missing['prefix']);
                $catalogue = $this->loaders['orm']->load($cacheResource, $region, $missing['prefix']);
                $this->catalogues[$region]->addCatalogue($catalogue);
            }
        }

        $this->loadFallbackCatalogues($region);
    }

    protected function writeAdditionalParameters($region, $prefix)
    {
        $cacheResource = $this->options['cache_dir'].'/additional/'.$prefix.'.'.$region.'.orm';

        $settings = $this->getEntityManager()->getRepository('OruSettingBundle:Setting')->findBy(
            array(
                'region'    => $region,
                'prefix'    => $prefix,
            )
        );

        $settings = new ArrayCollection($settings);

        $settings->matching(Criteria::create()->orderBy(array('type' => Criteria::ASC)));

        $additional = array();
        foreach($settings as $setting)
        {
            if(!isset($additional[$setting->getType()]))
                $additional[$setting->getType()] = array();

            $additional[$setting->getType()][$setting->getName()] = array(
                'value'         =>  $setting->getValue(),
                'description'   =>  $setting->getDescription(),
            );
        }

        $cache = new ConfigCache($cacheResource, $this->options['debug']);
        $dumper = new YamlDumper();
        $cache->write($dumper->dump($additional,3));

        return $cacheResource;
    }

    /**
     * @param string $region
     * @author Michaël VEROUX
     */
    private function loadFallbackCatalogues($region)
    {
        $current = $this->catalogues[$region];

        foreach ($this->computeFallbackRegions($region) as $fallback) {
            if (!isset($this->catalogues[$fallback])) {
                $this->doLoadCatalogue($fallback);
            }

            $current->addFallbackCatalogue($this->catalogues[$fallback]);
            $current = $this->catalogues[$fallback];
        }
    }

    /**
     * @param string|int $id
     * @param string $prefix
     * @param null|string $region
     * @return mixed
     * @author Michaël VEROUX
     */
    public function setting($id, $prefix = 'app', $region = null)
    {
        if (null === $region) {
            $region = $this->getRegion();
        }

        if (!isset($this->catalogues[$region])) {
            $this->loadCatalogue($region);
        }

        return $this->catalogues[$region]->get((string) $id, $prefix);
    }

    /**
     * @author Michaël VEROUX
     */
    protected function initialize()
    {
        foreach ($this->loaderIds as $id => $aliases) {
            foreach ($aliases as $alias) {
                $this->addLoader($alias, $this->container->get($id));
            }
        }
    }

    /**
     * @return array
     */
    public function getResources()
    {
        return $this->resources;
    }

    /**
     * @param $mixed
     * @author Michaël VEROUX
     */
    public function filter(&$mixed)
    {
        if(! $this->container->get('oru_setting.dynamic_security')->isGranted(self::ROLE_ADMIN))
        {
            if (!$this->container->get('oru_setting.dynamic_security')->isGranted(self::ROLE_BASIC)) {
                if ($mixed instanceof QueryBuilder) {
                    $this->filterAutreQuery($mixed);
                }
                if ($mixed instanceof ArrayCollection) {
                    $this->filterAutreCollection($mixed);
                }
            } else {
                if ($mixed instanceof QueryBuilder) {
                    $this->filterBasicQuery($mixed);
                }
                if ($mixed instanceof ArrayCollection) {
                    $this->filterBasicCollection($mixed);
                }
            }
        }
    }

    /**
     * @param QueryBuilder $query
     *
     * @author Michaël VEROUX
     */
    protected function filterAutreQuery(QueryBuilder $query)
    {
        $rootAliases = $query->getRootAliases();
        $query
            ->andWhere(sprintf('%s.role NOT IN (:roles)', array_shift($rootAliases)))
            ->setParameter('roles', array(self::ROLE_BASIC, self::ROLE_ADMIN))
        ;
    }

    /**
     * @param ArrayCollection $collection
     * @author Michaël VEROUX
     */
    protected function filterAutreCollection(ArrayCollection &$collection)
    {
        $collection = $collection->matching(
            Criteria::create()->where(
                Criteria::expr()->notIn('role', array(self::ROLE_ADMIN, self::ROLE_BASIC))
            )
        );
    }

    /**
     * @param QueryBuilder $query
     * @author Michaël VEROUX
     */
    protected function filterBasicQuery(QueryBuilder $query)
    {
        $rootAliases = $query->getRootAliases();
        $query
            ->andWhere(sprintf('%s.role = :role', array_shift($rootAliases)))
            ->setParameter('role', self::ROLE_BASIC)
        ;
    }

    /**
     * @param ArrayCollection $collection
     * @author Michaël VEROUX
     */
    protected function filterBasicCollection(ArrayCollection &$collection)
    {
        $collection = $collection->matching(
            Criteria::create()->where(
                Criteria::expr()->eq('role',self::ROLE_BASIC)
            )
        );
    }
} 