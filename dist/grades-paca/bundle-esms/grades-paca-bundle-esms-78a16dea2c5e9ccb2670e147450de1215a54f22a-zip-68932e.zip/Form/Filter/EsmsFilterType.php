<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 25/02/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form\Filter;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EsmsFilterType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('departements', 'entity', array(
                    'required'      =>  false,
                    'class'         =>  'OruAddressBundle:LstDepartement',
                    'expanded'      =>  false,
                    'multiple'      =>  true,
                )
            )
            ->add('etablissements', 'oru_etablissement_autocomplete', array(
                    'required'      =>  false,
                    'multiple'      =>  true,
                )
            )
            ->add('finess', 'search', array(
                    'required'      =>  false,
                )
            )
            ->add('increments', 'esms_annee', array(
                    'multiple'      =>  true,
                    'required'      =>  false,
                )
            )
            ->add('deleted','oru_oui_non', array(
                'required'      =>  false,
                'expanded' => false
            ))
            ->add('statut','esms_statut', array(
                    'required'      =>  false,
                    'expanded'      =>  false,
                )
            )
            ->add('filter', 'submit', array(
                    'label'                 => 'listing.action.filter',
                    'translation_domain'    => 'messages',
                    'attr' => array('class' => 'btn btn-primary')
                )
            )
            ->add('reset', 'submit', array(
                    'label'                 => 'listing.action.reset',
                    'translation_domain'    => 'messages',
                    'attr' => array('class' => 'btn btn-default')
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Filter\EsmsFilter',
            'csrf_protection' => false,
            'validation_groups' => false,
            'translation_domain'    => 'OruEsmsBundle',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_esms_filter';
    }
}