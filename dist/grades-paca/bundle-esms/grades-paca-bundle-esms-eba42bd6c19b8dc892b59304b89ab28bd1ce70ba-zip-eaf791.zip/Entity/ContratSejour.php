<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 22/01/14
 * Time: 17:07
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\ContratSejour as BaseContratSejour;
use Oru\Bundle\FormIncrementalBundle\Entity\FormIncrementalInterface;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class ContratSejour.
 *
 * @author Michaël VEROUX
 */
class ContratSejour extends BaseContratSejour implements GroupSequenceProviderInterface, FormIncrementalInterface
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var Esms
     */
    protected $esms;

    public function __clone()
    {
        $this->id = null;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $esms
     */
    public function setEsms($esms)
    {
        $this->esms = $esms;
    }

    /**
     * @return mixed
     */
    public function getEsms()
    {
        return $this->esms;
    }

    /**
     * Return current increment of object (year, month or what you want...).
     *
     * @return int
     *
     * @author Michaël VEROUX
     */
    public function getIncrement()
    {
        return $this->getEsms()->getIncrement();
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $transPrefix = 'oru_esms_contratSejour.';
        $groups = array();

        $frequenceChoix = array_flip($this->getEsms()->getTranslatedChoicesByKey('oru_esms.frequence'));

        if (false !== strpos($this->getAvenantSixMois(), end($frequenceChoix))) {
            $groups[] = 'avenantSixMoisJamais';
        }

        $personneParticipeChoix = array_flip($this->getEsms()->getTranslatedChoicesByKey($transPrefix.'personneParticipe'));
        if (false !== strpos($this->getPersonneParticipe(), end($personneParticipeChoix))) {
            $groups[] = 'personneParticipeNon';
        }

        $informationChoix = array_flip($this->getEsms()->getTranslatedChoicesByKey($transPrefix.'information'));
        if (false !== strpos($this->getInformation(), end($informationChoix))) {
            $groups[] = 'informationAutre';
        }

        if (!$this->getReactualiseAnnuel() && null !== $this->getReactualiseAnnuel()) {
            $groups[] = 'reactualiseAnnuelFalse';
        }

        return $groups;
    }
}
