<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 09:41
 */

namespace Oru\Bundle\EsmsBundle\Model;

/**
 * Class FinVie.
 *
 * @author Michaël VEROUX
 */
class FinVie
{
    /**
     * @var string|null
     */
    protected $droits = null;

    /**
     * @var string|null
     */
    protected $directivesNombre = null;

    /**
     * @var string|null
     */
    protected $accompagnesNombre = null;

    protected $percentCalcDroits = 0;

    /**
     * @param string|null $accompagnesNombre
     */
    public function setAccompagnesNombre($accompagnesNombre)
    {
        $this->accompagnesNombre = $accompagnesNombre;
    }

    /**
     * @return string|null
     */
    public function getAccompagnesNombre()
    {
        return $this->accompagnesNombre;
    }

    /**
     * @param string|null $directivesNombre
     */
    public function setDirectivesNombre($directivesNombre)
    {
        $this->directivesNombre = $directivesNombre;
    }

    /**
     * @return string|null
     */
    public function getDirectivesNombre()
    {
        return $this->directivesNombre;
    }

    /**
     * @param string|null $droits
     */
    public function setDroits($droits)
    {
        $this->droits = $droits;
    }

    /**
     * @return string|null
     */
    public function getDroits()
    {
        return $this->droits;
    }

    /**
     * @param int $percentCalcDroits
     */
    public function setPercentCalcDroits($percentCalcDroits)
    {
        $this->percentCalcDroits = $percentCalcDroits;
    }

    /**
     * @return int
     */
    public function getPercentCalcDroits()
    {
        return $this->percentCalcDroits;
    }
}
