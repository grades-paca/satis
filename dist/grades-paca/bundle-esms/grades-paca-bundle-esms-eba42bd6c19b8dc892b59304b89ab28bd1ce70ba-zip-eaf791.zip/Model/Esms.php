<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 20/01/14
 * Time: 13:40
 */

namespace Oru\Bundle\EsmsBundle\Model;

/**
 * Class Esms.
 *
 * @author Michaël VEROUX
 */
class Esms
{
    /**
     * @var string|null
     */
    protected $professionnelFormation = null;

    /**
     * @var string|null
     */
    protected $conseilVieSociale = null;

    /**
     * @var string|null
     */
    protected $personnesQualifiees = null;

    /**
     * @var string|null
     */
    protected $plaintesReclamations = null;

    /**
     * @var string|null
     */
    protected $bientraitance = null;

    /**
     * @var string|null
     */
    protected $finVie = null;

    /**
     * @var string|null
     */
    protected $accesDonneesSante = null;

    /**
     * @var string|null
     */
    protected $livretAccueil = null;

    /**
     * @var string|null
     */
    protected $contratSoutien = null;

    /**
     * @var string|null
     */
    protected $contratSejour = null;

    /**
     * @var string|null
     */
    protected $reglement = null;

    /**
     * @var string|null
     */
    protected $projetEtablissement = null;

    /**
     * @var string|null
     */
    protected $evaluations = null;

    /**
     * @var string|null
     */
    protected $suiviOutils = null;

    /**
     * @var string|null
     */
    protected $identification = null;

    /**
     * @param string|null $professionnelFormation
     */
    public function setProfessionnelFormation($professionnelFormation)
    {
        $this->professionnelFormation = $professionnelFormation;
    }

    /**
     * @return string|null
     */
    public function getProfessionnelFormation()
    {
        return $this->professionnelFormation;
    }

    /**
     * @author Michaël VEROUX
     */
    public function unsetUnusedSubs()
    {
        $this->getProfessionnelFormation()->unsetUnusedSubs();
    }

    /**
     * @param string|null $conseilVieSociale
     */
    public function setConseilVieSociale($conseilVieSociale)
    {
        $this->conseilVieSociale = $conseilVieSociale;
    }

    /**
     * @return string|null
     */
    public function getConseilVieSociale()
    {
        return $this->conseilVieSociale;
    }

    /**
     * @param string|null $personnesQualifiees
     */
    public function setPersonnesQualifiees($personnesQualifiees)
    {
        $this->personnesQualifiees = $personnesQualifiees;
    }

    /**
     * @return string|null
     */
    public function getPersonnesQualifiees()
    {
        return $this->personnesQualifiees;
    }

    /**
     * @param string|null $plaintesReclamations
     */
    public function setPlaintesReclamations($plaintesReclamations)
    {
        $this->plaintesReclamations = $plaintesReclamations;
    }

    /**
     * @return string|null
     */
    public function getPlaintesReclamations()
    {
        return $this->plaintesReclamations;
    }

    /**
     * @param string|null $bientraitance
     */
    public function setBientraitance($bientraitance)
    {
        $this->bientraitance = $bientraitance;
    }

    /**
     * @return string|null
     */
    public function getBientraitance()
    {
        return $this->bientraitance;
    }

    /**
     * @param string|null $finVie
     */
    public function setFinVie($finVie)
    {
        $this->finVie = $finVie;
    }

    /**
     * @return string|null
     */
    public function getFinVie()
    {
        return $this->finVie;
    }

    /**
     * @param string|null $accesDonneesSante
     */
    public function setAccesDonneesSante($accesDonneesSante)
    {
        $this->accesDonneesSante = $accesDonneesSante;
    }

    /**
     * @return string|null
     */
    public function getAccesDonneesSante()
    {
        return $this->accesDonneesSante;
    }

    /**
     * @param string|null $livretAccueil
     */
    public function setLivretAccueil($livretAccueil)
    {
        $this->livretAccueil = $livretAccueil;
    }

    /**
     * @return string|null
     */
    public function getLivretAccueil()
    {
        return $this->livretAccueil;
    }

    /**
     * @param string|null $contratSoutien
     */
    public function setContratSoutien($contratSoutien)
    {
        $this->contratSoutien = $contratSoutien;
    }

    /**
     * @return string|null
     */
    public function getContratSoutien()
    {
        return $this->contratSoutien;
    }

    /**
     * @param string|null $contratSejour
     */
    public function setContratSejour($contratSejour)
    {
        $this->contratSejour = $contratSejour;
    }

    /**
     * @return string|null
     */
    public function getContratSejour()
    {
        return $this->contratSejour;
    }

    /**
     * @param null|string $reglement
     */
    public function setReglement($reglement)
    {
        $this->reglement = $reglement;
    }

    /**
     * @return null|string
     */
    public function getReglement()
    {
        return $this->reglement;
    }

    /**
     * @param string|null $projetEtablissement
     */
    public function setProjetEtablissement($projetEtablissement)
    {
        $this->projetEtablissement = $projetEtablissement;
    }

    /**
     * @return string|null
     */
    public function getProjetEtablissement()
    {
        return $this->projetEtablissement;
    }

    /**
     * @param string|null $evaluations
     */
    public function setEvaluations($evaluations)
    {
        $this->evaluations = $evaluations;
    }

    /**
     * @return string|null
     */
    public function getEvaluations()
    {
        return $this->evaluations;
    }

    /**
     * @param string|null $suiviOutils
     */
    public function setSuiviOutils($suiviOutils)
    {
        $this->suiviOutils = $suiviOutils;
    }

    /**
     * @return string|null
     */
    public function getSuiviOutils()
    {
        return $this->suiviOutils;
    }

    /**
     * @param null|string $identification
     */
    public function setIdentification($identification)
    {
        $this->identification = $identification;
    }

    /**
     * @return null|string
     */
    public function getIdentification()
    {
        return $this->identification;
    }
}
