<?php

namespace Oru\Bundle\EsmsBundle\Controller;

use Oru\Bundle\DesignBundle\Controller\FlashControllerTrait;
use Oru\Bundle\EsmsBundle\Entity\Esms;
use Oru\Bundle\EsmsBundle\Entity\Identification;
use Oru\Bundle\EsmsBundle\Exception\IntegrityException;
use Oru\Bundle\EsmsBundle\Form\EtablissementType;
use Oru\Bundle\EsmsBundle\Form\Filter\EsmsFilterType;
use Oru\Bundle\EsmsBundle\Voter\EsmsVoter;
use Oru\Bundle\RorBundle\Entity\Etablissement;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Oru\Bundle\EsmsBundle\Listing\EsmsListingType;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\Validator\Constraints\Email;

/**
 * Class EsmsController
 * @package Oru\Bundle\EsmsBundle\Controller
 * @author Michaël VEROUX
 */
class EsmsController extends Controller
{
    use FlashControllerTrait;

    /**
     * @var array
     */
    private $filterDefaults = array();

    /**
     *
     */
    public function __construct()
    {
        $this->filterDefaults = array(
            'increments'    => array(date('Y')),
        );
    }

    public function indexAction(Request $request, $form = null)
    {
        if(null === $form)
        {
            $form = $this->createForm(new EsmsFilterType())->submit($request->getSession()->get('oru_esms.filter', $this->filterDefaults));
        }

        $this->getDoctrine()->getManager()->getFilters()->disable('softdeleteable');
        $entities = $this->get('oru_esms.esms_provider')->findList($form->getData());

        $listing = $this->container->get('paginator.factory')->create(
            new EsmsListingType($form->getData()->getDeleted()),
            $entities,
            $request->query->get('page', 1)
        );

        $formCreate = $this->createForm(new EtablissementType(), new Identification(), array(
            'action' => $this->generateUrl('oru_esms_pre_new'),
            'method' => 'POST',
        ));

        return $this->render('OruEsmsBundle:Esms:index.html.twig',
            array(
                'listing'       => $listing,
                'form'          => $form->createView(),
                'form_create'   => $formCreate->createView(),
            )
        );
    }

    public function filterAction(Request $request)
    {
        $form = $this->createForm(new EsmsFilterType())->handleRequest($request);

        if ($form->get('reset')->isClicked())
        {
            $request->getSession()->set('oru_esms.filter', $this->filterDefaults);

            return $this->redirect($this->generateUrl('oru_esms'));
        }

        if($form->isValid()) {
            $request->getSession()->set('oru_esms.filter', $request->get($form->getName()));

            return $this->redirect($this->generateUrl('oru_esms'));
        }

        return $this->indexAction($request, $form);
    }

    /**
     * @param $etablissement
     * @return \Symfony\Component\HttpFoundation\Response
     * @author Michaël VEROUX
     */
    public function newAction(Etablissement $etablissement)
    {
        try
        {
            $entity = $this->get('oru_esms.esms_provider')->create($etablissement);
        }
        catch(IntegrityException $e)
        {
            $esms = $this->get('oru_esms.esms_provider')->findCurrentByEtablissement($etablissement);

            return $this->redirect($this->generateUrl('oru_esms_access', array('id' => $esms->getIdentification()->getEtablissement()->getId())));
        }

        if(!$this->get('security.authorization_checker')->isGranted(EsmsVoter::EDIT, $entity))
            if(!$this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ROR_ADMIN'))
                throw new AccessDeniedHttpException('Droits insuffisants !');

        if(!$this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ESMS_EDIT', $etablissement))
            throw new AccessDeniedHttpException('Droits insuffisants !');

        $this->addSessionMessage(sprintf('Vous allez créer un formulaire Esms sur l\'établissement %s', $etablissement));

        $this->get('twig')->addGlobal('ESMSYEAR', $entity->getIncrement() - 1);

        $form = $this->container->get('form.factory')->create(
            'oru_esms',
            $entity
        );

        return $this->render('OruEsmsBundle:Esms:new.html.twig', array(
                'form'      =>  $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     * @param string $finess
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     */
    public function createAction(Request $request, Etablissement $etablissement)
    {
        $entity = $this->get('oru_esms.esms_provider')->create($etablissement);

        if(!$this->get('security.authorization_checker')->isGranted(EsmsVoter::EDIT, $entity))
            if(!$this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ROR_ADMIN'))
                throw new AccessDeniedHttpException('Droits insuffisants !');

        if(!$this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ESMS_EDIT', $etablissement))
            throw new AccessDeniedHttpException('Droits insuffisants !');

        $this->get('twig')->addGlobal('ESMSYEAR', $entity->getIncrement() - 1);

        $form = $this->container->get('form.factory')->create(
            'oru_esms',
            $entity
        );

        $form->submit($request->request->get($form->getName()));

        if($form->isValid())
        {
            $entity->unsetUnusedSubs();
            $em = $this->getDoctrine()->getManager();
            $em->persist($entity);
            $em->flush();
            $this->addSessionMessage('Vos données sont enregistrées.');
            $this->sendMessageCloture($entity);

            if($entity->getComplete())
            {
                $this->addSessionMessage('Votre formulaire a bien été clôturé, un message va être envoyé à l\'ARS.');

                return $this->redirect($this->generateUrl('oru_esms_show', array('id' => $entity->getId())));
            }
            else
                return $this->redirect($this->generateUrl('oru_esms_edit', array('id' => $entity->getId())));
        }

        $this->addSessionMessage('Le formulaire soumis contient des erreurs...', 'warning');

        return $this->render('OruEsmsBundle:Esms:new.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Esms $entity
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function editAction(Esms $entity)
    {
        if(!$this->get('security.authorization_checker')->isGranted(EsmsVoter::EDIT, $entity))
            if(!$this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ROR_ADMIN'))
                throw new AccessDeniedHttpException('Droits insuffisants !');

        if(!$this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ESMS_EDIT', $entity->getIdentification()->getEtablissement()))
            throw new AccessDeniedHttpException('Droits insuffisants !');

        $this->get('twig')->addGlobal('ESMSYEAR', $entity->getIncrement() - 1);

        $form = $this->container->get('form.factory')->create(
            'oru_esms',
            $this->get('oru_esms.esms_provider')->find($entity->getId())
        );

        return $this->render('OruEsmsBundle:Esms:edit.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Esms $entity
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function showAction(Esms $entity)
    {
        $this->get('twig')->addGlobal('ESMSYEAR', $entity->getIncrement() - 1);

        $form = $this->container->get('form.factory')->create(
            'oru_esms',
            $this->get('oru_esms.esms_provider')->find($entity->getId())
        );

        return $this->render('OruEsmsBundle:Esms:show.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    /**
     * @param Esms $entity
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function openAction(Esms $entity, Request $request)
    {
        if(!$this->get('security.authorization_checker')->isGranted(EsmsVoter::UNLOCK, $entity))
            throw new AccessDeniedHttpException('Droits insuffisants !');

        if(!$this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ESMS_UNLOCK'))
            throw new AccessDeniedHttpException('Droits insuffisants !');

        $entity->setComplete(false);
        $this->getDoctrine()->getManager()->flush();

        $referer = $request->headers->get('referer');

        if($referer)
            return $this->redirect($referer);

        return $this->redirect($this->generateUrl('oru_esms'));
    }

    public function preNewAction(Request $request)
    {
        $identification = new Identification();

        $form = $this->createForm(new EtablissementType(), $identification);

        $form->submit($request->request->get($form->getName()));

        if($form->isValid())
        {
            return $this->redirect($this->generateUrl('oru_esms_new', array('etablissement' => $identification->getEtablissement()->getId())));
        }

        return $this->redirect($this->generateUrl('oru_esms'));
    }

    /**
     * @param Request $request
     * @param Esms $entity
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     */
    public function updateAction(Request $request, Esms $entity)
    {
        if(!$this->get('security.authorization_checker')->isGranted(EsmsVoter::EDIT, $entity))
            if(!$this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ROR_ADMIN'))
                throw new AccessDeniedHttpException('Droits insuffisants !');

        if(!$this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ESMS_EDIT', $entity->getIdentification()->getEtablissement()))
            throw new AccessDeniedHttpException('Droits insuffisants !');

        $this->get('twig')->addGlobal('ESMSYEAR', $entity->getIncrement() - 1);

        /** @var \Symfony\Component\Form\Form $form */
        $form = $this->container->get('form.factory')->create(
            'oru_esms',
            $this->get('oru_esms.esms_provider')->find($entity->getId())
        );

        $form->submit($request->request->get($form->getName()));

        if($form->isValid())
        {
            $entity->unsetUnusedSubs();
            $em = $this->getDoctrine()->getManager();
            $em->persist($entity);
            $em->flush();
            $this->addSessionMessage('Vos données sont enregistrées.');
            $this->sendMessageCloture($entity);

            if($entity->getComplete())
            {
                $this->addSessionMessage('Votre formulaire a bien été clôturé, un message va être envoyé à l\'ARS.');

                return $this->redirect($this->generateUrl('oru_esms_show', array('id' => $entity->getId())));
            }
            else
                return $this->redirect($this->generateUrl('oru_esms_edit', array('id' => $entity->getId())));
        }

        $this->addSessionMessage('Le formulaire soumis contient des erreurs...', 'warning');

        return $this->render('OruEsmsBundle:Esms:edit.html.twig',
            array(
                'form' => $form->createView(),
            )
        );
    }

    public function deleteAction(Request $request, Esms $entity)
    {
        if(!$this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ESMS_DELETE', $entity->getIdentification()->getEtablissement()))
            throw new AccessDeniedHttpException('Droits insuffisants !');

        if(!$this->get('security.authorization_checker')->isGranted(EsmsVoter::DELETE, $entity))
        {
            $this->addSessionMessage('Vos droits sont insuffisants !', 'error');
            throw new AccessDeniedHttpException();
        }

        $this->getDoctrine()->getManager()->remove($entity);
        $this->getDoctrine()->getManager()->flush();

        return new Response();
    }

    public function restaureAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();
        $em->getFilters()->disable('softdeleteable');
        $entity = $this->get('oru_esms.esms_provider')->find($id);

        if(!$this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_ESMS_DELETE', $entity->getIdentification()->getEtablissement()))
            throw new AccessDeniedHttpException('Droits insuffisants !');

        if(!$this->get('security.authorization_checker')->isGranted(EsmsVoter::DELETE, $entity))
        {
            $this->addSessionMessage('Vos droits sont insuffisants !', 'error');
            throw new AccessDeniedHttpException();
        }

        $entity->setDeleted(null);

        $em->flush();

        return new Response();
    }

    /**
     * @param Etablissement $etablissement
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws \Symfony\Component\HttpKernel\Exception\NotFoundHttpException
     */
    public function accessAction(Etablissement $etablissement)
    {
        $esms = $this->get('oru_esms.esms_provider')->findCurrentByEtablissement($etablissement);

        if(!$esms)
            return $this->newAction($etablissement);

        return $this->editAction($esms);
    }

    /**
     * @param Etablissement $etablissement
     * @return \Symfony\Component\HttpFoundation\Response
     * @throws \Symfony\Component\HttpKernel\Exception\NotFoundHttpException
     */
    public function accessShowAction(Etablissement $etablissement)
    {
        $esms = $this->get('oru_esms.esms_provider')->findCurrentByEtablissement($etablissement);

        if(!$esms)
        {
            $this->addSessionMessage('Aucun formulaire rempli pour cet Établissement !', 'error');
            $url = $this->generateUrl('oru_esms_access',array('etablissement' => $etablissement->getId()));
            $this->addSessionMessage(sprintf('Essayez de <a href="%s">remplir le formulaire ici.</a>',$url), 'notice');
            return $this->failedAction();
        }

        return $this->showAction($esms);
    }

    public function failedAction()
    {
        return $this->render('OruEsmsBundle:Esms:failed.html.twig'
        );
    }

    protected  function sendMessageCloture(Esms $esms)
    {
        if(! $esms->getComplete()) return;

        $to = $this->getUser()->getEmail();
        $copies = $this->get('oru_setting')->setting('clotureEmails', 'OruEsmsBundle');

        if(!$to)
        {
            $to = current($copies);
        }

        // @TODO Récupérer les référents lorsque ça sera possible...
        $referents = array();
        if(!$to || count($this->get('validator')->validateValue($to,array(new Email())))){
            throw new \Exception('Not valid email');
        }

        $arCc = array();
        foreach($copies as $cc){
            if($cc && !count($this->get('validator')->validateValue($cc, array(new Email())))){
                array_push($arCc, $cc);
            }
        }
        foreach($referents as $referent){
            if($referent->getEmail() && !count($this->get('validator')->validateValue($referent->getEmail(), array(new Email())))){
                array_push($arCc, $referent->getEmail());
            }
        }

        $vars = array(
            'etablissement'=> $esms->getIdentification()->getEtablissement(),
            'esms' => $esms,
        );
        $this->get('oru_mail.mailer')->sendEmailMessage('OruEsmsBundle:Mail:cloture.html.twig', $vars, $to, null, null, $arCc);
    }
}
