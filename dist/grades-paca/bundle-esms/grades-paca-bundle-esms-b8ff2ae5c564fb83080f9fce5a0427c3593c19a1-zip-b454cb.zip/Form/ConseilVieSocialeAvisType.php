<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ConseilVieSocialeAvisType
 * @package Oru\Bundle\EsmsBundle\Form
 * @author Michaël VEROUX
 */
class ConseilVieSocialeAvisType extends AbstractType
{
    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('avisOrganisationInterieureEmis', 'number', array(
                    'attr'=> array('class' => 'avis_emis'),
                )
            )
            ->add('avisOrganisationInterieureSuivi', 'number', array(
                    'attr'=> array('class' => 'avis_suivi'),
                )
            )
            ->add('avisQualiteHebergementEmis', 'number', array(
                    'attr'=> array('class' => 'avis_emis'),
                )
            )
            ->add('avisQualiteHebergementSuivi', 'number', array(
                    'attr'=> array('class' => 'avis_suivi'),
                )
            )
            ->add('avisQualiteRestaurationEmis', 'number', array(
                    'attr'=> array('class' => 'avis_emis'),
                )
            )
            ->add('avisQualiteRestaurationSuivi', 'number', array(
                    'attr'=> array('class' => 'avis_suivi'),
                )
            )
            ->add('avisAnimationEmis', 'number', array(
                    'attr'=> array('class' => 'avis_emis'),
                )
            )
            ->add('avisAnimationSuivi', 'number', array(
                    'attr'=> array('class' => 'avis_suivi'),
                )
            )
            ->add('avisServiceTherapeutiqueEmis', 'number', array(
                    'attr'=> array('class' => 'avis_emis'),
                )
            )
            ->add('avisServiceTherapeutiqueSuivi', 'number', array(
                    'attr'=> array('class' => 'avis_suivi'),
                )
            )
            ->add('avisTravauxEquipementEmis', 'number', array(
                    'attr'=> array('class' => 'avis_emis'),
                )
            )
            ->add('avisTravauxEquipementSuivi', 'number', array(
                    'attr'=> array('class' => 'avis_suivi'),
                )
            )
            ->add('avisNatureServiceEmis', 'number', array(
                    'attr'=> array('class' => 'avis_emis'),
                )
            )
            ->add('avisNatureServiceSuivi', 'number', array(
                    'attr'=> array('class' => 'avis_suivi'),
                )
            )
            ->add('avisAffectationLocauxCollectifsEmis', 'number', array(
                    'attr'=> array('class' => 'avis_emis'),
                )
            )
            ->add('avisAffectationLocauxCollectifsSuivi', 'number', array(
                    'attr'=> array('class' => 'avis_suivi'),
                )
            )
            ->add('avisEntretienLocauxEmis', 'number', array(
                    'attr'=> array('class' => 'avis_emis'),
                )
            )
            ->add('avisEntretienLocauxSuivi', 'number', array(
                    'attr'=> array('class' => 'avis_suivi'),
                )
            )
            ->add('avisVieInstitutionnelleEmis', 'number', array(
                    'attr'=> array('class' => 'avis_emis'),
                )
            )
            ->add('avisVieInstitutionnelleSuivi', 'number', array(
                    'attr'=> array('class' => 'avis_suivi'),
                )
            )
            ->add('avisCommunicationExterneEmis', 'number', array(
                    'attr'=> array('class' => 'avis_emis'),
                )
            )
            ->add('avisCommunicationExterneSuivi', 'number', array(
                    'attr'=> array('class' => 'avis_suivi'),
                )
            )
            ->add('avisAutreEmis', 'number', array(
                    'attr'=> array('class' => 'avis_emis'),
                )
            )
            ->add('avisAutreSuivi', 'number', array(
                    'attr'=> array('class' => 'avis_suivi'),
                )
            )
            ->add('sumEmis', 'oru_sum', array(
                    'mapped'        => false,
                    'type_class'    => 'avis_emis',
                    'attr'          => array('disabled' => 'disabled', 'class' => 'bold'),
                )
            )
            ->add('sumSuivi', 'oru_sum', array(
                    'mapped'        => false,
                    'type_class'    => 'avis_suivi',
                    'attr'          => array('disabled' => 'disabled', 'class' => 'bold'),
                )
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\ConseilVieSocialeAvis',
            'translation_domain'    => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getName()
    {
        return 'conseilVieSocialeAvis';
    }
} 