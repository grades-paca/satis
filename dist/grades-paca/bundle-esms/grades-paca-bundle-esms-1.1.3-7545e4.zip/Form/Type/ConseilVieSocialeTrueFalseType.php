<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 20/01/14
 * Time: 16:38
 */

namespace Oru\Bundle\EsmsBundle\Form\Type;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ConseilVieSocialeTrueFalseType
 * @package Oru\Bundle\EsmsBundle\Form\Type
 * @author Michaël VEROUX
 */
class ConseilVieSocialeTrueFalseType extends AbstractType
{
    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setRequired(array('on_true'));
        $resolver->setRequired(array('on_false'));
    }

    /**
     * @param FormView $view
     * @param FormInterface $form
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        $view->vars['on_true'] = $options['on_true'];
        $view->vars['on_false'] = $options['on_false'];
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getParent()
    {
        return 'text';
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'conseil_vie_sociale_true_false';
    }
}