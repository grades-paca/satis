<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ConseilVieSocialeType
 * @package Oru\Bundle\EsmsBundle\Form
 * @author Michaël VEROUX
 */
class ConseilVieSocialeType extends AbstractType
{
    /**
     * @var \Oru\Bundle\EsmsBundle\Choice\ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param ChoiceProvider $choiceProvider
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(ChoiceProvider $choiceProvider, IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->choiceProvider = $choiceProvider;
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choicesPrefix = 'oru_esms_' . $this->getName();

        $builder
            ->add('exist', 'oru_conditional', array(
                    'choices'           =>  array(
                        1   =>  'Oui',
                        0   =>  'Non',
                    ),
                    'conditionals'      =>  array(
                        1   =>  array(
                            'anneeNbr',
                            'anneeInstallation',
                            'conseilVieSocialeRepresentant',
                        ),
                        0   =>  array(
                            'nonRaison',
                            'autreFormeGroupeDiscussion',
                        ),
                    ),
                )
            )
            ->add('nonRaison', 'choice', array(
                    'placeholder'   =>  '---choix---',
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'nonRaison', 4),
                )
            )
            ->add('autreFormeGroupeDiscussion', 'oru_choices_to_string', array(
                    'expanded'      =>  true,
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'autreFormeGroupeDiscussion', 4),
                )
            )
            ->add('autreFormeAutreDetail'
            )
            ->add('anneeInstallation', null, array(
                    'attr'          =>  array('min' => 1980),
                )
            )
            ->add('anneeNbr', 'number', array(
                )
            )
            ->add('reglementInterieur', 'oru_conditional', array(
                    'choices'           =>  array(
                        1   =>  'Oui',
                        0   =>  'Non',
                    ),
                    'conditionals'      =>  array(
                        0   =>  array(
                            'reglementInterieurDetailListe',
                            'reglementInterieurDetail',
                        ),
                    ),
                )
            )
            ->add('reglementInterieurDetailListe', 'oru_choices_to_string', array(
                    'expanded'      =>  true,
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'reglementInterieurDetailListe', 5),
                )
            )
            ->add('reglementInterieurDetail'
            )
            ->add('formationMembre', 'oru_oui_non', array(
                    'placeholder'   =>  'Non concerné',
                    'expanded'      =>  false,
                )
            )
            ->add('conseilVieSocialeRepresentant', 'conseilVieSocialeRepresentant'
            )
            ->add('representantVoixConsultativeExterieurDetailListe', 'oru_choices_to_string', array(
                    'expanded'      =>  true,
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'representantVoixConsultativeExterieurDetailListe', 11),
                )
            )
            ->add('representantVoixConsultativeExterieurDetail'
            )
            ->add('representantInferieurMoitieDetail'
            )
            ->add('presidence', 'choice', array(
                    'expanded'      =>  true,
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'presidence', 4),
                )
            )
            ->add('presidenceAutre'
            )
            ->add('crCommuniques', 'oru_choices_to_string', array(
                    'expanded'      =>  true,
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'crCommuniques', 7),
                )
            )
            ->add('crAffiches', 'oru_oui_non'
            )
            ->add('avisSollicite', 'oru_choices_to_string', array(
                    'expanded'      =>  true,
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'avisSollicite', 17),
                )
            )
            ->add('avisSolliciteAutre'
            )
            ->add('conseilVieSocialeAvisExist', 'oru_oui_non_detail', array(
                    'placeholder'   => 'Non concerné',
                    'detail'        => 'conseilVieSocialeAvis',
                    'on_no'         => false,
                    'expanded'      => false,
                )
            )
            ->add('conseilVieSocialeAvis', 'conseilVieSocialeAvis'
            )
            ->add('avisAutreDetail'
            )
            ->add('avisNonSuiviDetail'
            )
            ->add('avisSuiviDetail'
            )
            ->add('autreForme', 'oru_oui_non', array(
                    'placeholder'   =>  'Non concerné',
                    'expanded'      =>  false,
                )
            )
            ->add('autreFormeDocument', 'oru_oui_non'
            )
            ->add('estimation', 'oru_conditional', array(
                    'placeholder'       =>  'Non concerné',
                    'choices'           =>  array(
                        1   =>  'Oui',
                        0   =>  'Non',
                    ),
                    'conditionals'      =>  array(
                        0   =>  array(
                            'estimationDetailListe',
                            'estimationDetail',
                        ),
                    ),
                )
            )
            ->add('estimationDetailListe', 'oru_choices_to_string', array(
                    'expanded'      =>  true,
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'estimationDetailListe', 4),
                )
            )
            ->add('estimationDetail'
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\ConseilVieSociale',
            'translation_domain'    => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getName()
    {
        return 'conseilVieSociale';
    }
} 