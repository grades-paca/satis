<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:39
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\ProfessionnelFormation as BaseProfessionnelFormation;
use Oru\Bundle\FormIncrementalBundle\Entity\FormIncrementalInterface;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class ProfessionnelFormation
 * @package Oru\Bundle\EsmsBundle\Entity
 * @author Michaël VEROUX
 */
class ProfessionnelFormation extends BaseProfessionnelFormation implements GroupSequenceProviderInterface, FormIncrementalInterface
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var Esms
     */
    protected $esms;

    /**
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $esms
     */
    public function setEsms($esms)
    {
        $this->esms = $esms;
    }

    /**
     * @return mixed
     */
    public function getEsms()
    {
        return $this->esms;
    }

    /**
     * Get professionnelFormationTheme
     *
     * @return \Oru\Bundle\EsmsBundle\Entity\ProfessionnelFormationTheme
     */
    public function getProfessionnelFormationTheme()
    {
        if(null === $this->professionnelFormationTheme)
        {
            $this->setProfessionnelFormationTheme(new ProfessionnelFormationTheme());
            $this->getProfessionnelFormationTheme()->setProfessionnelFormation($this);
        }

        return $this->professionnelFormationTheme;
    }

    /**
     * Get professionnelFormationType
     *
     * @return \Oru\Bundle\EsmsBundle\Entity\ProfessionnelFormationType
     */
    public function getProfessionnelFormationType()
    {
        return null === $this->professionnelFormationType ? new ProfessionnelFormationType() : parent::getProfessionnelFormationType();
    }

    /**
     * Return current increment of object (year, month or what you want...)
     * @return int
     * @author Michaël VEROUX
     */
    public function getIncrement()
    {
        return $this->getEsms()->getIncrement();
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $groups = array();

        if($this->getSuiviFormation())
        {
            $groups[] = 'suiviFormationTrue';
        }
        elseif(null !== $this->getSuiviFormation())
        {
            if(2014 < $this->getIncrement())
            {
                $groups[] = 'suiviFormation2015False';
            }
            else
            {
                $groups[] = 'suiviFormationFalse';
            }
        }

        return array_merge(
            $groups,
            $this->getProfessionnelFormationTheme()->getGroupSequence(),
            $this->getProfessionnelFormationType()->getGroupSequence()
        );
    }

    public function __clone()
    {
        $this->id = null;
    }
}