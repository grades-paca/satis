<?php
/**
 * Author: Michaël VEROUX
 * Date: 02/02/16
 * Time: 10:02
 */

namespace Oru\Bundle\EsmsBundle\Subscriber;

use Oru\Bundle\FormExportBundle\Event\CustomTypeEvent;
use Oru\Bundle\FormExportBundle\Event\RemoveTypeEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Oru\Bundle\FormExportBundle\Export\ChoiceTypeDisplay;

/**
 * Class FormExportSubscriber
 *
 * @package Oru\Bundle\EsmsBundle\Subscriber
 * @author Michaël VEROUX
 */
class FormExportSubscriber implements EventSubscriberInterface
{
    /**
     * @var ChoiceTypeDisplay
     */
    protected $choiceDisplay;

    /**
     * FormExportSubscriber constructor.
     *
     * @param ChoiceTypeDisplay $choiceDisplay
     */
    public function __construct(ChoiceTypeDisplay $choiceDisplay)
    {
        $this->choiceDisplay = $choiceDisplay;
    }

    /**
     * Returns an array of event names this subscriber wants to listen to.
     *
     * The array keys are event names and the value can be:
     *
     *  * The method name to call (priority defaults to 0)
     *  * An array composed of the method name to call and the priority
     *  * An array of arrays composed of the method names to call and respective
     *    priorities, or 0 if unset
     *
     * For instance:
     *
     *  * array('eventName' => 'methodName')
     *  * array('eventName' => array('methodName', $priority))
     *  * array('eventName' => array(array('methodName1', $priority), array('methodName2'))
     *
     * @return array The event names to listen to
     */
    public static function getSubscribedEvents()
    {
        if (class_exists('\Oru\Bundle\FormExportBundle\Event\FormExportEvents')) {
            return array(
                \Oru\Bundle\FormExportBundle\Event\FormExportEvents::CUSTOM_TYPE_CONVERT    => 'customType',
                \Oru\Bundle\FormExportBundle\Event\FormExportEvents::REMOVE_TYPE            => 'removeType',
            );
        }

        return array();
    }

    /**
     * @param CustomTypeEvent $event
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function customType(CustomTypeEvent $event)
    {
        if ('oru_esms' !== $event->getExportType()) {
            return;
        }

        $type = $event->getTypeName();
        $formView = $event->getFormView();
        $value = $formView->vars['value'];

        $choiceTypes = array(
            'esms_annee',
            'difficulte',
            'esms_statut',
            'frequence',
            'personnes',
        );
        if (in_array($type, $choiceTypes)) {
            if ('personnes' == $type) {
                $formView->vars['multiple'] = true;
            }
            $display = $this->choiceDisplay->get($formView);
            $event->setDisplayable($display);
            $event->stopPropagation();

            return;
        }

        if ('conseil_vie_sociale_true_false' == $type) {
            $event->setDisplayable($value);
            $event->stopPropagation();

            return;
        }
    }

    /**
     * @param RemoveTypeEvent $event
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function removeType(RemoveTypeEvent $event)
    {
        if ('oru_esms' == $event->getExportType()) {
            $event->addRemoveRootType('save');
            $event->addRemoveRootType('save_definitively');
            $event->addRemoveRootType('recoverable');
        }
    }
}
