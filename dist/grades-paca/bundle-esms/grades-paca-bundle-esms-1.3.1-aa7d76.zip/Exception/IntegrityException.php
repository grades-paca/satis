<?php
/**
 * Author: Michaël VEROUX
 * Date: 17/07/14
 * Time: 16:54
 */

namespace Oru\Bundle\EsmsBundle\Exception;

class IntegrityException extends \InvalidArgumentException
{
}
