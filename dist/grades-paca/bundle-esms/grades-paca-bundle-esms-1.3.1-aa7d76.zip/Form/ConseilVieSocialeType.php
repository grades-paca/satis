<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\FormBundle\Form\Type\ChoicesToStringType;
use Oru\Bundle\FormBundle\Form\Type\ConditionalType;
use Oru\Bundle\FormBundle\Form\Type\OuiNonDetailType;
use Oru\Bundle\FormBundle\Form\Type\OuiNonType;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ConseilVieSocialeType.
 *
 * @author Michaël VEROUX
 */
class ConseilVieSocialeType extends AbstractType
{
    /**
     * @var \Oru\Bundle\EsmsBundle\Choice\ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param ChoiceProvider                $choiceProvider
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(ChoiceProvider $choiceProvider, IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->choiceProvider = $choiceProvider;
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choicesPrefix = 'oru_esms_'.$this->getName();

        $builder
            ->add('exist', ConditionalType::class, array(
                    'choices' => array(
                        1 => 'Oui',
                        0 => 'Non',
                    ),
                    'conditionals' => array(
                        1 => array(
                            'anneeNbr',
                            'anneeInstallation',
                            'conseilVieSocialeRepresentant',
                        ),
                        0 => array(
                            'nonRaison',
                            'autreFormeGroupeDiscussion',
                        ),
                    ),
                )
            )
            ->add('nonRaison', ChoiceType::class, array(
                    'placeholder' => '---choix---',
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'nonRaison', 4),
                )
            )
            ->add('autreFormeGroupeDiscussion', ChoicesToStringType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'autreFormeGroupeDiscussion', 4),
                )
            )
            ->add('autreFormeAutreDetail'
            )
            ->add('anneeInstallation', null, array(
                    'attr' => array('min' => 1980),
                )
            )
            ->add('anneeNbr', NumberType::class, array(
                )
            )
            ->add('reglementInterieur', ConditionalType::class, array(
                    'choices' => array(
                        1 => 'Oui',
                        0 => 'Non',
                    ),
                    'conditionals' => array(
                        0 => array(
                            'reglementInterieurDetailListe',
                            'reglementInterieurDetail',
                        ),
                    ),
                )
            )
            ->add('reglementInterieurDetailListe', ChoicesToStringType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'reglementInterieurDetailListe', 5),
                )
            )
            ->add('reglementInterieurDetail'
            )
            ->add('formationMembre', OuiNonType::class, array(
                    'placeholder' => 'Non concerné',
                    'expanded' => false,
                )
            )
            ->add('conseilVieSocialeRepresentant', ConseilVieSocialeRepresentantType::class
            )
            ->add('representantVoixConsultativeExterieurDetailListe', ChoicesToStringType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'representantVoixConsultativeExterieurDetailListe', 11),
                )
            )
            ->add('representantVoixConsultativeExterieurDetail'
            )
            ->add('representantInferieurMoitieDetail'
            )
            ->add('presidence', ChoiceType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'presidence', 4),
                )
            )
            ->add('presidenceAutre'
            )
            ->add('crCommuniques', ChoicesToStringType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'crCommuniques', 7),
                )
            )
            ->add('crAffiches', OuiNonType::class
            )
            ->add('avisSollicite', ChoicesToStringType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'avisSollicite', 17),
                )
            )
            ->add('avisSolliciteAutre'
            )
            ->add('conseilVieSocialeAvisExist', OuiNonDetailType::class, array(
                    'placeholder' => 'Non concerné',
                    'detail' => 'conseilVieSocialeAvis',
                    'on_no' => false,
                    'expanded' => false,
                )
            )
            ->add('conseilVieSocialeAvis', ConseilVieSocialeAvisType::class
            )
            ->add('avisAutreDetail'
            )
            ->add('avisNonSuiviDetail'
            )
            ->add('avisSuiviDetail'
            )
            ->add('autreForme', OuiNonType::class, array(
                    'placeholder' => 'Non concerné',
                    'expanded' => false,
                )
            )
            ->add('autreFormeDocument', OuiNonType::class
            )
            ->add('estimation', ConditionalType::class, array(
                    'placeholder' => 'Non concerné',
                    'choices' => array(
                        1 => 'Oui',
                        0 => 'Non',
                    ),
                    'conditionals' => array(
                        0 => array(
                            'estimationDetailListe',
                            'estimationDetail',
                        ),
                    ),
                )
            )
            ->add('estimationDetailListe', ChoicesToStringType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'estimationDetailListe', 4),
                )
            )
            ->add('estimationDetail'
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\ConseilVieSociale',
            'translation_domain' => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getBlockPrefix()
    {
        return 'conseilVieSociale';
    }
}
