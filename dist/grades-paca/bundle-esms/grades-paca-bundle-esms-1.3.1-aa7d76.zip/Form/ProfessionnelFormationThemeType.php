<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 16/01/14
 * Time: 16:55
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\FormBundle\Form\Type\ChoicesToStringType;
use Oru\Bundle\FormBundle\Form\Type\SumType;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ProfessionnelFormationThemeType.
 *
 * @author Michaël VEROUX
 */
class ProfessionnelFormationThemeType extends AbstractType
{
    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @var ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     * @param ChoiceProvider                $choiceProvider
     */
    public function __construct(IncrementalValiditySubscriber $incrementalValiditySubscriber, ChoiceProvider $choiceProvider)
    {
        $this->validitySubscriber = $incrementalValiditySubscriber;
        $this->choiceProvider = $choiceProvider;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choicesPrefix = 'oru_esms_professionnelFormation_'.$this->getName();

        $builder
            ->add('droitIndividuelPropose', NumberType::class, array(
                    'attr' => array('class' => 'theme_propose'),
                )
            )
            ->add('droitIndividuelForme', NumberType::class, array(
                    'attr' => array('class' => 'theme_forme'),
                )
            )
            ->add('droitCollectifPropose', NumberType::class, array(
                    'attr' => array('class' => 'theme_propose'),
                )
            )
            ->add('droitCollectifForme', NumberType::class, array(
                    'attr' => array('class' => 'theme_forme'),
                )
            )
            ->add('suiviOutilsPropose', NumberType::class, array(
                    'attr' => array('class' => 'theme_propose'),
                )
            )
            ->add('suiviOutilsForme', NumberType::class, array(
                    'attr' => array('class' => 'theme_forme'),
                )
            )
            ->add('pecDouleurPropose', NumberType::class, array(
                    'attr' => array('class' => 'theme_propose'),
                )
            )
            ->add('pecDouleurForme', NumberType::class, array(
                    'attr' => array('class' => 'theme_forme'),
                )
            )
            ->add('traitancePropose', NumberType::class, array(
                    'attr' => array('class' => 'theme_propose'),
                )
            )
            ->add('traitanceForme', NumberType::class, array(
                    'attr' => array('class' => 'theme_forme'),
                )
            )
            ->add('palliatifPropose', NumberType::class, array(
                    'attr' => array('class' => 'theme_propose'),
                )
            )
            ->add('palliatifForme', NumberType::class, array(
                    'attr' => array('class' => 'theme_forme'),
                )
            )
            ->add('conseilVieSocialePropose', NumberType::class, array(
                    'attr' => array('class' => 'theme_propose'),
                )
            )
            ->add('conseilVieSocialeForme', NumberType::class, array(
                    'attr' => array('class' => 'theme_forme'),
                )
            )
            ->add('autrePropose', NumberType::class, array(
                    'attr' => array('class' => 'theme_propose'),
                )
            )
            ->add('autreForme', NumberType::class, array(
                    'attr' => array('class' => 'theme_forme'),
                )
            )
            ->add('sumPropose', SumType::class, array(
                    'mapped' => false,
                    'type_class' => 'theme_propose',
                    'attr' => array('disabled' => 'disabled', 'class' => 'bold'),
                )
            )
            ->add('sumForme', SumType::class, array(
                    'mapped' => false,
                    'type_class' => 'theme_forme',
                    'attr' => array('disabled' => 'disabled', 'class' => 'bold'),
                )
            )
            ->add('autreDetailListe', ChoicesToStringType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'autreDetailListe', 14),
                )
            )
            ->add('autreDetail', TextareaType::class
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\ProfessionnelFormationTheme',
            'translation_domain' => 'OruEsmsBundle',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'professionnelFormationTheme';
    }
}
