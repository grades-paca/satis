<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\FormBundle\Form\Type\SumType;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ConseilVieSocialeAvisType.
 *
 * @author Michaël VEROUX
 */
class ConseilVieSocialeAvisType extends AbstractType
{
    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('avisOrganisationInterieureEmis', NumberType::class, array(
                    'attr' => array('class' => 'avis_emis'),
                )
            )
            ->add('avisOrganisationInterieureSuivi', NumberType::class, array(
                    'attr' => array('class' => 'avis_suivi'),
                )
            )
            ->add('avisQualiteHebergementEmis', NumberType::class, array(
                    'attr' => array('class' => 'avis_emis'),
                )
            )
            ->add('avisQualiteHebergementSuivi', NumberType::class, array(
                    'attr' => array('class' => 'avis_suivi'),
                )
            )
            ->add('avisQualiteRestaurationEmis', NumberType::class, array(
                    'attr' => array('class' => 'avis_emis'),
                )
            )
            ->add('avisQualiteRestaurationSuivi', NumberType::class, array(
                    'attr' => array('class' => 'avis_suivi'),
                )
            )
            ->add('avisAnimationEmis', NumberType::class, array(
                    'attr' => array('class' => 'avis_emis'),
                )
            )
            ->add('avisAnimationSuivi', NumberType::class, array(
                    'attr' => array('class' => 'avis_suivi'),
                )
            )
            ->add('avisServiceTherapeutiqueEmis', NumberType::class, array(
                    'attr' => array('class' => 'avis_emis'),
                )
            )
            ->add('avisServiceTherapeutiqueSuivi', NumberType::class, array(
                    'attr' => array('class' => 'avis_suivi'),
                )
            )
            ->add('avisTravauxEquipementEmis', NumberType::class, array(
                    'attr' => array('class' => 'avis_emis'),
                )
            )
            ->add('avisTravauxEquipementSuivi', NumberType::class, array(
                    'attr' => array('class' => 'avis_suivi'),
                )
            )
            ->add('avisNatureServiceEmis', NumberType::class, array(
                    'attr' => array('class' => 'avis_emis'),
                )
            )
            ->add('avisNatureServiceSuivi', NumberType::class, array(
                    'attr' => array('class' => 'avis_suivi'),
                )
            )
            ->add('avisAffectationLocauxCollectifsEmis', NumberType::class, array(
                    'attr' => array('class' => 'avis_emis'),
                )
            )
            ->add('avisAffectationLocauxCollectifsSuivi', NumberType::class, array(
                    'attr' => array('class' => 'avis_suivi'),
                )
            )
            ->add('avisEntretienLocauxEmis', NumberType::class, array(
                    'attr' => array('class' => 'avis_emis'),
                )
            )
            ->add('avisEntretienLocauxSuivi', NumberType::class, array(
                    'attr' => array('class' => 'avis_suivi'),
                )
            )
            ->add('avisVieInstitutionnelleEmis', NumberType::class, array(
                    'attr' => array('class' => 'avis_emis'),
                )
            )
            ->add('avisVieInstitutionnelleSuivi', NumberType::class, array(
                    'attr' => array('class' => 'avis_suivi'),
                )
            )
            ->add('avisCommunicationExterneEmis', NumberType::class, array(
                    'attr' => array('class' => 'avis_emis'),
                )
            )
            ->add('avisCommunicationExterneSuivi', NumberType::class, array(
                    'attr' => array('class' => 'avis_suivi'),
                )
            )
            ->add('avisAutreEmis', NumberType::class, array(
                    'attr' => array('class' => 'avis_emis'),
                )
            )
            ->add('avisAutreSuivi', NumberType::class, array(
                    'attr' => array('class' => 'avis_suivi'),
                )
            )
            ->add('sumEmis', SumType::class, array(
                    'mapped' => false,
                    'type_class' => 'avis_emis',
                    'attr' => array('disabled' => 'disabled', 'class' => 'bold'),
                )
            )
            ->add('sumSuivi', SumType::class, array(
                    'mapped' => false,
                    'type_class' => 'avis_suivi',
                    'attr' => array('disabled' => 'disabled', 'class' => 'bold'),
                )
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\ConseilVieSocialeAvis',
            'translation_domain' => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getBlockPrefix()
    {
        return 'conseilVieSocialeAvis';
    }
}
