<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 22/01/14
 * Time: 14:27
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\LivretAccueil as BaseLivretAccueil;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class LivretAccueil.
 *
 * @author Michaël VEROUX
 */
class LivretAccueil extends BaseLivretAccueil implements GroupSequenceProviderInterface
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var Esms
     */
    protected $esms;

    public function __clone()
    {
        $this->id = null;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $esms
     */
    public function setEsms($esms)
    {
        $this->esms = $esms;
    }

    /**
     * @return mixed
     */
    public function getEsms()
    {
        return $this->esms;
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isExist()
    {
        if (null === $this->exist) {
            $this->exist = null !== $this->getAnnee()
                           || null !== $this->getPossessionLivret()
                           || null !== $this->getPossessionMoment()
                           || null !== $this->getRemisePresentation()
                           || null !== $this->getRemiseVisite()
                           || null !== $this->getElement()
            ;
        }

        return $this->exist;
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $transPrefix = 'oru_esms_livretAccueil.';
        $groups = array();

        if ($this->isExist()) {
            $groups[] = 'laExistTrue';
        } else {
            $groups[] = 'laExistFalse';
        }

        $possessionLivretChoix = array_flip($this->getEsms()->getTranslatedChoicesByKey($transPrefix.'possessionLivret'));

        if ($this->getPossessionLivret() === end($possessionLivretChoix)) {
            $groups[] = 'possessionLivretFalse';
        }

        $remisePresentationChoix = array_flip($this->getEsms()->getTranslatedChoicesByKey($transPrefix.'remisePresentation'));

        if ($this->getRemisePresentation() === end($remisePresentationChoix)) {
            $groups[] = 'remisePresentationFalse';
        }

        $elementChoix = array_flip($this->getEsms()->getTranslatedChoicesByKey($transPrefix.'element'));

        if (false !== strpos($this->getElement(), end($elementChoix))) {
            $groups[] = 'elementAutreTrue';
        }

        return $groups;
    }
}
