<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 12:06
 */

namespace Oru\Bundle\EsmsBundle\Model;

use Oru\Bundle\FormIncrementalBundle\Annotation\FieldValidity;

/**
 * Class ContratSoutien.
 *
 * @author Michaël VEROUX
 */
class ContratSoutien
{
    /**
     * @var null|bool
     *
     * @FieldValidity(start=2015)
     */
    protected $concerne = true;

    /**
     * @var string|null
     */
    protected $difficultes = null;

    /**
     * @param bool|null $concerne
     *
     * @return $this
     */
    public function setConcerne($concerne)
    {
        $this->concerne = $concerne;

        return $this;
    }

    /**
     * @return bool|null
     */
    public function getConcerne()
    {
        return $this->concerne;
    }

    /**
     * @param string|null $difficultes
     */
    public function setDifficultes($difficultes)
    {
        $this->difficultes = $difficultes;
    }

    /**
     * @return string|null
     */
    public function getDifficultes()
    {
        return $this->difficultes;
    }
}
