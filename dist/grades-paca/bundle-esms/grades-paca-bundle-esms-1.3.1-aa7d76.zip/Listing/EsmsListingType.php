<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 25/02/14
 * Time: 13:14
 */

namespace Oru\Bundle\EsmsBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EsmsListingType extends AbstractListingType
{
    protected $granted = array();

    /**
     * @var bool
     */
    protected $deleted = false;

    public function __construct($deleted = false)
    {
        $this->deleted = $deleted;
    }

    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('identification', null, array(
                    'sort' => 'et.nom',
                    'label' => 'oru_esms.identification',
                    'translation_domain' => 'OruEsmsBundle',
                )
            )
            ->add('finessEtablissement', null, array(
                    'sort' => 'et.finessGeographique',
                    'label' => 'oru_esms_etablissement.finess',
                    'translation_domain' => 'OruEsmsBundle',
                )
            )
            ->add('increment', null, array(
                    'sort' => 'e.created',
                    'label' => 'oru_esms.increment',
                    'translation_domain' => 'OruEsmsBundle',
                )
            )
            ->add('complete', null, array(
                    'sort' => 'e.complete',
                    'label' => 'oru_esms.complete',
                    'translation_domain' => 'OruEsmsBundle',
                )
            )
            ->add('show', 'object_action', array(
                    'route' => 'oru_esms_show',
                    'label' => 'show',
                )
            )
            ->add('edit', 'object_action', array(
                    'route' => 'oru_esms_edit',
                    'label' => 'edit',
                    'role' => 'ORU_ESMS_EDIT',
                )
            )
        ;

        if ($this->deleted) {
            $builder
                ->add('restaure', 'object_action', array(
                        'route' => 'oru_esms_restaure',
                        'label' => 'listing.action.desarchive',
                        'role' => 'ROLE_ESMS_DELETE',
                        'attr' => array('class' => 'restaure'),
                    )
                )
            ;
        } else {
            $builder
                ->add('delete', 'object_action', array(
                        'route' => 'oru_esms_delete',
                        'label' => 'listing.action.archive',
                        'role' => 'ROLE_ESMS_DELETE',
                        'attr' => array('class' => 'delete'),
                    )
                )
            ;
        }

        $builder
            ->add('open', 'object_action', array(
                    'route' => 'oru_esms_open',
                    'label' => 'open',
                    'role' => 'ORU_ESMS_UNLOCK',
                )
            )
            ->add('new', 'list_action', array(
                    'route' => 'oru_esms_pre_new',
                    'label' => 'listing.action.new',
                    'attr' => array('id' => 'esms_new', 'onclick' => 'return false;'),
                    'role' => 'ORU_ESMS_EDIT',
                )
            )
        ;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'oru_esms_listing';
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\Esms',
        ));
    }
}
