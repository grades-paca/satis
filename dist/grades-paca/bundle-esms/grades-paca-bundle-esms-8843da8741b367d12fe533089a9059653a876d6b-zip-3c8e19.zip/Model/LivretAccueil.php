<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 10:46
 */

namespace Oru\Bundle\EsmsBundle\Model;

/**
 * Class LivretAccueil
 * @package Oru\Bundle\EsmsBundle\Model
 * @author Michaël VEROUX
 */
class LivretAccueil
{
    /**
     * @var boolean|null
     */
    protected $exist = null;

    /**
     * @var string|null
     */
    protected $annee = null;

    /**
     * @var string|null
     */
    protected $inexistantDetail = null;

    /**
     * @var string|null
     */
    protected $possessionLivret = null;

    /**
     * @var string|null
     */
    protected $possessionNonDetail = null;

    /**
     * @var string|null
     */
    protected $possessionMoment = null;

    /**
     * @var string|null
     */
    protected $remisePresentation = null;

    /**
     * @var string|null
     */
    protected $remisePresentationJamaisDetail = null;

    /**
     * @var string|null
     */
    protected $remiseVisite = null;

    /**
     * @var string|null
     */
    protected $element = null;

    /**
     * @var string|null
     */
    protected $elementAutre = null;

    /**
     * @param bool|null $exist
     * @return $this
     */
    public function setExist($exist)
    {
        $this->exist = $exist;

        return $this;
    }

    /**
     * @param string|null $annee
     */
    public function setAnnee($annee)
    {
        $this->annee = $annee;
    }

    /**
     * @return string|null
     */
    public function getAnnee()
    {
        return $this->annee;
    }

    /**
     * @param string|null $element
     */
    public function setElement($element)
    {
        $this->element = $element;
    }

    /**
     * @return string|null
     */
    public function getElement()
    {
        return $this->element;
    }

    /**
     * @param string|null $elementAutre
     */
    public function setElementAutre($elementAutre)
    {
        $this->elementAutre = $elementAutre;
    }

    /**
     * @return string|null
     */
    public function getElementAutre()
    {
        return $this->elementAutre;
    }

    /**
     * @param string|null $inexistantDetail
     */
    public function setInexistantDetail($inexistantDetail)
    {
        $this->inexistantDetail = $inexistantDetail;
    }

    /**
     * @return string|null
     */
    public function getInexistantDetail()
    {
        return $this->inexistantDetail;
    }

    /**
     * @param string|null $possessionLivret
     */
    public function setPossessionLivret($possessionLivret)
    {
        $this->possessionLivret = $possessionLivret;
    }

    /**
     * @return string|null
     */
    public function getPossessionLivret()
    {
        return $this->possessionLivret;
    }

    /**
     * @param string|null $possessionMoment
     */
    public function setPossessionMoment($possessionMoment)
    {
        $this->possessionMoment = $possessionMoment;
    }

    /**
     * @return string|null
     */
    public function getPossessionMoment()
    {
        return $this->possessionMoment;
    }

    /**
     * @param string|null $possessionNonDetail
     */
    public function setPossessionNonDetail($possessionNonDetail)
    {
        $this->possessionNonDetail = $possessionNonDetail;
    }

    /**
     * @return string|null
     */
    public function getPossessionNonDetail()
    {
        return $this->possessionNonDetail;
    }

    /**
     * @param string|null $remisePresentation
     */
    public function setRemisePresentation($remisePresentation)
    {
        $this->remisePresentation = $remisePresentation;
    }

    /**
     * @return string|null
     */
    public function getRemisePresentation()
    {
        return $this->remisePresentation;
    }

    /**
     * @param string|null $remisePresentationJamaisDetail
     */
    public function setRemisePresentationJamaisDetail($remisePresentationJamaisDetail)
    {
        $this->remisePresentationJamaisDetail = $remisePresentationJamaisDetail;
    }

    /**
     * @return string|null
     */
    public function getRemisePresentationJamaisDetail()
    {
        return $this->remisePresentationJamaisDetail;
    }

    /**
     * @param string|null $remiseVisite
     */
    public function setRemiseVisite($remiseVisite)
    {
        $this->remiseVisite = $remiseVisite;
    }

    /**
     * @return string|null
     */
    public function getRemiseVisite()
    {
        return $this->remiseVisite;
    }
}