<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 03/06/2014
 * Time: 16:10
 */

namespace Oru\Bundle\EsmsBundle\Model;

/**
 * Class Reglement
 * @package Oru\Bundle\EsmsBundle\Model
 * @author Michaël VEROUX
 */
class Reglement
{
    /**
     * @var string|null
     */
    protected $reglementFonctionnement = null;

    /**
     * @var string|null
     */
    protected $reglementFonctionnementNonDetail = null;

    /**
     * @var string|null
     */
    protected $reglementRemis = null;

    /**
     * @var string|null
     */
    protected $reglementAffiche = null;

    /**
     * @var string|null
     */
    protected $reglementRemisIntervenants = null;

    /**
     * @var string|null
     */
    protected $reglementEvoque = null;

    /**
     * @param string|null $reglementAffiche
     */
    public function setReglementAffiche($reglementAffiche)
    {
        $this->reglementAffiche = $reglementAffiche;
    }

    /**
     * @return string|null
     */
    public function getReglementAffiche()
    {
        return $this->reglementAffiche;
    }

    /**
     * @param string|null $reglementEvoque
     */
    public function setReglementEvoque($reglementEvoque)
    {
        $this->reglementEvoque = $reglementEvoque;
    }

    /**
     * @return string|null
     */
    public function getReglementEvoque()
    {
        return $this->reglementEvoque;
    }

    /**
     * @param string|null $reglementFonctionnement
     */
    public function setReglementFonctionnement($reglementFonctionnement)
    {
        $this->reglementFonctionnement = $reglementFonctionnement;
    }

    /**
     * @return string|null
     */
    public function getReglementFonctionnement()
    {
        return $this->reglementFonctionnement;
    }

    /**
     * @param string|null $reglementFonctionnementNonDetail
     */
    public function setReglementFonctionnementNonDetail($reglementFonctionnementNonDetail)
    {
        $this->reglementFonctionnementNonDetail = $reglementFonctionnementNonDetail;
    }

    /**
     * @return string|null
     */
    public function getReglementFonctionnementNonDetail()
    {
        return $this->reglementFonctionnementNonDetail;
    }

    /**
     * @param string|null $reglementRemis
     */
    public function setReglementRemis($reglementRemis)
    {
        $this->reglementRemis = $reglementRemis;
    }

    /**
     * @return string|null
     */
    public function getReglementRemis()
    {
        return $this->reglementRemis;
    }

    /**
     * @param string|null $reglementRemisIntervenants
     */
    public function setReglementRemisIntervenants($reglementRemisIntervenants)
    {
        $this->reglementRemisIntervenants = $reglementRemisIntervenants;
    }

    /**
     * @return string|null
     */
    public function getReglementRemisIntervenants()
    {
        return $this->reglementRemisIntervenants;
    }
}