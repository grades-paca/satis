<?php
/**
 * Author: Michaël VEROUX
 * Date: 29/01/15
 * Time: 12:08
 */

namespace Oru\Bundle\EsmsBundle\Doctrine\Query\Mysql;

use Doctrine\ORM\Query\AST\Functions\FunctionNode;
use Doctrine\ORM\Query\Lexer;

/**
 * Class Year
 * @package Oru\Bundle\EsmsBundle\Doctrine\Query\Mysql
 * @author Michaël VEROUX
 */
class Year extends FunctionNode
{
    /**
     * @var
     */
    public $date;

    /**
     * @param \Doctrine\ORM\Query\SqlWalker $sqlWalker
     * @return string
     * @author Michaël VEROUX
     */
    public function getSql(\Doctrine\ORM\Query\SqlWalker $sqlWalker)
    {
        return "YEAR(" . $sqlWalker->walkArithmeticPrimary($this->date) . ")";
    }

    /**
     * @param \Doctrine\ORM\Query\Parser $parser
     * @author Michaël VEROUX
     */
    public function parse(\Doctrine\ORM\Query\Parser $parser)
    {
        $lexer = $parser->getLexer();
        $parser->match(Lexer::T_IDENTIFIER);
        $parser->match(Lexer::T_OPEN_PARENTHESIS);
        $this->date = $parser->ArithmeticPrimary();
        $parser->match(Lexer::T_CLOSE_PARENTHESIS);
    }
}