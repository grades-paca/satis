<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 22/01/14
 * Time: 13:54
 */

namespace Oru\Bundle\EsmsBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class DifficulteType
 * @package Oru\Bundle\EsmsBundle\Form\Type
 * @author Michaël VEROUX
 */
class DifficulteType extends AbstractType
{
    static public $baseChoices = array(
        'Très facile'           =>  'Très facile',
        'Plutôt facile'         =>  'Plutôt facile',
        'Plutôt pas facile'     =>  'Plutôt pas facile',
        'Difficile'             =>  'Difficile',
    );

    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'choices'           => static::$baseChoices,
            'placeholder'       => '----choix----',
        ));

        parent::configureOptions($resolver);
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getParent()
    {
        return 'choice';
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'difficulte';
    }
}