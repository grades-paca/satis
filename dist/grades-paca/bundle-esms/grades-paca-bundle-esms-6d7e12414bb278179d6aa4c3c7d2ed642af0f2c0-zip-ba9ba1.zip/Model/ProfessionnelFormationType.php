<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 13/null1/14
 * Time: 15:58
 */

namespace Oru\Bundle\EsmsBundle\Model;

/**
 * Class ProfessionnelFormationType
 * @package Oru\Bundle\EsmsBundle\Model
 * @author Michaël VEROUX
 */
class ProfessionnelFormationType
{
    /**
     * @var string|null
     */
    protected $medicalForme = null;

    /**
     * @var string|null
     */
    protected $paramedicalForme = null;

    /**
     * @var string|null
     */
    protected $socialForme = null;

    /**
     * @var string|null
     */
    protected $administratifForme = null;

    /**
     * @var string|null
     */
    protected $educatifForme = null;

    /**
     * @var string|null
     */
    protected $professionnelFormation = null;

    /**
     * @param string|null $administratifForme
     */
    public function setAdministratifForme($administratifForme)
    {
        $this->administratifForme = $administratifForme;
    }

    /**
     * @return string|null
     */
    public function getAdministratifForme()
    {
        return $this->administratifForme;
    }

    /**
     * @param string|null $educatifForme
     */
    public function setEducatifForme($educatifForme)
    {
        $this->educatifForme = $educatifForme;
    }

    /**
     * @return string|null
     */
    public function getEducatifForme()
    {
        return $this->educatifForme;
    }

    /**
     * @param string|null $medicalForme
     */
    public function setMedicalForme($medicalForme)
    {
        $this->medicalForme = $medicalForme;
    }

    /**
     * @return string|null
     */
    public function getMedicalForme()
    {
        return $this->medicalForme;
    }

    /**
     * @param string|null $paramedicalForme
     */
    public function setParamedicalForme($paramedicalForme)
    {
        $this->paramedicalForme = $paramedicalForme;
    }

    /**
     * @return string|null
     */
    public function getParamedicalForme()
    {
        return $this->paramedicalForme;
    }

    /**
     * @param string|null $socialForme
     */
    public function setSocialForme($socialForme)
    {
        $this->socialForme = $socialForme;
    }

    /**
     * @return string|null
     */
    public function getSocialForme()
    {
        return $this->socialForme;
    }

    /**
     * @param ProfessionnelFormation|null $professionnelFormation
     */
    public function setProfessionnelFormation(ProfessionnelFormation $professionnelFormation = null)
    {
        $this->professionnelFormation = $professionnelFormation;
    }

    /**
     * @return ProfessionnelFormation|null
     */
    public function getProfessionnelFormation()
    {
        return $this->professionnelFormation;
    }
}