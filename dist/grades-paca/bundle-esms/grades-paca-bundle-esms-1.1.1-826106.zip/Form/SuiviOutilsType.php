<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\EsmsBundle\Entity\SuiviOutils;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class SuiviOutilsType
 * @package Oru\Bundle\EsmsBundle\Form
 * @author Michaël VEROUX
 */
class SuiviOutilsType extends AbstractType
{
    /**
     * @var \Oru\Bundle\EsmsBundle\Choice\ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param ChoiceProvider $choiceProvider
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(ChoiceProvider $choiceProvider, IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->choiceProvider = $choiceProvider;
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choicesPrefix = 'oru_esms_' . $this->getName();

        $builder
            ->add('difficultes', 'oru_section'
            )
            ->add('difficultesLivretBoolean', 'oru_checked_detail', array(
                    'detail'    =>  'difficultesLivret',
                )
            )
            ->add('difficultesLivret'
            )
            ->add('difficultesInstancesParticipationBoolean', 'oru_checked_detail', array(
                    'detail'    =>  'difficultesInstancesParticipation',
                )
            )
            ->add('difficultesInstancesParticipation'
            )
            ->add('difficultesContratSejourBoolean', 'oru_checked_detail', array(
                    'detail'    =>  'difficultesContratSejour',
                )
            )
            ->add('difficultesContratSejour'
            )
            ->add('difficultesReglementFonctionnementBoolean', 'oru_checked_detail', array(
                    'detail'    =>  'difficultesReglementFonctionnement',
                )
            )
            ->add('difficultesReglementFonctionnement'
            )
            ->add('difficultesProjetEtablissementBoolean', 'oru_checked_detail', array(
                    'detail'    =>  'difficultesProjetEtablissement',
                )
            )
            ->add('difficultesProjetEtablissement'
            )
            ->add('difficultesEvaluationsInternesBoolean', 'oru_checked_detail', array(
                    'detail'    =>  'difficultesEvaluationsInternes',
                )
            )
            ->add('difficultesEvaluationsInternes'
            )
            ->add('difficultesEvaluationsExternesBoolean', 'oru_checked_detail', array(
                    'detail'    =>  'difficultesEvaluationsExternes',
                )
            )
            ->add('difficultesEvaluationsExternes'
            )
            ->add('difficultesEnd', 'oru_section', array(
                    'label'     =>  ' ',
                )
            )
            ->add('documentAdapteDeficiences', 'frequence', array(
                    'placeholder'       =>  'Non concerné',
                    'justify'           =>  array('documentAdapteDeficiencesNonDetail'),
                )
            )
            ->add('documentAdapteDeficiencesNonDetail'
            )
            ->add('documentAdapteAccompagnes', 'oru_choices_to_string', array(
                    'expanded'      =>  true,
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'documentAdapteAccompagnes', 4),
                )
            )
            ->add('actualisation', 'oru_section'
            )
            ->add('actualisationLivretBoolean', 'oru_conditional', array(
                    'expanded'          =>  true,
                    'choices'           =>  array(
                        '1'     =>  'Oui',
                        '0'     =>  'Jamais actualisé',
                    ),
                    'conditionals'      =>  array(
                        '1'     =>  array('actualisationLivret'),
                    ),
                )
            )
            ->add('actualisationLivret', null, array(
                    'attr'          =>  array('min' => 1980),
                )
            )
            ->add('actualisationContratSejourBoolean', 'oru_conditional', array(
                    'expanded'          =>  true,
                    'choices'           =>  array(
                        '1'     =>  'Oui',
                        '0'     =>  'Jamais actualisé',
                    ),
                    'conditionals'      =>  array(
                        '1'     =>  array('actualisationContratSejour'),
                    ),
                )
            )
            ->add('actualisationContratSejour', null, array(
                    'attr'          =>  array('min' => 1980),
                )
            )
            ->add('actualisationProjetEtablissementBoolean', 'oru_conditional', array(
                    'expanded'          =>  true,
                    'choices'           =>  array(
                        '1'     =>  'Oui',
                        '0'     =>  'Jamais actualisé',
                    ),
                    'conditionals'      =>  array(
                        '1'     =>  array('actualisationProjetEtablissement'),
                    ),
                )
            )
            ->add('actualisationProjetEtablissement', null, array(
                    'attr'          =>  array('min' => 1980),
                )
            )
            ->add('actualisationEnd', 'oru_section', array(
                    'label'     =>  ' ',
                )
            )
            ->add('outilsEvaluation', 'oru_section'
            )
            ->add('outilsEvaluationLivretBoolean', 'oru_conditional', array(
                    'expanded'          =>  true,
                    'choices'           =>  array(
                        '1'     =>  'Oui',
                        '0'     =>  'Jamais',
                    ),
                    'conditionals'      =>  array(
                        '1'     =>  array('outilsEvaluationLivret','outilsEvaluationLivretQui'),
                    ),
                )
            )
            ->add('outilsEvaluationLivret'
            )
            ->add('outilsEvaluationLivretQui', 'personnes'
            )
            ->add('outilsEvaluationContratSejourBoolean', 'oru_conditional', array(
                    'expanded'          =>  true,
                    'choices'           =>  array(
                        '1'     =>  'Oui',
                        '0'     =>  'Jamais',
                    ),
                    'conditionals'      =>  array(
                        '1'     =>  array('outilsEvaluationContratSejour','outilsEvaluationContratSejourQui'),
                    ),
                )
            )
            ->add('outilsEvaluationContratSejour'
            )
            ->add('outilsEvaluationContratSejourQui', 'personnes'
            )
            ->add('outilsEvaluationLivretProjetEtablissementBoolean', 'oru_conditional', array(
                    'expanded'          =>  true,
                    'choices'           =>  array(
                        '1'     =>  'Oui',
                        '0'     =>  'Jamais',
                    ),
                    'conditionals'      =>  array(
                        '1'     =>  array('outilsEvaluationLivretProjetEtablissement','outilsEvaluationLivretProjetEtablissementQui'),
                    ),
                )
            )
            ->add('outilsEvaluationLivretProjetEtablissement'
            )
            ->add('outilsEvaluationLivretProjetEtablissementQui', 'personnes'
            )
            ->add('outilsEvaluationLivretReglementBoolean', 'oru_conditional', array(
                    'expanded'          =>  true,
                    'choices'           =>  array(
                        '1'     =>  'Oui',
                        '0'     =>  'Jamais',
                    ),
                    'conditionals'      =>  array(
                        '1'     =>  array('outilsEvaluationLivretReglement','outilsEvaluationLivretReglementQui'),
                    ),
                )
            )
            ->add('outilsEvaluationLivretReglement'
            )
            ->add('outilsEvaluationLivretReglementQui', 'personnes'
            )
            ->add('outilsEvaluationEnd', 'oru_section', array(
                    'label'     =>  ' ',
                )
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\SuiviOutils',
            'translation_domain'    => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getName()
    {
        return 'suiviOutils';
    }
} 