<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class EvaluationsType
 * @package Oru\Bundle\EsmsBundle\Form
 * @author Michaël VEROUX
 */
class EvaluationsType extends AbstractType
{
    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('evaluations', 'oru_section'
            )
            ->add('interne', 'oru_oui_non_detail', array(
                    'detail'        =>  'interneDate',
                    'on_no'         =>  false,
                )
            )
            ->add('interneDate', null, array(
                    'attr'          =>  array('min' => 1980),
                )
            )
            ->add('externe', 'oru_oui_non_detail', array(
                    'detail'        =>  'externeDate',
                    'on_no'         =>  false,
                )
            )
            ->add('externeDate', null, array(
                    'attr'          =>  array('min' => 1980),
                )
            )
            ->add('nonEvaluationDetail'
            )
            ->add('resultats', 'oru_section'
            )
            ->add('resultatInterne', 'oru_oui_non'
            )
            ->add('resultatExterne', 'oru_oui_non'
            )
            ->add('nonEvaluationResultatDetail'
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\Evaluations',
            'translation_domain'    => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getName()
    {
        return 'evaluations';
    }
} 