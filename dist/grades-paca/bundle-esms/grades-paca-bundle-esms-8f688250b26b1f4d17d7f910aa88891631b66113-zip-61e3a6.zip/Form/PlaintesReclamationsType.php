<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class PlaintesReclamationsType
 * @package Oru\Bundle\EsmsBundle\Form
 * @author Michaël VEROUX
 */
class PlaintesReclamationsType extends AbstractType
{
    /**
     * @var \Oru\Bundle\EsmsBundle\Choice\ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param ChoiceProvider $choiceProvider
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(ChoiceProvider $choiceProvider, IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->choiceProvider = $choiceProvider;
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choicesPrefix = 'oru_esms_' . $this->getName();

        $builder
            ->add('processus', 'oru_conditional', array(
                    'placeholder'       =>  '---choix---',
                    'choices'           =>  array(
                        'oui'             =>  'oui',
                        'non'             =>  'non',
                        'en cours'        =>  'en cours',
                        'en projet'       =>  'en projet',
                    ),
                    'conditionals'          =>  array(
                        'oui'   =>  array('plaintesTotal','plaintesDossierMedical'),
                    ),
                )
            )
            ->add('plaintesTotal'
            )
            ->add('plaintesDossierMedical'
            )
            ->add('plaintesThemesListe', 'oru_choices_to_string', array(
                    'expanded'      =>  true,
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'plaintesThemesListe', 9),
                )
            )
            ->add('plaintesThemes'
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\PlaintesReclamations',
            'translation_domain'    => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getName()
    {
        return 'plaintesReclamations';
    }
} 