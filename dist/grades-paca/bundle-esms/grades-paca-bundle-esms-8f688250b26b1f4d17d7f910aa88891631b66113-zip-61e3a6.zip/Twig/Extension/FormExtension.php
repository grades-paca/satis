<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 17/01/14
 * Time: 09:12
 */

namespace Oru\Bundle\EsmsBundle\Twig\Extension;

use Symfony\Component\Form\FormView;

/**
 * Class FormExtension
 * @package Oru\Bundle\EsmsBundle\Twig\Extension
 * @author Michaël VEROUX
 */
class FormExtension extends \Twig_Extension
{
    /**
     * {@inheritdoc}
     */
    public function getFunctions()
    {
        return array(
            new \Twig_SimpleFunction('form_suffixed', array($this, 'getSuffixed')),
        );
    }

    /**
     * @param FormView $view
     * @param string $suffix
     * @return array
     */
    public function getSuffixed(FormView $view, $suffix)
    {
        $suffixed = array();

        foreach($view as $name => $element)
        {
            if(0 < $pos = strpos($name,$suffix))
            {
                $suffixed[] = substr($name, 0, $pos);
            }
        }
        return $suffixed;
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getName()
    {
        return 'oru_esms.twig.extension.form';
    }
}