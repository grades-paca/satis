<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 16/01/14
 * Time: 17:01
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\ProfessionnelFormationTheme as BaseProfessionnelFormationTheme;
use Oru\Bundle\FormIncrementalBundle\Entity\FormIncrementalInterface;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class ProfessionnelFormationTheme
 * @package Oru\Bundle\EsmsBundle\Entity
 * @author Michaël VEROUX
 */
class ProfessionnelFormationTheme extends BaseProfessionnelFormationTheme implements GroupSequenceProviderInterface, FormIncrementalInterface
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Return current increment of object (year, month or what you want...)
     * @return int
     * @author Michaël VEROUX
     */
    public function getIncrement()
    {
        return $this->getProfessionnelFormation()->getIncrement();
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $groups = array();

        if(0 < strlen((string)$this->getAutreDetail()))
        {
            $groups[] = 'autreDetailNotNull';
        }

        return $groups;
    }

    public function __clone()
    {
        $this->id = null;
    }
} 