<?php

namespace Oru\Bundle\EsmsBundle\Form\Type;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EsmsStatutType extends AbstractType
{
    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'choices' => array(
                '1' => 'Clôturé',
                '0' => 'En cours de rédaction',
                'placeholder' => 'Indifférent'

            ),
            'multiple' => false,
            'expanded' => true,
        ));
    }

    /**
     * @return string
     */
    public function getParent()
    {
        return 'choice';
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'esms_statut';
    }
}