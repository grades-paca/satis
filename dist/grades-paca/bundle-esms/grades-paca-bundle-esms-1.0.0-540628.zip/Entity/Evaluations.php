<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 22/01/14
 * Time: 18:51
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\Evaluations as BaseEvaluations;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class Evaluations
 * @package Oru\Bundle\EsmsBundle\Entity
 * @author Michaël VEROUX
 */
class Evaluations extends BaseEvaluations implements GroupSequenceProviderInterface
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var Esms
     */
    protected $esms;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $esms
     */
    public function setEsms($esms)
    {
        $this->esms = $esms;
    }

    /**
     * @return mixed
     */
    public function getEsms()
    {
        return $this->esms;
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $groups = array();

        if($this->getInterne())
        {
            $groups[] = 'interneTrue';
        }
        elseif(null !== $this->getInterne())
        {
            $groups[] = 'interneFalse';
        }

        if($this->getExterne())
        {
            $groups[] = 'externeTrue';
        }
        elseif(null !== $this->getExterne())
        {
            $groups[] = 'externeFalse';
        }

        if(2 === count(array_intersect(array('interneFalse','externeFalse'), $groups)))
        {
            $groups[] = 'interneExterneFalse';
        }

        if(
            !$this->getResultatInterne() &&
            null !== $this->getResultatInterne() &&
            !$this->getResultatExterne() &&
            null !== $this->getResultatExterne()
        )
        {
            $groups[] = 'resultatInterneExterneFalse';
        }

        return $groups;
    }

    public function __clone()
    {
        $this->id = null;
    }
} 