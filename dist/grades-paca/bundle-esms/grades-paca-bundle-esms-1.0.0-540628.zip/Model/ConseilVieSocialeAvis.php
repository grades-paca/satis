<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 21/01/14
 * Time: 11:14
 */

namespace Oru\Bundle\EsmsBundle\Model;

/**
 * Class ConseilVieSocialeAvis
 * @package Oru\Bundle\EsmsBundle\Model
 * @author Michaël VEROUX
 */
class ConseilVieSocialeAvis
{
    /**
     * @var string|null
     */
    protected $avisOrganisationInterieureEmis = null;

    /**
     * @var string|null
     */
    protected $avisOrganisationInterieureSuivi = null;

    /**
     * @var string|null
     */
    protected $avisQualiteHebergementEmis = null;

    /**
     * @var string|null
     */
    protected $avisQualiteHebergementSuivi = null;

    /**
     * @var string|null
     */
    protected $avisQualiteRestaurationEmis = null;

    /**
     * @var string|null
     */
    protected $avisQualiteRestaurationSuivi = null;

    /**
     * @var string|null
     */
    protected $avisAnimationEmis = null;

    /**
     * @var string|null
     */
    protected $avisAnimationSuivi = null;

    /**
     * @var string|null
     */
    protected $avisServiceTherapeutiqueEmis = null;

    /**
     * @var string|null
     */
    protected $avisServiceTherapeutiqueSuivi = null;

    /**
     * @var string|null
     */
    protected $avisTravauxEquipementEmis = null;

    /**
     * @var string|null
     */
    protected $avisTravauxEquipementSuivi = null;

    /**
     * @var string|null
     */
    protected $avisNatureServiceEmis = null;

    /**
     * @var string|null
     */
    protected $avisNatureServiceSuivi = null;

    /**
     * @var string|null
     */
    protected $avisAffectationLocauxCollectifsEmis = null;

    /**
     * @var string|null
     */
    protected $avisAffectationLocauxCollectifsSuivi = null;

    /**
     * @var string|null
     */
    protected $avisEntretienLocauxEmis = null;

    /**
     * @var string|null
     */
    protected $avisEntretienLocauxSuivi = null;

    /**
     * @var string|null
     */
    protected $avisVieInstitutionnelleEmis = null;

    /**
     * @var string|null
     */
    protected $avisVieInstitutionnelleSuivi = null;

    /**
     * @var string|null
     */
    protected $avisCommunicationExterneEmis = null;

    /**
     * @var string|null
     */
    protected $avisCommunicationExterneSuivi = null;

    /**
     * @var string|null
     */
    protected $avisAutreEmis = null;

    /**
     * @var string|null
     */
    protected $avisAutreSuivi = null;

    /**
     * @var string|null
     */
    protected $conseilVieSociale = null;

    /**
     * @param string|null $avisAffectationLocauxCollectifsEmis
     */
    public function setAvisAffectationLocauxCollectifsEmis($avisAffectationLocauxCollectifsEmis)
    {
        $this->avisAffectationLocauxCollectifsEmis = $avisAffectationLocauxCollectifsEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisAffectationLocauxCollectifsEmis()
    {
        return $this->avisAffectationLocauxCollectifsEmis;
    }

    /**
     * @param string|null $avisAffectationLocauxCollectifsSuivi
     */
    public function setAvisAffectationLocauxCollectifsSuivi($avisAffectationLocauxCollectifsSuivi)
    {
        $this->avisAffectationLocauxCollectifsSuivi = $avisAffectationLocauxCollectifsSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisAffectationLocauxCollectifsSuivi()
    {
        return $this->avisAffectationLocauxCollectifsSuivi;
    }

    /**
     * @param string|null $avisAnimationEmis
     */
    public function setAvisAnimationEmis($avisAnimationEmis)
    {
        $this->avisAnimationEmis = $avisAnimationEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisAnimationEmis()
    {
        return $this->avisAnimationEmis;
    }

    /**
     * @param string|null $avisAnimationSuivi
     */
    public function setAvisAnimationSuivi($avisAnimationSuivi)
    {
        $this->avisAnimationSuivi = $avisAnimationSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisAnimationSuivi()
    {
        return $this->avisAnimationSuivi;
    }

    /**
     * @param string|null $avisAutreEmis
     */
    public function setAvisAutreEmis($avisAutreEmis)
    {
        $this->avisAutreEmis = $avisAutreEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisAutreEmis()
    {
        return $this->avisAutreEmis;
    }

    /**
     * @param string|null $avisAutreSuivi
     */
    public function setAvisAutreSuivi($avisAutreSuivi)
    {
        $this->avisAutreSuivi = $avisAutreSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisAutreSuivi()
    {
        return $this->avisAutreSuivi;
    }

    /**
     * @param string|null $avisCommunicationExterneEmis
     */
    public function setAvisCommunicationExterneEmis($avisCommunicationExterneEmis)
    {
        $this->avisCommunicationExterneEmis = $avisCommunicationExterneEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisCommunicationExterneEmis()
    {
        return $this->avisCommunicationExterneEmis;
    }

    /**
     * @param string|null $avisCommunicationExterneSuivi
     */
    public function setAvisCommunicationExterneSuivi($avisCommunicationExterneSuivi)
    {
        $this->avisCommunicationExterneSuivi = $avisCommunicationExterneSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisCommunicationExterneSuivi()
    {
        return $this->avisCommunicationExterneSuivi;
    }

    /**
     * @param string|null $avisEntretienLocauxEmis
     */
    public function setAvisEntretienLocauxEmis($avisEntretienLocauxEmis)
    {
        $this->avisEntretienLocauxEmis = $avisEntretienLocauxEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisEntretienLocauxEmis()
    {
        return $this->avisEntretienLocauxEmis;
    }

    /**
     * @param string|null $avisEntretienLocauxSuivi
     */
    public function setAvisEntretienLocauxSuivi($avisEntretienLocauxSuivi)
    {
        $this->avisEntretienLocauxSuivi = $avisEntretienLocauxSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisEntretienLocauxSuivi()
    {
        return $this->avisEntretienLocauxSuivi;
    }

    /**
     * @param string|null $avisNatureServiceEmis
     */
    public function setAvisNatureServiceEmis($avisNatureServiceEmis)
    {
        $this->avisNatureServiceEmis = $avisNatureServiceEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisNatureServiceEmis()
    {
        return $this->avisNatureServiceEmis;
    }

    /**
     * @param string|null $avisNatureServiceSuivi
     */
    public function setAvisNatureServiceSuivi($avisNatureServiceSuivi)
    {
        $this->avisNatureServiceSuivi = $avisNatureServiceSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisNatureServiceSuivi()
    {
        return $this->avisNatureServiceSuivi;
    }

    /**
     * @param string|null $avisOrganisationInterieureEmis
     */
    public function setAvisOrganisationInterieureEmis($avisOrganisationInterieureEmis)
    {
        $this->avisOrganisationInterieureEmis = $avisOrganisationInterieureEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisOrganisationInterieureEmis()
    {
        return $this->avisOrganisationInterieureEmis;
    }

    /**
     * @param string|null $avisOrganisationInterieureSuivi
     */
    public function setAvisOrganisationInterieureSuivi($avisOrganisationInterieureSuivi)
    {
        $this->avisOrganisationInterieureSuivi = $avisOrganisationInterieureSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisOrganisationInterieureSuivi()
    {
        return $this->avisOrganisationInterieureSuivi;
    }

    /**
     * @param string|null $avisQualiteHebergementEmis
     */
    public function setAvisQualiteHebergementEmis($avisQualiteHebergementEmis)
    {
        $this->avisQualiteHebergementEmis = $avisQualiteHebergementEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisQualiteHebergementEmis()
    {
        return $this->avisQualiteHebergementEmis;
    }

    /**
     * @param string|null $avisQualiteHebergementSuivi
     */
    public function setAvisQualiteHebergementSuivi($avisQualiteHebergementSuivi)
    {
        $this->avisQualiteHebergementSuivi = $avisQualiteHebergementSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisQualiteHebergementSuivi()
    {
        return $this->avisQualiteHebergementSuivi;
    }

    /**
     * @param string|null $avisQualiteRestaurationEmis
     */
    public function setAvisQualiteRestaurationEmis($avisQualiteRestaurationEmis)
    {
        $this->avisQualiteRestaurationEmis = $avisQualiteRestaurationEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisQualiteRestaurationEmis()
    {
        return $this->avisQualiteRestaurationEmis;
    }

    /**
     * @param string|null $avisQualiteRestaurationSuivi
     */
    public function setAvisQualiteRestaurationSuivi($avisQualiteRestaurationSuivi)
    {
        $this->avisQualiteRestaurationSuivi = $avisQualiteRestaurationSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisQualiteRestaurationSuivi()
    {
        return $this->avisQualiteRestaurationSuivi;
    }

    /**
     * @param string|null $avisServiceTherapeutiqueEmis
     */
    public function setAvisServiceTherapeutiqueEmis($avisServiceTherapeutiqueEmis)
    {
        $this->avisServiceTherapeutiqueEmis = $avisServiceTherapeutiqueEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisServiceTherapeutiqueEmis()
    {
        return $this->avisServiceTherapeutiqueEmis;
    }

    /**
     * @param string|null $avisServiceTherapeutiqueSuivi
     */
    public function setAvisServiceTherapeutiqueSuivi($avisServiceTherapeutiqueSuivi)
    {
        $this->avisServiceTherapeutiqueSuivi = $avisServiceTherapeutiqueSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisServiceTherapeutiqueSuivi()
    {
        return $this->avisServiceTherapeutiqueSuivi;
    }

    /**
     * @param string|null $avisTravauxEquipementEmis
     */
    public function setAvisTravauxEquipementEmis($avisTravauxEquipementEmis)
    {
        $this->avisTravauxEquipementEmis = $avisTravauxEquipementEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisTravauxEquipementEmis()
    {
        return $this->avisTravauxEquipementEmis;
    }

    /**
     * @param string|null $avisTravauxEquipementSuivi
     */
    public function setAvisTravauxEquipementSuivi($avisTravauxEquipementSuivi)
    {
        $this->avisTravauxEquipementSuivi = $avisTravauxEquipementSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisTravauxEquipementSuivi()
    {
        return $this->avisTravauxEquipementSuivi;
    }

    /**
     * @param string|null $avisVieInstitutionnelleEmis
     */
    public function setAvisVieInstitutionnelleEmis($avisVieInstitutionnelleEmis)
    {
        $this->avisVieInstitutionnelleEmis = $avisVieInstitutionnelleEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisVieInstitutionnelleEmis()
    {
        return $this->avisVieInstitutionnelleEmis;
    }

    /**
     * @param string|null $avisVieInstitutionnelleSuivi
     */
    public function setAvisVieInstitutionnelleSuivi($avisVieInstitutionnelleSuivi)
    {
        $this->avisVieInstitutionnelleSuivi = $avisVieInstitutionnelleSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisVieInstitutionnelleSuivi()
    {
        return $this->avisVieInstitutionnelleSuivi;
    }

    /**
     * @param string|null $conseilVieSociale
     */
    public function setConseilVieSociale($conseilVieSociale)
    {
        $this->conseilVieSociale = $conseilVieSociale;
    }

    /**
     * @return string|null
     */
    public function getConseilVieSociale()
    {
        return $this->conseilVieSociale;
    }

} 