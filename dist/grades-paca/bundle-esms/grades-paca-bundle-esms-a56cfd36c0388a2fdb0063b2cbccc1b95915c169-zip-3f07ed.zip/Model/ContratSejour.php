<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 12:10
 */

namespace Oru\Bundle\EsmsBundle\Model;

use Oru\Bundle\FormIncrementalBundle\Annotation\FieldValidity;

/**
 * Class ContratSejour.
 *
 * @author Michaël VEROUX
 */
class ContratSejour
{
    /**
     * @var string|null
     */
    protected $signeJourAdmission = null;

    /**
     * @var string|null
     */
    protected $signeQuinzeJours = null;

    /**
     * @var string|null
     */
    protected $signeQuinzeTrenteJours = null;

    /**
     * @var string|null
     */
    protected $signePlusTrenteJours = null;

    /**
     * @var string|null
     */
    protected $avenantSixMois = null;

    /**
     * @var string|null
     */
    protected $avenantSixMoisJamais = null;

    /**
     * @var string|null
     */
    protected $personneParticipe = null;

    /**
     * @var string|null
     *
     * @FieldValidity(start=2015)
     */
    protected $personneParticipeNonDetailListe = null;

    /**
     * @var string|null
     */
    protected $personneParticipeNonDetail = null;

    /**
     * @var string|null
     */
    protected $clauseModification = null;

    /**
     * @var string|null
     */
    protected $information = null;

    /**
     * @var string|null
     */
    protected $informationAutre = null;

    /**
     * @var string|null
     */
    protected $reactualiseAnnuel = null;

    /**
     * @var string|null
     */
    protected $reactualiseAnnuelNonDetail = null;

    /**
     * @var string|null
     */
    protected $reglementFonctionnement = null;

    /**
     * @var string|null
     */
    protected $reglementFonctionnementNonDetail = null;

    /**
     * @var string|null
     */
    protected $reglementRemis = null;

    /**
     * @var string|null
     */
    protected $reglementAffiche = null;

    /**
     * @var string|null
     */
    protected $reglementRemisIntervenants = null;

    /**
     * @var string|null
     */
    protected $reglementEvoque = null;

    /**
     * @param string|null $avenantSixMois
     */
    public function setAvenantSixMois($avenantSixMois)
    {
        $this->avenantSixMois = $avenantSixMois;
    }

    /**
     * @return string|null
     */
    public function getAvenantSixMois()
    {
        return $this->avenantSixMois;
    }

    /**
     * @param string|null $avenantSixMoisJamais
     */
    public function setAvenantSixMoisJamais($avenantSixMoisJamais)
    {
        $this->avenantSixMoisJamais = $avenantSixMoisJamais;
    }

    /**
     * @return string|null
     */
    public function getAvenantSixMoisJamais()
    {
        return $this->avenantSixMoisJamais;
    }

    /**
     * @param string|null $clauseModification
     */
    public function setClauseModification($clauseModification)
    {
        $this->clauseModification = $clauseModification;
    }

    /**
     * @return string|null
     */
    public function getClauseModification()
    {
        return $this->clauseModification;
    }

    /**
     * @param string|null $information
     */
    public function setInformation($information)
    {
        $this->information = $information;
    }

    /**
     * @return string|null
     */
    public function getInformation()
    {
        return $this->information;
    }

    /**
     * @param string|null $informationAutre
     */
    public function setInformationAutre($informationAutre)
    {
        $this->informationAutre = $informationAutre;
    }

    /**
     * @return string|null
     */
    public function getInformationAutre()
    {
        return $this->informationAutre;
    }

    /**
     * @param string|null $personneParticipe
     */
    public function setPersonneParticipe($personneParticipe)
    {
        $this->personneParticipe = $personneParticipe;
    }

    /**
     * @return string|null
     */
    public function getPersonneParticipe()
    {
        return $this->personneParticipe;
    }

    /**
     * @param string|null $personneParticipeNonDetail
     */
    public function setPersonneParticipeNonDetail($personneParticipeNonDetail)
    {
        $this->personneParticipeNonDetail = $personneParticipeNonDetail;
    }

    /**
     * @return string|null
     */
    public function getPersonneParticipeNonDetail()
    {
        return $this->personneParticipeNonDetail;
    }

    /**
     * @param null|string $personneParticipeNonDetailListe
     *
     * @return $this
     */
    public function setPersonneParticipeNonDetailListe($personneParticipeNonDetailListe)
    {
        $this->personneParticipeNonDetailListe = $personneParticipeNonDetailListe;

        return $this;
    }

    /**
     * @return null|string
     */
    public function getPersonneParticipeNonDetailListe()
    {
        return $this->personneParticipeNonDetailListe;
    }

    /**
     * @param string|null $reactualiseAnnuel
     */
    public function setReactualiseAnnuel($reactualiseAnnuel)
    {
        $this->reactualiseAnnuel = $reactualiseAnnuel;
    }

    /**
     * @return string|null
     */
    public function getReactualiseAnnuel()
    {
        return $this->reactualiseAnnuel;
    }

    /**
     * @param string|null $reactualiseAnnuelNonDetail
     */
    public function setReactualiseAnnuelNonDetail($reactualiseAnnuelNonDetail)
    {
        $this->reactualiseAnnuelNonDetail = $reactualiseAnnuelNonDetail;
    }

    /**
     * @return string|null
     */
    public function getReactualiseAnnuelNonDetail()
    {
        return $this->reactualiseAnnuelNonDetail;
    }

    /**
     * @param string|null $reglementAffiche
     */
    public function setReglementAffiche($reglementAffiche)
    {
        $this->reglementAffiche = $reglementAffiche;
    }

    /**
     * @return string|null
     */
    public function getReglementAffiche()
    {
        return $this->reglementAffiche;
    }

    /**
     * @param string|null $reglementEvoque
     */
    public function setReglementEvoque($reglementEvoque)
    {
        $this->reglementEvoque = $reglementEvoque;
    }

    /**
     * @return string|null
     */
    public function getReglementEvoque()
    {
        return $this->reglementEvoque;
    }

    /**
     * @param string|null $reglementFonctionnement
     */
    public function setReglementFonctionnement($reglementFonctionnement)
    {
        $this->reglementFonctionnement = $reglementFonctionnement;
    }

    /**
     * @return string|null
     */
    public function getReglementFonctionnement()
    {
        return $this->reglementFonctionnement;
    }

    /**
     * @param string|null $reglementFonctionnementNonDetail
     */
    public function setReglementFonctionnementNonDetail($reglementFonctionnementNonDetail)
    {
        $this->reglementFonctionnementNonDetail = $reglementFonctionnementNonDetail;
    }

    /**
     * @return string|null
     */
    public function getReglementFonctionnementNonDetail()
    {
        return $this->reglementFonctionnementNonDetail;
    }

    /**
     * @param string|null $reglementRemis
     */
    public function setReglementRemis($reglementRemis)
    {
        $this->reglementRemis = $reglementRemis;
    }

    /**
     * @return string|null
     */
    public function getReglementRemis()
    {
        return $this->reglementRemis;
    }

    /**
     * @param string|null $reglementRemisIntervenants
     */
    public function setReglementRemisIntervenants($reglementRemisIntervenants)
    {
        $this->reglementRemisIntervenants = $reglementRemisIntervenants;
    }

    /**
     * @return string|null
     */
    public function getReglementRemisIntervenants()
    {
        return $this->reglementRemisIntervenants;
    }

    /**
     * @param string|null $signeJourAdmission
     */
    public function setSigneJourAdmission($signeJourAdmission)
    {
        $this->signeJourAdmission = $signeJourAdmission;
    }

    /**
     * @return string|null
     */
    public function getSigneJourAdmission()
    {
        return $this->signeJourAdmission;
    }

    /**
     * @param string|null $signePlusTrenteJours
     */
    public function setSignePlusTrenteJours($signePlusTrenteJours)
    {
        $this->signePlusTrenteJours = $signePlusTrenteJours;
    }

    /**
     * @return string|null
     */
    public function getSignePlusTrenteJours()
    {
        return $this->signePlusTrenteJours;
    }

    /**
     * @param string|null $signeQuinzeJours
     */
    public function setSigneQuinzeJours($signeQuinzeJours)
    {
        $this->signeQuinzeJours = $signeQuinzeJours;
    }

    /**
     * @return string|null
     */
    public function getSigneQuinzeJours()
    {
        return $this->signeQuinzeJours;
    }

    /**
     * @param string|null $signeQuinzeTrenteJours
     */
    public function setSigneQuinzeTrenteJours($signeQuinzeTrenteJours)
    {
        $this->signeQuinzeTrenteJours = $signeQuinzeTrenteJours;
    }

    /**
     * @return string|null
     */
    public function getSigneQuinzeTrenteJours()
    {
        return $this->signeQuinzeTrenteJours;
    }
}
