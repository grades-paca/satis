<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 09:44
 */

namespace Oru\Bundle\EsmsBundle\Model;

use Oru\Bundle\FormIncrementalBundle\Annotation\FieldValidity;

/**
 * Class AccesDonneesSante.
 *
 * @author Michaël VEROUX
 */
class AccesDonneesSante
{
    /**
     * @var string|null
     */
    protected $accesGeneraliste = null;

    /**
     * @var string|null
     */
    protected $accesInfirmier = null;

    /**
     * @var string|null
     */
    protected $accesKine = null;

    /**
     * @var string|null
     */
    protected $accesDentiste = null;

    /**
     * @var string|null
     */
    protected $accesPodologue = null;

    /**
     * @var string|null
     */
    protected $accesOphtalmo = null;

    /**
     * @var string|null
     */
    protected $accesPsy = null;

    /**
     * @var string|null
     *
     * @FieldValidity(start=2015)
     */
    protected $accesDifficulteListe = null;

    /**
     * @var string|null
     */
    protected $accesDifficulte = null;

    /**
     * @var string|null
     */
    protected $accesDonneesDossierMedical = null;

    /**
     * @var string|null
     */
    protected $accesDonneesDecision = null;

    /**
     * @var string|null
     */
    protected $accesDonneesSoinsProposes = null;

    /**
     * @var string|null
     */
    protected $accesDonneestraitantChoix = null;

    /**
     * @param string|null $accesDentiste
     */
    public function setAccesDentiste($accesDentiste)
    {
        $this->accesDentiste = $accesDentiste;
    }

    /**
     * @return string|null
     */
    public function getAccesDentiste()
    {
        return $this->accesDentiste;
    }

    /**
     * @param string|null $accesDifficulte
     */
    public function setAccesDifficulte($accesDifficulte)
    {
        $this->accesDifficulte = $accesDifficulte;
    }

    /**
     * @return string|null
     */
    public function getAccesDifficulte()
    {
        return $this->accesDifficulte;
    }

    /**
     * @param null|string $accesDifficulteListe
     *
     * @return $this
     */
    public function setAccesDifficulteListe($accesDifficulteListe)
    {
        $this->accesDifficulteListe = $accesDifficulteListe;

        return $this;
    }

    /**
     * @return null|string
     */
    public function getAccesDifficulteListe()
    {
        return $this->accesDifficulteListe;
    }

    /**
     * @param string|null $accesDonneesDecision
     */
    public function setAccesDonneesDecision($accesDonneesDecision)
    {
        $this->accesDonneesDecision = $accesDonneesDecision;
    }

    /**
     * @return string|null
     */
    public function getAccesDonneesDecision()
    {
        return $this->accesDonneesDecision;
    }

    /**
     * @param string|null $accesDonneesDossierMedical
     */
    public function setAccesDonneesDossierMedical($accesDonneesDossierMedical)
    {
        $this->accesDonneesDossierMedical = $accesDonneesDossierMedical;
    }

    /**
     * @return string|null
     */
    public function getAccesDonneesDossierMedical()
    {
        return $this->accesDonneesDossierMedical;
    }

    /**
     * @param string|null $accesDonneesSoinsProposes
     */
    public function setAccesDonneesSoinsProposes($accesDonneesSoinsProposes)
    {
        $this->accesDonneesSoinsProposes = $accesDonneesSoinsProposes;
    }

    /**
     * @return string|null
     */
    public function getAccesDonneesSoinsProposes()
    {
        return $this->accesDonneesSoinsProposes;
    }

    /**
     * @param string|null $accesDonneestraitantChoix
     */
    public function setAccesDonneestraitantChoix($accesDonneestraitantChoix)
    {
        $this->accesDonneestraitantChoix = $accesDonneestraitantChoix;
    }

    /**
     * @return string|null
     */
    public function getAccesDonneestraitantChoix()
    {
        return $this->accesDonneestraitantChoix;
    }

    /**
     * @param string|null $accesGeneraliste
     */
    public function setAccesGeneraliste($accesGeneraliste)
    {
        $this->accesGeneraliste = $accesGeneraliste;
    }

    /**
     * @return string|null
     */
    public function getAccesGeneraliste()
    {
        return $this->accesGeneraliste;
    }

    /**
     * @param string|null $accesInfirmier
     */
    public function setAccesInfirmier($accesInfirmier)
    {
        $this->accesInfirmier = $accesInfirmier;
    }

    /**
     * @return string|null
     */
    public function getAccesInfirmier()
    {
        return $this->accesInfirmier;
    }

    /**
     * @param string|null $accesKine
     */
    public function setAccesKine($accesKine)
    {
        $this->accesKine = $accesKine;
    }

    /**
     * @return string|null
     */
    public function getAccesKine()
    {
        return $this->accesKine;
    }

    /**
     * @param string|null $accesOphtalmo
     */
    public function setAccesOphtalmo($accesOphtalmo)
    {
        $this->accesOphtalmo = $accesOphtalmo;
    }

    /**
     * @return string|null
     */
    public function getAccesOphtalmo()
    {
        return $this->accesOphtalmo;
    }

    /**
     * @param string|null $accesPodologue
     */
    public function setAccesPodologue($accesPodologue)
    {
        $this->accesPodologue = $accesPodologue;
    }

    /**
     * @return string|null
     */
    public function getAccesPodologue()
    {
        return $this->accesPodologue;
    }

    /**
     * @param string|null $accesPsy
     */
    public function setAccesPsy($accesPsy)
    {
        $this->accesPsy = $accesPsy;
    }

    /**
     * @return string|null
     */
    public function getAccesPsy()
    {
        return $this->accesPsy;
    }
}
