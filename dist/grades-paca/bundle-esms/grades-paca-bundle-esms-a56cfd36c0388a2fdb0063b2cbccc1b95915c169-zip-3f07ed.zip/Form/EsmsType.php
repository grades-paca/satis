<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 20/01/14
 * Time: 13:38
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\EsmsBundle\Choice\ChoiceInjectorInterface;
use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\FormBundle\Form\Type\RecoverableFormType;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class EsmsType.
 *
 * @author Michaël VEROUX
 */
class EsmsType extends AbstractType
{
    /**
     * @var \Oru\Bundle\EsmsBundle\Choice\ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param ChoiceProvider                $choiceProvider
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(ChoiceProvider $choiceProvider, IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->choiceProvider = $choiceProvider;
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('identification', new IdentificationType(), array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('professionnelFormation', ProfessionnelFormationType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('conseilVieSociale', ConseilVieSocialeType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('personnesQualifiees', PersonnesQualifieesType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('plaintesReclamations', PlaintesReclamationsType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('bientraitance', BientraitanceType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('finVie', FinVieType::class
            )
            ->add('accesDonneesSante', AccesDonneesSanteType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('livretAccueil', LivretAccueilType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('contratSoutien', ContratSoutienType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('contratSejour', ContratSejourType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('reglement', ReglementType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('projetEtablissement', ProjetEtablissementType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('evaluations', EvaluationsType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('suiviOutils', SuiviOutilsType::class, array(
                    'attr' => array('class' => 'form_row subForm'),
                )
            )
            ->add('save', SubmitType::class, array(
                    'validation_groups' => 'integrity',
                    'label' => 'save',
                    'translation_domain' => 'messages',
                    'attr' => array(
                        'class' => 'btn btn-primary',
                    ),
                )
            )
            ->add('save_definitively', SubmitType::class, array(
                    'label' => 'save_definitively',
                    'translation_domain' => 'messages',
                    'attr' => array(
                        'class' => 'btn btn-primary',
                    ),
                )
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $choiceProvider = $this->choiceProvider;
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\Esms',
            'translation_domain' => 'OruEsmsBundle',
            'required' => false,
            'validation_groups' => function (FormInterface $form) use ($choiceProvider) {
                $data = $form->getData();
                $data->setComplete(true);
                if ($data instanceof GroupSequenceProviderInterface) {
                    if ($data instanceof ChoiceInjectorInterface) {
                        $data->setTranslatedChoices($choiceProvider->getChoices());
                    }

                    return $data->getGroupSequence();
                }
            },
        ));
    }

    public function getParent()
    {
        return RecoverableFormType::class;
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_esms';
    }
}
