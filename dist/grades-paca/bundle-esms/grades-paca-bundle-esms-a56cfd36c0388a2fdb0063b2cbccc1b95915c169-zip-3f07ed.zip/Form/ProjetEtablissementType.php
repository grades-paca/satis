<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\FormBundle\Form\Type\ChoicesToStringType;
use Oru\Bundle\FormBundle\Form\Type\ConditionalType;
use Oru\Bundle\FormBundle\Form\Type\OuiNonDetailType;
use Oru\Bundle\FormBundle\Form\Type\OuiNonType;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ProjetEtablissementType.
 *
 * @author Michaël VEROUX
 */
class ProjetEtablissementType extends AbstractType
{
    /**
     * @var \Oru\Bundle\EsmsBundle\Choice\ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param ChoiceProvider                $choiceProvider
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(ChoiceProvider $choiceProvider, IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->choiceProvider = $choiceProvider;
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choicesPrefix = 'oru_esms_'.$this->getName();

        $builder
            ->add('existe', OuiNonDetailType::class, array(
                    'detail' => 'existeDetail',
                )
            )
            ->add('existeDetail'
            )
            ->add('pratiqueAnesm', ConditionalType::class, array(
                    'expanded' => true,
                    'choices' => array(
                        '1' => 'oui',
                        '0' => 'non',
                    ),
                    'conditionals' => array(
                        '0' => array(
                            'nonAnesmRedacteur',
                        ),
                    ),
                )
            )
            ->add('anesm', ChoicesToStringType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'anesm', 4),
                )
            )
            ->add('nonAnesmRedacteur', ChoiceType::class, array(
                    'placeholder' => '---choix---',
                    'expanded' => false,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'nonAnesmRedacteur', 3),
                )
            )
            ->add('conformeAnesm', OuiNonDetailType::class, array(
                    'on_no' => false,
                    'detail' => 'conformeAnesmSuivi',
                )
            )
            ->add('conformeAnesmSuivi', ChoicesToStringType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'conformeAnesmSuivi', 10),
                )
            )
            ->add('comiteSuivi', OuiNonType::class
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\ProjetEtablissement',
            'translation_domain' => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getBlockPrefix()
    {
        return 'projetEtablissement';
    }

    /**
     * @param $string
     *
     * @return array
     *
     * @author Michaël VEROUX
     */
    protected function translateArrayKeys($string)
    {
        if (is_array($string)) {
            return array_combine(array_map(array($this, 'translateArrayKeys'), $string), $string);
        }

        return $this->translator->trans($string, array(), 'OruEsmsBundle');
    }
}
