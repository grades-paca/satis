<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:06
 */

namespace Oru\Bundle\EsmsBundle\Form\Type;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class PersonnesType.
 *
 * @author Michaël VEROUX
 */
class PersonnesType extends AbstractType
{
    /**
     * @var \Oru\Bundle\EsmsBundle\Choice\ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @param ChoiceProvider $choiceProvider
     */
    public function __construct(ChoiceProvider $choiceProvider)
    {
        $this->choiceProvider = $choiceProvider;
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $choices = $this->choiceProvider->getFieldChoices('oru_esms', 'personnes', 5);

        $resolver->setDefaults(array(
            'choices' => $choices,
            'expanded' => true,
        ));

        parent::configureOptions($resolver);
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getParent()
    {
        return 'oru_choices_to_string';
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'personnes';
    }
}
