<?php
/**
 * Author: Michaël VEROUX
 * Date: 29/01/15
 * Time: 11:52
 */

namespace Oru\Bundle\EsmsBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class AnneeType.
 *
 * @author Michaël VEROUX
 */
class AnneeType extends AbstractType
{
    /**
     * @var array
     */
    protected $knownYears = array();

    /**
     * @param array $knownYears
     */
    public function __construct($knownYears)
    {
        $this->knownYears = array_combine($knownYears, $knownYears);
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        if (!array_key_exists(date('Y'), $this->knownYears)) {
            $this->knownYears[(int) date('Y')] = (int) date('Y');
        }
        ksort($this->knownYears);

        $resolver->setDefaults(array(
            'choices' => $this->knownYears,
        ));

        parent::configureOptions($resolver);
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getParent()
    {
        return ChoiceType::class;
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'esms_annee';
    }
}
