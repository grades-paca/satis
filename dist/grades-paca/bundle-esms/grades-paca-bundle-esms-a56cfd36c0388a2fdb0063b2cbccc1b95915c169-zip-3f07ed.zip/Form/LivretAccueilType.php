<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\FormBundle\Form\Type\ChoicesToStringType;
use Oru\Bundle\FormBundle\Form\Type\ConditionalType;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class LivretAccueilType.
 *
 * @author Michaël VEROUX
 */
class LivretAccueilType extends AbstractType
{
    /**
     * @var \Oru\Bundle\EsmsBundle\Choice\ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param ChoiceProvider                $choiceProvider
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(ChoiceProvider $choiceProvider, IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->choiceProvider = $choiceProvider;
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choicesPrefix = 'oru_esms_'.$this->getName();
        $remisePresentationChoix = $this->choiceProvider->getFieldChoices($choicesPrefix, 'remisePresentation', 4);
        $possessionLivretChoix = $this->choiceProvider->getFieldChoices($choicesPrefix, 'possessionLivret', 3);

        $builder
            ->add('exist', ConditionalType::class, array(
                    'expanded' => true,
                    'choices' => array(
                        '1' => 'oui',
                        '0' => 'non',
                    ),
                    'conditionals' => array(
                        '1' => array(
                            'annee',
                            'possessionLivret',
                            'possessionMoment',
                            'remisePresentation',
                            'remiseVisite',
                            'element',
                        ),
                        '0' => array(
                            'inexistantDetail',
                        ),
                    ),
                )
            )
            ->add('annee', null, array(
                    'attr' => array('min' => 1980),
                )
            )
            ->add('inexistantDetail'
            )
            ->add('possessionLivret', ConditionalType::class, array(
                    'placeholder' => '---choix---',
                    'choices' => $possessionLivretChoix,
                    'conditionals' => array(
                        $this->getLastChoice($possessionLivretChoix) => array('possessionNonDetail'),
                    ),
                )
            )
            ->add('possessionNonDetail'
            )
            ->add('possessionMoment', ChoiceType::class, array(
                    'placeholder' => '---choix---',
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'possessionMoment', 3),
                )
            )
            ->add('remisePresentation', ConditionalType::class, array(
                    'placeholder' => '---choix---',
                    'choices' => $remisePresentationChoix,
                    'conditionals' => array(
                        $this->getLastChoice($remisePresentationChoix) => array('remisePresentationJamaisDetail'),
                    ),
                )
            )
            ->add('remisePresentationJamaisDetail'
            )
            ->add('remiseVisite', ChoiceType::class, array(
                    'placeholder' => '---choix---',
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'remiseVisite', 5),
                )
            )
            ->add('element', ChoicesToStringType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'element', 21),
                )
            )
            ->add('elementAutre'
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\LivretAccueil',
            'translation_domain' => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getBlockPrefix()
    {
        return 'livretAccueil';
    }

    /**
     * @param $array
     *
     * @return mixed
     *
     * @author Michaël VEROUX
     */
    protected function getLastChoice($array)
    {
        $choices = array_flip($array);

        return array_pop($choices);
    }
}
