<?php
/**
 * Author: Michaël VEROUX
 * Date: 29/01/15
 * Time: 12:16
 */

namespace Oru\Bundle\EsmsBundle\Doctrine\Query\Mysql;

use Doctrine\ORM\Query\AST\Functions\FunctionNode;
use Doctrine\ORM\Query\Lexer;

/**
 * Class Regexp.
 *
 * @author Michaël VEROUX
 */
class Regexp extends FunctionNode
{
    /**
     * @var
     */
    public $value = null;
    /**
     * @var
     */
    public $regexp = null;

    /**
     * @param \Doctrine\ORM\Query\SqlWalker $sqlWalker
     *
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getSql(\Doctrine\ORM\Query\SqlWalker $sqlWalker)
    {
        return '('.$this->value->dispatch($sqlWalker).' REGEXP '.$this->regexp->dispatch($sqlWalker).')';
    }

    /**
     * @param \Doctrine\ORM\Query\Parser $parser
     *
     * @author Michaël VEROUX
     */
    public function parse(\Doctrine\ORM\Query\Parser $parser)
    {
        $parser->match(Lexer::T_IDENTIFIER);
        $parser->match(Lexer::T_OPEN_PARENTHESIS);
        $this->value = $parser->StringPrimary();
        $parser->match(Lexer::T_COMMA);
        $this->regexp = $parser->StringExpression();
        $parser->match(Lexer::T_CLOSE_PARENTHESIS);
    }
}
