jQuery(function () {
    var allFields = jQuery([]).add('#oru_esms_etablissement_etablissement'),
        tips = jQuery(".validateTips");

    function updateTips(t) {
        tips
            .text(t)
            .addClass("ui-state-error");
    }

    function checkValue(o) {
        if (!o.val()) {
            updateTips("Vous devez renseigner tous les champs.");
            o.addClass("ui-state-error");
            return false;
        } else {
            return true;
        }
    }

    jQuery('a#esms_new').click(function () {

        $("#oru_esms_new_valid").click(function(){
            var bValid = true;
            allFields.removeClass("ui-state-error");

            bValid = bValid && checkValue(jQuery('#oru_esms_etablissement_etablissement'));

            if (bValid) {
                jQuery('#oru_esms_etablissement_etablissement').parents('form').submit();
            }
        });
        jQuery('#rorModal').modal('show');
    });
});