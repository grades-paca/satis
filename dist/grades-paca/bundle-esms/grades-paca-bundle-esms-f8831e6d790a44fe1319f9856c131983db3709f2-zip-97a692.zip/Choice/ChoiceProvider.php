<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 30/01/14
 * Time: 10:44
 */

namespace Oru\Bundle\EsmsBundle\Choice;

use Symfony\Component\Translation\TranslatorInterface;

/**
 * Class ChoiceProvider.
 *
 * @author Michaël VEROUX
 */
class ChoiceProvider
{
    /**
     * @var \Symfony\Component\Translation\TranslatorInterface
     */
    protected $translator;

    /**
     * @var array
     */
    protected $choices = array();

    /**
     * @param TranslatorInterface $translator
     */
    public function __construct(TranslatorInterface $translator)
    {
        $this->translator = $translator;
    }

    /**
     * @return array
     */
    public function getChoices()
    {
        return $this->choices;
    }

    /**
     * @param string $prefix
     * @param string $property
     * @param int    $nb
     *
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function getFieldChoices($prefix, $property, $nb = 1)
    {
        $fullField = sprintf('%s.%s', $prefix, $property);
        if (isset($this->choices[$fullField])) {
            return $this->choices[$fullField];
        }
        $key = sprintf('%sChoix.choix', $fullField);

        return $this->choices[$fullField] = $this->genChoiceKeys($key, $nb);
    }

    /**
     * @param string $key
     * @param int    $number
     *
     * @return array
     *
     * @author Michaël VEROUX
     */
    protected function genChoiceKeys($key, $number)
    {
        $keys = array();
        for ($i = 1; $i <= $number; ++$i) {
            $keys[$key.$i] = $this->translator->trans($key.$i, array(), 'OruEsmsBundle');
        }

        return $keys;
    }
}
