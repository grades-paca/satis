<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 13/01/14
 * Time: 16:01
 */

namespace Oru\Bundle\EsmsBundle\Model;

use Oru\Bundle\FormIncrementalBundle\Annotation\FieldValidity;

/**
 * Class ProfessionnelFormation.
 *
 * @author Michaël VEROUX
 */
class ProfessionnelFormation
{
    /**
     * @var string|null
     */
    protected $suiviFormation = null;

    /**
     * @var string|null
     *
     * @FieldValidity(stop=2014)
     */
    protected $suiviFormationNonDetail = null;

    /**
     * @var string|null
     *
     * @FieldValidity(start=2015)
     */
    protected $suiviFormationNonDetail2015 = null;

    /**
     * @var string|null
     *
     * @FieldValidity(start=2015)
     */
    protected $suiviFormationNonDetailLibre2015 = null;

    /**
     * @var string|null
     */
    protected $professionnelFormationTheme = null;

    /**
     * @var string|null
     */
    protected $professionnelFormationType = null;

    /**
     * @param mixed $professionnelFormationTheme
     */
    public function setProfessionnelFormationTheme(\Oru\Bundle\EsmsBundle\Model\ProfessionnelFormationTheme $professionnelFormationTheme)
    {
        $this->professionnelFormationTheme = $professionnelFormationTheme;
    }

    /**
     * @return mixed
     */
    public function getProfessionnelFormationTheme()
    {
        return $this->professionnelFormationTheme;
    }

    /**
     * @param mixed $professionnelFormationType
     */
    public function setProfessionnelFormationType(\Oru\Bundle\EsmsBundle\Model\ProfessionnelFormationType $professionnelFormationType)
    {
        $this->professionnelFormationType = $professionnelFormationType;
    }

    /**
     * @return mixed
     */
    public function getProfessionnelFormationType()
    {
        return $this->professionnelFormationType;
    }

    /**
     * @param mixed $suiviFormation
     */
    public function setSuiviFormation($suiviFormation)
    {
        $this->suiviFormation = $suiviFormation;
    }

    /**
     * @return mixed
     */
    public function getSuiviFormation()
    {
        return $this->suiviFormation;
    }

    /**
     * @param mixed $suiviFormationNonDetail
     */
    public function setSuiviFormationNonDetail($suiviFormationNonDetail)
    {
        $this->suiviFormationNonDetail = $suiviFormationNonDetail;
    }

    /**
     * @return mixed
     */
    public function getSuiviFormationNonDetail()
    {
        return $this->suiviFormationNonDetail;
    }

    /**
     * @param mixed $suiviFormationNonDetail2015
     *
     * @return $this
     */
    public function setSuiviFormationNonDetail2015($suiviFormationNonDetail2015)
    {
        $this->suiviFormationNonDetail2015 = $suiviFormationNonDetail2015;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getSuiviFormationNonDetail2015()
    {
        return $this->suiviFormationNonDetail2015;
    }

    /**
     * @param mixed $suiviFormationNonDetailLibre2015
     *
     * @return $this
     */
    public function setSuiviFormationNonDetailLibre2015($suiviFormationNonDetailLibre2015)
    {
        $this->suiviFormationNonDetailLibre2015 = $suiviFormationNonDetailLibre2015;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getSuiviFormationNonDetailLibre2015()
    {
        return $this->suiviFormationNonDetailLibre2015;
    }

    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public static function subRequired()
    {
        return array(
            'suiviFormation' => array(
                '0' => array(
                    'suiviFormationNonDetail',
                    'suiviFormationNonDetail2015',
                ),
                '1' => array(
                    'professionnelFormationTheme',
                    'professionnelFormationType',
                ),
            ),
        );
    }

    /**
     * @author Michaël VEROUX
     */
    public function unsetUnusedSubs()
    {
        foreach (self::subRequired() as $field => $constraint) {
            $constraint_key = (string) $this->$field;
            foreach ($constraint as $expected_value => $sub_properties) {
                foreach ($sub_properties as $sub_property) {
                    if ($constraint_key === (string) $expected_value) {
                        continue;
                    }
                    $this->$sub_property = null;
                }
            }
        }
    }
}
