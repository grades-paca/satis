<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 13:38
 */

namespace Oru\Bundle\EsmsBundle\Model;

/**
 * Class ProjetEtablissement.
 *
 * @author Michaël VEROUX
 */
class ProjetEtablissement
{
    /**
     * @var string|null
     */
    protected $existe = null;

    /**
     * @var string|null
     */
    protected $existeDetail = null;

    /**
     * @var string|null
     */
    protected $pratiqueAnesm = null;

    /**
     * @var string|null
     */
    protected $anesm = null;

    /**
     * @var string|null
     */
    protected $nonAnesmRedacteur = null;

    /**
     * @var string|null
     */
    protected $conformeAnesm = null;

    /**
     * @var string|null
     */
    protected $conformeAnesmSuivi = null;

    /**
     * @var string|null
     */
    protected $comiteSuivi = null;

    /**
     * @param string|null $anesm
     */
    public function setAnesm($anesm)
    {
        $this->anesm = $anesm;
    }

    /**
     * @return string|null
     */
    public function getAnesm()
    {
        return $this->anesm;
    }

    /**
     * @param string|null $comiteSuivi
     */
    public function setComiteSuivi($comiteSuivi)
    {
        $this->comiteSuivi = $comiteSuivi;
    }

    /**
     * @return string|null
     */
    public function getComiteSuivi()
    {
        return $this->comiteSuivi;
    }

    /**
     * @param string|null $conformeAnesm
     */
    public function setConformeAnesm($conformeAnesm)
    {
        $this->conformeAnesm = $conformeAnesm;
    }

    /**
     * @return string|null
     */
    public function getConformeAnesm()
    {
        return $this->conformeAnesm;
    }

    /**
     * @param string|null $conformeAnesmSuivi
     */
    public function setConformeAnesmSuivi($conformeAnesmSuivi)
    {
        $this->conformeAnesmSuivi = $conformeAnesmSuivi;
    }

    /**
     * @return string|null
     */
    public function getConformeAnesmSuivi()
    {
        return $this->conformeAnesmSuivi;
    }

    /**
     * @param string|null $existe
     */
    public function setExiste($existe)
    {
        $this->existe = $existe;
    }

    /**
     * @return string|null
     */
    public function getExiste()
    {
        return $this->existe;
    }

    /**
     * @param null|string $existeDetail
     */
    public function setExisteDetail($existeDetail)
    {
        $this->existeDetail = $existeDetail;
    }

    /**
     * @return null|string
     */
    public function getExisteDetail()
    {
        return $this->existeDetail;
    }

    /**
     * @param string|null $nonAnesmRedacteur
     */
    public function setNonAnesmRedacteur($nonAnesmRedacteur)
    {
        $this->nonAnesmRedacteur = $nonAnesmRedacteur;
    }

    /**
     * @return string|null
     */
    public function getNonAnesmRedacteur()
    {
        return $this->nonAnesmRedacteur;
    }

    /**
     * @param string|null $pratiqueAnesm
     */
    public function setPratiqueAnesm($pratiqueAnesm)
    {
        $this->pratiqueAnesm = $pratiqueAnesm;
    }

    /**
     * @return string|null
     */
    public function getPratiqueAnesm()
    {
        return $this->pratiqueAnesm;
    }
}
