<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 13:56
 */

namespace Oru\Bundle\EsmsBundle\Model;

/**
 * Class SuiviOutils.
 *
 * @author Michaël VEROUX
 */
class SuiviOutils
{
    /**
     * @var bool
     */
    protected $difficultesLivretBoolean = false;

    /**
     * @var string|null
     */
    protected $difficultesLivret = null;

    /**
     * @var bool
     */
    protected $difficultesInstancesParticipationBoolean = false;

    /**
     * @var string|null
     */
    protected $difficultesInstancesParticipation = null;

    /**
     * @var bool
     */
    protected $difficultesContratSejourBoolean = false;

    /**
     * @var string|null
     */
    protected $difficultesContratSejour = null;

    /**
     * @var bool
     */
    protected $difficultesReglementFonctionnementBoolean = false;

    /**
     * @var string|null
     */
    protected $difficultesReglementFonctionnement = null;

    /**
     * @var bool
     */
    protected $difficultesProjetEtablissementBoolean = false;

    /**
     * @var string|null
     */
    protected $difficultesProjetEtablissement = null;

    /**
     * @var bool
     */
    protected $difficultesEvaluationsInternesBoolean = false;

    /**
     * @var string|null
     */
    protected $difficultesEvaluationsInternes = null;

    /**
     * @var bool
     */
    protected $difficultesEvaluationsExternesBoolean = false;

    /**
     * @var string|null
     */
    protected $difficultesEvaluationsExternes = null;

    /**
     * @var string|null
     */
    protected $documentAdapteDeficiences = null;

    /**
     * @var string|null
     */
    protected $documentAdapteDeficiencesNonDetail = null;

    /**
     * @var string|null
     */
    protected $documentAdapteAccompagnes = null;

    /**
     * @var string|null
     */
    protected $actualisationLivret = null;

    /**
     * @var string|null
     */
    protected $actualisationContratSejour = null;

    /**
     * @var string|null
     */
    protected $actualisationProjetEtablissement = null;

    /**
     * @var string|null
     */
    protected $outilsEvaluationLivret = null;

    /**
     * @var string|null
     */
    protected $outilsEvaluationLivretQui = null;

    /**
     * @var string|null
     */
    protected $outilsEvaluationContratSejour = null;

    /**
     * @var string|null
     */
    protected $outilsEvaluationContratSejourQui = null;

    /**
     * @var string|null
     */
    protected $outilsEvaluationLivretProjetEtablissement = null;

    /**
     * @var string|null
     */
    protected $outilsEvaluationLivretProjetEtablissementQui = null;

    /**
     * @var string|null
     */
    protected $outilsEvaluationLivretReglement = null;

    /**
     * @var string|null
     */
    protected $outilsEvaluationLivretReglementQui = null;

    /**
     * @param bool $difficultesLivretBoolean
     */
    public function setDifficultesLivretBoolean($difficultesLivretBoolean)
    {
        $this->difficultesLivretBoolean = $difficultesLivretBoolean;
    }

    /**
     * @return bool
     */
    public function getDifficultesLivretBoolean()
    {
        return $this->difficultesLivretBoolean;
    }

    /**
     * @param bool $difficultesContratSejourBoolean
     */
    public function setDifficultesContratSejourBoolean($difficultesContratSejourBoolean)
    {
        $this->difficultesContratSejourBoolean = $difficultesContratSejourBoolean;
    }

    /**
     * @return bool
     */
    public function getDifficultesContratSejourBoolean()
    {
        return $this->difficultesContratSejourBoolean;
    }

    /**
     * @param bool $difficultesEvaluationsExternesBoolean
     */
    public function setDifficultesEvaluationsExternesBoolean($difficultesEvaluationsExternesBoolean)
    {
        $this->difficultesEvaluationsExternesBoolean = $difficultesEvaluationsExternesBoolean;
    }

    /**
     * @return bool
     */
    public function getDifficultesEvaluationsExternesBoolean()
    {
        return $this->difficultesEvaluationsExternesBoolean;
    }

    /**
     * @param bool $difficultesEvaluationsInternesBoolean
     */
    public function setDifficultesEvaluationsInternesBoolean($difficultesEvaluationsInternesBoolean)
    {
        $this->difficultesEvaluationsInternesBoolean = $difficultesEvaluationsInternesBoolean;
    }

    /**
     * @return bool
     */
    public function getDifficultesEvaluationsInternesBoolean()
    {
        return $this->difficultesEvaluationsInternesBoolean;
    }

    /**
     * @param bool $difficultesInstancesParticipationBoolean
     */
    public function setDifficultesInstancesParticipationBoolean($difficultesInstancesParticipationBoolean)
    {
        $this->difficultesInstancesParticipationBoolean = $difficultesInstancesParticipationBoolean;
    }

    /**
     * @return bool
     */
    public function getDifficultesInstancesParticipationBoolean()
    {
        return $this->difficultesInstancesParticipationBoolean;
    }

    /**
     * @param bool $difficultesProjetEtablissementBoolean
     */
    public function setDifficultesProjetEtablissementBoolean($difficultesProjetEtablissementBoolean)
    {
        $this->difficultesProjetEtablissementBoolean = $difficultesProjetEtablissementBoolean;
    }

    /**
     * @return bool
     */
    public function getDifficultesProjetEtablissementBoolean()
    {
        return $this->difficultesProjetEtablissementBoolean;
    }

    /**
     * @param bool $difficultesReglementFonctionnementBoolean
     */
    public function setDifficultesReglementFonctionnementBoolean($difficultesReglementFonctionnementBoolean)
    {
        $this->difficultesReglementFonctionnementBoolean = $difficultesReglementFonctionnementBoolean;
    }

    /**
     * @return bool
     */
    public function getDifficultesReglementFonctionnementBoolean()
    {
        return $this->difficultesReglementFonctionnementBoolean;
    }

    /**
     * @param string|null $actualisationContratSejour
     */
    public function setActualisationContratSejour($actualisationContratSejour)
    {
        $this->actualisationContratSejour = $actualisationContratSejour;
    }

    /**
     * @return string|null
     */
    public function getActualisationContratSejour()
    {
        return $this->actualisationContratSejour;
    }

    /**
     * @param string|null $actualisationLivret
     */
    public function setActualisationLivret($actualisationLivret)
    {
        $this->actualisationLivret = $actualisationLivret;
    }

    /**
     * @return string|null
     */
    public function getActualisationLivret()
    {
        return $this->actualisationLivret;
    }

    /**
     * @param string|null $actualisationProjetEtablissement
     */
    public function setActualisationProjetEtablissement($actualisationProjetEtablissement)
    {
        $this->actualisationProjetEtablissement = $actualisationProjetEtablissement;
    }

    /**
     * @return string|null
     */
    public function getActualisationProjetEtablissement()
    {
        return $this->actualisationProjetEtablissement;
    }

    /**
     * @param string|null $difficultesContratSejour
     */
    public function setDifficultesContratSejour($difficultesContratSejour)
    {
        if (null === $difficultesContratSejour) {
            $this->setDifficultesContratSejourBoolean(false);
        } else {
            $this->setDifficultesContratSejourBoolean(true);
        }

        $this->difficultesContratSejour = $difficultesContratSejour;
    }

    /**
     * @return string|null
     */
    public function getDifficultesContratSejour()
    {
        return $this->difficultesContratSejour;
    }

    /**
     * @param string|null $difficultesEvaluationsExternes
     */
    public function setDifficultesEvaluationsExternes($difficultesEvaluationsExternes)
    {
        if (null === $difficultesEvaluationsExternes) {
            $this->setDifficultesEvaluationsExternesBoolean(false);
        } else {
            $this->setDifficultesEvaluationsExternesBoolean(true);
        }

        $this->difficultesEvaluationsExternes = $difficultesEvaluationsExternes;
    }

    /**
     * @return string|null
     */
    public function getDifficultesEvaluationsExternes()
    {
        return $this->difficultesEvaluationsExternes;
    }

    /**
     * @param string|null $difficultesEvaluationsInternes
     */
    public function setDifficultesEvaluationsInternes($difficultesEvaluationsInternes)
    {
        if (null === $difficultesEvaluationsInternes) {
            $this->setDifficultesEvaluationsInternesBoolean(false);
        } else {
            $this->setDifficultesEvaluationsInternesBoolean(true);
        }

        $this->difficultesEvaluationsInternes = $difficultesEvaluationsInternes;
    }

    /**
     * @return string|null
     */
    public function getDifficultesEvaluationsInternes()
    {
        return $this->difficultesEvaluationsInternes;
    }

    /**
     * @param string|null $difficultesInstancesParticipation
     */
    public function setDifficultesInstancesParticipation($difficultesInstancesParticipation)
    {
        if (null === $difficultesInstancesParticipation) {
            $this->setDifficultesInstancesParticipationBoolean(false);
        } else {
            $this->setDifficultesInstancesParticipationBoolean(true);
        }

        $this->difficultesInstancesParticipation = $difficultesInstancesParticipation;
    }

    /**
     * @return string|null
     */
    public function getDifficultesInstancesParticipation()
    {
        return $this->difficultesInstancesParticipation;
    }

    /**
     * @param string|null $difficultesLivret
     */
    public function setDifficultesLivret($difficultesLivret)
    {
        if (null === $difficultesLivret) {
            $this->setDifficultesLivretBoolean(false);
        } else {
            $this->setDifficultesLivretBoolean(true);
        }

        $this->difficultesLivret = $difficultesLivret;
    }

    /**
     * @return string|null
     */
    public function getDifficultesLivret()
    {
        return $this->difficultesLivret;
    }

    /**
     * @param string|null $difficultesProjetEtablissement
     */
    public function setDifficultesProjetEtablissement($difficultesProjetEtablissement)
    {
        if (null === $difficultesProjetEtablissement) {
            $this->setDifficultesProjetEtablissementBoolean(false);
        } else {
            $this->setDifficultesProjetEtablissementBoolean(true);
        }

        $this->difficultesProjetEtablissement = $difficultesProjetEtablissement;
    }

    /**
     * @return string|null
     */
    public function getDifficultesProjetEtablissement()
    {
        return $this->difficultesProjetEtablissement;
    }

    /**
     * @param string|null $difficultesReglementFonctionnement
     */
    public function setDifficultesReglementFonctionnement($difficultesReglementFonctionnement)
    {
        if (null === $difficultesReglementFonctionnement) {
            $this->setDifficultesReglementFonctionnementBoolean(false);
        } else {
            $this->setDifficultesReglementFonctionnementBoolean(true);
        }

        $this->difficultesReglementFonctionnement = $difficultesReglementFonctionnement;
    }

    /**
     * @return string|null
     */
    public function getDifficultesReglementFonctionnement()
    {
        return $this->difficultesReglementFonctionnement;
    }

    /**
     * @param string|null $documentAdapteAccompagnes
     */
    public function setDocumentAdapteAccompagnes($documentAdapteAccompagnes)
    {
        $this->documentAdapteAccompagnes = $documentAdapteAccompagnes;
    }

    /**
     * @return string|null
     */
    public function getDocumentAdapteAccompagnes()
    {
        return $this->documentAdapteAccompagnes;
    }

    /**
     * @param string|null $documentAdapteDeficiences
     */
    public function setDocumentAdapteDeficiences($documentAdapteDeficiences)
    {
        $this->documentAdapteDeficiences = $documentAdapteDeficiences;
    }

    /**
     * @return string|null
     */
    public function getDocumentAdapteDeficiences()
    {
        return $this->documentAdapteDeficiences;
    }

    /**
     * @param string|null $documentAdapteDeficiencesNonDetail
     */
    public function setDocumentAdapteDeficiencesNonDetail($documentAdapteDeficiencesNonDetail)
    {
        $this->documentAdapteDeficiencesNonDetail = $documentAdapteDeficiencesNonDetail;
    }

    /**
     * @return string|null
     */
    public function getDocumentAdapteDeficiencesNonDetail()
    {
        return $this->documentAdapteDeficiencesNonDetail;
    }

    /**
     * @param string|null $outilsEvaluationContratSejour
     */
    public function setOutilsEvaluationContratSejour($outilsEvaluationContratSejour)
    {
        $this->outilsEvaluationContratSejour = $outilsEvaluationContratSejour;
    }

    /**
     * @return string|null
     */
    public function getOutilsEvaluationContratSejour()
    {
        return $this->outilsEvaluationContratSejour;
    }

    /**
     * @param string|null $outilsEvaluationLivret
     */
    public function setOutilsEvaluationLivret($outilsEvaluationLivret)
    {
        $this->outilsEvaluationLivret = $outilsEvaluationLivret;
    }

    /**
     * @return string|null
     */
    public function getOutilsEvaluationLivret()
    {
        return $this->outilsEvaluationLivret;
    }

    /**
     * @param string|null $outilsEvaluationLivretProjetEtablissement
     */
    public function setOutilsEvaluationLivretProjetEtablissement($outilsEvaluationLivretProjetEtablissement)
    {
        $this->outilsEvaluationLivretProjetEtablissement = $outilsEvaluationLivretProjetEtablissement;
    }

    /**
     * @return string|null
     */
    public function getOutilsEvaluationLivretProjetEtablissement()
    {
        return $this->outilsEvaluationLivretProjetEtablissement;
    }

    /**
     * @param string|null $outilsEvaluationLivretReglement
     */
    public function setOutilsEvaluationLivretReglement($outilsEvaluationLivretReglement)
    {
        $this->outilsEvaluationLivretReglement = $outilsEvaluationLivretReglement;
    }

    /**
     * @return string|null
     */
    public function getOutilsEvaluationLivretReglement()
    {
        return $this->outilsEvaluationLivretReglement;
    }

    /**
     * @param string|null $outilsEvaluationContratSejourQui
     */
    public function setOutilsEvaluationContratSejourQui($outilsEvaluationContratSejourQui)
    {
        $this->outilsEvaluationContratSejourQui = $outilsEvaluationContratSejourQui;
    }

    /**
     * @return string|null
     */
    public function getOutilsEvaluationContratSejourQui()
    {
        return $this->outilsEvaluationContratSejourQui;
    }

    /**
     * @param string|null $outilsEvaluationLivretProjetEtablissementQui
     */
    public function setOutilsEvaluationLivretProjetEtablissementQui($outilsEvaluationLivretProjetEtablissementQui)
    {
        $this->outilsEvaluationLivretProjetEtablissementQui = $outilsEvaluationLivretProjetEtablissementQui;
    }

    /**
     * @return string|null
     */
    public function getOutilsEvaluationLivretProjetEtablissementQui()
    {
        return $this->outilsEvaluationLivretProjetEtablissementQui;
    }

    /**
     * @param string|null $outilsEvaluationLivretQui
     */
    public function setOutilsEvaluationLivretQui($outilsEvaluationLivretQui)
    {
        $this->outilsEvaluationLivretQui = $outilsEvaluationLivretQui;
    }

    /**
     * @return string|null
     */
    public function getOutilsEvaluationLivretQui()
    {
        return $this->outilsEvaluationLivretQui;
    }

    /**
     * @param string|null $outilsEvaluationLivretReglementQui
     */
    public function setOutilsEvaluationLivretReglementQui($outilsEvaluationLivretReglementQui)
    {
        $this->outilsEvaluationLivretReglementQui = $outilsEvaluationLivretReglementQui;
    }

    /**
     * @return string|null
     */
    public function getOutilsEvaluationLivretReglementQui()
    {
        return $this->outilsEvaluationLivretReglementQui;
    }
}
