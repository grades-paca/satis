<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 09:35
 */

namespace Oru\Bundle\EsmsBundle\Model;

use Oru\Bundle\FormIncrementalBundle\Annotation\FieldValidity;

/**
 * Class PlaintesReclamations
 * @package Oru\Bundle\EsmsBundle\Model
 * @author Michaël VEROUX
 */
class PlaintesReclamations
{
    /**
         * @var string|null
     */
    protected $processus = null;

    /**
     * @var string|null
     */
    protected $plaintesTotal = null;

    /**
     * @var string|null
     */
    protected $plaintesDossierMedical = null;

    /**
     * @var string|null
     *
     * @FieldValidity(start=2015)
     */
    protected $plaintesThemesListe = null;

    /**
     * @var string|null
     */
    protected $plaintesThemes = null;

    /**
     * @param string|null $plaintesDossierMedical
     */
    public function setPlaintesDossierMedical($plaintesDossierMedical)
    {
        $this->plaintesDossierMedical = $plaintesDossierMedical;
    }

    /**
     * @return string|null
     */
    public function getPlaintesDossierMedical()
    {
        return $this->plaintesDossierMedical;
    }

    /**
     * @param string|null $plaintesThemes
     */
    public function setPlaintesThemes($plaintesThemes)
    {
        $this->plaintesThemes = $plaintesThemes;
    }

    /**
     * @return string|null
     */
    public function getPlaintesThemes()
    {
        return $this->plaintesThemes;
    }

    /**
     * @param null|string $plaintesThemesListe
     * @return $this
     */
    public function setPlaintesThemesListe($plaintesThemesListe)
    {
        $this->plaintesThemesListe = $plaintesThemesListe;

        return $this;
    }

    /**
     * @return null|string
     */
    public function getPlaintesThemesListe()
    {
        return $this->plaintesThemesListe;
    }

    /**
     * @param string|null $plaintesTotal
     */
    public function setPlaintesTotal($plaintesTotal)
    {
        $this->plaintesTotal = $plaintesTotal;
    }

    /**
     * @return string|null
     */
    public function getPlaintesTotal()
    {
        return $this->plaintesTotal;
    }

    /**
     * @param string|null $processus
     */
    public function setProcessus($processus)
    {
        $this->processus = $processus;
    }

    /**
     * @return string|null
     */
    public function getProcessus()
    {
        return $this->processus;
    }
} 