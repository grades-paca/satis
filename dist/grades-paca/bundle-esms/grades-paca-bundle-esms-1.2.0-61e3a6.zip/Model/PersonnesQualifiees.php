<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 09:17
 */

namespace Oru\Bundle\EsmsBundle\Model;

use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class PersonnesQualifiees
 * @package Oru\Bundle\EsmsBundle\Model
 * @author Michaël VEROUX
 */
class PersonnesQualifiees implements GroupSequenceProviderInterface
{
    /**
     * @var string|null
     */
    protected $listeConnaissance = null;

    /**
     * @var string|null
     */
    protected $recoursNombre = null;

    /**
     * @var string|null
     */
    protected $recoursNombreCr = null;

    /**
     * @var string|null
     */
    protected $listeLivret = null;

    /**
     * @param string|null $listeConnaissance
     */
    public function setListeConnaissance($listeConnaissance)
    {
        $this->listeConnaissance = $listeConnaissance;
    }

    /**
     * @return string|null
     */
    public function getListeConnaissance()
    {
        return $this->listeConnaissance;
    }

    /**
     * @param string|null $listeLivret
     */
    public function setListeLivret($listeLivret)
    {
        $this->listeLivret = $listeLivret;
    }

    /**
     * @return string|null
     */
    public function getListeLivret()
    {
        return $this->listeLivret;
    }

    /**
     * @param string|null $recoursNombre
     */
    public function setRecoursNombre($recoursNombre)
    {
        $this->recoursNombre = $recoursNombre;
    }

    /**
     * @return string|null
     */
    public function getRecoursNombre()
    {
        return $this->recoursNombre;
    }

    /**
     * @param string|null $recoursNombreCr
     */
    public function setRecoursNombreCr($recoursNombreCr)
    {
        $this->recoursNombreCr = $recoursNombreCr;
    }

    /**
     * @return string|null
     */
    public function getRecoursNombreCr()
    {
        return $this->recoursNombreCr;
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        // TODO: Implement getGroupSequence() method.
    }
} 