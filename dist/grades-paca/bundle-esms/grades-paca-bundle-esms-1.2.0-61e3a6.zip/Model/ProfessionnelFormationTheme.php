<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 13/null1/14
 * Time: 15:5null
 */

namespace Oru\Bundle\EsmsBundle\Model;

use Oru\Bundle\FormIncrementalBundle\Annotation\FieldValidity;

/**
 * Class ProfessionnelFormationTheme
 * @package Oru\Bundle\EsmsBundle\Model
 * @author Michaël VEROUX
 */
class ProfessionnelFormationTheme
{
    /**
     * @var string|null
     */
    protected $droitIndividuelPropose = null;

    /**
     * @var string|null
     */
    protected $droitIndividuelForme = null;

    /**
     * @var string|null
     */
    protected $droitCollectifPropose = null;

    /**
     * @var string|null
     */
    protected $droitCollectifForme = null;

    /**
     * @var string|null
     */
    protected $suiviOutilsPropose = null;

    /**
     * @var string|null
     */
    protected $suiviOutilsForme = null;

    /**
     * @var string|null
     */
    protected $pecDouleurPropose = null;

    /**
     * @var string|null
     */
    protected $pecDouleurForme = null;

    /**
     * @var string|null
     */
    protected $traitancePropose = null;

    /**
     * @var string|null
     */
    protected $traitanceForme = null;

    /**
     * @var string|null
     */
    protected $palliatifPropose = null;

    /**
     * @var string|null
     */
    protected $palliatifForme = null;

    /**
     * @var string|null
     */
    protected $conseilVieSocialePropose = null;

    /**
     * @var string|null
     */
    protected $conseilVieSocialeForme = null;

    /**
     * @var string|null
     */
    protected $autreDetail = null;

    /**
     * @var string|null
     *
     * @FieldValidity(start=2015)
     */
    protected $autreDetailListe = null;

    /**
     * @var string|null
     */
    protected $autrePropose = null;

    /**
     * @var string|null
     */
    protected $autreForme = null;

    /**
     * @var string|null
     */
    protected $professionnelFormation = null;

    /**
     * @param string|null $autreDetail
     */
    public function setAutreDetail($autreDetail)
    {
        $this->autreDetail = $autreDetail;
    }

    /**
     * @return string|null
     */
    public function getAutreDetail()
    {
        return $this->autreDetail;
    }

    /**
     * @param null|string $autreDetailListe
     * @return $this
     */
    public function setAutreDetailListe($autreDetailListe)
    {
        $this->autreDetailListe = $autreDetailListe;

        return $this;
    }

    /**
     * @return null|string
     */
    public function getAutreDetailListe()
    {
        return $this->autreDetailListe;
    }

    /**
     * @param string|null $autreForme
     */
    public function setAutreForme($autreForme)
    {
        $this->autreForme = $autreForme;
    }

    /**
     * @return string|null
     */
    public function getAutreForme()
    {
        return $this->autreForme;
    }

    /**
     * @param string|null $autrePropose
     */
    public function setAutrePropose($autrePropose)
    {
        $this->autrePropose = $autrePropose;
    }

    /**
     * @return string|null
     */
    public function getAutrePropose()
    {
        return $this->autrePropose;
    }

    /**
     * @param string|null $conseilVieSocialeForme
     */
    public function setConseilVieSocialeForme($conseilVieSocialeForme)
    {
        $this->conseilVieSocialeForme = $conseilVieSocialeForme;
    }

    /**
     * @return string|null
     */
    public function getConseilVieSocialeForme()
    {
        return $this->conseilVieSocialeForme;
    }

    /**
     * @param string|null $conseilVieSocialePropose
     */
    public function setConseilVieSocialePropose($conseilVieSocialePropose)
    {
        $this->conseilVieSocialePropose = $conseilVieSocialePropose;
    }

    /**
     * @return string|null
     */
    public function getConseilVieSocialePropose()
    {
        return $this->conseilVieSocialePropose;
    }

    /**
     * @param string|null $droitCollectifForme
     */
    public function setDroitCollectifForme($droitCollectifForme)
    {
        $this->droitCollectifForme = $droitCollectifForme;
    }

    /**
     * @return string|null
     */
    public function getDroitCollectifForme()
    {
        return $this->droitCollectifForme;
    }

    /**
     * @param string|null $droitCollectifPropose
     */
    public function setDroitCollectifPropose($droitCollectifPropose)
    {
        $this->droitCollectifPropose = $droitCollectifPropose;
    }

    /**
     * @return string|null
     */
    public function getDroitCollectifPropose()
    {
        return $this->droitCollectifPropose;
    }

    /**
     * @param string|null $droitIndividuelForme
     */
    public function setDroitIndividuelForme($droitIndividuelForme)
    {
        $this->droitIndividuelForme = $droitIndividuelForme;
    }

    /**
     * @return string|null
     */
    public function getDroitIndividuelForme()
    {
        return $this->droitIndividuelForme;
    }

    /**
     * @param string|null $droitIndividuelPropose
     */
    public function setDroitIndividuelPropose($droitIndividuelPropose)
    {
        $this->droitIndividuelPropose = $droitIndividuelPropose;
    }

    /**
     * @return string|null
     */
    public function getDroitIndividuelPropose()
    {
        return $this->droitIndividuelPropose;
    }

    /**
     * @param string|null $palliatifForme
     */
    public function setPalliatifForme($palliatifForme)
    {
        $this->palliatifForme = $palliatifForme;
    }

    /**
     * @return string|null
     */
    public function getPalliatifForme()
    {
        return $this->palliatifForme;
    }

    /**
     * @param string|null $palliatifPropose
     */
    public function setPalliatifPropose($palliatifPropose)
    {
        $this->palliatifPropose = $palliatifPropose;
    }

    /**
     * @return string|null
     */
    public function getPalliatifPropose()
    {
        return $this->palliatifPropose;
    }

    /**
     * @param string|null $pecDouleurForme
     */
    public function setPecDouleurForme($pecDouleurForme)
    {
        $this->pecDouleurForme = $pecDouleurForme;
    }

    /**
     * @return string|null
     */
    public function getPecDouleurForme()
    {
        return $this->pecDouleurForme;
    }

    /**
     * @param string|null $pecDouleurPropose
     */
    public function setPecDouleurPropose($pecDouleurPropose)
    {
        $this->pecDouleurPropose = $pecDouleurPropose;
    }

    /**
     * @return string|null
     */
    public function getPecDouleurPropose()
    {
        return $this->pecDouleurPropose;
    }

    /**
     * @param string|null $suiviOutilsForme
     */
    public function setSuiviOutilsForme($suiviOutilsForme)
    {
        $this->suiviOutilsForme = $suiviOutilsForme;
    }

    /**
     * @return string|null
     */
    public function getSuiviOutilsForme()
    {
        return $this->suiviOutilsForme;
    }

    /**
     * @param string|null $suiviOutilsPropose
     */
    public function setSuiviOutilsPropose($suiviOutilsPropose)
    {
        $this->suiviOutilsPropose = $suiviOutilsPropose;
    }

    /**
     * @return string|null
     */
    public function getSuiviOutilsPropose()
    {
        return $this->suiviOutilsPropose;
    }

    /**
     * @param string|null $traitancePropose
     */
    public function setTraitancePropose($traitancePropose)
    {
        $this->traitancePropose = $traitancePropose;
    }

    /**
     * @return string|null
     */
    public function getTraitancePropose()
    {
        return $this->traitancePropose;
    }

    /**
     * @param string|null $traitanceforme
     */
    public function setTraitanceForme($traitanceforme)
    {
        $this->traitanceForme = $traitanceforme;
    }

    /**
     * @return string|null
     */
    public function getTraitanceForme()
    {
        return $this->traitanceForme;
    }

    /**
     * @param ProfessionnelFormation|null $professionnelFormation
     */
    public function setProfessionnelFormation(ProfessionnelFormation $professionnelFormation = null)
    {
        $this->professionnelFormation = $professionnelFormation;
    }

    /**
     * @return ProfessionnelFormation|null
     */
    public function getProfessionnelFormation()
    {
        return $this->professionnelFormation;
    }
}