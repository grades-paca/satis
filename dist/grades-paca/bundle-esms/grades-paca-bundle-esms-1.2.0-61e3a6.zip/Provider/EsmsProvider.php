<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 06/02/14
 * Time: 10:47
 */

namespace Oru\Bundle\EsmsBundle\Provider;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\Common\Persistence\ObjectManager;
use Oru\Bundle\EsmsBundle\Entity\Identification;
use Oru\Bundle\EsmsBundle\Exception\IntegrityException;
use Oru\Bundle\EsmsBundle\Filter\EsmsFilter;
use Oru\Bundle\EsmsBundle\Entity\Esms;
use Oru\Bundle\RorBundle\Entity\Etablissement;
use Oru\Bundle\SettingBundle\Setting\Setting;

/**
 * Class EsmsProvider
 * @package Oru\Bundle\EsmsBundle\Provider
 * @author Michaël VEROUX
 */
class EsmsProvider
{
    /**
     * @var \Doctrine\Common\Persistence\ObjectManager
     */
    protected $entityManager;

    /**
     * @var Setting
     */
    protected $setting;

    /**
     * @param ObjectManager $entityManager
     * @param Setting $setting
     */
    public function __construct(ObjectManager $entityManager, Setting $setting)
    {
        $this->entityManager = $entityManager;
        $this->setting = $setting;
    }

    /**
     * @param $id
     * @return object
     * @author Michaël VEROUX
     */
    public function find($id)
    {
        $esms = $this->entityManager->getRepository('OruEsmsBundle:Esms')->find($id);

        return $esms;
    }

    /**
     * @param Etablissement $etablissement
     * @return Esms
     * @author Michaël VEROUX
     */
    public function findCurrentByEtablissement(Etablissement $etablissement)
    {
        $esmes = $this->entityManager->getRepository('OruEsmsBundle:Esms')->findByEtablissementAndYear(
            $etablissement,
            date('Y')
        );

        if(count($esmes))
            return $esmes[0];

        return $this->create($etablissement);
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    public function findAll()
    {
        $esmses = $this->entityManager->getRepository('OruEsmsBundle:Esms')->findAll();

        return $esmses;
    }

    /**
     * @param EsmsFilter $esmsFilter
     * @return \Doctrine\ORM\QueryBuilder
     * @author Michaël VEROUX
     */
    public function findList(EsmsFilter $esmsFilter)
    {
        $builder = $this->entityManager->getRepository('OruEsmsBundle:Esms')
            ->createQueryBuilder("e")
            ->innerJoin('e.identification', 'i')
            ->innerJoin('i.etablissement', 'et')
        ;

        if(count($esmsFilter->getEtablissements()))
        {
            $builder
                ->andWhere('i.etablissement IN (:etablissements)')
                ->setParameter('etablissements', $esmsFilter->getEtablissementsIds())
            ;
        }

        if(count($esmsFilter->getDepartements()))
        {
            $builder
                ->innerJoin('et.adresse', 'a')
                ->innerJoin('a.departement', 'd')
                ->andWhere('a.departement IN (:departements)')
                ->setParameter('departements', $esmsFilter->getDepartementsIds())
            ;
        }



        if(null !== $esmsFilter->getFiness())
        {
            $builder
                ->andWhere('et.finessGeographique LIKE :finess')
                ->setParameter('finess', "%{$esmsFilter->getFiness()}%")
            ;
        }

        if(count($esmsFilter->getIncrements()))
        {
            $this->entityManager->getConfiguration()
                ->addCustomStringFunction('REGEXP', 'Oru\Bundle\EsmsBundle\Doctrine\Query\Mysql\Regexp')
            ;

            $builder
                ->andWhere('REGEXP(e.created, :increments) = 1')
                ->setParameter('increments', implode('.+|', $esmsFilter->getIncrements()) . '.+')
            ;
        }

        if(true === $esmsFilter->getDeleted())
            $builder->andWhere('e.deleted IS NOT NULL');
        else
            $builder->andWhere('e.deleted IS NULL');


        if('empty_value' !== $esmsFilter->getStatut())
        {
            switch($esmsFilter->getStatut())
            {
                case '0':
                    $builder->andWhere('e.complete = 0');
                    break;
                case '1':
                    $builder->andWhere('e.complete = 1');
                    break;
            }
        }

        return $builder;
    }

    /**
     * @param Etablissement $etablissement
     * @return Esms
     * @throws IntegrityException
     * @author Michaël VEROUX
     */
    public function create(Etablissement $etablissement)
    {
        $esmses = $this->entityManager->getRepository('OruEsmsBundle:Esms')->findByEtablissement(
            $etablissement
        );

        if(count($esmses))
        {
            if(! $esmses instanceof Collection)
            {
                $esmses = new ArrayCollection($esmses);
            }

            $currentYear = (int) date('Y');

            $currents = $esmses->filter(function(Esms $esms) use ($currentYear)
                {
                    if($currentYear === $esms->getIncrement())
                    {
                        return true;
                    }

                    return false;
                }
            );

            if(count($currents))
            {
                throw new IntegrityException('Form already exists for this etablissement');
            }
        }

        $esms = new Esms();
        $esms->getAccesDonneesSante();
        $esms->getBientraitance();
        $esms->getConseilVieSociale();
        $esms->getContratSejour();
        $esms->getContratSoutien();
        $esms->getEvaluations();
        $esms->getFinVie();
        $esms->getLivretAccueil();
        $esms->getPersonnesQualifiees();
        $esms->getPlaintesReclamations();
        $esms->getProfessionnelFormation()->getProfessionnelFormationTheme();
        $esms->getProjetEtablissement();
        $esms->getSuiviOutils();
        $esms->getReglement();

        $identification = new Identification();
        $identification->setEtablissement($etablissement);

        $esms->setIdentification($identification);

        if(count($esmses))
        {
            $last = $esmses->filter(function(Esms $esms) use ($currentYear)
                {
                    if($currentYear - 1  === $esms->getIncrement())
                    {
                        return true;
                    }

                    return false;
                }
            );

            if(count($last))
            {
                $this->copy($last->first(), $esms);
            }
        }

        return $esms;
    }

    protected function copy(Esms $last, Esms $esms)
    {
        $esms->setConseilVieSociale(
            clone $last->getConseilVieSociale()
        );
        $esms->getConseilVieSociale()->setConseilVieSocialeRepresentant(
            clone $last->getConseilVieSociale()->getConseilVieSocialeRepresentant()
        );
        $esms->getConseilVieSociale()->setConseilVieSocialeAvis(
            clone $last->getConseilVieSociale()->getConseilVieSocialeAvis()
        );
        $esms->setPersonnesQualifiees(
            clone $last->getPersonnesQualifiees()
        );
        $esms->getPersonnesQualifiees()->setRecoursNombre(null);
        $esms->getPersonnesQualifiees()->setRecoursNombreCr(null);
        $esms->getPlaintesReclamations()->setProcessus(
            $last->getPlaintesReclamations()->getProcessus()
        );
        $esms->getBientraitance()->setExiste(
            $last->getBientraitance()->getExiste()
        );
        $esms->getFinVie()->setDroits(
            $last->getFinVie()->getDroits()
        );
        $esms->setAccesDonneesSante(
            clone $last->getAccesDonneesSante()
        );
        $esms->setLivretAccueil(
            clone $last->getLivretAccueil()
        );
        $esms->getContratSoutien()->setConcerne(
            $last->getContratSoutien()->getConcerne()
        );
        $esms->setContratSejour(
            clone $last->getContratSejour()
        );
    }
} 