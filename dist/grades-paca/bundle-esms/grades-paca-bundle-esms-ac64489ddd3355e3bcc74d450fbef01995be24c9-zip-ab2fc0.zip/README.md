Bundle EsmsBundle
=================

Installation
------------

Dans le AppKernel.php, activer ce bundle

    $bundles[] = new Oru\Bundle\EsmsBundle\OruEsmsBundle();

Dans le routing.yml, ajouter les routes :

    oru_esms:
        resource: "@OruEsmsBundle/Resources/config/routing.yml"
        prefix: /esms

Dans le config.yml, ajouter ce bundle aux paramètres imports :

    imports:
    ...
    - { resource: @OruEsmsBundle/Resources/config/config.yml }

Vider le cache de Symfony

Description
-----------

Bundle des formulaires ESMS
