<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 20/01/14
 * Time: 15:09
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\ConseilVieSociale as BaseConseilVieSociale;
use Oru\Bundle\FormIncrementalBundle\Entity\FormIncrementalInterface;
use Symfony\Component\Validator\Context\ExecutionContextInterface;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class ConseilVieSociale
 * @package Oru\Bundle\EsmsBundle\Entity
 * @author Michaël VEROUX
 */
class ConseilVieSociale extends BaseConseilVieSociale implements GroupSequenceProviderInterface, FormIncrementalInterface
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var Esms
     */
    protected $esms;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $esms
     */
    public function setEsms($esms)
    {
        $this->esms = $esms;
    }

    /**
     * @return Esms
     */
    public function getEsms()
    {
        return $this->esms;
    }

    /**
     * @param ExecutionContextInterface $context
     * @author Michaël VEROUX
     */
    public function isAnneeInstallationValid(ExecutionContextInterface $context)
    {
        if ($this->getAnneeInstallation() > date('Y')) {
            $context->buildViolation('L\'année  saisie doit être dans le passé.')->atPath('anneeInstallation')->addViolation();
        }
    }

    /**
     * @return null|ConseilVieSocialeRepresentant
     * @author Michaël VEROUX
     */
    public function getConseilVieSocialeRepresentant()
    {
        return null === $this->conseilVieSocialeRepresentant ? new ConseilVieSocialeRepresentant() : parent::getConseilVieSocialeRepresentant();
    }

    /**
     * @return null|ConseilVieSocialeAvis
     * @author Michaël VEROUX
     */
    public function getConseilVieSocialeAvis()
    {
        return null === $this->conseilVieSocialeAvis ? new ConseilVieSocialeAvis() : parent::getConseilVieSocialeAvis();
    }

    /**
     * Return current increment of object (year, month or what you want...)
     * @return int
     * @author Michaël VEROUX
     */
    public function getIncrement()
    {
        return $this->getEsms()->getIncrement();
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $transPrefix = 'oru_esms_conseilVieSociale.';
        $groups = array();

        if($this->getExist())
        {
            $groups[] = 'cvsExistTrue';
        }
        else
        {
            $groups[] = 'cvsExistFalse';
        }

        if($this->getReglementInterieur())
        {
            $groups[] = 'reglementInterieurTrue';
        }
        elseif(null !== $this->getReglementInterieur())
        {
            $groups[] = 'reglementInterieurFalse';
        }

        $presidenceChoix = array_flip( $this->getEsms()->getTranslatedChoicesByKey($transPrefix . 'presidence') );

        if(false !== strpos($this->getPresidence(), end($presidenceChoix)))
        {
            $groups[] = 'presidenceAutreTrue';
        }

        $avisSolliciteChoix = array_flip( $this->getEsms()->getTranslatedChoicesByKey($transPrefix . 'avisSollicite') );

        if(false !== strpos($this->getAvisSollicite(), end($avisSolliciteChoix)))
        {
            $groups[] = 'avisSolliciteAutreTrue';
        }

        $autreFormeGroupeDiscussionChoix = array_flip( $this->getEsms()->getTranslatedChoicesByKey($transPrefix . 'autreFormeGroupeDiscussion') );

        if(false !== strpos($this->getAutreFormeGroupeDiscussion(), end($autreFormeGroupeDiscussionChoix)))
        {
            $groups[] = 'autreFormeAutreTrue';
        }

        if(false === $this->getEstimation())
        {
            $groups[] = 'estimationFalse';
        }

        return array_merge(
            $groups,
            $this->getConseilVieSocialeRepresentant() instanceof GroupSequenceProviderInterface ? $this->getConseilVieSocialeRepresentant()->getGroupSequence() : array(),
            $this->getConseilVieSocialeAvis() instanceof GroupSequenceProviderInterface ? $this->getConseilVieSocialeAvis()->getGroupSequence() : array()
        );
    }

    public function __clone()
    {
        $this->id = null;
    }
}