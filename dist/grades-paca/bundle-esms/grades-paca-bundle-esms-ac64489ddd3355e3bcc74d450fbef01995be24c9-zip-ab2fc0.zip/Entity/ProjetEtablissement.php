<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 22/01/14
 * Time: 18:24
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\ProjetEtablissement as BaseProjetEtablissement;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class ProjetEtablissement
 * @package Oru\Bundle\EsmsBundle\Entity
 * @author Michaël VEROUX
 */
class ProjetEtablissement extends BaseProjetEtablissement implements GroupSequenceProviderInterface
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var Esms
     */
    protected $esms;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $esms
     */
    public function setEsms($esms)
    {
        $this->esms = $esms;
    }

    /**
     * @return mixed
     */
    public function getEsms()
    {
        return $this->esms;
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $groups = array();

        if(!$this->getExiste() && null !== $this->getExiste())
        {
            $groups[] = 'peExisteFalse';
        }

        if(!$this->getPratiqueAnesm() && null !== $this->getPratiqueAnesm())
        {
            $groups[] = 'pratiqueAnesmFalse';
        }

        return $groups;
    }

    public function __clone()
    {
        $this->id = null;
    }
} 