<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\EsmsBundle\Entity\ContratSejour;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ContratSejourType
 * @package Oru\Bundle\EsmsBundle\Form
 * @author Michaël VEROUX
 */
class ContratSejourType extends AbstractType
{
    /**
     * @var \Oru\Bundle\EsmsBundle\Choice\ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param ChoiceProvider $choiceProvider
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(ChoiceProvider $choiceProvider, IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->choiceProvider = $choiceProvider;
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choicesPrefix = 'oru_esms_' . $this->getName();

        $personneParticipeChoix = $this->choiceProvider->getFieldChoices($choicesPrefix, 'personneParticipe', 3);

        $builder
            ->add('signeSection', 'oru_section', array()
            )
            ->add('signeJourAdmission', 'frequence'
            )
            ->add('signeQuinzeJours', 'frequence'
            )
            ->add('signeQuinzeTrenteJours', 'frequence'
            )
            ->add('signePlusTrenteJours', 'frequence'
            )
            ->add('signeSectionEnd', 'oru_section', array(
                    'label'     =>  ' ',
                )
            )
            ->add('avenantSixMois', 'frequence', array(
                    'justify'       =>  array('avenantSixMoisJamais'),
                )
            )
            ->add('avenantSixMoisJamais'
            )
            ->add('personneParticipe', 'oru_conditional', array(
                    'placeholder'   =>  '---choix---',
                    'expanded'      =>  false,
                    'choices'       =>  $personneParticipeChoix,
                    'conditionals'  =>  array(
                        $this->getLastChoice($personneParticipeChoix) =>  array('personneParticipeNonDetail'),
                    )
                )
            )
            ->add('personneParticipeNonDetailListe', 'oru_choices_to_string', array(
                    'expanded'      =>  true,
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'personneParticipeNonDetailListe', 4),
                )
            )
            ->add('personneParticipeNonDetail'
            )
            ->add('clauseModification'
            )
            ->add('information', 'oru_choices_to_string', array(
                    'expanded'      =>  true,
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'information', 6),
                )
            )
            ->add('informationAutre'
            )
            ->add('reactualiseAnnuel', 'oru_oui_non_detail', array(
                    'detail'    =>  'reactualiseAnnuelNonDetail'
                )
            )
            ->add('reactualiseAnnuelNonDetail'
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\ContratSejour',
            'translation_domain'    => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getName()
    {
        return 'contratSejour';
    }

    /**
     * @param $string
     * @return array
     * @author Michaël VEROUX
     */
    protected function translateArrayKeys($string)
    {
        if(is_array($string))
        {
            return array_combine(array_map(array($this,'translateArrayKeys'),$string), $string);
        }
        return $this->translator->trans($string, array(), 'OruEsmsBundle');
    }

    /**
     * @param $array
     * @return mixed
     * @author Michaël VEROUX
     */
    protected function getLastChoice($array)
    {
        $choices = array_flip($array);

        return array_pop($choices);
    }
} 