<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\EsmsBundle\Form\Type\DifficulteType;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class AccesDonneesSanteType
 * @package Oru\Bundle\EsmsBundle\Form
 * @author Michaël VEROUX
 */
class AccesDonneesSanteType extends AbstractType
{
    /**
     * @var \Oru\Bundle\EsmsBundle\Choice\ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param ChoiceProvider $choiceProvider
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(ChoiceProvider $choiceProvider, IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->choiceProvider = $choiceProvider;
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choicesPrefix = 'oru_esms_' . $this->getName();

        $builder
            ->add('accesProSection', 'oru_section'
            )
            ->add('accesGeneraliste', 'difficulte', array(
                      'choices'     => array_merge(DifficulteType::$baseChoices, array('Non concerné' => 'Non concerné')),
                )
            )
            ->add('accesInfirmier', 'difficulte'
            )
            ->add('accesKine', 'difficulte'
            )
            ->add('accesDentiste', 'difficulte'
            )
            ->add('accesPodologue', 'difficulte'
            )
            ->add('accesOphtalmo', 'difficulte'
            )
            ->add('accesPsy', 'difficulte'
            )
            ->add('accesDifficulteListe', 'oru_choices_to_string', array(
                    'expanded'      =>  true,
                    'choices'       =>  $this->choiceProvider->getFieldChoices($choicesPrefix, 'accesDifficulteListe', 5),
                )
            )
            ->add('accesDifficulte'
            )
            ->add('accesProSectionEnd', 'oru_section', array(
                    'label'     => ' ',
                )
            )
            ->add('accesDossierSection', 'oru_section'
            )
            ->add('accesDonneesDossierMedical', 'oru_oui_non', array(
                    'placeholder'       =>  'Ne sait pas / Non concerné',
                    'expanded'          =>  false,
                )
            )
            ->add('accesDonneesDecision', 'oru_oui_non', array(
                    'placeholder'       =>  'Ne sait pas',
                    'expanded'          =>  false,
                )
            )
            ->add('accesDonneesSoinsProposes', 'oru_oui_non', array(
                    'placeholder'       =>  'Ne sait pas',
                    'expanded'          =>  false,
                )
            )
            ->add('accesDonneestraitantChoix', 'oru_oui_non', array(
                    'placeholder'       =>  'Ne sait pas',
                    'expanded'          =>  false,
                )
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\AccesDonneesSante',
            'translation_domain'    => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getName()
    {
        return 'accesDonneesSante';
    }
} 