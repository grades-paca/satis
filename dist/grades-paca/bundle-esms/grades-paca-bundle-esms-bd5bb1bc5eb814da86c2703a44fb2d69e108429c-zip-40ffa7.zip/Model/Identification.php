<?php
/**
 * Author: Michaël VEROUX
 * Date: 11/07/14
 * Time: 12:16
 */

namespace Oru\Bundle\EsmsBundle\Model;

class Identification
{
    protected $handicapType;

    protected $activites;

    /**
     * @param mixed $handicapType
     */
    public function setHandicapType($handicapType)
    {
        $this->handicapType = $handicapType;
    }

    /**
     * @return mixed
     */
    public function getHandicapType()
    {
        return $this->handicapType;
    }

    /**
     * @param mixed $activites
     *
     * @return $this
     */
    public function setActivites($activites)
    {
        $this->activites = $activites;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getActivites()
    {
        return $this->activites;
    }
}
