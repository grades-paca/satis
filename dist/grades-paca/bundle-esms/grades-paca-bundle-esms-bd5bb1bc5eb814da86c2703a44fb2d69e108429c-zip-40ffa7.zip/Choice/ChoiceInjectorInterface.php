<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 30/01/14
 * Time: 11:43
 */

namespace Oru\Bundle\EsmsBundle\Choice;

/**
 * Interface ChoiceInjectorInterface.
 *
 * @author Michaël VEROUX
 */
interface ChoiceInjectorInterface
{
    /**
     * @param $translatedChoices
     *
     * @return ChoiceInjectorInterface
     *
     * @author Michaël VEROUX
     */
    public function setTranslatedChoices($translatedChoices);

    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function getTranslatedChoices();

    /**
     * @param $key
     *
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function getTranslatedChoicesByKey($key);
}
