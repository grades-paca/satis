<?php
/**
 * Author: Michaël VEROUX
 * Date: 11/07/14
 * Time: 12:13
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\Identification as BaseIdentification;
use Oru\Bundle\RorBundle\Entity\Etablissement;

class Identification extends BaseIdentification
{
    /**
     * @var int
     */
    protected $id = null;

    /**
     * @var EtablissementInterface
     */
    protected $etablissement = null;

    /**
     * @var Esms
     */
    protected $esms = null;

    public function __toString()
    {
        return (string) $this->getEtablissement();
    }

    public function __clone()
    {
        $this->id = null;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param \Oru\Bundle\PlanBleuBundle\Entity\EtablissementInterface $etablissement
     */
    public function setEtablissement($etablissement)
    {
        $this->etablissement = $etablissement;
    }

    /**
     * @return \Oru\Bundle\PlanBleuBundle\Entity\EtablissementInterface|Etablissement
     */
    public function getEtablissement()
    {
        return $this->etablissement;
    }

    /**
     * @param \Oru\Bundle\EsmsBundle\Entity\Esms $esms
     */
    public function setEsms($esms)
    {
        $this->esms = $esms;
    }

    /**
     * @return \Oru\Bundle\EsmsBundle\Entity\Esms
     */
    public function getEsms()
    {
        return $this->esms;
    }

    public function getNom()
    {
        return $this->getEtablissement()->getNom();
    }

    public function setNom($nom)
    {
        return $this->getEtablissement()->setNom($nom);
    }

    public function getFiness()
    {
        return $this->getEtablissement()->getFinessGeographique();
    }

    public function setFiness($finess)
    {
        return $this->getEtablissement()->setFinessGeographique($finess);
    }

    public function getSiret()
    {
        return $this->getEtablissement()->getSiret();
    }

    public function setSiret($siret)
    {
        return $this->getEtablissement()->setSiret($siret);
    }

    public function getStructure()
    {
        return (string) $this->getEtablissement()->getStructure();
    }

    public function setStructure($structure)
    {
    }

    public function getAdresse()
    {
        return $this->getEtablissement()->getAdresse();
    }

    public function setAdresse($adresse)
    {
    }

    public function getEmailAlerte()
    {
        return $this->getEtablissement()->getAlerteEmail();
    }

    public function setEmailAlerte($email)
    {
        return $this->getEtablissement()->setAlerteEmail($email);
    }

    public function getDepartementNom()
    {
        if (is_object($this->getEtablissement()->getAdresse()) && is_object($this->getEtablissement()->getAdresse()->getDepartement())) {
            return (string) $this->getEtablissement()->getAdresse()->getDepartement();
        }
    }

    public function setDepartementNom($departement)
    {
    }

    public function getTypeStatut()
    {
        return (string) $this->getEtablissement()->getStructure()->getStatutJuridique();
    }

    public function setTypeStatut($typeStatut)
    {
    }
}
