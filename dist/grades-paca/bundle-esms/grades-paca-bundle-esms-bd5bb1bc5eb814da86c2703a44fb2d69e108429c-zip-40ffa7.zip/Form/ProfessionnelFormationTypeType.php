<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 17/01/14
 * Time: 10:04
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\FormBundle\Form\Type\SumType;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ProfessionnelFormationTypeType.
 *
 * @author Michaël VEROUX
 */
class ProfessionnelFormationTypeType extends AbstractType
{
    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('medicalForme', NumberType::class, array(
                    'attr' => array('class' => 'type_forme'),
                )
            )
            ->add('paramedicalForme', NumberType::class, array(
                    'attr' => array('class' => 'type_forme'),
                )
            )
            ->add('socialForme', NumberType::class, array(
                    'attr' => array('class' => 'type_forme'),
                )
            )
            ->add('administratifForme', NumberType::class, array(
                    'attr' => array('class' => 'type_forme'),
                )
            )
            ->add('educatifForme', NumberType::class, array(
                    'attr' => array('class' => 'type_forme'),
                )
            )
            ->add('sumForme', SumType::class, array(
                    'mapped' => false,
                    'type_class' => 'type_forme',
                    'attr' => array('disabled' => 'disabled', 'class' => 'bold'),
                )
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\ProfessionnelFormationType',
            'translation_domain' => 'OruEsmsBundle',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'professionnelFormationType';
    }
}
