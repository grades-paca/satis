<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 20/01/14
 * Time: 15:09
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\ConseilVieSocialeRepresentant as BaseConseilVieSocialeRepresentant;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class ConseilVieSocialeRepresentant.
 *
 * @author Michaël VEROUX
 */
class ConseilVieSocialeRepresentant extends BaseConseilVieSocialeRepresentant implements GroupSequenceProviderInterface
{
    /**
     * @var int
     */
    protected $id;

    public function __clone()
    {
        $this->id = null;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $groups = array();

        if ($this->isRepresentantsLegauxLowerHalfMembres()) {
            $groups[] = 'representantInferieurMoitieTrue';
        }

        return $groups;
    }
}
