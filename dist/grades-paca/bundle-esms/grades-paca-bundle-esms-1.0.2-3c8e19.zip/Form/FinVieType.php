<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class FinVieType
 * @package Oru\Bundle\EsmsBundle\Form
 * @author Michaël VEROUX
 */
class FinVieType extends AbstractType
{
    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('droits', 'oru_conditional', array(
                    'placeholder'       =>  '---choix---',
                    'choices'           =>  array(
                        'oui'             =>  'oui',
                        'non'             =>  'non',
                        'non concerné'    =>  'non concerné',
                    ),
                    'conditionals'          =>  array(
                        'oui'   =>  array('directivesNombre','accompagnesNombre','percentCalcDroits'),
                    ),
                )
            )
            ->add('directivesNombre', null, array(
                    'attr'      =>  array('class' => 'droit_fin_vie'),
                )
            )
            ->add('accompagnesNombre', null, array(
                    'attr'      =>  array('class' => 'droit_fin_vie_total'),
                )
            )
            ->add('percentCalcDroits', 'oru_percent_calc', array(
//                    'mapped'        => false,
                    'type_class'    => 'droit_fin_vie',
                    'type_class_total' => 'droit_fin_vie_total',
                    'attr'          => array('readonly' => 'readonly'),
                )
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\FinVie',
            'translation_domain'    => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getName()
    {
        return 'finVie';
    }
} 