<?php

namespace Oru\Bundle\EsmsBundle;

use Oru\Bundle\SettingBundle\Bundle\OruBundle;

class OruEsmsBundle extends OruBundle
{
    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getFriendlyName()
    {
        return 'Bundle ESMS';
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getDescription()
    {
        return 'Formulaire ESMS';
    }
}
