<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 17/01/14
 * Time: 10:02
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\ProfessionnelFormationType as BaseProfessionnelFormationType;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class ProfessionnelFormationType
 * @package Oru\Bundle\EsmsBundle\Entity
 * @author Michaël VEROUX
 */
class ProfessionnelFormationType extends BaseProfessionnelFormationType implements GroupSequenceProviderInterface
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        return array();
    }

    public function __clone()
    {
        $this->id = null;
    }
} 