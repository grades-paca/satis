<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 22/01/14
 * Time: 13:54
 */

namespace Oru\Bundle\EsmsBundle\Form\Type;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\FormBundle\Form\Type\ConditionalType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Exception\BadMethodCallException;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class FrequenceType.
 *
 * @author Michaël VEROUX
 */
class FrequenceType extends AbstractType
{
    /**
     * @var \Oru\Bundle\EsmsBundle\Choice\ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @param ChoiceProvider $choiceProvider
     */
    public function __construct(ChoiceProvider $choiceProvider)
    {
        $this->choiceProvider = $choiceProvider;
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $choices = $this->choiceProvider->getFieldChoices('oru_esms', 'frequence', 4);

        $resolver->setDefined(array('justify'));

        $resolver->setDefaults(array(
                                   'choices_as_values' => true,
            'choices' => $choices,
            'conditionals' => array(),
            'placeholder' => '----choix----',
            'justify' => false,
        ));

        parent::configureOptions($resolver);
    }

    /**
     * @param FormView      $view
     * @param FormInterface $form
     * @param array         $options
     *
     * @throws \Symfony\Component\Form\Exception\BadMethodCallException
     *
     * @author Michaël VEROUX
     */
    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        if ($options['justify'] && !count($options['conditionals'])) {
            $choices_keys = array_keys($options['choices']);
            $never_index = end($choices_keys);

            if (!is_array($options['justify'])) {
                throw new BadMethodCallException('Option justify must be an array or false!');
            }
            $options['conditionals'] = array(
                $never_index => $options['justify'],
            );
        }
        $view->vars['conditionals'] = $options['conditionals'];
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getParent()
    {
        return ConditionalType::class;
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'frequence';
    }
}
