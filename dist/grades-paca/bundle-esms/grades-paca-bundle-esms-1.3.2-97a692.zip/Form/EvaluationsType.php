<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\FormBundle\Form\Type\OuiNonDetailType;
use Oru\Bundle\FormBundle\Form\Type\OuiNonType;
use Oru\Bundle\FormBundle\Form\Type\SectionType;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class EvaluationsType.
 *
 * @author Michaël VEROUX
 */
class EvaluationsType extends AbstractType
{
    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('evaluations', SectionType::class
            )
            ->add('interne', OuiNonDetailType::class, array(
                    'detail' => 'interneDate',
                    'on_no' => false,
                )
            )
            ->add('interneDate', null, array(
                    'attr' => array('min' => 1980),
                )
            )
            ->add('externe', OuiNonDetailType::class, array(
                    'detail' => 'externeDate',
                    'on_no' => false,
                )
            )
            ->add('externeDate', null, array(
                    'attr' => array('min' => 1980),
                )
            )
            ->add('nonEvaluationDetail'
            )
            ->add('resultats', SectionType::class
            )
            ->add('resultatInterne', OuiNonType::class
            )
            ->add('resultatExterne', OuiNonType::class
            )
            ->add('nonEvaluationResultatDetail'
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\Evaluations',
            'translation_domain' => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getBlockPrefix()
    {
        return 'evaluations';
    }
}
