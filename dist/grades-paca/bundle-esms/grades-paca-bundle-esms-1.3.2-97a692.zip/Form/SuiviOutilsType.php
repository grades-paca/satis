<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\EsmsBundle\Form\Type\FrequenceType;
use Oru\Bundle\EsmsBundle\Form\Type\PersonnesType;
use Oru\Bundle\FormBundle\Form\Type\CheckedDetailType;
use Oru\Bundle\FormBundle\Form\Type\ChoicesToStringType;
use Oru\Bundle\FormBundle\Form\Type\ConditionalType;
use Oru\Bundle\FormBundle\Form\Type\SectionType;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class SuiviOutilsType.
 *
 * @author Michaël VEROUX
 */
class SuiviOutilsType extends AbstractType
{
    /**
     * @var \Oru\Bundle\EsmsBundle\Choice\ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @param ChoiceProvider                $choiceProvider
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     */
    public function __construct(ChoiceProvider $choiceProvider, IncrementalValiditySubscriber $incrementalValiditySubscriber)
    {
        $this->choiceProvider = $choiceProvider;
        $this->validitySubscriber = $incrementalValiditySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choicesPrefix = 'oru_esms_'.$this->getName();

        $builder
            ->add('difficultes', SectionType::class
            )
            ->add('difficultesLivretBoolean', CheckedDetailType::class, array(
                    'detail' => 'difficultesLivret',
                )
            )
            ->add('difficultesLivret'
            )
            ->add('difficultesInstancesParticipationBoolean', CheckedDetailType::class, array(
                    'detail' => 'difficultesInstancesParticipation',
                )
            )
            ->add('difficultesInstancesParticipation'
            )
            ->add('difficultesContratSejourBoolean', CheckedDetailType::class, array(
                    'detail' => 'difficultesContratSejour',
                )
            )
            ->add('difficultesContratSejour'
            )
            ->add('difficultesReglementFonctionnementBoolean', CheckedDetailType::class, array(
                    'detail' => 'difficultesReglementFonctionnement',
                )
            )
            ->add('difficultesReglementFonctionnement'
            )
            ->add('difficultesProjetEtablissementBoolean', CheckedDetailType::class, array(
                    'detail' => 'difficultesProjetEtablissement',
                )
            )
            ->add('difficultesProjetEtablissement'
            )
            ->add('difficultesEvaluationsInternesBoolean', CheckedDetailType::class, array(
                    'detail' => 'difficultesEvaluationsInternes',
                )
            )
            ->add('difficultesEvaluationsInternes'
            )
            ->add('difficultesEvaluationsExternesBoolean', CheckedDetailType::class, array(
                    'detail' => 'difficultesEvaluationsExternes',
                )
            )
            ->add('difficultesEvaluationsExternes'
            )
            ->add('difficultesEnd', SectionType::class, array(
                    'label' => ' ',
                )
            )
            ->add('documentAdapteDeficiences', FrequenceType::class, array(
                    'placeholder' => 'Non concerné',
                    'justify' => array('documentAdapteDeficiencesNonDetail'),
                )
            )
            ->add('documentAdapteDeficiencesNonDetail'
            )
            ->add('documentAdapteAccompagnes', ChoicesToStringType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'documentAdapteAccompagnes', 4),
                )
            )
            ->add('actualisation', SectionType::class
            )
            ->add('actualisationLivretBoolean', ConditionalType::class, array(
                    'expanded' => true,
                    'choices_as_values' => true,
                    'choices' => array(
                        'Oui' => '1',
                        'Jamais actualisé' => '0',
                    ),
                    'conditionals' => array(
                        '1' => array('actualisationLivret'),
                    ),
                )
            )
            ->add('actualisationLivret', null, array(
                    'attr' => array('min' => 1980),
                )
            )
            ->add('actualisationContratSejourBoolean', ConditionalType::class, array(
                    'expanded' => true,
                    'choices_as_values' => true,
                    'choices' => array(
                        'Oui' => '1',
                        'Jamais actualisé' => '0',
                    ),
                    'conditionals' => array(
                        '1' => array('actualisationContratSejour'),
                    ),
                )
            )
            ->add('actualisationContratSejour', null, array(
                    'attr' => array('min' => 1980),
                )
            )
            ->add('actualisationProjetEtablissementBoolean', ConditionalType::class, array(
                    'expanded' => true,
                    'choices_as_values' => true,
                    'choices' => array(
                        'Oui' => '1',
                        'Jamais actualisé' => '0',
                    ),
                    'conditionals' => array(
                        '1' => array('actualisationProjetEtablissement'),
                    ),
                )
            )
            ->add('actualisationProjetEtablissement', null, array(
                    'attr' => array('min' => 1980),
                )
            )
            ->add('actualisationEnd', SectionType::class, array(
                    'label' => ' ',
                )
            )
            ->add('outilsEvaluation', SectionType::class
            )
            ->add('outilsEvaluationLivretBoolean', ConditionalType::class, array(
                    'expanded' => true,
                    'choices_as_values' => true,
                    'choices' => array(
                        'Oui' => '1',
                        'Jamais' => '0',
                    ),
                    'conditionals' => array(
                        '1' => array('outilsEvaluationLivret', 'outilsEvaluationLivretQui'),
                    ),
                )
            )
            ->add('outilsEvaluationLivret'
            )
            ->add('outilsEvaluationLivretQui', PersonnesType::class
            )
            ->add('outilsEvaluationContratSejourBoolean', ConditionalType::class, array(
                    'expanded' => true,
                    'choices_as_values' => true,
                    'choices' => array(
                        'Oui' => '1',
                        'Jamais' => '0',
                    ),
                    'conditionals' => array(
                        '1' => array('outilsEvaluationContratSejour', 'outilsEvaluationContratSejourQui'),
                    ),
                )
            )
            ->add('outilsEvaluationContratSejour'
            )
            ->add('outilsEvaluationContratSejourQui', PersonnesType::class
            )
            ->add('outilsEvaluationLivretProjetEtablissementBoolean', ConditionalType::class, array(
                    'expanded' => true,
                    'choices_as_values' => true,
                    'choices' => array(
                        'Oui' => '1',
                        'Jamais' => '0',
                    ),
                    'conditionals' => array(
                        '1' => array('outilsEvaluationLivretProjetEtablissement', 'outilsEvaluationLivretProjetEtablissementQui'),
                    ),
                )
            )
            ->add('outilsEvaluationLivretProjetEtablissement'
            )
            ->add('outilsEvaluationLivretProjetEtablissementQui', PersonnesType::class
            )
            ->add('outilsEvaluationLivretReglementBoolean', ConditionalType::class, array(
                    'expanded' => true,
                    'choices_as_values' => true,
                    'choices' => array(
                        'Oui' => '1',
                        'Jamais' => '0',
                    ),
                    'conditionals' => array(
                        '1' => array('outilsEvaluationLivretReglement', 'outilsEvaluationLivretReglementQui'),
                    ),
                )
            )
            ->add('outilsEvaluationLivretReglement'
            )
            ->add('outilsEvaluationLivretReglementQui', PersonnesType::class
            )
            ->add('outilsEvaluationEnd', SectionType::class, array(
                    'label' => ' ',
                )
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\SuiviOutils',
            'translation_domain' => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getBlockPrefix()
    {
        return 'suiviOutils';
    }
}
