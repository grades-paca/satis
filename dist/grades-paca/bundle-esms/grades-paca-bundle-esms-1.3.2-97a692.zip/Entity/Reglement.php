<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 03/06/2014
 * Time: 16:20
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\Reglement as BaseReglement;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class Reglement.
 *
 * @author Michaël VEROUX
 */
class Reglement extends BaseReglement implements GroupSequenceProviderInterface
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var Esms
     */
    protected $esms;

    public function __clone()
    {
        $this->id = null;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $esms
     */
    public function setEsms($esms)
    {
        $this->esms = $esms;
    }

    /**
     * @return mixed
     */
    public function getEsms()
    {
        return $this->esms;
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $transPrefix = 'oru_esms_reglement.';
        $groups = array();

        if (!$this->getReglementFonctionnement() && null !== $this->getReglementFonctionnement()) {
            $groups[] = 'reglementFonctionnementFalse';
        }

        return $groups;
    }
}
