<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 23/01/14
 * Time: 09:44
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\SuiviOutils as BaseSuiviOutils;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class SuiviOutils.
 *
 * @author Michaël VEROUX
 */
class SuiviOutils extends BaseSuiviOutils implements GroupSequenceProviderInterface
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var Esms
     */
    protected $esms;

    public function __clone()
    {
        $this->id = null;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $esms
     */
    public function setEsms($esms)
    {
        $this->esms = $esms;
    }

    /**
     * @return mixed
     */
    public function getEsms()
    {
        return $this->esms;
    }

    /**
     * @param $bool
     *
     * @author Michaël VEROUX
     */
    public function setActualisationLivretBoolean($bool)
    {
        $this->actualisationLivretBoolean = $bool;
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isActualisationLivretBoolean()
    {
        if (isset($this->actualisationLivretBoolean)) {
            return $this->actualisationLivretBoolean;
        }
        return null !== $this->getActualisationLivret();
    }

    /**
     * @param $bool
     *
     * @return mixed
     *
     * @author Michaël VEROUX
     */
    public function setActualisationContratSejourBoolean($bool)
    {
        if (isset($this->actualisationContratSejourBoolean)) {
            return $this->actualisationContratSejourBoolean;
        }
        $this->actualisationContratSejourBoolean = $bool;
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isActualisationContratSejourBoolean()
    {
        if (isset($this->actualisationContratSejourBoolean)) {
            return $this->actualisationContratSejourBoolean;
        }
        return null !== $this->getActualisationContratSejour();
    }

    /**
     * @param $bool
     *
     * @author Michaël VEROUX
     */
    public function setActualisationProjetEtablissementBoolean($bool)
    {
        $this->actualisationProjetEtablissementBoolean = $bool;
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isActualisationProjetEtablissementBoolean()
    {
        if (isset($this->actualisationProjetEtablissementBoolean)) {
            return $this->actualisationProjetEtablissementBoolean;
        }
        return null !== $this->getActualisationProjetEtablissement();
    }

    /**
     * @param $bool
     *
     * @author Michaël VEROUX
     */
    public function setOutilsEvaluationLivretBoolean($bool)
    {
        $this->outilsEvaluationLivretBoolean = $bool;
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isOutilsEvaluationLivretBoolean()
    {
        if (isset($this->outilsEvaluationLivretBoolean)) {
            return $this->outilsEvaluationLivretBoolean;
        }
        return null !== $this->getOutilsEvaluationLivret()
            || '' !== $this->getOutilsEvaluationLivretQui();
    }

    /**
     * @param $bool
     *
     * @author Michaël VEROUX
     */
    public function setOutilsEvaluationContratSejourBoolean($bool)
    {
        $this->outilsEvaluationContratSejourBoolean = $bool;
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isOutilsEvaluationContratSejourBoolean()
    {
        if (isset($this->outilsEvaluationContratSejourBoolean)) {
            return $this->outilsEvaluationContratSejourBoolean;
        }
        return null !== $this->getOutilsEvaluationContratSejour()
        || '' !== $this->getOutilsEvaluationContratSejourQui();
    }

    /**
     * @param $bool
     *
     * @author Michaël VEROUX
     */
    public function setOutilsEvaluationLivretProjetEtablissementBoolean($bool)
    {
        $this->outilsEvaluationLivretProjetEtablissementBoolean = $bool;
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isOutilsEvaluationLivretProjetEtablissementBoolean()
    {
        if (isset($this->outilsEvaluationLivretProjetEtablissementBoolean)) {
            return $this->outilsEvaluationLivretProjetEtablissementBoolean;
        }
        return null !== $this->getOutilsEvaluationLivretProjetEtablissement()
        || '' !== $this->getOutilsEvaluationLivretProjetEtablissementQui();
    }

    /**
     * @param $bool
     *
     * @author Michaël VEROUX
     */
    public function setOutilsEvaluationLivretReglementBoolean($bool)
    {
        $this->outilsEvaluationLivretReglementBoolean = $bool;
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isOutilsEvaluationLivretReglementBoolean()
    {
        if (isset($this->outilsEvaluationLivretReglementBoolean)) {
            return $this->outilsEvaluationLivretReglementBoolean;
        }
        return null !== $this->getOutilsEvaluationLivretReglement()
        || '' !== $this->getOutilsEvaluationLivretReglementQui();
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $groups = array();

        $frequenceChoix = array_flip($this->getEsms()->getTranslatedChoicesByKey('oru_esms.frequence'));

        if (false !== strpos($this->getDocumentAdapteDeficiences(), end($frequenceChoix))) {
            $groups[] = 'documentAdapteDeficiencesJamais';
        }

        if ($this->isActualisationLivretBoolean()) {
            $groups[] = 'actualisationLivretBooleanTrue';
        }

        if ($this->isActualisationContratSejourBoolean()) {
            $groups[] = 'actualisationContratSejourBooleanTrue';
        }

        if ($this->isActualisationProjetEtablissementBoolean()) {
            $groups[] = 'actualisationProjetEtablissementBooleanTrue';
        }

        if ($this->isOutilsEvaluationContratSejourBoolean()) {
            $groups[] = 'outilsEvaluationContratSejourBooleanTrue';
        }

        if ($this->isOutilsEvaluationLivretProjetEtablissementBoolean()) {
            $groups[] = 'outilsEvaluationLivretProjetEtablissementBooleanTrue';
        }

        if ($this->isOutilsEvaluationLivretBoolean()) {
            $groups[] = 'outilsEvaluationLivretBooleanTrue';
        }

        if ($this->isOutilsEvaluationLivretReglementBoolean()) {
            $groups[] = 'outilsEvaluationLivretReglementBooleanTrue';
        }

        return $groups;
    }
}
