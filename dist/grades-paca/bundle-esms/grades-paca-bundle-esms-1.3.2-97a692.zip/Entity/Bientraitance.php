<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 22/01/14
 * Time: 11:43
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\Bientraitance as BaseBientraitance;

/**
 * Class Bientraitance.
 *
 * @author Michaël VEROUX
 */
class Bientraitance extends BaseBientraitance
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var Esms
     */
    protected $esms;

    public function __clone()
    {
        $this->id = null;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $esms
     */
    public function setEsms($esms)
    {
        $this->esms = $esms;
    }

    /**
     * @return mixed
     */
    public function getEsms()
    {
        return $this->esms;
    }
}
