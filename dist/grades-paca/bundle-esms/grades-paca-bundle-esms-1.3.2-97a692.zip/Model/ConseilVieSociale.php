<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 13/01/14
 * Time: 16:06
 */

namespace Oru\Bundle\EsmsBundle\Model;

use Oru\Bundle\FormIncrementalBundle\Annotation\FieldValidity;

/**
 * Class ConseilVieSociale.
 *
 * @author Michaël VEROUX
 */
class ConseilVieSociale
{
    /**
     * @var bool
     */
    protected $exist = false;

    /**
     * @var string|null
     */
    protected $anneeInstallation = null;

    /**
     * @var string|null
     */
    protected $nonRaison = null;

    /**
     * @var string|null
     */
    protected $anneeNbr = null;

    /**
     * @var string|null
     */
    protected $reglementInterieur = null;

    /**
     * @var string|null
     *
     * @FieldValidity(start=2015)
     */
    protected $reglementInterieurDetailListe = null;

    /**
     * @var string|null
     */
    protected $reglementInterieurDetail = null;

    /**
     * @var string|null
     */
    protected $formationMembre = null;

    /**
     * @var string|null
     */
    protected $conseilVieSocialeRepresentant = null;

    /**
     * @var string|null
     *
     * @FieldValidity(start=2015)
     */
    protected $representantVoixConsultativeExterieurDetailListe = null;

    /**
     * @var string|null
     */
    protected $representantVoixConsultativeExterieurDetail = null;

    /**
     * @var string|null
     */
    protected $representantInferieurMoitieDetail = null;

    /**
     * @var string|null
     */
    protected $presidence = null;

    /**
     * @var string|null
     */
    protected $presidenceAutre = null;

    /**
     * @var string|null
     */
    protected $crCommuniques = null;

    /**
     * @var string|null
     */
    protected $crAffiches = null;

    /**
     * @var string|null
     */
    protected $avisSollicite = null;

    /**
     * @var string|null
     */
    protected $avisSolliciteAutre = null;

    /**
     * @var bool|null
     */
    protected $conseilVieSocialeAvisExist = null;

    /**
     * @var string|null
     */
    protected $conseilVieSocialeAvis = null;

    /**
     * @var string|null
     */
    protected $avisAutreDetail = null;

    /**
     * @var string|null
     */
    protected $avisNonSuiviDetail = null;

    /**
     * @var string|null
     */
    protected $avisSuiviDetail = null;

    /**
     * @var string|null
     */
    protected $autreForme = null;

    /**
     * @var string|null
     */
    protected $autreFormeGroupeDiscussion = null;

    /**
     * @var string|null
     */
    protected $autreFormeAutreDetail = null;

    /**
     * @var string|null
     */
    protected $autreFormeDocument = null;

    /**
     * @var string|null
     */
    protected $estimation = null;

    /**
     * @var string|null
     *
     * @FieldValidity(start=2015)
     */
    protected $estimationDetailListe = null;

    /**
     * @var string|null
     *
     * @FieldValidity(stop=2014)
     */
    protected $estimationDetail = null;

    /**
     * @param bool $exist
     */
    public function setExist($exist)
    {
        $this->exist = $exist;
    }

    /**
     * @return bool
     */
    public function getExist()
    {
        return $this->exist;
    }

    /**
     * @param string|null $anneeInstallation
     */
    public function setAnneeInstallation($anneeInstallation)
    {
        $this->anneeInstallation = $anneeInstallation;
    }

    /**
     * @return string|null
     */
    public function getAnneeInstallation()
    {
        return $this->anneeInstallation;
    }

    /**
     * @param string|null $anneeNbr
     */
    public function setAnneeNbr($anneeNbr)
    {
        $this->anneeNbr = $anneeNbr;
    }

    /**
     * @return string|null
     */
    public function getAnneeNbr()
    {
        return $this->anneeNbr;
    }

    /**
     * @param string|null $autreForme
     */
    public function setAutreForme($autreForme)
    {
        $this->autreForme = $autreForme;
    }

    /**
     * @return string|null
     */
    public function getAutreForme()
    {
        return $this->autreForme;
    }

    /**
     * @param string|null $autreFormeAutre
     */
    public function setAutreFormeAutre($autreFormeAutre)
    {
        $this->autreFormeAutre = $autreFormeAutre;
    }

    /**
     * @return string|null
     */
    public function getAutreFormeAutre()
    {
        return $this->autreFormeAutre;
    }

    /**
     * @param string|null $autreFormeAutreDetail
     */
    public function setAutreFormeAutreDetail($autreFormeAutreDetail)
    {
        $this->autreFormeAutreDetail = $autreFormeAutreDetail;
    }

    /**
     * @return string|null
     */
    public function getAutreFormeAutreDetail()
    {
        return $this->autreFormeAutreDetail;
    }

    /**
     * @param string|null $autreFormeConsultationPersonne
     */
    public function setAutreFormeConsultationPersonne($autreFormeConsultationPersonne)
    {
        $this->autreFormeConsultationPersonne = $autreFormeConsultationPersonne;
    }

    /**
     * @return string|null
     */
    public function getAutreFormeConsultationPersonne()
    {
        return $this->autreFormeConsultationPersonne;
    }

    /**
     * @param string|null $autreFormeDocument
     */
    public function setAutreFormeDocument($autreFormeDocument)
    {
        $this->autreFormeDocument = $autreFormeDocument;
    }

    /**
     * @return string|null
     */
    public function getAutreFormeDocument()
    {
        return $this->autreFormeDocument;
    }

    /**
     * @param string|null $autreFormeEnquete
     */
    public function setAutreFormeEnquete($autreFormeEnquete)
    {
        $this->autreFormeEnquete = $autreFormeEnquete;
    }

    /**
     * @return string|null
     */
    public function getAutreFormeEnquete()
    {
        return $this->autreFormeEnquete;
    }

    /**
     * @param string|null $autreFormeGroupeDiscussion
     */
    public function setAutreFormeGroupeDiscussion($autreFormeGroupeDiscussion)
    {
        $this->autreFormeGroupeDiscussion = $autreFormeGroupeDiscussion;
    }

    /**
     * @return string|null
     */
    public function getAutreFormeGroupeDiscussion()
    {
        return $this->autreFormeGroupeDiscussion;
    }

    /**
     * @param string|null $avisAffectationLocauxCollectifsEmis
     */
    public function setAvisAffectationLocauxCollectifsEmis($avisAffectationLocauxCollectifsEmis)
    {
        $this->avisAffectationLocauxCollectifsEmis = $avisAffectationLocauxCollectifsEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisAffectationLocauxCollectifsEmis()
    {
        return $this->avisAffectationLocauxCollectifsEmis;
    }

    /**
     * @param string|null $avisAffectationLocauxCollectifsSuivi
     */
    public function setAvisAffectationLocauxCollectifsSuivi($avisAffectationLocauxCollectifsSuivi)
    {
        $this->avisAffectationLocauxCollectifsSuivi = $avisAffectationLocauxCollectifsSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisAffectationLocauxCollectifsSuivi()
    {
        return $this->avisAffectationLocauxCollectifsSuivi;
    }

    /**
     * @param string|null $avisAnimationEmis
     */
    public function setAvisAnimationEmis($avisAnimationEmis)
    {
        $this->avisAnimationEmis = $avisAnimationEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisAnimationEmis()
    {
        return $this->avisAnimationEmis;
    }

    /**
     * @param string|null $avisAnimationSuivi
     */
    public function setAvisAnimationSuivi($avisAnimationSuivi)
    {
        $this->avisAnimationSuivi = $avisAnimationSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisAnimationSuivi()
    {
        return $this->avisAnimationSuivi;
    }

    /**
     * @param string|null $avisAutreDetail
     */
    public function setAvisAutreDetail($avisAutreDetail)
    {
        $this->avisAutreDetail = $avisAutreDetail;
    }

    /**
     * @return string|null
     */
    public function getAvisAutreDetail()
    {
        return $this->avisAutreDetail;
    }

    /**
     * @param string|null $avisAutreEmis
     */
    public function setAvisAutreEmis($avisAutreEmis)
    {
        $this->avisAutreEmis = $avisAutreEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisAutreEmis()
    {
        return $this->avisAutreEmis;
    }

    /**
     * @param string|null $avisAutreSuivi
     */
    public function setAvisAutreSuivi($avisAutreSuivi)
    {
        $this->avisAutreSuivi = $avisAutreSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisAutreSuivi()
    {
        return $this->avisAutreSuivi;
    }

    /**
     * @param string|null $avisCommunicationExterneEmis
     */
    public function setAvisCommunicationExterneEmis($avisCommunicationExterneEmis)
    {
        $this->avisCommunicationExterneEmis = $avisCommunicationExterneEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisCommunicationExterneEmis()
    {
        return $this->avisCommunicationExterneEmis;
    }

    /**
     * @param string|null $avisCommunicationExterneSuivi
     */
    public function setAvisCommunicationExterneSuivi($avisCommunicationExterneSuivi)
    {
        $this->avisCommunicationExterneSuivi = $avisCommunicationExterneSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisCommunicationExterneSuivi()
    {
        return $this->avisCommunicationExterneSuivi;
    }

    /**
     * @param string|null $avisEntretienLocauxEmis
     */
    public function setAvisEntretienLocauxEmis($avisEntretienLocauxEmis)
    {
        $this->avisEntretienLocauxEmis = $avisEntretienLocauxEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisEntretienLocauxEmis()
    {
        return $this->avisEntretienLocauxEmis;
    }

    /**
     * @param string|null $avisEntretienLocauxSuivi
     */
    public function setAvisEntretienLocauxSuivi($avisEntretienLocauxSuivi)
    {
        $this->avisEntretienLocauxSuivi = $avisEntretienLocauxSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisEntretienLocauxSuivi()
    {
        return $this->avisEntretienLocauxSuivi;
    }

    /**
     * @param string|null $avisNatureServiceEmis
     */
    public function setAvisNatureServiceEmis($avisNatureServiceEmis)
    {
        $this->avisNatureServiceEmis = $avisNatureServiceEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisNatureServiceEmis()
    {
        return $this->avisNatureServiceEmis;
    }

    /**
     * @param string|null $avisNatureServiceSuivi
     */
    public function setAvisNatureServiceSuivi($avisNatureServiceSuivi)
    {
        $this->avisNatureServiceSuivi = $avisNatureServiceSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisNatureServiceSuivi()
    {
        return $this->avisNatureServiceSuivi;
    }

    /**
     * @param string|null $avisNonSuiviDetail
     */
    public function setAvisNonSuiviDetail($avisNonSuiviDetail)
    {
        $this->avisNonSuiviDetail = $avisNonSuiviDetail;
    }

    /**
     * @return string|null
     */
    public function getAvisNonSuiviDetail()
    {
        return $this->avisNonSuiviDetail;
    }

    /**
     * @param string|null $avisOrganisationInterieureEmis
     */
    public function setAvisOrganisationInterieureEmis($avisOrganisationInterieureEmis)
    {
        $this->avisOrganisationInterieureEmis = $avisOrganisationInterieureEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisOrganisationInterieureEmis()
    {
        return $this->avisOrganisationInterieureEmis;
    }

    /**
     * @param string|null $avisOrganisationInterieureSuivi
     */
    public function setAvisOrganisationInterieureSuivi($avisOrganisationInterieureSuivi)
    {
        $this->avisOrganisationInterieureSuivi = $avisOrganisationInterieureSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisOrganisationInterieureSuivi()
    {
        return $this->avisOrganisationInterieureSuivi;
    }

    /**
     * @param string|null $avisQualiteHebergementEmis
     */
    public function setAvisQualiteHebergementEmis($avisQualiteHebergementEmis)
    {
        $this->avisQualiteHebergementEmis = $avisQualiteHebergementEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisQualiteHebergementEmis()
    {
        return $this->avisQualiteHebergementEmis;
    }

    /**
     * @param string|null $avisQualiteHebergementSuivi
     */
    public function setAvisQualiteHebergementSuivi($avisQualiteHebergementSuivi)
    {
        $this->avisQualiteHebergementSuivi = $avisQualiteHebergementSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisQualiteHebergementSuivi()
    {
        return $this->avisQualiteHebergementSuivi;
    }

    /**
     * @param string|null $avisQualiteRestaurationEmis
     */
    public function setAvisQualiteRestaurationEmis($avisQualiteRestaurationEmis)
    {
        $this->avisQualiteRestaurationEmis = $avisQualiteRestaurationEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisQualiteRestaurationEmis()
    {
        return $this->avisQualiteRestaurationEmis;
    }

    /**
     * @param string|null $avisQualiteRestaurationSuivi
     */
    public function setAvisQualiteRestaurationSuivi($avisQualiteRestaurationSuivi)
    {
        $this->avisQualiteRestaurationSuivi = $avisQualiteRestaurationSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisQualiteRestaurationSuivi()
    {
        return $this->avisQualiteRestaurationSuivi;
    }

    /**
     * @param string|null $avisServiceTherapeutiqueEmis
     */
    public function setAvisServiceTherapeutiqueEmis($avisServiceTherapeutiqueEmis)
    {
        $this->avisServiceTherapeutiqueEmis = $avisServiceTherapeutiqueEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisServiceTherapeutiqueEmis()
    {
        return $this->avisServiceTherapeutiqueEmis;
    }

    /**
     * @param string|null $avisServiceTherapeutiqueSuivi
     */
    public function setAvisServiceTherapeutiqueSuivi($avisServiceTherapeutiqueSuivi)
    {
        $this->avisServiceTherapeutiqueSuivi = $avisServiceTherapeutiqueSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisServiceTherapeutiqueSuivi()
    {
        return $this->avisServiceTherapeutiqueSuivi;
    }

    /**
     * @param string|null $avisSollicite
     */
    public function setAvisSollicite($avisSollicite)
    {
        $this->avisSollicite = $avisSollicite;
    }

    /**
     * @return string|null
     */
    public function getAvisSollicite()
    {
        return $this->avisSollicite;
    }

    /**
     * @param string|null $avisSolliciteAutre
     */
    public function setAvisSolliciteAutre($avisSolliciteAutre)
    {
        $this->avisSolliciteAutre = $avisSolliciteAutre;
    }

    /**
     * @return string|null
     */
    public function getAvisSolliciteAutre()
    {
        return $this->avisSolliciteAutre;
    }

    /**
     * @param string|null $avisSuiviDetail
     */
    public function setAvisSuiviDetail($avisSuiviDetail)
    {
        $this->avisSuiviDetail = $avisSuiviDetail;
    }

    /**
     * @return string|null
     */
    public function getAvisSuiviDetail()
    {
        return $this->avisSuiviDetail;
    }

    /**
     * @param string|null $avisTravauxEquipementEmis
     */
    public function setAvisTravauxEquipementEmis($avisTravauxEquipementEmis)
    {
        $this->avisTravauxEquipementEmis = $avisTravauxEquipementEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisTravauxEquipementEmis()
    {
        return $this->avisTravauxEquipementEmis;
    }

    /**
     * @param string|null $avisTravauxEquipementSuivi
     */
    public function setAvisTravauxEquipementSuivi($avisTravauxEquipementSuivi)
    {
        $this->avisTravauxEquipementSuivi = $avisTravauxEquipementSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisTravauxEquipementSuivi()
    {
        return $this->avisTravauxEquipementSuivi;
    }

    /**
     * @param string|null $avisVieInstitutionnelleEmis
     */
    public function setAvisVieInstitutionnelleEmis($avisVieInstitutionnelleEmis)
    {
        $this->avisVieInstitutionnelleEmis = $avisVieInstitutionnelleEmis;
    }

    /**
     * @return string|null
     */
    public function getAvisVieInstitutionnelleEmis()
    {
        return $this->avisVieInstitutionnelleEmis;
    }

    /**
     * @param string|null $avisVieInstitutionnelleSuivi
     */
    public function setAvisVieInstitutionnelleSuivi($avisVieInstitutionnelleSuivi)
    {
        $this->avisVieInstitutionnelleSuivi = $avisVieInstitutionnelleSuivi;
    }

    /**
     * @return string|null
     */
    public function getAvisVieInstitutionnelleSuivi()
    {
        return $this->avisVieInstitutionnelleSuivi;
    }

    /**
     * @param string|null $crAffiches
     */
    public function setCrAffiches($crAffiches)
    {
        $this->crAffiches = $crAffiches;
    }

    /**
     * @return string|null
     */
    public function getCrAffiches()
    {
        return $this->crAffiches;
    }

    /**
     * @param string|null $crCommuniques
     */
    public function setCrCommuniques($crCommuniques)
    {
        $this->crCommuniques = $crCommuniques;
    }

    /**
     * @return string|null
     */
    public function getCrCommuniques()
    {
        return $this->crCommuniques;
    }

    /**
     * @param string|null $estimation
     */
    public function setEstimation($estimation)
    {
        $this->estimation = $estimation;
    }

    /**
     * @return string|null
     */
    public function getEstimation()
    {
        return $this->estimation;
    }

    /**
     * @param string|null $estimationDetail
     */
    public function setEstimationDetail($estimationDetail)
    {
        $this->estimationDetail = $estimationDetail;
    }

    /**
     * @return string|null
     */
    public function getEstimationDetail()
    {
        return $this->estimationDetail;
    }

    /**
     * @param null|string $estimationDetailListe
     *
     * @return $this
     */
    public function setEstimationDetailListe($estimationDetailListe)
    {
        $this->estimationDetailListe = $estimationDetailListe;

        return $this;
    }

    /**
     * @return null|string
     */
    public function getEstimationDetailListe()
    {
        return $this->estimationDetailListe;
    }

    /**
     * @param string|null $formationMembre
     */
    public function setFormationMembre($formationMembre)
    {
        $this->formationMembre = $formationMembre;
    }

    /**
     * @return string|null
     */
    public function getFormationMembre()
    {
        return $this->formationMembre;
    }

    /**
     * @param string|null $nonRaison
     */
    public function setNonRaison($nonRaison)
    {
        $this->nonRaison = $nonRaison;
    }

    /**
     * @return string|null
     */
    public function getNonRaison()
    {
        return $this->nonRaison;
    }

    /**
     * @param string|null $presidence
     */
    public function setPresidence($presidence)
    {
        $this->presidence = $presidence;
    }

    /**
     * @param string|null $representantInferieurMoitieDetail
     */
    public function setRepresentantInferieurMoitieDetail($representantInferieurMoitieDetail)
    {
        $this->representantInferieurMoitieDetail = $representantInferieurMoitieDetail;
    }

    /**
     * @return string|null
     */
    public function getRepresentantInferieurMoitieDetail()
    {
        return $this->representantInferieurMoitieDetail;
    }

    /**
     * @param string|null $representantVoixConsultativeExterieurDetail
     */
    public function setRepresentantVoixConsultativeExterieurDetail($representantVoixConsultativeExterieurDetail)
    {
        $this->representantVoixConsultativeExterieurDetail = $representantVoixConsultativeExterieurDetail;
    }

    /**
     * @return string|null
     */
    public function getRepresentantVoixConsultativeExterieurDetail()
    {
        return $this->representantVoixConsultativeExterieurDetail;
    }

    /**
     * @param null|string $representantVoixConsultativeExterieurDetailListe
     *
     * @return $this
     */
    public function setRepresentantVoixConsultativeExterieurDetailListe($representantVoixConsultativeExterieurDetailListe)
    {
        $this->representantVoixConsultativeExterieurDetailListe = $representantVoixConsultativeExterieurDetailListe;

        return $this;
    }

    /**
     * @return null|string
     */
    public function getRepresentantVoixConsultativeExterieurDetailListe()
    {
        return $this->representantVoixConsultativeExterieurDetailListe;
    }

    /**
     * @return string|null
     */
    public function getPresidence()
    {
        return $this->presidence;
    }

    /**
     * @param string|null $presidenceAutre
     */
    public function setPresidenceAutre($presidenceAutre)
    {
        $this->presidenceAutre = $presidenceAutre;
    }

    /**
     * @return string|null
     */
    public function getPresidenceAutre()
    {
        return $this->presidenceAutre;
    }

    /**
     * @param string|null $reglementInterieur
     */
    public function setReglementInterieur($reglementInterieur)
    {
        $this->reglementInterieur = $reglementInterieur;
    }

    /**
     * @return string|null
     */
    public function getReglementInterieur()
    {
        return $this->reglementInterieur;
    }

    /**
     * @param string|null $reglementInterieurDetail
     */
    public function setReglementInterieurDetail($reglementInterieurDetail)
    {
        $this->reglementInterieurDetail = $reglementInterieurDetail;
    }

    /**
     * @return string|null
     */
    public function getReglementInterieurDetail()
    {
        return $this->reglementInterieurDetail;
    }

    /**
     * @param null|string $reglementInterieurDetailListe
     *
     * @return $this
     */
    public function setReglementInterieurDetailListe($reglementInterieurDetailListe)
    {
        $this->reglementInterieurDetailListe = $reglementInterieurDetailListe;

        return $this;
    }

    /**
     * @return null|string
     */
    public function getReglementInterieurDetailListe()
    {
        return $this->reglementInterieurDetailListe;
    }

    /**
     * @param string|null $conseilVieSocialeRepresentant
     */
    public function setConseilVieSocialeRepresentant($conseilVieSocialeRepresentant)
    {
        $this->conseilVieSocialeRepresentant = $conseilVieSocialeRepresentant;
    }

    /**
     * @return string|null
     */
    public function getConseilVieSocialeRepresentant()
    {
        return $this->conseilVieSocialeRepresentant;
    }

    /**
     * @param bool|null $conseilVieSocialeAvisExist
     *
     * @return $this
     */
    public function setConseilVieSocialeAvisExist($conseilVieSocialeAvisExist)
    {
        $this->conseilVieSocialeAvisExist = $conseilVieSocialeAvisExist;

        return $this;
    }

    /**
     * @return bool|null
     */
    public function getConseilVieSocialeAvisExist()
    {
        return $this->conseilVieSocialeAvisExist;
    }

    /**
     * @param string|null $conseilVieSocialeAvis
     */
    public function setConseilVieSocialeAvis($conseilVieSocialeAvis)
    {
        $this->conseilVieSocialeAvis = $conseilVieSocialeAvis;
    }

    /**
     * @return string|null
     */
    public function getConseilVieSocialeAvis()
    {
        return $this->conseilVieSocialeAvis;
    }
}
