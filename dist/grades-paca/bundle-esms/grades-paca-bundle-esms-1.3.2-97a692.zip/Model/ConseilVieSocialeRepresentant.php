<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 21/01/14
 * Time: 11:14
 */

namespace Oru\Bundle\EsmsBundle\Model;

/**
 * Class ConseilVieSocialeRepresentant.
 *
 * @author Michaël VEROUX
 */
class ConseilVieSocialeRepresentant
{
    /**
     * @var string|null
     */
    protected $representantPersonnesPec = null;

    /**
     * @var string|null
     */
    protected $representantFamilles = null;

    /**
     * @var string|null
     */
    protected $representantPersonnel = null;

    /**
     * @var string|null
     */
    protected $representantGestionnaire = null;

    /**
     * @var string|null
     */
    protected $representantVoixConsultative = null;

    /**
     * @var string|null
     */
    protected $representantVoixConsultativeAutre = null;

    /**
     * @var string|null
     */
    protected $conseilVieSociale = null;

    /**
     * @var int
     */
    protected $sumRepresentantsLegaux = 0;

    /**
     * @var int
     */
    protected $sumRepresentantsDeliberatifs = 0;

    /**
     * @param string|null $representantFamilles
     */
    public function setRepresentantFamilles($representantFamilles)
    {
        $this->representantFamilles = $representantFamilles;
    }

    /**
     * @return string|null
     */
    public function getRepresentantFamilles()
    {
        return $this->representantFamilles;
    }

    /**
     * @param string|null $representantGestionnaire
     */
    public function setRepresentantGestionnaire($representantGestionnaire)
    {
        $this->representantGestionnaire = $representantGestionnaire;
    }

    /**
     * @return string|null
     */
    public function getRepresentantGestionnaire()
    {
        return $this->representantGestionnaire;
    }

    /**
     * @param string|null $representantInferieurMoitieDetail
     */
    public function setRepresentantInferieurMoitieDetail($representantInferieurMoitieDetail)
    {
        $this->representantInferieurMoitieDetail = $representantInferieurMoitieDetail;
    }

    /**
     * @return string|null
     */
    public function getRepresentantInferieurMoitieDetail()
    {
        return $this->representantInferieurMoitieDetail;
    }

    /**
     * @param string|null $representantPersonnel
     */
    public function setRepresentantPersonnel($representantPersonnel)
    {
        $this->representantPersonnel = $representantPersonnel;
    }

    /**
     * @return string|null
     */
    public function getRepresentantPersonnel()
    {
        return $this->representantPersonnel;
    }

    /**
     * @param string|null $representantPersonnesPec
     */
    public function setRepresentantPersonnesPec($representantPersonnesPec)
    {
        $this->representantPersonnesPec = $representantPersonnesPec;
    }

    /**
     * @return string|null
     */
    public function getRepresentantPersonnesPec()
    {
        return $this->representantPersonnesPec;
    }

    /**
     * @param string|null $representantVoixConsultative
     */
    public function setRepresentantVoixConsultative($representantVoixConsultative)
    {
        $this->representantVoixConsultative = $representantVoixConsultative;
    }

    /**
     * @return string|null
     */
    public function getRepresentantVoixConsultative()
    {
        return $this->representantVoixConsultative;
    }

    /**
     * @param string|null $representantVoixConsultativeAutre
     */
    public function setRepresentantVoixConsultativeAutre($representantVoixConsultativeAutre)
    {
        $this->representantVoixConsultativeAutre = $representantVoixConsultativeAutre;
    }

    /**
     * @return string|null
     */
    public function getRepresentantVoixConsultativeAutre()
    {
        return $this->representantVoixConsultativeAutre;
    }

    /**
     * @param string|null $conseilVieSociale
     */
    public function setConseilVieSociale($conseilVieSociale)
    {
        $this->conseilVieSociale = $conseilVieSociale;
    }

    /**
     * @return string|null
     */
    public function getConseilVieSociale()
    {
        return $this->conseilVieSociale;
    }

    /**
     * @param int $sumRepresentantsDeliberatifs
     */
    public function setSumRepresentantsDeliberatifs($sumRepresentantsDeliberatifs)
    {
        $this->sumRepresentantsDeliberatifs = $sumRepresentantsDeliberatifs;
    }

    /**
     * @return int
     */
    public function getSumRepresentantsDeliberatifs()
    {
        return $this->sumRepresentantsDeliberatifs;
    }

    /**
     * @param int $sumRepresentantsLegaux
     */
    public function setSumRepresentantsLegaux($sumRepresentantsLegaux)
    {
        $this->sumRepresentantsLegaux = $sumRepresentantsLegaux;
    }

    /**
     * @return int
     */
    public function getSumRepresentantsLegaux()
    {
        return $this->sumRepresentantsLegaux;
    }

    /**
     * @return bool
     */
    public function isRepresentantsLegauxLowerHalfMembres()
    {
        if ($this->getSumRepresentantsLegaux() + $this->getSumRepresentantsDeliberatifs() > 0) {
            return false;
        }
        return $this->getSumRepresentantsLegaux() < ($this->getSumRepresentantsLegaux() + $this->getSumRepresentantsDeliberatifs()) / 2;
    }
}
