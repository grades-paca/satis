<?php
/**
 * Author: Michaël VEROUX
 * Date: 27/06/14
 * Time: 10:16
 */

namespace Oru\Bundle\EsmsBundle\Entity;

interface EtablissementInterface
{
    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getFinessGeographique();
} 