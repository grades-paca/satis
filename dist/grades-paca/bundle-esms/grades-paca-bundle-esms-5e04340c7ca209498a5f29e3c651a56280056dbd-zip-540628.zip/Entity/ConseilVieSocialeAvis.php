<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 20/01/14
 * Time: 15:09
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Model\ConseilVieSocialeAvis as BaseConseilVieSocialeAvis;

/**
 * Class ConseilVieSocialeAvis
 * @package Oru\Bundle\EsmsBundle\Entity
 * @author Michaël VEROUX
 */
class ConseilVieSocialeAvis extends BaseConseilVieSocialeAvis
{
    /**
     * @var ind
     */
    protected $id;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    public function __clone()
    {
        $this->id = null;
    }
} 