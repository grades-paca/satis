<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 09:40
 */

namespace Oru\Bundle\EsmsBundle\Model;

/**
 * Class Bientraitance
 * @package Oru\Bundle\EsmsBundle\Model
 * @author Michaël VEROUX
 */
class Bientraitance
{
    /**
     * @var string|null
     */
    protected $existe = null;

    /**
     * @param string|null $existe
     */
    public function setExiste($existe)
    {
        $this->existe = $existe;
    }

    /**
     * @return string|null
     */
    public function getExiste()
    {
        return $this->existe;
    }
} 