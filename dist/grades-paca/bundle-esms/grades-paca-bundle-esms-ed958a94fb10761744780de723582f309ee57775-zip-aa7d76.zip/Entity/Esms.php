<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 20/01/14
 * Time: 13:41
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Oru\Bundle\EsmsBundle\Choice\ChoiceInjectorInterface;
use Oru\Bundle\EsmsBundle\Model\Esms as BaseEsms;
use Oru\Bundle\FormIncrementalBundle\Entity\FormIncrementalInterface;
use Oru\Bundle\RorCredentialsBundle\Entity\Credential;
use Oru\Bundle\RorCredentialsBundle\Interfaces\CredentialSwitchEntityInterface;
use Symfony\Component\Validator\GroupSequenceProviderInterface;

/**
 * Class Esms.
 *
 * @author Michaël VEROUX
 */
class Esms extends BaseEsms implements GroupSequenceProviderInterface, ChoiceInjectorInterface, FormIncrementalInterface, CredentialSwitchEntityInterface
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var array
     */
    protected $translatedChoices;

    /**
     * @var bool
     */
    protected $complete = false;

    /**
     * @var \DateTime
     */
    protected $created;

    /**
     * @var \DateTime
     */
    protected $updated;

    /**
     * @var \DateTime
     */
    protected $deleted;

    public function __clone()
    {
        $this->id = null;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return null|ProfessionnelFormation
     *
     * @author Michaël VEROUX
     */
    public function getProfessionnelFormation()
    {
        if (null === $this->professionnelFormation) {
            $this->setProfessionnelFormation(new ProfessionnelFormation());
            $this->getProfessionnelFormation()->setEsms($this);
        }

        return $this->professionnelFormation;
    }

    /**
     * @return null|ConseilVieSociale
     *
     * @author Michaël VEROUX
     */
    public function getConseilVieSociale()
    {
        if (null === $this->conseilVieSociale) {
            $this->setConseilVieSociale(new ConseilVieSociale());
            $this->getConseilVieSociale()->setEsms($this);
        }

        return $this->conseilVieSociale;
    }

    /**
     * @return null|PersonnesQualifiees
     *
     * @author Michaël VEROUX
     */
    public function getPersonnesQualifiees()
    {
        if (null === $this->personnesQualifiees) {
            $this->setPersonnesQualifiees(new PersonnesQualifiees());
            $this->getPersonnesQualifiees()->setEsms($this);
        }

        return $this->personnesQualifiees;
    }

    /**
     * @return null|PlaintesReclamations
     *
     * @author Michaël VEROUX
     */
    public function getPlaintesReclamations()
    {
        if (null === $this->plaintesReclamations) {
            $this->setPlaintesReclamations(new PlaintesReclamations());
            $this->getPlaintesReclamations()->setEsms($this);
        }

        return $this->plaintesReclamations;
    }

    /**
     * @return null|Bientraitance
     *
     * @author Michaël VEROUX
     */
    public function getBientraitance()
    {
        if (null === $this->bientraitance) {
            $this->setBientraitance(new Bientraitance());
            $this->getBientraitance()->setEsms($this);
        }

        return $this->bientraitance;
    }

    /**
     * @return null|FinVie
     *
     * @author Michaël VEROUX
     */
    public function getFinVie()
    {
        if (null === $this->finVie) {
            $this->setFinVie(new FinVie());
            $this->getFinVie()->setEsms($this);
        }

        return $this->finVie;
    }

    /**
     * @return null|AccesDonneesSante
     *
     * @author Michaël VEROUX
     */
    public function getAccesDonneesSante()
    {
        if (null === $this->accesDonneesSante) {
            $this->setAccesDonneesSante(new AccesDonneesSante());
            $this->getAccesDonneesSante()->setEsms($this);
        }

        return $this->accesDonneesSante;
    }

    /**
     * @return null|LivretAccueil
     *
     * @author Michaël VEROUX
     */
    public function getLivretAccueil()
    {
        if (null === $this->livretAccueil) {
            $this->setLivretAccueil(new LivretAccueil());
            $this->getLivretAccueil()->setEsms($this);
        }

        return $this->livretAccueil;
    }

    /**
     * @return null|ContratSoutien
     *
     * @author Michaël VEROUX
     */
    public function getContratSoutien()
    {
        if (null === $this->contratSoutien) {
            $this->setContratSoutien(new ContratSoutien());
            $this->getContratSoutien()->setEsms($this);
        }

        return $this->contratSoutien;
    }

    /**
     * @return null|ContratSejour
     *
     * @author Michaël VEROUX
     */
    public function getContratSejour()
    {
        if (null === $this->contratSejour) {
            $this->setContratSejour(new ContratSejour());
            $this->getContratSejour()->setEsms($this);
        }

        return $this->contratSejour;
    }

    /**
     * @return null|ProjetEtablissement
     *
     * @author Michaël VEROUX
     */
    public function getProjetEtablissement()
    {
        if (null === $this->projetEtablissement) {
            $this->setProjetEtablissement(new ProjetEtablissement());
            $this->getProjetEtablissement()->setEsms($this);
        }

        return $this->projetEtablissement;
    }

    /**
     * @return null|Evaluations
     *
     * @author Michaël VEROUX
     */
    public function getEvaluations()
    {
        if (null === $this->evaluations) {
            $this->setEvaluations(new Evaluations());
            $this->getEvaluations()->setEsms($this);
        }

        return $this->evaluations;
    }

    /**
     * @return null|SuiviOutils
     *
     * @author Michaël VEROUX
     */
    public function getSuiviOutils()
    {
        if (null === $this->suiviOutils) {
            $this->setSuiviOutils(new SuiviOutils());
            $this->getSuiviOutils()->setEsms($this);
        }

        return $this->suiviOutils;
    }

    /**
     * @param bool $complete
     */
    public function setComplete($complete)
    {
        $this->complete = $complete;
    }

    /**
     * @return bool
     */
    public function getComplete()
    {
        return $this->complete;
    }

    /**
     * @param \DateTime $created
     */
    public function setCreated(\DateTime $created = null)
    {
        $this->created = $created;
    }

    /**
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param \DateTime $updated
     */
    public function setUpdated(\DateTime $updated = null)
    {
        $this->updated = $updated;
    }

    /**
     * @return \DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * @param \DateTime $deleted
     *
     * @return $this
     */
    public function setDeleted(\DateTime $deleted = null)
    {
        $this->deleted = $deleted;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getDeleted()
    {
        return $this->deleted;
    }

    public function getFinessEtablissement()
    {
        return $this->getIdentification()->getFiness();
    }

    /**
     * @param array $translatedChoices
     */
    public function setTranslatedChoices($translatedChoices)
    {
        $this->translatedChoices = $translatedChoices;
    }

    /**
     * @return array
     */
    public function getTranslatedChoices()
    {
        return $this->translatedChoices;
    }

    /**
     * @param string $key
     *
     * @return array
     */
    public function getTranslatedChoicesByKey($key)
    {
        if (isset($this->translatedChoices[$key])) {
            return $this->translatedChoices[$key];
        }
        return array();
    }

    /**
     * Returns which validation groups should be used for a certain state
     * of the object.
     *
     * @return array An array of validation groups
     */
    public function getGroupSequence()
    {
        $groups = array('integrity', 'default');

        return array_merge(
            $groups,
            $this->getProfessionnelFormation() instanceof GroupSequenceProviderInterface ? $this->getProfessionnelFormation()->getGroupSequence() : array(),
            $this->getConseilVieSociale() instanceof GroupSequenceProviderInterface ? $this->getConseilVieSociale()->getGroupSequence() : array(),
            $this->getPersonnesQualifiees() instanceof GroupSequenceProviderInterface ? $this->getPersonnesQualifiees()->getGroupSequence() : array(),
            $this->getPlaintesReclamations() instanceof GroupSequenceProviderInterface ? $this->getPlaintesReclamations()->getGroupSequence() : array(),
            $this->getBientraitance() instanceof GroupSequenceProviderInterface ? $this->getBientraitance()->getGroupSequence() : array(),
            $this->getFinVie() instanceof GroupSequenceProviderInterface ? $this->getFinVie()->getGroupSequence() : array(),
            $this->getAccesDonneesSante() instanceof GroupSequenceProviderInterface ? $this->getAccesDonneesSante()->getGroupSequence() : array(),
            $this->getLivretAccueil() instanceof GroupSequenceProviderInterface ? $this->getLivretAccueil()->getGroupSequence() : array(),
            $this->getContratSoutien() instanceof GroupSequenceProviderInterface ? $this->getContratSoutien()->getGroupSequence() : array(),
            $this->getContratSejour() instanceof GroupSequenceProviderInterface ? $this->getContratSejour()->getGroupSequence() : array(),
            $this->getReglement() instanceof GroupSequenceProviderInterface ? $this->getReglement()->getGroupSequence() : array(),
            $this->getProjetEtablissement() instanceof GroupSequenceProviderInterface ? $this->getProjetEtablissement()->getGroupSequence() : array(),
            $this->getEvaluations() instanceof GroupSequenceProviderInterface ? $this->getEvaluations()->getGroupSequence() : array(),
            $this->getSuiviOutils() instanceof GroupSequenceProviderInterface ? $this->getSuiviOutils()->getGroupSequence() : array()
        );
    }

    /**
     * Return current increment of object (year, month or what you want...).
     *
     * @return int
     *
     * @author Michaël VEROUX
     */
    public function getIncrement()
    {
        $created = $this->getCreated() instanceof \DateTime ? $this->getCreated() : new \DateTime('now');

        return (int) $created->format('Y');
    }

    /**
     * Renvoie l'instance d'une entité qui va être utilisable par le controleur de droits
     * c.a.d parmi : Professionel, Unité, Etablissement, Structure
     * pour contrôler l'acces à cette entité/ressource
     * en fonction éventuellement du droit passé en parametre.
     *
     * @param Credential $credential le droit à éventuellement utiliser pour distinguer la réponse
     *
     * @return mixed
     *
     *
     * Cas d'usage: si l'entité est un service, etablissement, structure (entité nativement gérée par les droits)
     *  getCredentialTarget( Credential $credential) {return $this ; }
     *
     * Cas d'usage: s'il s'agit d'une entité toujours rattachée à un service
     *  getCredentialTarget( Credential $credential) {return $this->getService() ; }
     *
     *
     * Cas d'usage: s'il s'agit d'une entité toujours rattachée à un établissement
     *  getCredentialTarget( Credential $credential) {return $this->getEtablissement() ; }
     *
     * Cas d'usage: si selon le focus-min (contexte du droit utilisé) on renvoie un service ou un établissement
     *
     *  getCredentialTarget( Credential $credential) {
     *  if($credential->getFocusMin()->getName() == Focus::FOCUS_UNITE  ) return $this->getService() ;
     *  if($credential->getFocusMin()->getName() == Focus::FOCUS_ETABLISSEMENT  ) return $this->getEtablissement() ;
     * }
     *
     * Cas d'usage: si selon le nom du droit on doit renvoyer des target différentes
     *
     *  getCredentialTarget( Credential $credential) {
     *  if($credential->getName() == "xxxxx'"  ) return $this->getService() ;
     * ....
     * }
     */
    public function getCredentialTarget(Credential $credential)
    {
        return $this->getIdentification()->getEtablissement();
    }
}
