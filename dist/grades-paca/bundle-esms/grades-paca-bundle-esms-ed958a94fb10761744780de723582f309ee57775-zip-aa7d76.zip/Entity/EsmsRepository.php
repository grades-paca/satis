<?php
/**
 * Author: Michaël VEROUX
 * Date: 17/07/14
 * Time: 16:37
 */

namespace Oru\Bundle\EsmsBundle\Entity;

use Doctrine\ORM\EntityRepository;
use Oru\Bundle\RorBundle\Entity\Etablissement;

class EsmsRepository extends EntityRepository
{
    /**
     * @param Etablissement $etablissement
     *
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function findByEtablissement(Etablissement $etablissement)
    {
        $builder = $this
            ->createQueryBuilder('es')
            ->innerJoin('es.identification', 'i')
            ->andWhere('i.etablissement = :etablissement')
            ->setParameter('etablissement', $etablissement)
        ;

        return $builder->getQuery()->getResult();
    }

    /**
     * @param Etablissement|null $etablissement
     * @param string|int         $year
     *
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function findByEtablissementAndYear(Etablissement $etablissement = null, $year)
    {
        $this->getEntityManager()->getConfiguration()
            ->addCustomStringFunction('YEAR', 'Oru\Bundle\EsmsBundle\Doctrine\Query\Mysql\Year')
        ;

        $builder = $this
            ->createQueryBuilder('es')
            ->innerJoin('es.identification', 'i')
            ->andWhere('YEAR(es.created) = :year')
            ->setParameter('year', $year)
        ;

        if (null !== $etablissement) {
            $builder->andWhere('i.etablissement = :etablissement')
                ->setParameter('etablissement', $etablissement)
            ;
        }

        return $builder->getQuery()->getResult();
    }

    /**
     * @param string|int $year
     *
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function findByYear($year)
    {
        return $this->findByEtablissementAndYear(null, $year);
    }

    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function getYearsExists()
    {
        $this->getEntityManager()->getConfiguration()
            ->addCustomStringFunction('YEAR', 'Oru\Bundle\EsmsBundle\Doctrine\Query\Mysql\Year')
        ;

        $builder = $this
            ->createQueryBuilder('es')
            ->select('YEAR(es.created) as year')
            ->groupBy('year')
        ;

        $result = $builder->getQuery()->getScalarResult();

        return array_map('current', $result);
    }
}
