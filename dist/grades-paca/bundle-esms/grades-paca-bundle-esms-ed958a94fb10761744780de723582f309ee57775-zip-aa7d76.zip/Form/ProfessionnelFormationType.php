<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 14:44
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\EsmsBundle\Choice\ChoiceProvider;
use Oru\Bundle\EsmsBundle\Entity\ProfessionnelFormation;
use Oru\Bundle\FormBundle\Form\Type\ChoicesToStringType;
use Oru\Bundle\FormBundle\Form\Type\ConditionalType;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ProfessionnelFormationType.
 *
 * @author Michaël VEROUX
 */
class ProfessionnelFormationType extends AbstractType
{
    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    /**
     * @var ChoiceProvider
     */
    protected $choiceProvider;

    /**
     * @param IncrementalValiditySubscriber $incrementalValiditySubscriber
     * @param ChoiceProvider                $choiceProvider
     */
    public function __construct(IncrementalValiditySubscriber $incrementalValiditySubscriber, ChoiceProvider $choiceProvider)
    {
        $this->validitySubscriber = $incrementalValiditySubscriber;
        $this->choiceProvider = $choiceProvider;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $inheritRequired = ProfessionnelFormation::subRequired();
        $choicesPrefix = 'oru_esms_'.$this->getName();

        $builder
            ->add('suiviFormation', ConditionalType::class,
                array(
                    'choices' => array(
                        '1' => 'oui',
                        '0' => 'non',
                    ),
                    'conditionals' => isset($inheritRequired['suiviFormation']) ? $inheritRequired['suiviFormation'] : array(),
                    )
            )
            ->add('suiviFormationNonDetail', TextareaType::class,
                array(
                )
            )
            ->add('suiviFormationNonDetail2015', ChoicesToStringType::class, array(
                    'expanded' => true,
                    'choices' => $this->choiceProvider->getFieldChoices($choicesPrefix, 'suiviFormationNonDetail2015', 6),
                )
            )
            ->add('suiviFormationNonDetailLibre2015', TextareaType::class,
                array(
                )
            )
            ->add('professionnelFormationTheme', ProfessionnelFormationThemeType::class
            )
            ->add('professionnelFormationType', ProfessionnelFormationTypeType::class
            )
        ;

        $builder->addEventSubscriber($this->validitySubscriber);
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\ProfessionnelFormation',
            'translation_domain' => 'OruEsmsBundle',
        ));
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getBlockPrefix()
    {
        return 'professionnelFormation';
    }
}
