<?php
/**
 * Author: Michaël VEROUX
 * Date: 01/07/14
 * Time: 13:41
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Oru\Bundle\RorBundle\Form\Type\EtablissementAutocompleteType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EtablissementType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('etablissement', EtablissementAutocompleteType::class, array(
                    'multiple' => false,
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     *
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\Identification',
            'translation_domain' => 'OruEsmsBundle',
            'required' => false,
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_esms_etablissement';
    }
}
