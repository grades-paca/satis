<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 25/02/14
 * Time: 15:28
 */

namespace Oru\Bundle\EsmsBundle\Filter;

class EsmsFilter
{
    protected $departements = array();

    protected $etablissements = array();

    protected $finess = '';

    protected $increments;

    protected $complete = null;

    protected $deleted = false;

    protected $statut = 'empty_value';

    public function __construct()
    {
        $this->increments = array((int) date('Y'));
    }

    /**
     * @param array $departements
     */
    public function setDepartements($departements)
    {
        $this->departements = $departements;
    }

    /**
     * @return array
     */
    public function getDepartements()
    {
        return $this->departements;
    }

    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function getDepartementsIds()
    {
        $ids = array();
        foreach ($this->getDepartements() as $departement) {
            array_push($ids, $departement->getId());
        }

        return $ids;
    }

    /**
     * @param array $etablissements
     */
    public function setEtablissements($etablissements)
    {
        $this->etablissements = $etablissements;
    }

    /**
     * @return array
     */
    public function getEtablissements()
    {
        return $this->etablissements;
    }

    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function getEtablissementsIds()
    {
        $ids = array();
        foreach ($this->getEtablissements() as $etablissement) {
            array_push($ids, $etablissement->getId());
        }

        return $ids;
    }

    /**
     * @param string $finess
     */
    public function setFiness($finess)
    {
        $this->finess = $finess;
    }

    /**
     * @return string
     */
    public function getFiness()
    {
        return $this->finess;
    }

    /**
     * @param array $increments
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function setIncrements($increments)
    {
        $this->increments = $increments;

        return $this;
    }

    /**
     * @return array
     */
    public function getIncrements()
    {
        return $this->increments;
    }

    /**
     * @param null $complete
     */
    public function setComplete($complete)
    {
        $this->complete = $complete;
    }

    public function getComplete()
    {
        return $this->complete;
    }

    /**
     * @param bool $deleted
     *
     * @return $this
     */
    public function setDeleted($deleted)
    {
        $this->deleted = $deleted;

        return $this;
    }

    /**
     * @return bool
     */
    public function getDeleted()
    {
        return (bool) $this->deleted;
    }

    public function setStatut($statut)
    {
        $this->statut = $statut;

        return $this;
    }

    public function getStatut()
    {
        return $this->statut;
    }
}
