<?php
/**
 * Created by PhpStorm.
 * User: Michaël VEROUX
 * Date: 11/07/14
 * Time: 12:15
 */

namespace Oru\Bundle\EsmsBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class IdentificationType
 * @package Oru\Bundle\EsmsBundle\Form
 * @author Michaël VEROUX
 */
class IdentificationType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom', 'oru_static'
            )
            ->add('finess', 'oru_static'
            )
            ->add('typeStatut', 'oru_static'
            )
            ->add('departement_nom', 'oru_static'
            )
            ->add('activites', 'oru_choices_to_string', array(
                    'choices'       =>  array(
                        'Personnes âgées'       =>  'Personnes âgées',
                        'Personnes en situation de handicap'       =>  'Personnes en situation de handicap',
                        'Personnes en difficultés spécifiques (addictologie, personnes sans résidence stable, …)'       =>  'Personnes en difficultés spécifiques (addictologie, personnes sans résidence stable, …)',
                    ),
                )
            )
            ->add('handicap_type', 'choice', array(
                    'choices'       =>  array(
                        'adultes'       =>  'Adultes',
                        'enfants'       =>  'Enfants',
                    ),
                    'placeholder'   =>  'Non concerné',
                )
            )
        ;
    }

    /**
     * @param OptionsResolver $resolver
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\EsmsBundle\Entity\Identification',
            'translation_domain'    => 'OruEsmsBundle',
            'required' => false,
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_esms_identification';
    }
}