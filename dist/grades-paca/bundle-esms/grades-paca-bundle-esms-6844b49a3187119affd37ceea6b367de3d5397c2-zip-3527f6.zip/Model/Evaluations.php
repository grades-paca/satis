<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 13:51
 */

namespace Oru\Bundle\EsmsBundle\Model;

/**
 * Class Evaluations
 * @package Oru\Bundle\EsmsBundle\Model
 * @author Michaël VEROUX
 */
class Evaluations
{
    /**
     * @var string|null
     */
    protected $interne = null;

    /**
     * @var string|null
     */
    protected $interneDate = null;

    /**
     * @var string|null
     */
    protected $externe = null;

    /**
     * @var string|null
     */
    protected $externeDate = null;

    /**
     * @var string|null
     */
    protected $nonEvaluationDetail = null;

    /**
     * @var string|null
     */
    protected $resultatInterne = null;

    /**
     * @var string|null
     */
    protected $resultatExterne = null;

    /**
     * @var string|null
     */
    protected $nonEvaluationResultatDetail = null;

    /**
     * @param string|null $externe
     */
    public function setExterne($externe)
    {
        $this->externe = $externe;
    }

    /**
     * @return string|null
     */
    public function getExterne()
    {
        return $this->externe;
    }

    /**
     * @param string|null $externeDate
     */
    public function setExterneDate($externeDate)
    {
        $this->externeDate = $externeDate;
    }

    /**
     * @return string|null
     */
    public function getExterneDate()
    {
        return $this->externeDate;
    }

    /**
     * @param string|null $interne
     */
    public function setInterne($interne)
    {
        $this->interne = $interne;
    }

    /**
     * @return string|null
     */
    public function getInterne()
    {
        return $this->interne;
    }

    /**
     * @param string|null $interneDate
     */
    public function setInterneDate($interneDate)
    {
        $this->interneDate = $interneDate;
    }

    /**
     * @return string|null
     */
    public function getInterneDate()
    {
        return $this->interneDate;
    }

    /**
     * @param string|null $nonEvaluationDetail
     */
    public function setNonEvaluationDetail($nonEvaluationDetail)
    {
        $this->nonEvaluationDetail = $nonEvaluationDetail;
    }

    /**
     * @return string|null
     */
    public function getNonEvaluationDetail()
    {
        return $this->nonEvaluationDetail;
    }

    /**
     * @param string|null $nonEvaluationResultatDetail
     */
    public function setNonEvaluationResultatDetail($nonEvaluationResultatDetail)
    {
        $this->nonEvaluationResultatDetail = $nonEvaluationResultatDetail;
    }

    /**
     * @return string|null
     */
    public function getNonEvaluationResultatDetail()
    {
        return $this->nonEvaluationResultatDetail;
    }

    /**
     * @param string|null $resultatExterne
     */
    public function setResultatExterne($resultatExterne)
    {
        $this->resultatExterne = $resultatExterne;
    }

    /**
     * @return string|null
     */
    public function getResultatExterne()
    {
        return $this->resultatExterne;
    }

    /**
     * @param string|null $resultatInterne
     */
    public function setResultatInterne($resultatInterne)
    {
        $this->resultatInterne = $resultatInterne;
    }

    /**
     * @return string|null
     */
    public function getResultatInterne()
    {
        return $this->resultatInterne;
    }
} 