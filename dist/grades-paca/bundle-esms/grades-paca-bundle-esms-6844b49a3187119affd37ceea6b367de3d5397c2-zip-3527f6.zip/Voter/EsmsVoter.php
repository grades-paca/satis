<?php
/**
 * Author: Michaël VEROUX
 * Date: 01/04/14
 * Time: 14:05
 */

namespace Oru\Bundle\EsmsBundle\Voter;

use Oru\Bundle\EsmsBundle\Entity\Esms;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Psr\Log\LoggerInterface;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Authorization\Voter\VoterInterface;

class EsmsVoter implements VoterInterface
{
    const EDIT = 'ORU_ESMS_EDIT';
    const UNLOCK = 'ORU_ESMS_UNLOCK';
    const DELETE = 'ORU_ESMS_DELETE';

    /** @var  LoggerInterface */
    protected $logger;

    /**
     * @var Setting
     */
    protected $setting;

    public function __construct(LoggerInterface $logger, Setting $setting)
    {
        $this->logger = $logger;

        $this->setting = $setting;
    }

    /**
     * Checks if the voter supports the given attribute.
     *
     * @param string $attribute An attribute
     *
     * @return Boolean true if this Voter supports the attribute, false otherwise
     */
    public function supportsAttribute($attribute)
    {
        return $attribute === self::EDIT;
    }

    /**
     * Checks if the voter supports the given class.
     *
     * @param string $class A class name
     *
     * @return Boolean true if this Voter can process the class
     */
    public function supportsClass($class)
    {
        $supports = 'Oru\Bundle\EsmsBundle\Entity\Esms';

        return $supports === $class || is_subclass_of($class, $supports);
    }

    /**
     * Returns the vote for the given parameters.
     *
     * This method must return one of the following constants:
     * ACCESS_GRANTED, ACCESS_DENIED, or ACCESS_ABSTAIN.
     *
     * @param TokenInterface $token A TokenInterface instance
     * @param object $object The object to secure
     * @param array $attributes An array of attributes associated with the method being invoked
     *
     * @return integer either ACCESS_GRANTED, ACCESS_ABSTAIN, or ACCESS_DENIED
     */
    public function vote(TokenInterface $token, $object, array $attributes)
    {
        if($object instanceof Esms && $object->getComplete() && count(array_intersect(array(self::EDIT), $attributes)))
        {
            $this->logger->warning('Object closed can\'t EDIT!');
            $this->logger->error(sprintf('Access denied by %s line %s', __CLASS__, __LINE__));
            return VoterInterface::ACCESS_DENIED;
        }

        if($object instanceof Esms && !$object->getComplete() && count(array_intersect(array(self::UNLOCK), $attributes)))
        {
            $this->logger->warning('Object not closed can\'t OPEN!');
            $this->logger->error(sprintf('Access denied by %s line %s', __CLASS__, __LINE__));
            return VoterInterface::ACCESS_DENIED;
        }

        $now = new \DateTime();
        $dateCloture = null !== $this->setting->setting('dateCloture', 'OruEsmsBundle') ?
            $this->setting->setting('dateCloture', 'OruEsmsBundle') :
            $now->add(new \DateInterval('P1D'))
        ;
        $dateDemarrage = null !== $this->setting->setting('dateDemarrage', 'OruEsmsBundle') ?
            $this->setting->setting('dateDemarrage', 'OruEsmsBundle') :
            $now->sub(new \DateInterval('P1D'));

        if($object instanceof Esms && count(array_intersect(array(self::EDIT, self::UNLOCK), $attributes)) && $object->getCreated() instanceof \DateTime)
        {
            if(!(0 === $object->getCreated()->diff($dateCloture)->invert && 1 === $object->getCreated()->diff($dateDemarrage)->invert))
            {
                $this->logger->warning('Date overflow can\'t EDIT/UNLOCK!');
                $this->logger->error(sprintf('Access denied by %s line %s', __CLASS__, __LINE__));

                return VoterInterface::ACCESS_DENIED;
            }
        }

        if(
            !(
                0 === $now->diff($dateCloture)->invert
                && 1 === $now->diff($dateDemarrage)->invert
            )
            && count(array_intersect(array(self::EDIT), $attributes))
        )
        {
            $this->logger->warning('Date overflow can\'t EDIT!');
            $this->logger->error(sprintf('Access denied by %s line %s', __CLASS__, __LINE__));
            return VoterInterface::ACCESS_DENIED;
        }

        if($object instanceof Esms)
        {
            return VoterInterface::ACCESS_GRANTED;
        }
        else
        {
            return VoterInterface::ACCESS_ABSTAIN;
        }
    }
}