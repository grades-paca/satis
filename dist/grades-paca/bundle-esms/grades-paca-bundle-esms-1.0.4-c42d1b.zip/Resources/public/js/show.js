jQuery( document ).ready(function(){
    jQuery('select:visible').each(function(){
        var id = jQuery(this).attr('id');
        if(jQuery(this).children('option:selected').val())
            var value = jQuery(this).children('option:selected').text();
        else
            var value = '---';
        jQuery(this).after('<p>' + value + '</p>');
    });
    jQuery('select:visible, div.select2-container').hide();

    jQuery('input[type=radio]:visible').each(function(){

        if(jQuery(this).hasClass('to_hide')) return;

        var name = jQuery(this).attr('name');
        var value = jQuery('input[name="' + name + '"]:checked').val();
        if(! value)
        {
            jQuery(this).after('<p>---</p>');
        }else{
            var id = jQuery('input[name="' + name + '"]:checked').attr('id');
            jQuery(this).after('<p>' + jQuery('label[for="' + id + '"]').text() + '</p>');
        }

        var mask = new Array();
        jQuery('input[name="' + name + '"]').each(function(){
            var id = jQuery(this).attr('id');
            jQuery('label[for="' + id + '"]').addClass('to_hide');
        });
        jQuery('input[name="' + name + '"]').addClass('to_hide');
    });
    jQuery('.to_hide').hide();

    jQuery('input[type=text]:visible, input[type=number]:visible, textarea:visible').each(function(){
        if(jQuery(this).val())
            var value = jQuery(this).val();
        else
            var value = '---';
        jQuery(this).after('<p>' + value + '</p>');
    });
    jQuery('input[type=text]:visible, input[type=number]:visible, textarea:visible, input[type=submit], button[type=submit]').hide();
    jQuery('input:visible').attr('disabled','disabled');
    jQuery('form').append('<button name="print" onclick="window.print();return false;" class="btn btn-primary">Imprimer</button>')
});