<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 18/04/2017
 * Time: 10:53
 */

namespace Oru\Bundle\FormIncrementalBundle\Service;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\FormIncrementalBundle\Annotation\Collector;
use Oru\Bundle\FormIncrementalBundle\Cache\Manager;

class FieldValidityDescription
{
    /**
     * @var Manager
     */
    private $manager;

    /**
     * @var EntityManager
     */
    private $em;

    public function __construct(Manager $manager, EntityManager $em)
    {
        $this->manager = $manager;
        $this->em = $em;
    }

    public function update()
    {
        $i = 0;

        $this->em->createQuery('DELETE FROM OruFormIncrementalBundle:FieldValidityDescription')->execute();

        foreach ((array) $this->manager->getFieldValidity() as $entities) {
            foreach ($entities as $entity => $fields) {
                $metadata = $this->em->getClassMetadata($entity);
                $metaTableName = $metadata->getTableName();
                foreach ($fields as $field) {
                    $metaFieldName = $metadata->getColumnName($field->fieldName);

                    //Quand il y a des range on insère les lignes associées
                    if (is_array($field->range)) {
                        foreach ($field->range as $range) {
                            $description = new \Oru\Bundle\FormIncrementalBundle\Entity\FieldValidityDescription();
                            $description->setStart($range[0]);
                            $description->setStop($range[1]);
                            $description->setField($metaFieldName);
                            $description->setTableName($metaTableName);
                            $this->em->persist($description);
                            ++$i;
                        }
                    }

                    //Quand il y a un start et stop, on s'assure qu'il ne s'agisse pas des valeurs par défaut avant de les insérer
                    if (!(Collector::INCREMENT_MAX === $field->stop && Collector::INCREMENT_MIN === $field->start && is_array($field->range))) {
                        $description = new \Oru\Bundle\FormIncrementalBundle\Entity\FieldValidityDescription();
                        $description->setStart($field->start);
                        $description->setStop($field->stop);
                        $description->setField($metaFieldName);
                        $description->setTableName($metaTableName);
                        $this->em->persist($description);
                        ++$i;
                    }

                    if ($i % 100 === 0) {
                        $this->em->flush();
                    }
                }
            }
        }

        $this->em->flush();
    }
}
