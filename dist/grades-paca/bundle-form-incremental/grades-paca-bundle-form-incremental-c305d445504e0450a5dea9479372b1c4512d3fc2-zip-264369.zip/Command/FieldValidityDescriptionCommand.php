<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 18/04/2017
 * Time: 10:48
 */

namespace Oru\Bundle\FormIncrementalBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class FieldValidityDescriptionCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('oru:fieldvalidity_description:update')
            ->setDescription('Met à jour la description des champs utilisant FormIncremental')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $container = $this->getContainer();
        $container->get('oru_form_incremental_field_validity_description')->update();
    }
}
