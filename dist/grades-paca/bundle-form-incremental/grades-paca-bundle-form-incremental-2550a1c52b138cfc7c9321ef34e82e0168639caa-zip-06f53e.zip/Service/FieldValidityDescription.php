<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 18/04/2017
 * Time: 10:53
 */

namespace Oru\Bundle\FormIncrementalBundle\Service;


use Doctrine\ORM\EntityManager;

use Oru\Bundle\FormIncrementalBundle\Cache\Manager;

class FieldValidityDescription
{
    /**
     * @var Manager
     */
    private $manager;

    /**
     * @var EntityManager
     */
    private $em;

    public function __construct(Manager $manager, EntityManager $em)
    {
        $this->manager = $manager;
        $this->em = $em;
    }

    public function update()
    {
        $i=0;

        $this->em->createQuery('DELETE FROM OruFormIncrementalBundle:FieldValidityDescription')->execute();

        foreach((array)$this->manager->getFieldValidity() as $entities){
            foreach($entities as $entity => $fields){
                $metadata = $this->em->getClassMetadata($entity);
                foreach($fields as $field){
                    $description = new \Oru\Bundle\FormIncrementalBundle\Entity\FieldValidityDescription();
                    $description->setStart($field->start);
                    $description->setStop($field->stop);
                    $description->setField($metadata->getColumnName($field->fieldName));
                    $description->setTableName($metadata->getTableName());

                    $this->em->persist($description);

                    if($i % 100 == 0){
                        $this->em->flush();
                    }

                    $i++;
                }
            }
        }

        $this->em->flush();
    }
}