<?php
/**
 * Author: Michaël VEROUX
 * Date: 22/01/15
 * Time: 12:38
 */

namespace Oru\Bundle\FormIncrementalBundle\Annotation;

use \Doctrine\Common\Annotations\Annotation;

/**
 * Class FieldValidity
 * @package Oru\Bundle\FormIncrementalBundle\Annotation
 * @Annotation
 * @author Michaël VEROUX
 */
class FieldValidity
{
    /**
     * @var int
     */
    public $start = Collector::INCREMENT_MIN;

    /**
     * @var int
     */
    public $stop = Collector::INCREMENT_MAX;

    /**
     * @var string
     */
    public $fieldName;

    /**
     * @return string
     */
    public function getFieldName()
    {
        return $this->fieldName;
    }

    /**
     * @return int
     */
    public function getStart()
    {
        return $this->start;
    }

    /**
     * @return int
     */
    public function getStop()
    {
        return $this->stop;
    }

    /**
     * @param string $fieldName
     * @return $this
     */
    public function setFieldName($fieldName)
    {
        $this->fieldName = $fieldName;

        return $this;
    }

    /**
     * @param int $start
     * @return $this
     */
    public function setStart($start)
    {
        $this->start = $start;

        return $this;
    }

    /**
     * @param int $stop
     * @return $this
     */
    public function setStop($stop)
    {
        $this->stop = $stop;

        return $this;
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    public function toArray()
    {
        return array(
            'start' => $this->start,
            'stop'  => $this->stop,
        );
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function __toString()
    {
        return $this->getFieldName();
    }
} 