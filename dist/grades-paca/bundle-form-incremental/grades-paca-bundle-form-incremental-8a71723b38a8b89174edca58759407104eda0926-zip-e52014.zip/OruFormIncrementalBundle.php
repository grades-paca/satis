<?php
/**
 * Author: Michaël VEROUX
 * Date: 22/01/15
 * Time: 09:27
 */

namespace Oru\Bundle\FormIncrementalBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruFormIncrementalBundle extends Bundle
{

} 