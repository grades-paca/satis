<?php
/**
 * Author: Michaël VEROUX
 * Date: 22/01/15
 * Time: 15:19
 */

namespace Oru\Bundle\FormIncrementalBundle\Cache;

use Oru\Bundle\FormIncrementalBundle\Annotation\Collector;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Serializer;

/**
 * Class FieldValidity
 * @package Oru\Bundle\FormIncrementalBundle\Cache
 * @author Michaël VEROUX
 */
class FieldValidity
{
    /**
     * @var array
     */
    protected $fieldsValidity = array();

    /**
     * @param string $className
     * @param string $jsonFields
     * @author Michaël VEROUX
     */
    public function addClassFieldsValidity($className, $jsonFields)
    {
        $encoders = array(new JsonEncoder());
        $normalizers = array(new GetSetMethodNormalizer());
        $serializer = new Serializer($normalizers, $encoders);

        $this->fieldsValidity[$className] = array_map(function($value) use ($serializer)
            {
                return $serializer->deserialize($value, Collector::ANNOTATION_CLASS, 'json');
            },
            json_decode($jsonFields)
        );
    }

    /**
     * @return array
     */
    public function getFieldsValidity()
    {
        return $this->fieldsValidity;
    }

    /**
     * @param string $class
     * @param int $increment
     * @return array
     * @author Michaël VEROUX
     */
    public function getFieldsByClassAndIncrementObj($class, $increment)
    {
        $isRangeInFunction = array($this, 'isRangeIn');
        $filtered = array_filter($this->fieldsValidity[$class], function(\Oru\Bundle\FormIncrementalBundle\Annotation\FieldValidity $value) use ($increment, $isRangeInFunction)
            {
                $range = $value->getRange();
                if (is_array($range)) {
                    if (Collector::INCREMENT_MAX === $value->getStop() && Collector::INCREMENT_MIN === $value->getStart()) {
                        $value->setStop(Collector::INCREMENT_MIN); // Très important pour pouvoir utiliser range seul (sans définir start et stop)
                    }
                    foreach ($range as $item) {
                        $isRangeIn = $isRangeInFunction($item[0], $item[1], $increment);
                        if (true === $isRangeIn) {
                            return true;
                        }
                    }
                }

                $isRangeIn = $isRangeInFunction($value->getStart(), $value->getStop(), $increment);

                return $isRangeIn;
            }
        );

        return $filtered;
    }

    /**
     * @param string $class
     * @param int $increment
     * @return array
     * @author Michaël VEROUX
     */
    public function getFieldsRemovedByClassAndIncrementObj($class, $increment)
    {
        return array_diff(
            $this->fieldsValidity[$class],
            $this->getFieldsByClassAndIncrementObj($class, $increment)
        );
    }

    /**
     * @param string $class
     * @param int $increment
     * @return array
     * @author Michaël VEROUX
     */
    public function getFieldsByClassAndIncrement($class, $increment)
    {
        return array_map(function(\Oru\Bundle\FormIncrementalBundle\Annotation\FieldValidity $entity)
            {
                return $entity->getFieldName();
            },
            $this->getFieldsByClassAndIncrementObj($class, $increment)
        );
    }

    /**
     * @param string $class
     * @param int $increment
     * @return array
     * @author Michaël VEROUX
     */
    public function getFieldsRemovedByClassAndIncrement($class, $increment)
    {
        return array_map(function(\Oru\Bundle\FormIncrementalBundle\Annotation\FieldValidity $entity)
            {
                return $entity->getFieldName();
            },
            $this->getFieldsRemovedByClassAndIncrementObj($class, $increment)
        );
    }

    /**
     * @param int $start
     * @param int $stop
     * @param int $value
     *
     * @return bool
     *
     * @author Michaël VEROUX
     */
    private function isRangeIn($start, $stop, $value)
    {
        if($value >= $start && $value <= $stop)
        {
            return true;
        }

        return false;
    }
} 