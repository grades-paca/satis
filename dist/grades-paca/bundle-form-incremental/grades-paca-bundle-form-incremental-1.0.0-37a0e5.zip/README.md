OruFormIncrementalBundle
=============

Description
-----------

Ce bundle permet de supprimer automatiquement des champs de formulaire selon une plage de validité d'une propriété de l'entité liée.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/form-incremental":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\FormIncrementalBundle\OruFormIncrementalBundle();
```

Vider le cache de Symfony2

Utilisation
-----------

### Entité

``` php
use Oru\Bundle\FormIncrementalBundle\Annotation\FieldValidity;
use Oru\Bundle\FormIncrementalBundle\Entity\FormIncrementalInterface;

class Entity implements FormIncrementalInterface
{
    /**
     * @var mixed
     * @FieldValidity(start=2010, stop=2011)
     */
    protected $property;

    /**
     * @return int
     */
    public function getIncrement()
    {
        return (int)$this->whatYouWant();
    }
}
```

### FormType

Déclaration du service

``` xml
    <service id="my_form_type" class="My\Bundle\FormType">
        <argument type="service" id="oru_form_incremental.incremental_form_subscriber" />
    </service>
```

Class FormType

``` php
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Oru\Bundle\FormIncrementalBundle\Form\Subscriber\IncrementalValiditySubscriber;

class FormType extends AbstractType
{
    /**
     * @var IncrementalValiditySubscriber
     */
    protected $validitySubscriber;

    public function __construct(IncrementalValiditySubscriber $validitySubscriber)
    {
        $this->validitySubscriber = $validitySubscriber;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        ...

        $builder->addEventSubscriber($this->validitySubscriber);
    }
}
```

Et le tour est joué, tous les champs qui ne correspondent pas à l'interval donné seront supprimés dans l'objet form.