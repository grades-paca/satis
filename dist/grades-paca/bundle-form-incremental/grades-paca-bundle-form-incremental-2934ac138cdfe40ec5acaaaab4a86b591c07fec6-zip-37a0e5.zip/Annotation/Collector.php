<?php
/**
 * Author: Michaël VEROUX
 * Date: 22/01/15
 * Time: 13:30
 */

namespace Oru\Bundle\FormIncrementalBundle\Annotation;

//use Doctrine\ORM\Tools\DisconnectedClassMetadataFactory;
// @todo change when #8742 will be resolved
use Oru\Bundle\RorBundle\Doctrine\Mapping\DisconnectedClassMetadataFactory;

use Doctrine\Common\Persistence\Mapping\RuntimeReflectionService;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\Annotations\Reader;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Serializer;

/**
 * Class Collector
 * @package Oru\Bundle\FormIncrementalBundle\Annotation
 * @author Michaël VEROUX
 */
class Collector
{
    const FORM_INCREMENTAL_INTERFACE = 'Oru\Bundle\FormIncrementalBundle\Entity\FormIncrementalInterface';
    const ANNOTATION_CLASS = 'Oru\Bundle\FormIncrementalBundle\Annotation\FieldValidity';
    const INCREMENT_MIN = 0;
    const INCREMENT_MAX = 3000;

    /**
     * @var ObjectManager
     */
    protected $em;

    /**
     * @var Reader
     */
    protected $reader;

    /**
     * @var array
     */
    protected $supportedEntities = array();

    /**
     * @param ObjectManager $em
     * @param Reader $reader
     */
    public function __construct(ObjectManager $em, Reader $reader)
    {
        $this->em = $em;
        $this->reader = $reader;
    }

    /**
     * @author Michaël VEROUX
     */
    protected function initSupportedEntities()
    {
        $metadataFactory = new DisconnectedClassMetadataFactory();
        $metadataFactory->setEntityManager($this->em);
        $reflectionService = new RuntimeReflectionService();

        foreach($metadataFactory->getAllMetadata() as $metadata)
        {
            $metadata->initializeReflection($reflectionService);

            if($metadata->getReflectionClass()->implementsInterface(self::FORM_INCREMENTAL_INTERFACE))
            {
                $this->supportedEntities[$metadata->getReflectionClass()->getName()] = array();
                $this->collectAnnotations($metadata->getReflectionClass());
            }
        }
    }

    /**
     * @param \ReflectionClass $reflectionClass
     * @author Michaël VEROUX
     */
    protected function collectAnnotations(\ReflectionClass $reflectionClass)
    {
        $encoders = array(new JsonEncoder());
        $normalizers = array(new GetSetMethodNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $defaultValues = array(
            'start'     => self::INCREMENT_MIN,
            'stop'      => self::INCREMENT_MAX,
        );

        $tmp = array();
        foreach($reflectionClass->getProperties() as $property)
        {
            $defaultValues['fieldName'] = $property->getName();
            $annotation = $this->reader->getPropertyAnnotation($property, self::ANNOTATION_CLASS);

            if(null === $annotation)
            {
                $class = self::ANNOTATION_CLASS;
                $annotation = new $class();
            }

            $values = array_merge($defaultValues, $annotation->toArray());

            array_push($tmp, $serializer->serialize($values, 'json'));
        }

        $this->supportedEntities[$reflectionClass->getName()] = $serializer->serialize($tmp, 'json');
    }

    /**
     * @return array
     */
    public function getSupportedEntities()
    {
        $this->initSupportedEntities();

        return $this->supportedEntities;
    }
} 