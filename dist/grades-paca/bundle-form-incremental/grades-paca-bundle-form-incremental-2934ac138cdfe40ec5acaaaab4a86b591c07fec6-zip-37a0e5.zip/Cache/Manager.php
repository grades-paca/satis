<?php
/**
 * Author: Michaël VEROUX
 * Date: 22/01/15
 * Time: 15:07
 */

namespace Oru\Bundle\FormIncrementalBundle\Cache;

use Oru\Bundle\FormIncrementalBundle\Annotation\Collector;
use Symfony\Component\Config\ConfigCache;
use Symfony\Component\Config\Resource\DirectoryResource;
use Symfony\Component\Config\Resource\FileResource;
use Oru\Bundle\FormIncrementalBundle\Cache\FieldValidity;

class Manager
{
    /**
     * @var Collector
     */
    protected $collector;

    /**
     * @var FieldValidity
     */
    protected $fieldValidity;

    /**
     * @param Collector $collector
     * @param array $options
     * @throws \InvalidArgumentException
     */
    public function __construct(Collector $collector, $options = array())
    {
        $this->collector = $collector;

        $this->options = array(
            'cache_dir' => null,
            'root_dir' => null,
            'debug'     => false,
        );

        if ($diff = array_diff(array_keys($options), array_keys($this->options))) {
            throw new \InvalidArgumentException(sprintf('The Cache manager does not support the following options: \'%s\'.', implode('\', \'', $diff)));
        }

        $this->options = array_merge($this->options, $options);
    }

    /**
     * @author Michaël VEROUX
     */
    public function init()
    {
        $cacheFile = sprintf('%s/fields-validity.php', $this->options['cache_dir']);

        $cache = new ConfigCache($cacheFile, $this->options['debug']);

        if(!$cache->isFresh())
        {
            $cacheAll = array_map(function($key, $value)
                {
                    return sprintf("\$fieldValidity->addClassFieldsValidity('%s', '%s');", $key, $value);
                },
                array_keys($this->collector->getSupportedEntities()),
                $this->collector->getSupportedEntities()
            );
            $content = sprintf(<<<EOF
<?php

use Oru\Bundle\FormIncrementalBundle\Cache\FieldValidity;

\$fieldValidity = new FieldValidity();
%s
return \$fieldValidity;

EOF
                ,
                implode("\n", $cacheAll)
            );

            $cache->write($content, array(new DirectoryResource($this->options['root_dir'] . '/../src/'), new FileResource($this->options['root_dir'] . '/../composer.json')));
        }

        $this->fieldValidity = include $cache;
    }

    /**
     * @return FieldValidity
     */
    public function getFieldValidity()
    {
        if(null === $this->fieldValidity)
        {
            $this->init();
        }

        return $this->fieldValidity;
    }
}