<?php
/**
 * Author: Michaël VEROUX
 * Date: 21/01/15
 * Time: 14:30
 */

namespace Oru\Bundle\FormIncrementalBundle\Form\Subscriber;

use Doctrine\Common\Util\ClassUtils;
use Oru\Bundle\FormIncrementalBundle\Entity\FormIncrementalInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Oru\Bundle\FormIncrementalBundle\Cache\Manager;

/**
 * Class IncrementalValiditySubscriber
 * @package Oru\Bundle\FormIncrementalBundle\Form\Subscriber
 * @author Michaël VEROUX
 */
class IncrementalValiditySubscriber implements EventSubscriberInterface
{
    /**
     * @var Manager
     */
    protected $cacheManager;

    /**
     * @param Manager $cacheManager
     */
    public function __construct(Manager $cacheManager)
    {
        $this->cacheManager = $cacheManager;
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    public static function getSubscribedEvents()
    {
        return array(
            FormEvents::POST_SET_DATA => array('manageIncrementalFields'),
        );
    }

    /**
     * @param FormEvent $event
     * @author Michaël VEROUX
     */
    public function manageIncrementalFields(FormEvent $event)
    {
        if(!$event->getData() instanceof FormIncrementalInterface)
        {
            return;
        }

        $removes = $this->cacheManager->getFieldValidity()->getFieldsRemovedByClassAndIncrement(
            ClassUtils::getRealClass(get_class($event->getData())),
            $event->getData()->getIncrement()
        );

        foreach($removes as $remove)
        {
            if($event->getForm()->has($remove))
            {
                $event->getForm()->remove($remove);
            }
        }
    }
}