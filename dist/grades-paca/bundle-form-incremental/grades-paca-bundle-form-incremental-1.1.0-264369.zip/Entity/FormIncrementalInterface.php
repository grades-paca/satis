<?php
/**
 * Author: Michaël VEROUX
 * Date: 22/01/15
 * Time: 13:43
 */

namespace Oru\Bundle\FormIncrementalBundle\Entity;

/**
 * Interface FormIncrementalInterface.
 *
 * @author Michaël VEROUX
 */
interface FormIncrementalInterface
{
    /**
     * Return current increment of object (year, month or what you want...).
     *
     * @return int
     *
     * @author Michaël VEROUX
     */
    public function getIncrement();
}
