<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\SmsBundle\Command;


use Oru\Bundle\SmsBundle\Factory\SmsFactory;
use Oru\Bundle\SmsBundle\Manager\SmsManager;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class SendCommand extends ContainerAwareCommand
{
    /**
     * @inheritdoc
     */
    public function configure()
    {
        $this
            ->setName('oru:sms:send')
            ->setDescription("Envoi un SMS")
            ->addArgument('telephone', InputArgument::REQUIRED, "Numéro de téléphone")
            ->addArgument('message', InputArgument::REQUIRED, "Message")
            ->addOption('--transport', '-t', InputOption::VALUE_OPTIONAL, 'Mode de transport')
        ;
    }

    /**
     * @inheritdoc
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $smsManager = $this->getContainer()->get('oru_sms.manager');
        $transport = (($input->hasOption('transport')) ? $input->getOption('transport') : null);
        if(!$smsManager->isAbleToSend($transport)) {
            if($transport) {
                $output->writeln("<error>Impossible d'initialiser le mode de transport $transport.</error>");
            } else {
                $output->writeln("<error>Aucun mode de transport fonctionnel.</error>");
            }
            if ($output->getVerbosity() > OutputInterface::VERBOSITY_VERBOSE && $smsManager->getLastError()) {
                $output->writeln("<error>Dernière erreur rencontrée : {$smsManager->getLastError()}</error>");
            }
        } else {
            if ($transport) {
                $smsManager->chooseTransport($transport);
            }

            $factory = $this->getContainer()->get('oru_sms.factory');
            $sms = $factory->create($input->getArgument('telephone'), $input->getArgument('message'));

            $smsManager->send($sms);
            $output->writeln("Statut de votre SMS : {$sms->getReadableStatus()}");
            if ($output->getVerbosity() > OutputInterface::VERBOSITY_VERBOSE && $sms->getStatus() == SmsManager::ERROR) {
                $output->writeln("<error>Dernière erreur rencontrée : {$smsManager->getLastError()}</error>");
            }
        }
    }
}