<?php


namespace Oru\Bundle\SmsBundle\Entity;

use Doctrine\ORM\EntityRepository;


class SmsRepository extends EntityRepository
{
    /**
     * @param \Oru\Bundle\SmsBundle\Filter\SmsFilter $filter
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function findList(\Oru\Bundle\SmsBundle\Filter\SmsFilter $filter)
    {
        $builder = $this->createQueryBuilder("u")->orderBy('u.createdAt', 'desc');
        if($filter->getMessage())
        {
            $builder->andWhere("u.message like :message")->setParameter("message","%{$filter->getMessage()}%");
        }
        if($filter->getCreatedAfter())
        {
            $builder->andWhere("u.createdAt >= :createdAfter")->setParameter("createdAfter","{$filter->getCreatedAfter()->format('Y-m-d H:i:s')}");
        }
        if($filter->getCreatedBefore())
        {
            $builder->andWhere("u.createdAt <= :createdBefore")->setParameter("createdBefore","{$filter->getCreatedBefore()->format('Y-m-d H:i:s')}");
        }
        return $builder;
    }

    /**
     * Nombre de SMS à un statut et un environnement particulier
     *
     * @param $status
     * @param $env
     * @return mixed
     */
    public function countStatus($status, $env)
    {
        return $this
            ->createQueryBuilder('u')
            ->select('count(u)')
            ->andWhere('u.status = :status')
            ->setParameter('status', $status)
            ->andWhere('u.environment like :env')
            ->setParameter('env', $env)
            ->getQuery()
            ->getSingleScalarResult();
    }
} 