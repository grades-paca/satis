<?php

namespace Oru\Bundle\SmsBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class SmsFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('message', 'search', array('required' => false, 'label' => 'Sms.message', 'translation_domain' => 'OruSmsBundle'))
            ->add('createdAfter', 'datetime', array('required' => false, 'label' => 'Sms.createdAfter', 'translation_domain' => 'OruSmsBundle', 'date_widget' => 'single_text', 'time_widget' => 'single_text'))
            ->add('createdBefore', 'datetime', array('required' => false, 'label' => 'Sms.createdBefore', 'translation_domain' => 'OruSmsBundle', 'date_widget' => 'single_text', 'time_widget' => 'single_text'))
            ->add('filter', 'submit', array('label' => 'listing.action.filter', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-primary')))
            ->add('reset', 'submit', array('label' => 'listing.action.reset', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-default')))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\SmsBundle\Filter\SmsFilter'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_smsbundle_smsfilter';
    }
}
