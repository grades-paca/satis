<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\SmsBundle\Transport\Mipih;

use libphonenumber\PhoneNumberFormat;
use libphonenumber\PhoneNumberUtil;
use Oru\Bundle\SmsBundle\Entity\Sms;
use Oru\Bundle\SmsBundle\Exception\ParameterNotInitialisedException;
use Oru\Bundle\SmsBundle\Exception\SftpConnectionException;
use Oru\Bundle\SmsBundle\Manager\SmsManager;
use Symfony\Component\Config\ConfigCache;

class FileTransport extends AbstractTransport
{
    /**
     * @var string
     */
    protected $fileSftpUrl;

    /**
     * @var string
     */
    protected $username;

    /**
     * @var string
     */
    protected $password;

    /**
     * @var string
     */
    protected $host;

    /**
     * @var string
     */
    protected $port;

    /**
     * @var string
     */
    protected $directory;

    /**
     * @var string
     */
    protected $cache;

    /**
     * {@inheritdoc}
     */
    public function initialize()
    {
        parent::initialize();

        if (!$this->codeFonction) {
            $this->codeFonction = $this->setting->setting('fileCodeFonction', 'OruSmsBundle');
        }

        if (!$this->codeFonction) {
            throw new ParameterNotInitialisedException('Paramètre fileCodeFonction du bundle OruSmsBundle non initialisé.');
        }

        if (!$this->fileSftpUrl) {
            $this->fileSftpUrl = $this->setting->setting('fileSftpUrl', 'OruSmsBundle');
            if (preg_match('#^(.*):(.*)@(.*):([0-9]*)[/]?(.*)$#', $this->fileSftpUrl, $matches) !== false) {
                if (isset($matches[4])) {
                    $this->username = $matches[1];
                    $this->password = $matches[2];
                    $this->host = $matches[3];
                    $this->port = $matches[4];
                    $this->directory = $matches[5];
                }
            }
        }

        if (!$this->fileSftpUrl || !$this->username || !$this->password || !$this->host || !$this->port) {
            throw new ParameterNotInitialisedException('Paramètre fileSftpUrl du bundle OruSmsBundle non initialisé ou incorrect.');
        }
    }

    /**
     * {@inheritdoc}
     */
    public function send(Sms $sms)
    {
        $this->initialize();

        $message = '';
        $util = PhoneNumberUtil::getInstance();
        foreach ($sms->getDestinataires() as $key => $destinataire) {
            $message .= implode(';', array(
                $this->idEtablissement,
                $this->codeAppli,
                $this->codeFonction,
                $sms->getId(),
                $key,
                str_replace(' ', '', $util->format($destinataire->getTelephone(), PhoneNumberFormat::NATIONAL)),
                str_replace(';', ',', $sms->getMessage()),
                '', // vide pour envoi immédiat
                '', // vide pour envoi immédiat
            ))."\n";
        }
        $filename = $this->idEtablissement.'-'.date('Ymd-His00').'.sms';

        try {
            if ($this->sendFile($filename, $message)) {
                $destinataire->setStatus(SmsManager::SENDED);

                return true;
            }
            $destinataire->setStatus(SmsManager::ERROR);

            return false;
        } catch (\Exception $e) {
            $this->lastError = $e->getMessage().' à '.$e->getFile().':'.$e->getLine();
            $sms->setStatus(SmsManager::ERROR);

            return false;
        }
    }

    /**
     * @param $cacheDir string
     */
    public function setCache($cacheDir)
    {
        $this->cache = $cacheDir.'/rest/';
    }

    /**
     * Envoi du fichier en SFTP.
     *
     * @param $filename
     * @param $message
     *
     * @throws SftpConnectionException
     *
     * @return bool
     */
    protected function sendFile($filename, $message)
    {
        $cache = new ConfigCache($this->cache.$filename, false);
        if (!$cache->isFresh()) {
            $cache->write($message);
        }

        $connection = ssh2_connect($this->host, $this->port);
        if (!$connection) {
            throw new SftpConnectionException("Impossible de se connecter à {$this->host}:{$this->port} via le protocole SSH.");
        }
        if (!ssh2_auth_password($connection, $this->username, $this->password)) {
            throw new SftpConnectionException("Impossible de s'identifier à {$this->host}:{$this->port} via le protocole SSH avec l'identifiant {$this->username}.");
        }

        $sftp = ssh2_sftp($connection);
        if (!$sftp) {
            throw new SftpConnectionException("Impossible d'initialiser le sous-sytème SFTP.");
        }

        $srcFile = fopen($this->cache.$filename, 'r');
        $resFile = fopen("ssh2.sftp://{$sftp}/".(($this->directory) ? $this->directory.'/' : '').$filename, 'w');
        $result = stream_copy_to_stream($srcFile, $resFile);
        fclose($resFile);
        fclose($srcFile);

        return $result;
    }
}
