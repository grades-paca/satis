<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\SmsBundle\Transport;

use Oru\Bundle\SmsBundle\Entity\Sms;
use Oru\Bundle\SmsBundle\Exception\ParameterNotInitialisedException;

interface TransportInterface
{
    /**
     * Initilisation du mode de transport.
     *
     * @throws ParameterNotInitialisedException
     */
    public function initialize();

    /**
     * Envoi imédiat d'un ou plusieurs SMS.
     *
     * @param Sms $sms
     *
     * @return bool
     */
    public function send(Sms $sms);

    /**
     * @return string
     */
    public function getName();

    /**
     * @return string
     */
    public function getLastError();
}
