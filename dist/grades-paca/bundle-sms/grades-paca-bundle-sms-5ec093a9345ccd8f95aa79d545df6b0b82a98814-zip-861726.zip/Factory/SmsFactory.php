<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\SmsBundle\Factory;


use libphonenumber\PhoneNumberUtil;
use Oru\Bundle\SmsBundle\Entity\Destinataire;
use Oru\Bundle\SmsBundle\Entity\Sms;
use Oru\Bundle\SmsBundle\Exception\MessageLengthException;
use Oru\Bundle\SmsBundle\Exception\TelephoneInvalidException;
use Oru\Bundle\SmsBundle\Manager\SmsManager;
use Symfony\Bundle\FrameworkBundle\Templating\EngineInterface;

class SmsFactory
{
    /**
     * @var string
     */
    private $defaultIndicatif;

    /**
     * @var \Twig_Environment
     */
    private $twig;

    /**
     * SmsFactory constructor.
     * @param $defaultIndicatif
     * @param EngineInterface $twig
     */
    public function __construct($defaultIndicatif, \Twig_Environment $twig)
    {
        $this->defaultIndicatif = $defaultIndicatif;
        $this->twig = $twig;
    }


    /**
     * Créer une entité SMS
     *
     * @param $telephones
     * @param $message
     * @return Sms
     */
    public function create($telephones, $message) {

        $sms = new Sms();
        if(is_array($telephones)) {
            foreach($telephones as $telephone) {
                $sms->addDestinataire($this->getDestinataire($telephone));
            }
        } else if(is_string($telephones)) {
            $sms->addDestinataire($this->getDestinataire($telephones));
        }
        if(strlen($message) > 160) {
            throw new MessageLengthException("Le message \"$message\" mesure plus de 160 caractères.");
        }
        $sms->setMessage($message);
        return $sms;
    }

    /**
     * Créer une entité destinataire
     *
     * @param $telephone
     * @return Destinataire
     */
    protected function getDestinataire($telephone)
    {
        $destinataire = new Destinataire();
        $util = PhoneNumberUtil::getInstance();
        $phoneNumber = $util->parse($telephone, $this->defaultIndicatif);
        if(!$util->isValidNumber($phoneNumber)) {
            throw new TelephoneInvalidException("Le numéro de téléphone \"$telephone\" n'est pas valide.");
        }
        $destinataire->setTelephone($phoneNumber);
        $destinataire->setStatus(SmsManager::WAITING);
        return $destinataire;
    }

    /**
     * Créé une entité SMS depuis un template
     *
     * @param $template
     * @param array $parameters
     * @param array $to
     * @return Sms
     */
    public function createFromTemplate($template, $parameters = array(), $to = array())
    {
        $rendered = $this->twig->loadTemplate($template);
        $bodyText = $rendered->renderBlock('body_text', $parameters);
        return $this->create($to, $bodyText);
    }
}