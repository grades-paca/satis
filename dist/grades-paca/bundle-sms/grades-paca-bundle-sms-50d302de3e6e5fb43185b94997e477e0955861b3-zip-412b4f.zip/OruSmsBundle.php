<?php

namespace Oru\Bundle\SmsBundle;

use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Oru\Bundle\SmsBundle\DependencyInjection\Compiler\TransportPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class OruSmsBundle extends OruBundle
{
    /**
     * OruSmsBundle constructor.
     */
    public function __construct()
    {
        DynamicLoader::addYaml('@OruSmsBundle/Resources/config/routing.yml');
    }

    /**
     * {@inheritdoc}
     */
    public function build(ContainerBuilder $container)
    {
        parent::build($container);
        $container->addCompilerPass(new TransportPass());
    }

    /**
     * {@inheritdoc}
     */
    public static function getFriendlyName()
    {
        return 'SMS';
    }

    /**
     * {@inheritdoc}
     */
    public static function getDescription()
    {
        return "Bundle permettant l'envoi de SMS";
    }
}
