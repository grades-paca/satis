<?php

namespace Oru\Bundle\SmsBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class SmsListingType extends AbstractListingType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('readableStatus', null, array('label' => 'listing.status', 'translation_domain' => 'OruSmsBundle'))
            ->add('message', null, array('label' => 'listing.message', 'translation_domain' => 'OruSmsBundle', 'template' => '@OruSms/Sms/listing.message.html.twig'))
            ->add('transport', null, array('label' => 'listing.transport', 'translation_domain' => 'OruSmsBundle'))
            ->add('createdAt', null, array('label' => 'listing.createdAt', 'translation_domain' => 'OruSmsBundle'))
            ->add('show', 'object_action', array('route' => 'sms_show', 'label' => 'listing.action.show'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\SmsBundle\Entity\Sms',
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_smsbundle_smslisting';
    }
}
