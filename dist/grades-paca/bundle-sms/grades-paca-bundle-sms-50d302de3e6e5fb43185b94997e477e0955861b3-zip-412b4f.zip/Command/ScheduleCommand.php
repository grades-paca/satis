<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\SmsBundle\Command;

use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class ScheduleCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    /**
     * {@inheritdoc}
     */
    public function configure()
    {
        $this
            ->setName('oru:sms:schedule')
            ->setDescription('Envoi les SMS en attente')
            ->addOption('--transport', '-t', InputOption::VALUE_OPTIONAL, 'Mode de transport')
        ;
    }

    /**
     * {@inheritdoc}
     */
    public function getMaxRunningTimeSec()
    {
        return 30;
    }

    /**
     * {@inheritdoc}
     */
    public function isConcurentAllowed()
    {
        return false;
    }

    /**
     * {@inheritdoc}
     */
    public function getTypeFieldFromArgumentName($name, &$type = 'text', &$options = array())
    {
        // TODO: Implement getTypeFieldFromArgumentName() method.
    }

    /**
     * {@inheritdoc}
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $smsManager = $this->getContainer()->get('oru_sms.manager');
        if ($smsManager->hasSms()) {
            $transport = (($input->hasOption('transport')) ? $input->getOption('transport') : null);
            if (!$smsManager->isAbleToSend($transport)) {
                if ($transport) {
                    $output->writeln("<error>Impossible d'initialiser le mode de transport $transport.</error>");
                } else {
                    $output->writeln('<error>Aucun mode de transport fonctionnel.</error>');
                }
                if ($output->getVerbosity() > OutputInterface::VERBOSITY_VERBOSE && $smsManager->getLastError()) {
                    $output->writeln("<error>Dernière erreur rencontrée : {$smsManager->getLastError()}</error>");
                }
            } else {
                if ($transport) {
                    $smsManager->chooseTransport($transport);
                }
                $output->write('Traitement en cours des SMS... ');
                $output->writeln($smsManager->sendAll().' SMS envoyés.');
                if ($output->getVerbosity() > OutputInterface::VERBOSITY_VERBOSE && $smsManager->getLastError()) {
                    $output->writeln("<error>Dernière erreur rencontrée : {$smsManager->getLastError()}</error>");
                }
            }
        } else {
            $output->writeln('Aucun SMS en attente.');
        }
    }
}
