<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\SmsBundle\Entity;

use libphonenumber\PhoneNumber;
use Oru\Bundle\SmsBundle\Manager\SmsManager;

class Destinataire
{
    /**
     * @var PhoneNumber
     */
    private $telephone;

    /**
     * @var int
     */
    private $id;

    /**
     * @var \Oru\Bundle\SmsBundle\Entity\Sms
     */
    private $sms;

    /**
     * @var string
     */
    private $status;

    /**
     * @var string
     */
    private $code;

    /**
     * Set telephone.
     *
     * @param PhoneNumber $telephone
     *
     * @return Destinataire
     */
    public function setTelephone($telephone)
    {
        $this->telephone = $telephone;

        return $this;
    }

    /**
     * Get telephone.
     *
     * @return PhoneNumber
     */
    public function getTelephone()
    {
        return $this->telephone;
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set sms.
     *
     * @param \Oru\Bundle\SmsBundle\Entity\Sms $sms
     *
     * @return Destinataire
     */
    public function setSms(\Oru\Bundle\SmsBundle\Entity\Sms $sms = null)
    {
        $this->sms = $sms;

        return $this;
    }

    /**
     * Get sms.
     *
     * @return \Oru\Bundle\SmsBundle\Entity\Sms
     */
    public function getSms()
    {
        return $this->sms;
    }

    /**
     * Set status.
     *
     * @param string $status
     *
     * @return Sms
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status.
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Renvoi le status de manière lisible.
     *
     * @return string
     */
    public function getReadableStatus()
    {
        switch ($this->status) {
            case SmsManager::SENDED:
                return 'Envoyé';
            case SmsManager::WAITING:
                return 'En attente';
            case SmsManager::ERROR:
                return 'Erreur';
        }
    }

    /**
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @param string $code
     */
    public function setCode($code)
    {
        $this->code = $code;
    }
}
