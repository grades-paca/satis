<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\SmsBundle\Transport\Mipih;

use libphonenumber\PhoneNumberFormat;
use libphonenumber\PhoneNumberUtil;
use Oru\Bundle\SmsBundle\Entity\Sms;
use Oru\Bundle\SmsBundle\Exception\ParameterNotInitialisedException;
use Oru\Bundle\SmsBundle\Exception\ParseResponseException;
use Oru\Bundle\SmsBundle\Manager\SmsManager;
use Oru\Bundle\WebClientBundle\Client\ProxyClient;

class RestTransport extends AbstractTransport
{
    /**
     * @var string
     */
    protected $restUrl;

    /**
     * @var ProxyClient
     */
    protected $webClient;

    /**
     * RestTransport constructor.
     *
     * @param ProxyClient $webClient
     */
    public function __construct(ProxyClient $webClient)
    {
        $this->webClient = $webClient;
    }

    /**
     * {@inheritdoc}
     */
    public function initialize()
    {
        parent::initialize();

        if (!$this->codeFonction) {
            $this->codeFonction = $this->setting->setting('restCodeFonction', 'OruSmsBundle');
        }

        if (!$this->codeFonction) {
            throw new ParameterNotInitialisedException('Paramètre restCodeFonction du bundle OruSmsBundle non initialisé.');
        }

        if (!$this->restUrl) {
            $this->restUrl = str_replace('?', '', $this->setting->setting('restUrl', 'OruSmsBundle'));
        }

        if (!$this->restUrl) {
            throw new ParameterNotInitialisedException('Paramètre restUrl du bundle OruSmsBundle non initialisé.');
        }
    }

    /**
     * {@inheritdoc}
     */
    public function send(Sms $sms)
    {
        $this->initialize();
        $url = $this->restUrl."?etab={$this->idEtablissement}&appli={$this->codeAppli}&fonction={$this->codeFonction}";
        $util = PhoneNumberUtil::getInstance();
        foreach ($sms->getDestinataires() as $destinataire) {
            $telephone = str_replace(' ', '', $util->format($destinataire->getTelephone(), PhoneNumberFormat::NATIONAL));
            $message = urlencode($sms->getMessage());
            $currentUrl = $url."&dest=$telephone&msg=$message";

            $headers = $this->webClient->getHeader();
            $headers->set('Content-type', 'text/xml;charset="utf-8"');
            $response = $this->webClient->get($currentUrl);
            try {
                $result = $this->processResponse($response);
                $destinataire->setStatus((isset($result['status'])) ? $result['status'] : SmsManager::ERROR);
                $destinataire->setCode((isset($result['code'])) ? $result['code'] : '');
                if (isset($result['msg'])) {
                    if (is_array($result['msg'])) {
                        $this->lastError = implode(', ', $result['msg']);
                    } else {
                        $this->lastError = (string) $result['msg'];
                    }
                }
            } catch (ParseResponseException $e) {
                $destinataire->setStatus(SmsManager::ERROR);
                $this->lastError = $e->getMessage();

                return false;
            }
        }

        return true;
    }

    /**
     * @param $response
     *
     * @throws ParseResponseException
     *
     * @return array
     */
    protected function processResponse($response)
    {
        // mode poupées russes off
        $FormattedResponse = preg_replace("#<\?xml(.*)\?>#", '', $response);

        $xml = simplexml_load_string($FormattedResponse, 'SimpleXMLElement', LIBXML_NSCLEAN);

        if (!isset($xml->codeReponse)) {
            throw new ParseResponseException("Impossible de parcourir la réponse : $response");
        }

        $result = array('code' => (string) $xml->codeReponse);
        switch ($xml->codeReponse) {
            case 'ERR0000':
                $result['status'] = SmsManager::SENDED;

                return $result;
            case 'ERR0010':
            case 'ERR0050':
                if (isset($xml->msgErreurs)) {
                    foreach ($xml->msgErreurs as $msgErreur) {
                        $result['msg'][] = (isset($msgErreur->erreur) && isset($msgErreur->erreur->motif)) ? (string) $msgErreur->erreur->motif : '';
                    }
                }
                $result['status'] = SmsManager::ERROR;

                return $result;
            default:
                throw new ParseResponseException("Impossible de parcourir la réponse : $response");
        }
    }
}
