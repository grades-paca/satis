<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\SmsBundle\Manager;


use Doctrine\ORM\EntityManager;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Oru\Bundle\SmsBundle\Entity\Sms;
use Oru\Bundle\SmsBundle\Exception\SmsInitialisationException;
use Oru\Bundle\SmsBundle\Factory\SmsFactory;
use Oru\Bundle\SmsBundle\Transport\TransportInterface;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpKernel\Kernel;

class SmsManager
{
    /**
     * @var EntityManager
     */
    protected $em;

    /**
     * @var Setting
     */
    protected $setting;

    /**
     * @var TransportInterface
     */
    protected $transport;

    /**
     * @var TransportChain
     */
    protected $transportChain;

    /**
     * @var Session
     */
    protected $session;

    /**
     * @var string
     */
    protected $lastError;

    /**
     * @var Kernel
     */
    protected $kernel;

    /**
     * @var SmsFactory
     */
    protected $smsFactory;

    const SENDED = 3;
    const SENDING = 2;
    const WAITING = 1;
    CONST ERROR = -1;

    /**
     * SmsManager constructor.
     */
    public function __construct(EntityManager $em, Setting $setting, TransportChain $transportChain, Kernel $kernel)
    {
        $this->em = $em;
        $this->setting = $setting;
        $this->transportChain = $transportChain;
        $this->kernel = $kernel;
        $this->lastError = false;
        $transport = $this->setting->setting('transport', 'OruSmsBundle');
        if($transport && $this->transportChain->getTransport('transport')) {
            $this->transport = $this->transportChain->getTransport('transport');
        }
    }

    /**
     * Peut-on utiliser l'envoi de SMS ?
     *
     * @return bool
     */
    public function isAbleToSend($transportRequired = null)
    {
        foreach($this->transportChain->getTransports() as $transport) {
            if(!$transportRequired || strcmp($transport->getName(),$transportRequired) === 0) {
                try {
                    $transport->initialize();
                    return true;
                } catch (SmsInitialisationException $e) {
                    $this->lastError = $e->getMessage();
                }
            }
        }

        return false;
    }

    /**
     * Sauvegarde du SMS
     *
     * @param Sms $sms
     */
    public function store(Sms $sms)
    {
        if(!$sms->getId()) {
            $sms->setEnvironment($this->kernel->getEnvironment());
            $sms->setStatus(self::WAITING);
            $this->em->persist($sms);
            $this->em->flush($sms);
        }
    }

    /**
     * Existe-t-il des SMS en attente ?
     */
    public function hasSms()
    {
        return $this->em->getRepository('OruSmsBundle:Sms')->countStatus(self::WAITING, $this->kernel->getEnvironment());
    }

    /**
     * Envoi de tous les SMS en attente
     */
    public function sendAll()
    {
        $sms = $this->em->getRepository('OruSmsBundle:Sms')->findBy(array('status' => self::WAITING, 'environment' => $this->kernel->getEnvironment()));
        $counter = 0;
        foreach($sms as $oneSms) {
            $status = $this->send($oneSms);
            if($status == self::SENDED) {
                $counter++;
            }
        }
        return $counter;
    }

    /**
     * Envoi du/des SMS (dépend du nombre de destinataires). Si un moyen de transport échoue, le suivant est utilisé.
     *
     * @param Sms $sms
     * @return statut
     */
    public function send(Sms $sms)
    {
        try {
            $this->store($sms);
        } catch(\Exception $e) {
            $error = "Une erreur s'est produite lors de la sauvegarde de votre SMS : {$e->getMessage()}.";
            $this->lastError = $error;
            $sms->setStatus(self::ERROR);
            return $sms->getStatus();
        }

        $sms->setStatus(self::SENDING);
        $this->em->flush($sms);

        $failed = array();
        if($this->transport) {
            $transport = $this->transport;
        } else {
            $transport = $this->transportChain->getBestTransport($sms);
        }

        do {
            try {
                $transport->initialize();
                $transport->send($sms);
                $sms->setTransport($transport->getName());
                $sms->updateStatus();
                $this->em->flush();
                $this->lastError = $transport->getLastError();
                return $sms->getStatus();
            } catch (SmsInitialisationException $e) {
                $failed[] = $transport->getName();
                $error = "Une erreur s'est produite lors de l'utilisation du mode de transport de SMS {$transport->getName()} : {$transport->getLastError()}. Une autre mode de transport va être utilisé.";
                $this->lastError = $error;
            }
        // test du transport suivant
        } while ($transport = $this->transportChain->getBestTransport($sms, $failed));

        $this->lastError = "Une erreur s'est produite lors de l'utilisation du mode de transport de SMS {$transport->getName()} : {$transport->getLastError()}.";
        if ($this->session) {
            $this->session->getFlashBag()->add('error',$error);
        }

        return self::ERROR;
    }

    /**
     * Envoi d'un SMS
     *
     * @param $uriTemplate Template contenant le SMS à envoyer
     * @param array $parameters Variables du template
     * @param array $to Destinataires
     * @return integer le statut du SMS
     */
    public function sendSmsMessage($uriTemplate, $parameters = array(), $to = array())
    {
        $sms = $this->smsFactory->createFromTemplate($uriTemplate, $parameters, $to);
        return $this->send($sms);
    }

    /**
     * Enregistrement d'un SMS
     *
     * @param $uriTemplate Template contenant le SMS à envoyer
     * @param array $parameters Variables du template
     * @param array $to Destinataires
     * @return bool Booléen confirmant l'enregistrement
     */
    public function storeSmsMessage($uriTemplate, $parameters = array(), $to = array())
    {
        $sms = $this->smsFactory->createFromTemplate($uriTemplate, $parameters, $to);
        return $this->store($sms);
    }

    /**
     * @return TransportInterface
     */
    public function getTransport()
    {
        return $this->transport;
    }

    /**
     * @param TransportInterface $transport
     */
    public function setTransport($transport)
    {
        $this->transport = $transport;
    }

    /**
     * @param $transportAlias
     */
    public function chooseTransport($transportAlias)
    {
        $this->transport = $this->transportChain->getTransport($transportAlias);
    }

    /**
     * @return Session
     */
    public function getSession()
    {
        return $this->session;
    }

    /**
     * @param Session $session
     */
    public function setSession($session)
    {
        $this->session = $session;
    }

    /**
     * @return string
     */
    public function getLastError()
    {
        return $this->lastError;
    }

    /**
     * @param string $lastError
     */
    public function setLastError($lastError)
    {
        $this->lastError = $lastError;
    }

    /**
     * @return SmsFactory
     */
    public function getSmsFactory()
    {
        return $this->smsFactory;
    }

    /**
     * @param SmsFactory $smsFactory
     */
    public function setSmsFactory($smsFactory)
    {
        $this->smsFactory = $smsFactory;
    }
}