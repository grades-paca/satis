<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\SmsBundle\Exception;

class ParseResponseException extends \Exception
{
}
