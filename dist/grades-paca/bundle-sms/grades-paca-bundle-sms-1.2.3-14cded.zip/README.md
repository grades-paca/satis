OruSmsBundle
============

Description
-----------

Ce bundle fournit un service d'envoi de SMS.

Installation
------------

Importer le paquet via composer

```
composer require "oru/sms"
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\SmsBundle\OruSmsBundle();
```

Vider le cache de Symfony2

### Liste des pages

[Pages](./oru-sms-bundle/revisions/master/entry/Resources/config/pages.xml)

### Liste des droits

[Droits](./oru-sms-bundle/revisions/master/entry/Resources/config/credentials.yml)

### Liste des paramètres

[Paramètres](./oru-sms-bundle/revisions/master/entry/Resources/settings/OruSmsBundle.generic.orm)


Utilisation
-----------

Ce bundle est désactivable. Tous les SMS sont stockés en base et une interface de suivi permet de les consulter.

Le mode de transport est géré via une passe de compilation. Il sera ainsi possile à terme d'ajouter d'autres moyens de transports.
Les deux modes de transports actuels sont :
- mipih_rest : envoi via appel d'une URL
- mipih_file : dépôt d'un fichier
Les paramètres concernant ces modes de transports sont disponibles dans la gestion des paramètres.
