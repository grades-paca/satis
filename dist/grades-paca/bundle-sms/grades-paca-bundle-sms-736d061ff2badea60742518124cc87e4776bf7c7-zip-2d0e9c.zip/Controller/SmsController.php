<?php

namespace Oru\Bundle\SmsBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Oru\Bundle\SmsBundle\Entity\Sms;
use Oru\Bundle\SmsBundle\Listing\SmsListingType;
use Oru\Bundle\SmsBundle\Form\SmsFilterType;

/**
 * Sms controller.
 *
 */
class SmsController extends Controller
{

    /**
     * Lists all Sms entities.
     *
     */
    public function indexAction(Request $request)
    {
        $form = $this->createForm(new SmsFilterType())->submit($request->getSession()->get('sms.filter', array()));
        $listing = $this->container->get('paginator.factory')->create(
            new SmsListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruSmsBundle:Sms')->findList($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('@OruSms/Sms/index.html.twig', array(
            'listing' => $listing,
            'form' => $this->createForm(new SmsFilterType(), $form->getData())->createView()
        ));
    }
    /**
     * Filters Sms entities.
     *
     */
    public function filterAction(Request $request)
    {
        $form = $this->createForm(new SmsFilterType())->handleRequest($request);

        if ($form->get('reset')->isClicked()) {
            $request->getSession()->remove('sms.filter');
            return $this->redirect($this->generateUrl('sms'));
        }

        if($form->isValid()) {
            $request->getSession()->set('sms.filter', $request->get($form->getName()));
            return $this->redirect($this->generateUrl('sms'));
        }

        $listing = $this->container->get('paginator.factory')->create(
            new SmsListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruSmsBundle:Sms')->findList($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('@OruSms/Sms/index.html.twig', array(
            'listing' => $listing,
            'form' => $form->createView()
        ));
    }

    /**
     * Finds and displays a Sms entity.
     *
     */
    public function showAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruSmsBundle:Sms')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Sms entity.');
        }

        return $this->render('@OruSms/Sms/show.html.twig', array(
            'entity'      => $entity,
        ));
    }
}
