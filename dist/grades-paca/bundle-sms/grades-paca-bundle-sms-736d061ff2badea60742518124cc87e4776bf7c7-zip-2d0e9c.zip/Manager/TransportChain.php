<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\SmsBundle\Manager;


use Oru\Bundle\SmsBundle\Entity\Sms;
use Oru\Bundle\SmsBundle\Transport\TransportInterface;

class TransportChain
{
    /**
     * @var array
     */
    private $transports;

    /**
     * TransportChain constructor.
     */
    public function __construct()
    {
        $this->transports = array();
    }

    /**
     * @param TransportInterface $transport
     * @param $alias
     * @param int $priority
     */
    public function addTransport(TransportInterface $transport, $alias)
    {
        $this->transports[$alias] = $transport;
    }

    /**
     * Récupère un moyen de transport
     *
     * @param $alias
     * @return mixed
     */
    public function getTransport($alias)
    {

        if (array_key_exists($alias, $this->transports)) {
            return $this->transports[$alias];
        }

        return false;
    }

    /**
     * Renvoi le transport le plus adapté pour un envoi
     *
     * @param Sms $sms
     * @return mixed
     */
    public function getBestTransport(Sms $sms, $exclude = array())
    {
        $count = $sms->getDestinataires()->count();
        if($count == 1 && array_search('mipih_rest', $exclude) === FALSE) {
            return $this->getTransport('mipih_rest');
        } else if(array_search('mipih_file', $exclude) === FALSE) {
            return $this->getTransport('mipih_file');
        }

        foreach($this->transports as $transport) {
            if(array_search($transport->getName(), $exclude) === FALSE) {
                return $transport;
            }
        }
    }

    /**
     * @return array
     */
    public function getTransports()
    {
        return $this->transports;
    }

}