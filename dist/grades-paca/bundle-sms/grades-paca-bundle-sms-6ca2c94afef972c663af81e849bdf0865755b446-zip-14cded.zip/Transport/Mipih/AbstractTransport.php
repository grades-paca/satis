<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\SmsBundle\Transport\Mipih;

use Oru\Bundle\SettingBundle\Setting\Setting;
use Oru\Bundle\SmsBundle\Exception\ParameterNotInitialisedException;
use Oru\Bundle\SmsBundle\Transport\TransportInterface;

abstract class AbstractTransport implements TransportInterface
{
    /**
     * @var string
     */
    protected $idEtablissement;

    /**
     * @var string
     */
    protected $codeAppli;

    /**
     * @var string
     */
    protected $codeFonction;

    /**
     * @var Setting
     */
    protected $setting;

    /**
     * @var string
     */
    protected $name;

    /**
     * @var string
     */
    protected $lastError;

    /**
     * @param Setting $setting
     */
    public function setSetting(Setting $setting)
    {
        $this->setting = $setting;
    }

    /**
     * {@inheritdoc}
     */
    public function initialize()
    {
        if (!$this->idEtablissement) {
            $this->idEtablissement = $this->setting->setting('idEtablissement', 'OruSmsBundle');
        }

        if (!$this->codeAppli) {
            $this->codeAppli = $this->setting->setting('codeAppli', 'OruSmsBundle');
        }

        if (!$this->idEtablissement || !$this->codeAppli) {
            if (!$this->idEtablissement) {
                throw new ParameterNotInitialisedException('Paramètre idEtablissement du bundle OruSmsBundle non initialisé.');
            }

            if (!$this->codeAppli) {
                throw new ParameterNotInitialisedException('Paramètre codeAppli du bundle OruSmsBundle non initialisé.');
            }
        }
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function getLastError()
    {
        return $this->lastError;
    }
}
