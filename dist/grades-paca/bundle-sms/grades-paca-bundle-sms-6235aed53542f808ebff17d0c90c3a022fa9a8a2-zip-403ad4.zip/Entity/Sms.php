<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\SmsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\SmsBundle\Manager\SmsManager;

class Sms
{

    /**
     * @var string
     */
    private $message;

    /**
     * @var string
     */
    private $environment;

    /**
     * @var \DateTime
     */
    private $createdAt;

    /**
     * @var \DateTime
     */
    private $updatedAt;

    /**
     * @var string
     */
    private $createdBy;

    /**
     * @var string
     */
    private $updatedBy;

    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $transport;

    /**
     * @var \Doctrine\Common\Collections\Collection
     */
    private $destinataires;

    /**
     * @var int
     */
    private $status;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->destinataires = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Set message
     *
     * @param string $message
     *
     * @return Sms
     */
    public function setMessage($message)
    {
        $this->message = $message;

        return $this;
    }

    /**
     * Get message
     *
     * @return string
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * Set environment
     *
     * @param string $environment
     *
     * @return Sms
     */
    public function setEnvironment($environment)
    {
        $this->environment = $environment;

        return $this;
    }

    /**
     * Get environment
     *
     * @return string
     */
    public function getEnvironment()
    {
        return $this->environment;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return Sms
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return Sms
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set createdBy
     *
     * @param string $createdBy
     *
     * @return Sms
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;

        return $this;
    }

    /**
     * Get createdBy
     *
     * @return string
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * Set updatedBy
     *
     * @param string $updatedBy
     *
     * @return Sms
     */
    public function setUpdatedBy($updatedBy)
    {
        $this->updatedBy = $updatedBy;

        return $this;
    }

    /**
     * Get updatedBy
     *
     * @return string
     */
    public function getUpdatedBy()
    {
        return $this->updatedBy;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Add destinataire
     *
     * @param \Oru\Bundle\SmsBundle\Entity\Destinataire $destinataire
     *
     * @return Sms
     */
    public function addDestinataire(\Oru\Bundle\SmsBundle\Entity\Destinataire $destinataire)
    {
        $destinataire->setSms($this);
        $this->destinataires[] = $destinataire;

        return $this;
    }

    /**
     * Remove destinataire
     *
     * @param \Oru\Bundle\SmsBundle\Entity\Destinataire $destinataire
     */
    public function removeDestinataire(\Oru\Bundle\SmsBundle\Entity\Destinataire $destinataire)
    {
        $this->destinataires->removeElement($destinataire);
    }

    /**
     * Get destinataires
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getDestinataires()
    {
        return $this->destinataires;
    }

    /**
     * @return string
     */
    public function getTransport()
    {
        return $this->transport;
    }

    /**
     * @param string $transport
     */
    public function setTransport($transport)
    {
        $this->transport = $transport;
    }

    /**
     * Renvoi le status cumulé de chaque destinataire
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param int $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * Renvoi le status de manière lisible
     *
     * @return string
     */
    public function getReadableStatus()
    {
        switch ($this->getStatus()) {
            case SmsManager::SENDED :
                return 'Envoyé';

            case SmsManager::WAITING :
                return 'En attente';

            case SmsManager::ERROR :
                return 'Erreur';
        }
    }

    /**
     * Calcule le statut de cette entité
     */
    public function updateStatus()
    {
        $status = null;
        if($this->getStatus() === SmsManager::ERROR) {
            return;
        }

        foreach($this->getDestinataires() as $key => $dest) {
            switch($dest->getStatus()) {
                case SmsManager::ERROR:
                    $status = SmsManager::ERROR;
                    break;

                case SmsManager::WAITING:
                    if($this->getStatus() == SmsManager::WAITING || $this->getStatus() == SmsManager::SENDED) {
                        $status = SmsManager::WAITING;
                    }
                    break;

                case SmsManager::SENDING:
                    if($this->getStatus() >= SmsManager::WAITING) {
                        $status = SmsManager::SENDING;
                    }
                    break;

                case SmsManager::SENDED:
                    if($this->getStatus() == SmsManager::SmsManager || $key === 0) {
                        $status = SmsManager::SENDED;
                    }
                    break;
            }
        }

        $this->setStatus($status);
    }
}
