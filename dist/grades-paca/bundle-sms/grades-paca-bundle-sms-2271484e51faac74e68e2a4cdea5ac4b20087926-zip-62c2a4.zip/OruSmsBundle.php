<?php

namespace Oru\Bundle\SmsBundle;

use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Oru\Bundle\SmsBundle\DependencyInjection\Compiler\TransportPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruSmsBundle extends OruBundle
{
    /**
     * @inheritdoc
     */
    public function build(ContainerBuilder $container)
    {
        $container->addCompilerPass(new TransportPass());
    }

    /**
     * @inheritdoc
     */
    public static function getFriendlyName()
    {
        return 'SMS';
    }

    /**
     *
     * @inheritdoc
     */
    public static function getDescription()
    {
        return "Bundle permettant l'envoi de SMS";
    }

}
