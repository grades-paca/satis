<?php

namespace Oru\Bundle\SmsBundle\Filter;

use Oru\Bundle\SmsBundle\Entity\Sms;


class SmsFilter extends Sms
{
    /**
     * @var \DateTime
     */
    private $createdAfter;

    /**
     * @var \DateTime
     */
    private $createdBefore;

    /**
     * @return \DateTime
     */
    public function getCreatedAfter()
    {
        return $this->createdAfter;
    }

    /**
     * @param \DateTime $createdAfter
     */
    public function setCreatedAfter($createdAfter)
    {
        $this->createdAfter = $createdAfter;
    }

    /**
     * @return \DateTime
     */
    public function getCreatedBefore()
    {
        return $this->createdBefore;
    }

    /**
     * @param \DateTime $createdBefore
     */
    public function setCreatedBefore($createdBefore)
    {
        $this->createdBefore = $createdBefore;
    }
}