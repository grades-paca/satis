<?php

namespace Oru\Bundle\SmsBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class SmsFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('message', SearchType::class, array('required' => false, 'label' => 'Sms.message', 'translation_domain' => 'OruSmsBundle'))
            ->add('createdAfter', DateTimeType::class, array('required' => false, 'label' => 'Sms.createdAfter', 'translation_domain' => 'OruSmsBundle', 'date_widget' => 'single_text', 'time_widget' => 'single_text'))
            ->add('createdBefore', DateTimeType::class, array('required' => false, 'label' => 'Sms.createdBefore', 'translation_domain' => 'OruSmsBundle', 'date_widget' => 'single_text', 'time_widget' => 'single_text'))
            ->add('filter', SubmitType::class, array('label' => 'listing.action.filter', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-primary')))
            ->add('reset', SubmitType::class, array('label' => 'listing.action.reset', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-default')))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\SmsBundle\Filter\SmsFilter',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_smsbundle_smsfilter';
    }
}
