OruSmsBundle
================

Description
-----------

Ce bundle fournit un service d'envoi de SMS.

Installation
------------

Importer le paquet via composer

```
composer require "oru/sms"
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\SmsBundle\OruSmsBundle();
```

Vider le cache de Symfony2

Utilisation
-----------

Ce bundle est désactivable. Différent modes de transports sont paramétrables dans les settings.
Tous les SMS sont stockés en base et une interface de suivi permet de les consulter.

Le mode de transport est géré via une passe de compilation. Il sera ainsi possile à terme d'ajouter d'autres moyens de transports.