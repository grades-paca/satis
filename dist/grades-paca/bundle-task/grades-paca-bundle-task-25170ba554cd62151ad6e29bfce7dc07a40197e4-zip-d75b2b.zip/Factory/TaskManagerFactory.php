<?php

namespace Oru\Bundle\TaskBundle\Factory;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\TaskBundle\Entity\Task;
use Oru\Bundle\TaskBundle\Manager\TaskManager;
use Symfony\Component\DependencyInjection\Container;
use RuntimeException;

/**
 * Class TaskManagerFactory.
 *
 * @author Michaël VEROUX
 */
class TaskManagerFactory
{
    /**
     * @var Container
     */
    protected $container;

    /**
     * TaskManagerFactory constructor.
     *
     * @param Container $container
     */
    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * @param int $taskId
     *
     * @return TaskManager
     *
     * @author Michaël VEROUX
     */
    public function create($taskId)
    {
        $repository = $this->getEntityManager()->getRepository('OruTaskBundle:Task');
        $task = $repository->find($taskId);

        if (!$task) {
            throw new RuntimeException(sprintf('Task %s not found!', $taskId));
        }

        $service = $this->getService($task);

        $taskManager = new TaskManager($this->getEntityManager());
        $taskManager->setService($service);
        $taskManager->setTask($task);
        $taskManager->setLogger($this->container->get('logger'));

        return $taskManager;
    }

    /**
     * @param Task $task
     *
     * @return object
     *
     * @author Michaël VEROUX
     */
    protected function getService(Task $task)
    {
        $serviceName = $task->getService();
        if ($this->container->has($serviceName)) {
            return $this->container->get($serviceName);
        }

        throw new RuntimeException(sprintf('Service %s does not exists', $serviceName));
    }

    /**
     * @return EntityManager
     *
     * @author Michaël VEROUX
     */
    protected function getEntityManager()
    {
        $em = $this->container->get('oru_task.entity_manager')->getManager();

        return $em;
    }
}
