<?php

namespace Oru\Bundle\TaskBundle;

use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Oru\Bundle\SettingBundle\Bundle\OruBundle;

/**
 * Class OruTaskBundle.
 *
 * @author Michaël VEROUX
 */
class OruTaskBundle extends OruBundle
{
    /**
     * @author Michaël VEROUX
     */
    public function __construct()
    {
        DynamicLoader::addXml('@OruTaskBundle/Resources/config/routing.xml');
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getFriendlyName()
    {
        return 'Tâches en arrière plan';
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getDescription()
    {
        return 'Tâches en arrière plan exécutées de manière asynchrone en passant par une pile';
    }
}
