<?php

namespace Oru\Bundle\TaskBundle\Event;

/**
 * Class PushMonoEvent.
 *
 * @author Michaël VEROUX
 */
class PushMonoEvent extends PushEvent
{

}
