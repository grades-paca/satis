<?php

namespace Oru\Bundle\TaskBundle\Controller;

use DateTime;
use Oru\Bundle\RorCredentialsBundle\Controller\CredentialControllerTrait;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Class NagiosController.
 *
 * @author Michaël VEROUX
 */
class NagiosController extends Controller
{
    use CredentialControllerTrait;

    /**
     * @param Request $request
     *
     * @return Response
     *
     * @author Michaël VEROUX
     */
    public function stateAction(Request $request)
    {
        $state = 'OK';
        $period = (int) $this->get('oru_setting')->setting('nagios_period_min', 'OruTaskBundle');
        $timestampPeriod = time() - (60 * $period);
        $since = new DateTime();
        $since->setTimestamp($timestampPeriod);

        $tasks = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->errorTasks($since);

        if (count($tasks)) {
            $state = 'Des erreurs sont survenues lors du traitement des dernières tâches asynchrones...'.PHP_EOL;
            foreach ($tasks as $task) {
                $codeName = $this->get('translator.default')->trans('oru_task_listing.code_value.'.$task->getCode(), array(), 'OruTaskBundle');
                $state .= sprintf('#%d [%s] [%s] %s'.PHP_EOL, $task->getId(), $task->getCreated()->format('d/m/Y H:i:s'), $codeName, $task->getService());
            }
        }

        $response = new Response($state);

        return $response;
    }

    /**
     * @param Request $request
     *
     * @return Response
     *
     * @author Michaël VEROUX
     */
    public function viewAction(Request $request)
    {
        $this->grantAccess('ORU_TASK_VIEW');

        $lastHourTimestamp = time() - 3600;
        $since = new DateTime();

        $since->setTimestamp($lastHourTimestamp);
        $lastHourCount = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->endedSinceCount($since);
        $lastHourErrorCount = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->endedErrorSinceCount($since);
        $lagCount = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->averageLagSince($since);
        $maxLag = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->maxLagSince($since);

        $since->setTimestamp($lastHourTimestamp - 3600);
        $lastHour2Count = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->endedSinceCount($since);
        $lastHour2ErrorCount = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->endedErrorSinceCount($since);
        $lag2Count = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->averageLagSince($since);
        $maxLag2 = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->maxLagSince($since);

        $since->setTimestamp($lastHourTimestamp - (3600 * 23));
        $lastHour24Count = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->endedSinceCount($since);
        $lastHour24ErrorCount = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->endedErrorSinceCount($since);
        $lag24Count = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->averageLagSince($since);
        $maxLag24 = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->maxLagSince($since);

        return $this->render('@OruTask/Nagios/view.html.twig', array(
            'lastHour' => $lastHourCount,
            'lastHour2' => $lastHour2Count,
            'lastHour24' => $lastHour24Count,
            'lastHourError' => $lastHourErrorCount,
            'lastHour2Error' => $lastHour2ErrorCount,
            'lastHour24Error' => $lastHour24ErrorCount,
            'lag' => $lagCount,
            'lag2' => $lag2Count,
            'lag24' => $lag24Count,
            'maxLag' => $maxLag,
            'maxLag2' => $maxLag2,
            'maxLag24' => $maxLag24,
        ));
    }
}
