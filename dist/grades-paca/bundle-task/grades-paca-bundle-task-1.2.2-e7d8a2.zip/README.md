Bundle OruTaskBundle
====================

Description
-----------

Ce bundle permet d'empiler des tâches à exécuter en arrière plan.

Installation du Bundle
------------

Importer le paquet via composer

    ./composer.phar require "oru/task":1.0

Dans le AppKernel.php, activer ce bundle

    $bundles[] = new Oru\Bundle\TaskBundle\OruTaskBundle();

Dans le config.yml, ajouter ce bundle au mapping Doctrine :

    doctrine:
        orm:
            ...
            entity_managers:
                default:
                    ...
                    mappings:
                        OruTaskBundle: ~

Vider le cache de Symfony

Utilisation
-----------

Une tâche à exécuter est obligatoirement un service avec des appels de méthodes de service avec ou sans paramètres.

Il faut lancer un événement **Oru\Bundle\TaskBundle\Event\Events::QUEUE_PUSH** pour ajouter une tâche à exécuter.
Il y a 2 types d'objet événement possibles :

**Oru\Bundle\TaskBundle\Event\PushEvent** : Pour les tâches qui peuvent être multithreadées
**Oru\Bundle\TaskBundle\Event\PushMonoEvent** : Pour les tâches qui ne doivent pas être multithreadées

Les 2 objets événement se construisent de la même façon et attendent les mêmes arguments.
Le nom du service, les méthodes à appeler avec les arguments et la priorité de la tâche dans la file d'attente.

Exemple :
```php
$serviceName = 'oru_mon_service';
$methodCalls = array(
    'setEntityId' => array(1),
    'performWhatYouWant' => array(),
);
$priority = Task::PRIORITY_LOW;

$event = new PushEvent($serviceName, $methodCalls, $priority);

$eventDispatcher->dispatch(Events::QUEUE_PUSH, $event);
```

La tâche est ajoutée à la file d'attente et sera traitée immédiatement si la queue était vide.

**Attention** : Le traitement étant asynchrone, il faut prendre en compte que cette tâche pourrait être démarrée alors que le script en cours n'a pas fini tous les traitements comme notamment des modifications en base de données.

**Droits et accès** : La queue est visible à l'adresse **/queue** et le droit associé est **ORU_TASK_VIEW**

Fonctionnement
--------------

**Manager\QueueManager** boucle en permanence pour trouver des tâches à dépiler en prenant soin de ne pas dépiler une tâche mono thread alors qu'il y en a déjà une en cours d'exécution. Toutes les 10 minutes **oru:task:check** vérifie que ce process existe et en relance un dans le cas contraire.
**QueueManager** lance dans un process séparé **Manager\TaskManager** la tâche définie par l'event qui a créé l'objet **Task**, le nombre de process simultanés possibles est défini par le setting **thread_max**.

**Manager\TaskManager** traite les instructions qui avaient été définies dans l'objet **PushEvent** et met à jour l'objet **Task** correspondant. Il utilise pour cela un EntityManager séparé pour éviter les effets de bords avec l'EntityManager utilisé par la tâche elle même.

**oru:task:kill** tue QueueManager tous les jours à 3h10 pour éviter que d'éventuelles fuites mémoires s'accumulent avec le temps.

**IMPORTANT** : Pour que les changements de setting soient pris en compte, il faut tuer le QueueManager en cours.

#### Statistiques de fonctionnement
Il y a une sonde prévue pour fonctionner avec NAGIOS à l'adresse _/queue/status/state_

Une page sur les statistiques de fonctionnement est consultables avec le droit ORU_TASK_VIEW, ici : _/queue/status/view_
