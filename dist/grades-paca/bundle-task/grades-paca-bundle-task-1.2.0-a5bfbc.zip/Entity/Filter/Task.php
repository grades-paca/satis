<?php

namespace Oru\Bundle\TaskBundle\Entity\Filter;

/**
 * Class Task.
 *
 * @author Michaël VEROUX
 */
class Task
{
    /**
     * @var string
     */
    protected $service;
    /**
     * @var array|null
     */
    protected $code;

    /**
     * @var \DateTime|null
     */
    protected $createdFrom;

    /**
     * @var \DateTime|null
     */
    protected $createdTo;

    /**
     * @var bool
     */
    protected $deleted;

    /**
     * @param string $service
     *
     * @return $this
     */
    public function setService($service)
    {
        $this->service = $service;

        return $this;
    }

    /**
     * @return string
     */
    public function getService()
    {
        return $this->service;
    }

    /**
     * @param array|null $code
     *
     * @return $this
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * @return array|null
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @param \DateTime|null $createdFrom
     *
     * @return $this
     */
    public function setCreatedFrom(\DateTime $createdFrom = null)
    {
        $this->createdFrom = $createdFrom;

        return $this;
    }

    /**
     * @return \DateTime|null
     */
    public function getCreatedFrom()
    {
        return $this->createdFrom;
    }

    /**
     * @param \DateTime|null $createdTo
     *
     * @return $this
     */
    public function setCreatedTo(\DateTime $createdTo = null)
    {
        $this->createdTo = $createdTo;

        return $this;
    }

    /**
     * @return \DateTime|null
     */
    public function getCreatedTo()
    {
        return $this->createdTo;
    }

    /**
     * @param bool $deleted
     *
     * @return $this
     */
    public function setDeleted($deleted)
    {
        $this->deleted = $deleted;

        return $this;
    }

    /**
     * @return bool
     */
    public function getDeleted()
    {
        return $this->deleted;
    }
}
