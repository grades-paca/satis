<?php

namespace Oru\Bundle\TaskBundle\Command;

use Oru\Bundle\ScheduleBundle\Command\AbstractContainerAwareScheduleDynamicCommand;
use Oru\Bundle\TaskBundle\Entity\Task;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class QueueCommand.
 *
 * @author Michaël VEROUX
 */
class QueueCheckCommand extends AbstractContainerAwareScheduleDynamicCommand
{
    const NAME = 'oru:task:check';

    /**
     * Doit renvoyer le nombre de secondes d'exécution acceptable avant que le gestionnaire de taches ne tue le processus
     * 0 si pas de limite.
     *
     * @param int $pid
     *
     * @return int
     **/
    public function getMaxRunningTime($pid)
    {
        return 300;
    }

    /**
     * Doit renvoyer un booleen signalant si la tache accepte d'être exécutée en parallèle avec d'autres taches issus de la même commande.
     *
     * @return bool
     */
    public function isConcurentAllowed()
    {
        return false;
    }

    /**
     * Cette methode fait le lien entre un nom de parametre ou d'option, et le type de champ au sens "formulaire symfony"
     * Si elle est implémentée vide, tout sera considéré comme du texte.
     *
     * Fonctionnement:
     * En fonction du nom de l'argument ou de l'option spécifié par $name
     * il faut affecter les variables passées en référence $type et $options
     * Ces variables seront utilisées lors de la génération du formulaire symfony d'interface graphique pour gêrer l'exécution du script
     * et seront passées à la commande FormBuilder::add (voir options de cette commande pour plus de détail sur le contenu éventuel de $options)
     *
     * @param mixed $name
     *
     * @return mixed
     */
    public function getTypeFieldFromArgumentName($name, &$type = 'text', &$options = array())
    {
        // TODO: Implement getTypeFieldFromArgumentName() method.
    }

    /**
     * Configures the current command.
     */
    protected function configure()
    {
        $this->setName(self::NAME)
            ->setDescription('Control daemon queue is running and launch it if not')
        ;
    }

    /**
     * Executes the current command.
     *
     * This method is not abstract because you can use this class
     * as a concrete class. In this case, instead of defining the
     * execute() method, you set the code to execute by passing
     * a Closure to the setCode() method.
     *
     * @param InputInterface  $input  An InputInterface instance
     * @param OutputInterface $output An OutputInterface instance
     *
     * @throws \LogicException When this abstract method is not implemented
     *
     * @return null|int null or 0 if everything went fine, or an error code
     *
     * @see setCode()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $stdOut = array();
        $consoleExe = sprintf('%s/console', $this->getContainer()->get('kernel')->getRootDir());

        $command = sprintf('ps -auxwww | grep "%s"', QueueCommand::NAME);
        exec($command, $stdOut);

        $processes = array_filter($stdOut, function ($out) use ($consoleExe) {
            if (false !== strpos($out, sprintf('%s %s', $consoleExe, QueueCommand::NAME))) {
                if (false !== strpos($out, 'grep')) {
                    return false;
                }

                return true;
            }

            return false;
        });

        if (!count($processes)) {
            $command = sprintf('%s %s -e prod > /dev/null 2>&1 &', $consoleExe, QueueCommand::NAME);
            exec($command);
        }

        $em = $this->getContainer()->get('doctrine.orm.default_entity_manager');
        $pendingTasks = $em->getRepository('OruTaskBundle:Task')->pendingTasks();
        foreach ($pendingTasks as $task) {
            $started = $task->getStarted();
            if (!$started instanceof \DateTime) {
                continue;
            }

            $timestampMax = $started->format('U') + $task->getTimeMax();
            $timestamp = time();

            if ($timestamp > $timestampMax) {
                $task->setCode(Task::CODE_ERROR_TIME);
                $em->flush();
                $em->remove($task);
                shell_exec(sprintf('kill -9 %d', $task->getPid()));
            }
        }
        $em->flush();
    }
}
