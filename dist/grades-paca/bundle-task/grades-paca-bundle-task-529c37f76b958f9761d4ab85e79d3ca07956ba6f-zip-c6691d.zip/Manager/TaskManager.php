<?php

namespace Oru\Bundle\TaskBundle\Manager;

use Doctrine\ORM\EntityManager;
use Monolog\Logger;
use Oru\Bundle\TaskBundle\Entity\Task;
use Oru\Bundle\TaskBundle\Task\TaskTimeMaxInterface;
use ReflectionClass;
use RuntimeException;
use Exception;

/**
 * Class TaskManager.
 *
 * @author Michaël VEROUX
 */
class TaskManager
{
    /**
     * @var object
     */
    protected $service;

    /**
     * @var Task
     */
    protected $task;

    /**
     * @var EntityManager
     */
    protected $taskEntityManager;

    /**
     * @var int
     */
    protected $startedMs;

    /**
     * @var Logger
     */
    protected $logger;

    /**
     * TaskManager constructor.
     *
     * @param EntityManager $taskEntityManager
     */
    public function __construct(EntityManager $taskEntityManager)
    {
        $this->taskEntityManager = $taskEntityManager;
    }

    /**
     * @param Logger $logger
     *
     * @return $this
     */
    public function setLogger(Logger $logger)
    {
        $this->logger = $logger;

        return $this;
    }

    /**
     * @param string $msg
     *
     * @author Michaël VEROUX
     */
    public function setLogInfo($msg)
    {
        if ($this->logger) {
            $this->logger->info($msg);
        }
    }

    /**
     * @param object $service
     *
     * @return $this
     */
    public function setService($service)
    {
        $this->service = $service;

        return $this;
    }

    /**
     * @param Task $task
     *
     * @return $this
     */
    public function setTask($task)
    {
        $this->task = $task;

        return $this;
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function run()
    {
        register_shutdown_function(array($this, 'shutDown'));

        $this->startedMs = round(microtime(true) * 1000);

        try {
            if ($this->task) {
                $this->setLogInfo('Run task '.$this->task->getId());
            }
            $this->execute();
        } catch (Exception $e) {
            $this->endTask($e);

            return false;
        }
        $this->endTask();

        return true;
    }

    /**
     * @return void
     * @author Michaël VEROUX
     */
    public function shutDown()
    {
        $error = error_get_last();
        if ($this->task) {
            if (null !== $error) {
                $errorTypes = array(E_ERROR);
                if (in_array($error['type'], $errorTypes)) {
                    $msg = $this->task->getDetail().PHP_EOL.$error['message'];
                    $this->task->setDetail($msg);
                    $this->task->setCode(Task::CODE_ERROR);
                }
            }
            $this->task->setDeleted(new \DateTime());

            $this->taskEntityManager->flush();
        }
    }

    /**
     * @author Michaël VEROUX
     */
    protected function setMaxTime()
    {
        if ($this->service instanceof TaskTimeMaxInterface) {
            $timeMax = $this->service->maxAllowedExecutionTime();
            if ($timeMax > $this->task->getTimeMax()) {
                $this->task->setTimeMax($timeMax);
                $this->taskEntityManager->flush();
            }
        }
    }

    /**
     * @param Exception|null $e
     *
     * @author Michaël VEROUX
     */
    protected function endTask(Exception $e = null)
    {
        $state = Task::CODE_SUCESS;
        $stoppedMs = round(microtime(true) * 1000);

        if ($e instanceof Exception) {
            $state = Task::CODE_ERROR;
            $this->task->setDetail($e->getMessage());
        }

        $this->task->setCode($state);
        $this->task->setTimeJobMs($stoppedMs - $this->startedMs);
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    protected function execute()
    {
        $serviceReflection = $this->getServiceReflection();

        foreach ($this->task->getServiceCalls() as $method => $args) {
            if (!$serviceReflection->hasMethod($method)) {
                throw new RuntimeException(sprintf('Spooler, this service "%s" hasn\'t any method named "%s".', $this->task->getService(), $method));
            }
            if (!is_array($args)) {
                throw new RuntimeException('Spooler, $args must be an array!');
            }

            try {
                $serviceReflection->getMethod($method)->invokeArgs($this->service, $args);
            } catch (Exception $e) {
                $this->endTask($e);
            }

            $this->setMaxTime();
        }

        return true;
    }

    /**
     * @return ReflectionClass
     *
     * @author Michaël VEROUX
     */
    protected function getServiceReflection()
    {
        $reflection = new ReflectionClass($this->service);

        return $reflection;
    }
}
