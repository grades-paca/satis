<?php

namespace Oru\Bundle\TaskBundle\Manager;

use Doctrine\ORM\EntityManager;

/**
 * Class TaskEntityManager.
 *
 * This manager is to update task without side effect with entity modified by runing the task
 *
 * @author Michaël VEROUX
 */
class TaskEntityManager
{
    /**
     * @var EntityManager
     */
    protected $em;

    /**
     * @var EntityManager|null
     */
    protected $singleEm;

    /**
     * SingleEntityManager constructor.
     *
     * @param EntityManager $em
     */
    public function __construct(EntityManager $em)
    {
        $this->em = $em;
    }

    /**
     * @return EntityManager
     *
     * @author Michaël VEROUX
     */
    public function getManager()
    {
        if (null === $this->singleEm) {
            $enabledFilters = $this->em->getFilters()->getEnabledFilters();

            $this->singleEm = EntityManager::create(
                $this->em->getConnection(),
                $this->em->getConfiguration()
            );

            if (is_array($enabledFilters)) {
                foreach ($enabledFilters as $name => $filter) {
                    $this->singleEm->getFilters()->enable($name);
                }
            }
        }

        return $this->singleEm;
    }
}
