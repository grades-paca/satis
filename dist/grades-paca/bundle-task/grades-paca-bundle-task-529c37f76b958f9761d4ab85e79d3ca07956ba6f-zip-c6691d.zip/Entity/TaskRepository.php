<?php

namespace Oru\Bundle\TaskBundle\Entity;

use Doctrine\ORM\EntityRepository;
use Oru\Bundle\TaskBundle\Entity\Filter\Task as TaskFilter;

/**
 * Class TaskRepository.
 *
 * @author Michaël VEROUX
 */
class TaskRepository extends EntityRepository
{
    /**
     * @param TaskFilter $taskFilter
     *
     * @return \Doctrine\ORM\QueryBuilder
     * @author Michaël VEROUX
     */
    public function findList(TaskFilter $taskFilter)
    {
        $builder = $this->createQueryBuilder('s')->orderBy('s.created', 'DESC');

        if ($taskFilter->getService()) {
            $builder->andWhere('s.service LIKE :service');
            $builder->setParameter('service', sprintf('%%%s%%', $taskFilter->getService()));
        }

        if ($taskFilter->getCode()) {
            $builder->andWhere('s.code IN (:codes)');
            $builder->setParameter('codes', $taskFilter->getCode());
        }

        if ($taskFilter->getCreatedFrom()) {
            $builder->andWhere('s.created >= :dateFrom');
            $builder->setParameter('dateFrom', $taskFilter->getCreatedFrom()->format('Y-m-d H:i:s'));
        }

        if ($taskFilter->getCreatedTo()) {
            $builder->andWhere('s.created <= :dateTo');
            $builder->setParameter('dateTo', $taskFilter->getCreatedTo()->format('Y-m-d H:i:s'));
        }

        if ($taskFilter->getDeleted()) {
            try {
                $this->getEntityManager()->getFilters()->disable('softdeleteable');
            } catch (\InvalidArgumentException $e) {
            }

            $builder->andWhere('s.deleted IS NOT NULL');
        }

        return $builder;
    }

    /**
     * @return Task|null
     *
     * @author Michaël VEROUX
     */
    public function unstack()
    {
        $builder = $this->createQueryBuilder('t')
            ->where('t.code >= 0 AND t.code < 10')
            ->addOrderBy('t.priority', 'DESC')
            ->addOrderBy('t.created', 'ASC')
            ->addOrderBy('t.id', 'ASC')
            ->setMaxResults(1)
        ;

        $lockedServices = $this->pendingMonoTaskServices();
        if (count($lockedServices)) {
            $builder->andWhere('t.service NOT IN (:services)');
            $builder->setParameter('services', $lockedServices);
        }

        $results = $builder->getQuery()->execute();

        return count($results) ? array_shift($results) : null;
    }

    /**
     * @param string $serviceName
     * @param string $callsId
     *
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function openedExists($serviceName, $callsId)
    {
        $builder = $this->createQueryBuilder('t')
            ->select('COUNT(t.id)')
            ->where('t.code >= 0 AND t.code <= 10')
            ->andWhere('t.service = :service AND t.serviceCallsId = :callsId')
            ->setParameter('service', $serviceName)
            ->setParameter('callsId', $callsId)
        ;

        $nb = $builder->getQuery()->getSingleScalarResult();

        return (bool)$nb;
    }

    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function pendingMonoTaskServices()
    {
        $builder = $this->pendingTasksQuery();
        $builder->andWhere('t.mono = 1');
        $builder->select('t.service')->distinct();

        $result = $builder->getQuery()->getArrayResult();
        $services = array_map('current', $result);

        return $services;
    }

    /**
     * @return Task[]
     *
     * @author Michaël VEROUX
     */
    public function pendingTasks()
    {
        $builder = $this->pendingTasksQuery();

        $tasks = $builder->getQuery()->execute();

        return $tasks;
    }

    /**
     * @return int
     *
     * @author Michaël VEROUX
     */
    public function pendingTasksCount()
    {
        $builder = $this->pendingTasksQuery();
        $builder->select('COUNT(t.id)');

        $nb = $builder->getQuery()->getSingleScalarResult();

        return (int)$nb;
    }

    /**
     * @return \Doctrine\ORM\QueryBuilder
     *
     * @author Michaël VEROUX
     */
    protected function pendingTasksQuery()
    {
        $builder = $this->createQueryBuilder('t')
            ->where('t.code = 10')
        ;

        return $builder;
    }
}
