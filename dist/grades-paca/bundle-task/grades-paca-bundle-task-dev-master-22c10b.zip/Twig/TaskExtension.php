<?php

namespace Oru\Bundle\TaskBundle\Twig;

use Twig\Extension\AbstractExtension;
use Twig\TwigFilter;

/**
 * Class TaskExtension.
 *
 * @author Michaël VEROUX
 */
class TaskExtension extends AbstractExtension
{
    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function getFilters()
    {
        return array(
            new TwigFilter('argDisplay', array($this, 'argDisplay')),
        );
    }

    /**
     * @param mixed $value
     *
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function argDisplay($value)
    {
        return var_export($value, true);
    }
}
