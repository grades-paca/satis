<?php

namespace Oru\Bundle\TaskBundle\Entity;

use DateTime;
use RuntimeException;

/**
 * Class Task.
 *
 * @author Michaël VEROUX
 */
class Task
{
    const PRIORITY_VERY_LOW = -255;
    const PRIORITY_LOW = -128;
    const PRIORITY_NORMAL = 0;
    const PRIORITY_HIGH = 128;
    const PRIORITY_VERY_HIGH = 255;

    const CODE_NEW = 0;
    const CODE_SERVICE_UNAVAILABLE = 1;
    const CODE_PROCESSING = 10;
    const CODE_SUCESS = 100;
    const CODE_ERROR_TIME = -98;
    const CODE_ERROR_MEMORY = -99;
    const CODE_ERROR = -100;

    /**
     * @var int
     */
    private $id;

    /**
     * @var string
     */
    private $service;

    /**
     * @var array
     */
    private $serviceCalls;

    /**
     * @var string
     */
    private $serviceCallsId;

    /**
     * @var int
     */
    private $priority;

    /**
     * @var int
     */
    private $code;

    /**
     * @var string|null
     */
    private $detail;

    /**
     * @var int
     */
    private $pid;

    /**
     * @var int
     */
    private $timeJobMs;

    /**
     * @var int
     */
    private $timeMax;

    /**
     * @var bool
     */
    private $mono = false;

    /**
     * @var DateTime|null
     */
    private $created;

    /**
     * @var DateTime|null
     */
    private $started;

    /**
     * @var DateTime|null
     */
    private $updated;

    /**
     * @var DateTime|null
     */
    private $deleted;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getService()
    {
        return $this->service;
    }

    /**
     * @param string $service
     *
     * @return $this
     */
    public function setService($service)
    {
        $this->service = $service;

        return $this;
    }

    /**
     * @return array
     */
    public function getServiceCalls()
    {
        return $this->serviceCalls;
    }

    /**
     * @param array $serviceCalls
     *
     * @return $this
     */
    public function setServiceCalls($serviceCalls)
    {
        if (!is_array($serviceCalls)) {
            throw new RuntimeException('Array needed!');
        }

        $this->serviceCalls = $serviceCalls;

        return $this;
    }

    /**
     * @return string
     */
    public function getServiceCallsId()
    {
        return $this->serviceCallsId;
    }

    /**
     * @param string $serviceCallsId
     *
     * @return $this
     */
    public function setServiceCallsId($serviceCallsId)
    {
        $this->serviceCallsId = $serviceCallsId;

        return $this;
    }

    /**
     * @return int
     */
    public function getPriority()
    {
        return $this->priority;
    }

    /**
     * @param int $priority
     *
     * @return $this
     */
    public function setPriority($priority)
    {
        $this->priority = $priority;

        return $this;
    }

    /**
     * @return int
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @param int $code
     *
     * @return $this
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * @return null|string
     */
    public function getDetail()
    {
        return $this->detail;
    }

    /**
     * @param null|string $detail
     *
     * @return $this
     */
    public function setDetail($detail)
    {
        $this->detail = $detail;

        return $this;
    }

    /**
     * @return int
     */
    public function getPid()
    {
        return $this->pid;
    }

    /**
     * @param int $pid
     *
     * @return $this
     */
    public function setPid($pid)
    {
        $this->pid = $pid;

        return $this;
    }

    /**
     * @return int
     */
    public function getTimeJobMs()
    {
        return $this->timeJobMs;
    }

    /**
     * @param int $timeJobMs
     *
     * @return $this
     */
    public function setTimeJobMs($timeJobMs)
    {
        $this->timeJobMs = $timeJobMs;

        return $this;
    }

    /**
     * @return int
     */
    public function getTimeMax()
    {
        return $this->timeMax;
    }

    /**
     * @param int $timeMax
     *
     * @return $this
     */
    public function setTimeMax($timeMax)
    {
        $this->timeMax = $timeMax;

        return $this;
    }

    /**
     * @return bool
     */
    public function isMono()
    {
        return $this->mono;
    }

    /**
     * @param bool $mono
     *
     * @return $this
     */
    public function setMono($mono)
    {
        $this->mono = $mono;

        return $this;
    }

    /**
     * @return DateTime|null
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param DateTime|null $created
     *
     * @return $this
     */
    public function setCreated(DateTime $created = null)
    {
        $this->created = $created;

        return $this;
    }

    /**
     * @return DateTime|null
     */
    public function getStarted()
    {
        return $this->started;
    }

    /**
     * @param DateTime|null $started
     *
     * @return $this
     */
    public function setStarted(DateTime $started = null)
    {
        $this->started = $started;

        return $this;
    }

    /**
     * @return DateTime|null
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * @param DateTime|null $updated
     *
     * @return $this
     */
    public function setUpdated(DateTime $updated = null)
    {
        $this->updated = $updated;

        return $this;
    }

    /**
     * @return DateTime|null
     */
    public function getDeleted()
    {
        return $this->deleted;
    }

    /**
     * @param DateTime|null $deleted
     *
     * @return $this
     */
    public function setDeleted(DateTime $deleted = null)
    {
        $this->deleted = $deleted;

        return $this;
    }

    /**
     * @author Michaël VEROUX
     */
    public function reset()
    {
        $this->setCode(static::CODE_NEW);
        $this->setPid(null);
        $this->setTimeJobMs(null);
        $this->setDetail(null);
    }
}
