<?php

namespace Oru\Bundle\TaskBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class QueueCommand.
 *
 * @author Michaël VEROUX
 */
class QueueCommand extends ContainerAwareCommand
{
    const NAME = 'oru:task:queue';

    /**
     * Configures the current command.
     */
    protected function configure()
    {
        $this->setName(self::NAME)
            ->setDescription('Daemon queue to unstack tasks.')
        ;
    }

    /**
     * Executes the current command.
     *
     * This method is not abstract because you can use this class
     * as a concrete class. In this case, instead of defining the
     * execute() method, you set the code to execute by passing
     * a Closure to the setCode() method.
     *
     * @param InputInterface  $input An InputInterface instance
     * @param OutputInterface $output An OutputInterface instance
     *
     * @return null|int null or 0 if everything went fine, or an error code
     *
     * @throws \LogicException When this abstract method is not implemented
     *
     * @see setCode()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        ini_set('max_execution_time', 0);

        $setting = $this->getContainer()->get('oru_setting');
        $threadMax = $setting->setting('thread_max', 'OruTaskBundle');
        $busyPause = $setting->setting('search_busy_pause', 'OruTaskBundle');
        $freePause = $setting->setting('search_free_pause', 'OruTaskBundle');
        $loadAverageMax = $setting->setting('load_average_max', 'OruTaskBundle');

        do {
            $pendingTasks = $this->getContainer()->get('oru_task.queue_manager')->pendingTasksCount();

            if ($threadMax <= $pendingTasks) {
                sleep($busyPause);

                continue;
            }

            $loadAvg = sys_getloadavg();
            if ($loadAverageMax < $loadAvg[0]) {
                sleep($busyPause);

                continue;
            }

            $hasTask = $this->getContainer()->get('oru_task.queue_manager')->unstack();

            if (!$hasTask) {
                sleep($freePause);
            }
        } while (true);
    }
}
