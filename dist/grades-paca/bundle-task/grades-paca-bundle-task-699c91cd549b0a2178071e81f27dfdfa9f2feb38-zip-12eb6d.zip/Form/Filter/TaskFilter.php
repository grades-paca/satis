<?php

namespace Oru\Bundle\TaskBundle\Form\Filter;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class TaskFilter.
 *
 * @author Michaël VEROUX
 */
class TaskFilter extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $etatChoices = array();
        $reflection = new \ReflectionClass('Oru\Bundle\TaskBundle\Entity\Task');
        $constants = $reflection->getConstants();
        foreach ($constants as $constant => $value) {
            if (0 === strpos($constant, 'CODE_')) {
                $etatChoices[$value] = 'oru_task_listing.code_value.'.$value;
            }
        }

        $builder
            ->add('service', 'search', array(
                'required'      => false,
            ))
            ->add('code', 'choice', array(
                'required'      => false,
                'placeholder'   => 'Indifférent',
                'choices'       => $etatChoices,
                'multiple'      => true,
            ))
            ->add('created_from', 'datetime', array(
                'required'      => false,
                'date_widget'   => 'single_text',
                'time_widget'   => 'single_text',
            ))
            ->add('created_to', 'datetime', array(
                'required'      => false,
                'date_widget'   => 'single_text',
                'time_widget'   => 'single_text',
            ))
            ->add('deleted', 'oru_oui_non', array(
                'expanded'      => false,
            ))
            ->add('filter', 'submit', array(
                'label'                 => 'listing.action.filter',
                'translation_domain'    => 'messages',
                'attr'          => array(
                    'class'         => 'btn btn-primary',
                ),
            ))
            ->add('reset', 'submit', array(
                'label'                 => 'listing.action.reset',
                'translation_domain'    => 'messages',
                'attr'          => array(
                    'class'         => 'btn btn-default',
                ),
            ))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
           'data_class' => 'Oru\Bundle\TaskBundle\Entity\Filter\Task',
           'csrf_protection' => false,
           'validation_groups' => false,
           'translation_domain'    => 'OruTaskBundle',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_task_filter';
    }
}
