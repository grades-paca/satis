<?php

namespace Oru\Bundle\TaskBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class TaskRunCommand.
 *
 * @author Michaël VEROUX
 */
class TaskRunCommand extends ContainerAwareCommand
{
    const NAME = 'oru:task:run';

    /**
     * Configures the current command.
     */
    protected function configure()
    {
        $this
            ->setName(self::NAME)
            ->addArgument('id', InputArgument::REQUIRED, 'ID de la task à exécuter')
            ->setDescription('Exécute la tâche passée en argument (ID)')
        ;
    }

    /**
     * Executes the current command.
     *
     * This method is not abstract because you can use this class
     * as a concrete class. In this case, instead of defining the
     * execute() method, you set the code to execute by passing
     * a Closure to the setCode() method.
     *
     * @param InputInterface  $input An InputInterface instance
     * @param OutputInterface $output An OutputInterface instance
     *
     * @return null|int null or 0 if everything went fine, or an error code
     *
     * @throws \LogicException When this abstract method is not implemented
     *
     * @see setCode()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $taskId = $input->getArgument('id');

        $taskManager = $this->getContainer()->get('oru_task.manager_factory')->create($taskId);
        $taskManager->run();
    }
}
