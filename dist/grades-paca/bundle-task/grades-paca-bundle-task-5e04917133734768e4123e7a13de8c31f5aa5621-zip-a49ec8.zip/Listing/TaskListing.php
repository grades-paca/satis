<?php

namespace Oru\Bundle\TaskBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class TaskListing.
 *
 * @author Michaël VEROUX
 */
class TaskListing extends AbstractListingType
{
    /**
     * @param ListingBuilderInterface $builder
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('created', null, array(
                'sort' => 's.created',
                'label'     => 'oru_task_listing.created',
                'translation_domain' => 'OruTaskBundle',
            ))
            ->add('started', null, array(
                'sort' => 's.started',
                'label'     => 'oru_task_listing.started',
                'translation_domain' => 'OruTaskBundle',
            ))
            ->add('service', null, array(
                'sort' => 's.service',
                'label'     => 'oru_task_listing.service',
                'translation_domain' => 'OruTaskBundle',
            ))
            ->add('code', null, array(
                'sort' => 's.code',
                'template'  => '@OruTask/Listing/code.html.twig',
                'label'     => 'oru_task_listing.code',
                'translation_domain' => 'OruTaskBundle',
            ))
            ->add('timeJobMs', null, array(
                'sort' => 's.timeJobMs',
                'label'     => 'oru_task_listing.timeJobMs',
                'translation_domain' => 'OruTaskBundle',
            ))
            ->add('show', 'object_action', array(
                'route'     => 'oru_task_show',
                'label'     => 'listing.action.show',
                'translation_domain' => 'messages',
            ))
        ;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'oru_task_listing';
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\TaskBundle\Entity\Task',
        ));
    }
}
