<?php

namespace Oru\Bundle\TaskBundle\Factory;

use Oru\Bundle\SettingBundle\Setting\Setting;
use Oru\Bundle\TaskBundle\Entity\Task;
use RuntimeException;

/**
 * Class TaskFactory.
 *
 * @author Michaël VEROUX
 */
class TaskFactory
{
    /**
     * @var Setting
     */
    protected $setting;

    /**
     * TaskFactory constructor.
     *
     * @param Setting $setting
     */
    public function __construct(Setting $setting)
    {
        $this->setting = $setting;
    }

    /**
     * @param string $serviceName
     * @param array  $methodCalls
     * @param int    $priority
     * @param bool   $mono
     *
     * @return Task
     *
     * @author Michaël VEROUX
     */
    public function create($serviceName, $methodCalls, $priority = Task::PRIORITY_NORMAL, $mono = false)
    {
        if (!is_array($methodCalls)) {
            throw new RuntimeException('Array expected!');
        }

        $timeMax = $this->setting->setting('execution_time_max', 'OruTaskBundle');

        $task = new Task();
        $task->setTimeMax($timeMax);
        $task->setService($serviceName);
        $task->setServiceCalls($methodCalls);
        $task->setServiceCallsId(
            $this->generateMethodCallsId($task->getServiceCalls())
        );
        $task->setPriority($priority);
        $task->setCode(Task::CODE_NEW);
        $task->setMono($mono);

        return $task;
    }

    /**
     * @param array $methodCalls
     *
     * @return string
     *
     * @author Michaël VEROUX
     */
    private function generateMethodCallsId($methodCalls)
    {
        $serialId = md5(serialize($methodCalls));

        return $serialId;
    }
}
