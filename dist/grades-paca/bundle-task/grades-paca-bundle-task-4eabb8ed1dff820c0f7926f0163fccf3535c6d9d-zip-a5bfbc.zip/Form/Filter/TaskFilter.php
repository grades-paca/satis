<?php

namespace Oru\Bundle\TaskBundle\Form\Filter;

use Oru\Bundle\FormBundle\Form\Type\OuiNonType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class TaskFilter.
 *
 * @author Michaël VEROUX
 */
class TaskFilter extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     *
     * @author Michaël VEROUX
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $etatChoices = array();
        $reflection = new \ReflectionClass('Oru\Bundle\TaskBundle\Entity\Task');
        $constants = $reflection->getConstants();
        foreach ($constants as $constant => $value) {
            if (0 === strpos($constant, 'CODE_')) {
                $etatChoices[$value] = 'oru_task_listing.code_value.'.$value;
            }
        }

        $builder
            ->add('service', SearchType::class, array(
                'required' => false,
            ))
            ->add('code', ChoiceType::class, array(
                'required' => false,
                'placeholder' => 'Indifférent',
                'choices' => $etatChoices,
                'multiple' => true,
            ))
            ->add('created_from', DateTimeType::class, array(
                'required' => false,
                'date_widget' => 'single_text',
                'time_widget' => 'single_text',
            ))
            ->add('created_to', DateTimeType::class, array(
                'required' => false,
                'date_widget' => 'single_text',
                'time_widget' => 'single_text',
            ))
            ->add('deleted', OuiNonType::class, array(
                'expanded' => false,
            ))
            ->add('filter', SubmitType::class, array(
                'label' => 'listing.action.filter',
                'translation_domain' => 'messages',
                'attr' => array(
                    'class' => 'btn btn-primary',
                ),
            ))
            ->add('reset', SubmitType::class, array(
                'label' => 'listing.action.reset',
                'translation_domain' => 'messages',
                'attr' => array(
                    'class' => 'btn btn-default',
                ),
            ))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
           'data_class' => 'Oru\Bundle\TaskBundle\Entity\Filter\Task',
           'csrf_protection' => false,
           'validation_groups' => false,
           'translation_domain' => 'OruTaskBundle',
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_task_filter';
    }
}
