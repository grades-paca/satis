<?php

namespace Oru\Bundle\TaskBundle\Event;

/**
 * Class Events.
 *
 * @author Michaël VEROUX
 */
class Events
{
    const QUEUE_PUSH = 'oru_task_queue.push';
}
