<?php

namespace Oru\Bundle\TaskBundle\Task;

/**
 * Interface TaskTimeMaxInterface.
 *
 * @author Michaël VEROUX
 */
interface TaskTimeMaxInterface
{
    /**
     * @return int time in seconds
     * @author Michaël VEROUX
     */
    public function maxAllowedExecutionTime();
}
