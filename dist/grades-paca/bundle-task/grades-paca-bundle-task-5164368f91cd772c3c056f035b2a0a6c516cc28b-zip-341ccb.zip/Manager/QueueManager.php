<?php

namespace Oru\Bundle\TaskBundle\Manager;

use Doctrine\ORM\EntityManager;
use Monolog\Logger;
use Oru\Bundle\TaskBundle\Command\TaskRunCommand;
use Oru\Bundle\TaskBundle\Entity\Task;
use DateTime;

/**
 * Class QueueManager.
 *
 * @author Michaël VEROUX
 */
class QueueManager
{
    /**
     * @var EntityManager
     */
    protected $em;

    /**
     * @var EntityManager|null
     */
    protected $customEm;

    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @var string
     */
    protected $rootDir;

    /**
     * @var array
     */
    protected $lockedServices = array();

    /**
     * QueueManager constructor.
     *
     * @param EntityManager $em
     * @param string        $rootDir
     */
    public function __construct(EntityManager $em, $rootDir)
    {
        $this->em = $em;
        $this->rootDir = $rootDir;
    }

    /**
     * @param Logger $logger
     *
     * @return $this
     */
    public function setLogger(Logger $logger)
    {
        $this->logger = $logger;

        return $this;
    }

    /**
     * @param string $msg
     *
     * @author Michaël VEROUX
     */
    public function setLogInfo($msg)
    {
        if ($this->logger) {
            $this->logger->info($msg);
        }
    }

    /**
     * @param Task $task
     *
     * @author Michaël VEROUX
     */
    public function push(Task $task)
    {
        $repository = $this->getManager()->getRepository('OruTaskBundle:Task');
        $exists = $repository->openedExists($task->getService(), $task->getServiceCallsId());

        if (!$exists) {
            $this->getManager()->persist($task);
        }
    }

    /**
     * @author Michaël VEROUX
     */
    public function unstack()
    {
        $hasTask = false;
        $repository = $this->getManager()->getRepository('OruTaskBundle:Task');
        $task = $repository->unstack();

        if ($task) {
            $task->setCode(Task::CODE_PROCESSING);
            $task->setStarted(new DateTime());
            $this->getManager()->flush();

            $consoleExe = sprintf('%s/console', $this->rootDir);
            $execute = sprintf('php %s %s %d -e prod > /dev/null 2>&1 & echo $! & ', $consoleExe, TaskRunCommand::NAME, $task->getId());
            $this->setLogInfo($execute);
            exec($execute ,$op);
            $pid = (int)$op[0];

            $task->setPid($pid);
            $this->getManager()->flush();

            $hasTask = true;
        }

        $this->clearManager();

        return $hasTask;
    }

    /**
     * @return int
     *
     * @author Michaël VEROUX
     */
    public function pendingTasksCount()
    {
        $repository = $this->getManager()->getRepository('OruTaskBundle:Task');
        $pendingTasks = $repository->pendingTasksCount();

        return $pendingTasks;
    }

    /**
     * @author Michaël VEROUX
     */
    public function flush()
    {
        if (!$this->customEm) {
            return;
        }

        $this->getManager()->flush();
        $this->clearManager();
    }

    /**
     * @return EntityManager|null
     *
     * @author Michaël VEROUX
     */
    protected function getManager() {
        if (null === $this->customEm) {
            $enabledFilters = $this->em->getFilters()->getEnabledFilters();

            $this->customEm = EntityManager::create(
                $this->em->getConnection(),
                $this->em->getConfiguration()
            );

            if (is_array($enabledFilters)) {
                foreach ($enabledFilters as $name => $filter) {
                    $this->customEm->getFilters()->enable($name);
                }
            }
        }

        return $this->customEm;
    }

    /**
     * @author Michaël VEROUX
     */
    protected function clearManager() {
        if (!$this->customEm) {
            return;
        }

        $this->customEm->clear();
        $this->customEm = null;
    }
}
