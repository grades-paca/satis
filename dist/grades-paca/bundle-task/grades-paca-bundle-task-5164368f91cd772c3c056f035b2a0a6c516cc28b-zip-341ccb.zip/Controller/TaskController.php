<?php

namespace Oru\Bundle\TaskBundle\Controller;

use Oru\Bundle\DesignBundle\Controller\FlashControllerTrait;
use Oru\Bundle\RorCredentialsBundle\Controller\CredentialControllerTrait;
use Oru\Bundle\TaskBundle\Entity\Task;
use Oru\Bundle\TaskBundle\Form\Filter\TaskFilter;
use Oru\Bundle\TaskBundle\Listing\TaskListing;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

/**
 * Class TaskController.
 *
 * @author Michaël VEROUX
 */
class TaskController extends Controller
{
    use FlashControllerTrait;
    use CredentialControllerTrait;

    /**
     * @var array
     */
    protected $filterDefault = array('deleted' => '0');

    /**
     * @param Request $request
     * @param null    $form
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @author Michaël VEROUX
     */
    public function indexAction(Request $request, $form = null)
    {
        $this->grantAccess('ORU_TASK_VIEW');

        $em = $this->getDoctrine()->getManager();

        if (null === $form) {
            $form = $this
                ->createForm(new TaskFilter())
                ->submit($request->getSession()
                ->get('oru_task.filter', $this->filterDefault))
            ;
        }

        $entities = $em->getRepository('OruTaskBundle:Task')->findList($form->getData());

        $listing = $this->container->get('paginator.factory')->create(
            new TaskListing(),
            $entities,
            $request->query->get('page', 1)
        );

        return $this->render(
            'OruTaskBundle:Task:index.html.twig',
            array(
                'listing' => $listing,
                'form'    => $form->createView(),
            )
        );
    }

    /**
     * @param Request $request
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
     * @throws AccessDeniedException
     * @author Michaël VEROUX
     */
    public function filterAction(Request $request)
    {
        $this->grantAccess('ORU_TASK_VIEW');

        $form = $this->createForm(new TaskFilter())->handleRequest($request);

        if ($form->get('reset')->isClicked()) {
            $request->getSession()->set('oru_task.filter', $this->filterDefault);

            return $this->redirect($this->generateUrl('oru_task'));
        }

        if ($form->isValid()) {
            $request->getSession()->set('oru_task.filter', $request->get($form->getName()));

            return $this->redirect($this->generateUrl('oru_task'));
        }

        return $this->indexAction($request, $form);
    }

    /**
     * @param int $id
     *
     * @return Response
     * @throws \Symfony\Component\HttpKernel\Exception\NotFoundHttpException
     * @throws AccessDeniedException
     * @author Michaël VEROUX
     */
    public function showAction($id)
    {
        $this->grantAccess('ORU_TASK_VIEW');

        try {
            $this->getDoctrine()->getManager()->getFilters()->disable('softdeleteable');
        } catch (\InvalidArgumentException $e) {
        }

        $entity = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->find($id);
        if (!$entity) {
            throw new NotFoundHttpException('Entity does not exists!');
        }

        return $this->render(
            'OruTaskBundle:Task:show.html.twig',
            array(
                'entity' => $entity,
            )
        );
    }

    /**
     * @param int $id
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     * @throws AccessDeniedException
     * @author Michaël VEROUX
     */
    public function renewAction($id)
    {
        $this->grantAccess('ORU_TASK_VIEW');

        try {
            $this->getDoctrine()->getManager()->getFilters()->disable('softdeleteable');
        } catch (\InvalidArgumentException $e) {
        }

        $entity = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->find($id);

        if ($entity->getDeleted()) {
            $entity->setDeleted(null);
            $message = $this
                ->get('translator.default')
                ->transChoice('oru_task.archive.success', 0, array(), 'OruTaskBundle')
            ;
            $this->addSessionMessage($message);
        }

        $entity->reset();
        $message = $this->get('translator.default')->trans('oru_task.renew_success', array(), 'OruTaskBundle');
        $this->addSessionMessage($message);

        $this->getDoctrine()->getManager()->flush();

        return $this->redirect($this->generateUrl('oru_task'));
    }

    /**
     * @param int $id
     *
     * @return Response
     * @throws \Symfony\Component\HttpKernel\Exception\NotFoundHttpException
     * @throws AccessDeniedException
     * @author Michaël VEROUX
     */
    public function deleteAction($id)
    {
        $this->grantAccess('ORU_TASK_VIEW');

        try {
            $this->getDoctrine()->getManager()->getFilters()->disable('softdeleteable');
        } catch (\InvalidArgumentException $e) {
        }

        /** @var Task $entity */
        $entity = $this->getDoctrine()->getRepository('OruTaskBundle:Task')->find($id);
        if (!$entity) {
            throw new NotFoundHttpException('Entity does not exists!');
        }

        if ($entity->getDeleted()) {
            $entity->setDeleted(null);
            $entity->setPid(null);
            $message = $this
                ->get('translator.default')
                ->transChoice('oru_task.archive.success', 0, array(), 'OruTaskBundle')
            ;
        } else {
            try {
                $this->getDoctrine()->getManager()->getFilters()->enable('softdeleteable');
            } catch (\InvalidArgumentException $e) {
            }
            $this->getDoctrine()->getManager()->remove($entity);
            $message = $this
                ->get('translator.default')
                ->transChoice('oru_task.archive.success', 1, array(), 'OruTaskBundle')
            ;
        }

        $this->getDoctrine()->getManager()->flush();

        $this->addSessionMessage($message);

        $response = new Response();
        $response->headers->set('Content-type', 'application/json; charset=utf-8');
        $content = array('redirect' => $this->get('router')->generate('oru_task'));
        $response->setContent(json_encode($content));

        return $response;
    }
}
