<?php

namespace Oru\Bundle\TaskBundle\Subscriber;

use Oru\Bundle\TaskBundle\Event\Events;
use Oru\Bundle\TaskBundle\Event\PushEvent;
use Oru\Bundle\TaskBundle\Event\PushMonoEvent;
use Oru\Bundle\TaskBundle\Factory\TaskFactory;
use Oru\Bundle\TaskBundle\Manager\QueueManager;
use Symfony\Component\Console\ConsoleEvents;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * Class EventTaskSubscriber.
 *
 * @author Michaël VEROUX
 */
class EventTaskSubscriber implements EventSubscriberInterface
{
    /**
     * @var TaskFactory
     */
    protected $taskFactory;

    /**
     * @var QueueManager
     */
    protected $queueManager;

    /**
     * EventTaskSubcriber constructor.
     *
     * @param TaskFactory  $taskFactory
     * @param QueueManager $queueManager
     */
    public function __construct(TaskFactory $taskFactory, QueueManager $queueManager)
    {
        $this->taskFactory = $taskFactory;
        $this->queueManager = $queueManager;
    }

    /**
     * Returns an array of event names this subscriber wants to listen to.
     *
     * The array keys are event names and the value can be:
     *
     *  * The method name to call (priority defaults to 0)
     *  * An array composed of the method name to call and the priority
     *  * An array of arrays composed of the method names to call and respective
     *    priorities, or 0 if unset
     *
     * For instance:
     *
     *  * array('eventName' => 'methodName')
     *  * array('eventName' => array('methodName', $priority))
     *  * array('eventName' => array(array('methodName1', $priority), array('methodName2')))
     *
     * @return array The event names to listen to
     */
    public static function getSubscribedEvents()
    {
        return array(
            Events::QUEUE_PUSH => 'push',
            KernelEvents::FINISH_REQUEST => 'flush',
            ConsoleEvents::TERMINATE => 'flush',
        );
    }

    /**
     * @param PushEvent $event
     *
     * @author Michaël VEROUX
     */
    public function push(PushEvent $event)
    {
        $serviceName = $event->service();
        $methodCalls = $event->serviceCalls();
        $priority = $event->priority();
        $mono = false;
        if ($event instanceof PushMonoEvent) {
            $mono = true;
        }

        $task = $this->taskFactory->create($serviceName, $methodCalls, $priority, $mono);

        $this->queueManager->push($task);
    }

    /**
     * @author Michaël VEROUX
     */
    public function flush()
    {
        $this->queueManager->flush();
    }
}
