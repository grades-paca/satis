<?php

namespace Oru\Bundle\TaskBundle\Event;

use Oru\Bundle\TaskBundle\Entity\Task;
use Symfony\Component\EventDispatcher\Event;

/**
 * Class PushEvent.
 *
 * @author Michaël VEROUX
 */
class PushEvent extends Event
{
    /**
     * @var int
     */
    protected $priority = Task::PRIORITY_NORMAL;

    /**
     * @var array
     */
    protected $serviceCalls = array();

    /**
     * @var string
     */
    protected $service;

    /**
     * @param string $service
     * @param array  $serviceCalls
     * @param int    $priority
     */
    public function __construct($service, $serviceCalls = array(), $priority = Task::PRIORITY_NORMAL)
    {
        $this->service = $service;
        $this->serviceCalls = $serviceCalls;
        $this->priority = $priority;
    }

    /**
     * @return int
     */
    public function priority()
    {
        return $this->priority;
    }

    /**
     * @return array
     */
    public function serviceCalls()
    {
        return $this->serviceCalls;
    }

    /**
     * @return string
     */
    public function service()
    {
        return $this->service;
    }
}
