<?php

namespace Oru\Bundle\MailBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EmailListingType extends AbstractListingType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('status', null, array('sort' => 'u.status', 'label' => 'listing.status', 'translation_domain' => 'OruMailBundle', 'template' => '@OruMail/Email/status.html.twig'))
            ->add('subject', null, array('label' => 'listing.subject', 'translation_domain' => 'OruMailBundle'))
            ->add('recipients', null, array('label' => 'listing.recipients', 'translation_domain' => 'OruMailBundle', 'template' => '@OruMail/Email/recipients.html.twig'))
            ->add('createdAt', null, array('sort' => 'u.createdAt', 'label' => 'listing.createdAt', 'translation_domain' => 'OruMailBundle'))
            ->add('createdBy', null, array('sort' => 'u.createdBy', 'label' => 'listing.createdBy', 'translation_domain' => 'OruMailBundle', 'template' => '@OruMail/Email/createdBy.html.twig'))
            ->add('show', 'object_action', array('route' => 'oru_email_show', 'label' => 'listing.action.show'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\MailBundle\Entity\Email',
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_mailbundle_emaillisting';
    }
}
