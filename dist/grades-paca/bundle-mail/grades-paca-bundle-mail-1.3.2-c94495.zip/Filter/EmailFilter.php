<?php

namespace Oru\Bundle\MailBundle\Filter;

use DateTime;

/**
 * Class EmailFilter.
 *
 * @author Michaël VEROUX
 */
class EmailFilter
{
    /**
     * @var DateTime|null
     */
    protected $createdFrom;

    /**
     * @var DateTime|null
     */
    protected $createdTo;

    /**
     * @var string|null
     */
    protected $searchInMessage;

    /**
     * @return DateTime|null
     */
    public function getCreatedFrom()
    {
        return $this->createdFrom;
    }

    /**
     * @param DateTime|null $createdFrom
     *
     * @return $this
     */
    public function setCreatedFrom($createdFrom)
    {
        $this->createdFrom = $createdFrom;

        return $this;
    }

    /**
     * @return DateTime|null
     */
    public function getCreatedTo()
    {
        return $this->createdTo;
    }

    /**
     * @param DateTime|null $createdTo
     *
     * @return $this
     */
    public function setCreatedTo($createdTo)
    {
        $this->createdTo = $createdTo;

        return $this;
    }

    /**
     * @return null|string
     */
    public function getSearchInMessage()
    {
        return $this->searchInMessage;
    }

    /**
     * @param null|string $searchInMessage
     *
     * @return $this
     */
    public function setSearchInMessage($searchInMessage)
    {
        $this->searchInMessage = $searchInMessage;

        return $this;
    }
}
