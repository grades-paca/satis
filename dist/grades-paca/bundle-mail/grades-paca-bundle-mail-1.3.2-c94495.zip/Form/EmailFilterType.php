<?php

namespace Oru\Bundle\MailBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EmailFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('createdFrom', DateType::class, array('required' => false, 'label' => 'Email.createdFrom', 'translation_domain' => 'OruMailBundle', 'widget' => 'single_text'))
            ->add('createdTo', DateType::class, array('required' => false, 'label' => 'Email.createdTo', 'translation_domain' => 'OruMailBundle', 'widget' => 'single_text'))
            ->add('searchInMessage', TextType::class, array('required' => false, 'label' => 'Email.searchInMessage', 'translation_domain' => 'OruMailBundle'))
            ->add('filter', SubmitType::class, array('label' => 'listing.action.filter', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-primary')))
            ->add('reset', SubmitType::class, array('label' => 'listing.action.reset', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-default')))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\MailBundle\Filter\EmailFilter',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_mailbundle_emailfilter';
    }
}
