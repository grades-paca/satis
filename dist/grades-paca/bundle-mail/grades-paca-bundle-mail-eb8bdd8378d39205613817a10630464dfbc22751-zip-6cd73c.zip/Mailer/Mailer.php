<?php

namespace Oru\Bundle\MailBundle\Mailer;

use Oru\Bundle\MailBundle\Entity\Email;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Symfony\Component\Routing\RouterInterface;
use Symfony\Component\Templating\EngineInterface;
use WhiteOctober\SwiftMailerDBBundle\EmailInterface;

/**
 * Class Mailer
 *
 * @package Oru\Bundle\MailBundle\Mailer
 * @author Michaël VEROUX
 */
class Mailer
{
    /**
     * @var \Swift_Mailer
     */
    protected $mailer;

    /**
     * @var RouterInterface
     */
    protected $router;

    /**
     * @var EngineInterface
     */
    protected $templating;

    /**
     * @var Setting
     */
    protected $settings;

    /**
     * @var \Twig_Environment
     */
    protected $twig;

    /**
     * @var string
     */
    protected $environment;

    /**
     * Mailer constructor.
     *
     * @param \Swift_Mailer     $mailer
     * @param RouterInterface   $router
     * @param EngineInterface   $templating
     * @param Setting           $settings
     * @param \Twig_Environment $twig
     * @param string            $environment
     */
    public function __construct(\Swift_Mailer $mailer, RouterInterface $router, EngineInterface $templating, Setting $settings, \Twig_Environment $twig, $environment)
    {
        $this->mailer = $mailer;
        $this->router = $router;
        $this->templating = $templating;
        $this->settings = $settings;
        $this->twig = $twig;
        $this->environment = $environment;
    }

    /**
     * Créer et envoi un Message
     *
     * @param string            $uriTemplate
     * @param array             $parameters
     * @param string|array|null $toEmail
     * @param string|null       $fromEmail
     * @param string|array|null $ccEmail
     * @param string|array|null $bccEmail
     * @return int
     */
    public function sendEmailMessage($uriTemplate, $parameters = array(), $toEmail = null, $fromEmail = null, $ccEmail = null, $bccEmail = null)
    {
        $message = $this->createEmailMessage($uriTemplate, $parameters, $toEmail, $fromEmail, $ccEmail, $bccEmail);

        return $this->mailer->send($message);
    }

    /**
     * @return EngineInterface
     */
    public function getTemplating()
    {
        return $this->templating;
    }

    /**
     * Créer un Message
     *
     * @param string            $uriTemplate
     * @param array             $parameters
     * @param string|array|null $toEmail
     * @param string|null       $fromEmail
     * @param string|array|null $ccEmail
     * @param string|array|null $bccEmail
     * @return Message
     */
    public function createEmailMessage($uriTemplate, $parameters = array(), $toEmail = null, $fromEmail = null, $ccEmail = null, $bccEmail = null)
    {
        $template = $this->twig->loadTemplate($uriTemplate); // Define your own schema

        $message = new Message();
        $subjectPrefix = $this->settings->setting('subject_prefix', 'OruMailBundle');
        if ($template->hasBlock('subject', $parameters)) {
            $subject = $template->renderBlock('subject', $parameters);
            $message->setSubject(($subjectPrefix) ? "$subjectPrefix $subject" : $subject);
        } else {
            $message->setSubject($subjectPrefix);
        }

        if ($template->hasBlock('body_text', $parameters)) {
            $bodyText = $template->renderBlock('body_text', $parameters);
            if($bodyText && strlen($bodyText) > 1) {
                $message->setBody($bodyText, 'text/plain');
            }
        }

        if ($template->hasBlock('body_html', $parameters)) {
            $bodyHtml = $template->renderBlock('body_html', $parameters);
            if ($bodyHtml && strlen($bodyHtml) > 1) {
                $message->addPart($bodyHtml, 'text/html');
            }
        }

        $message->setSender($this->settings->setting('mail_sender', 'OruMailBundle'));
        $message->setFrom($this->settings->setting('mail_from', 'OruMailBundle'));
        $message->setTo($this->settings->setting('mail_rcpt', 'OruMailBundle'));

        if ($fromEmail) {
            $message->setFrom($fromEmail);
        }

        if ($toEmail) {
            $message->setTo($toEmail);
        }

        if ($ccEmail) {
            $message->setCc($ccEmail);
        }

        if ($bccEmail) {
            $message->setBcc($bccEmail);
        }

        return $message;
    }

    /**
     * Créer une entité Email depuis un Swift_Mime_Message
     *
     * @param \Swift_Mime_Message $message
     * @return Email
     */
    public function createMessageEntity(\Swift_Mime_Message $message)
    {
        $mailObject = new Email();
        $mailObject->setMessage(serialize($message));
        $mailObject->setStatus(EmailInterface::STATUS_READY);
        $mailObject->setEnvironment($this->environment);

        return $mailObject;
    }

    /**
     * Envoi un Swift_Mime_Message
     *
     * @param \Swift_Mime_Message $message
     * @return int
     */
    public function sendMessage(\Swift_Mime_Message $message)
    {
        return $this->mailer->send($message);
    }
}
