<?php

namespace Oru\Bundle\MailBundle\Mailer;

use Oru\Bundle\MailBundle\Entity\Email;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Symfony\Component\Routing\RouterInterface;
use Symfony\Component\Templating\EngineInterface;
use WhiteOctober\SwiftMailerDBBundle\EmailInterface;

class Mailer {

    /**
     * @var \Swift_Mailer
     */
    protected $mailer;

    /**
     * @var RouterInterface
     */
    protected $router;

    /**
     * @var EngineInterface
     */
    protected $templating;

    /**
     * @var Setting
     */
    protected $settings;

    /**
     * @var \Twig_Environment
     */
    protected $twig;

    /**
     * @var string
     */
    protected $environment;

    public function __construct(\Swift_Mailer $mailer, RouterInterface $router, EngineInterface $templating, Setting $settings, \Twig_Environment $twig, $environment)
    {
        $this->mailer = $mailer;
        $this->router = $router;
        $this->templating = $templating;
        $this->settings = $settings;
        $this->twig = $twig;
        $this->environment = $environment;
    }

    /**
     * Créer et envoi un Swift_Mime_Message
     *
     * @param $uriTemplate
     * @param array $parameters
     * @param null $toEmail
     * @param null $fromEmail
     * @param null $ccEmail
     * @param null $bccEmail
     * @return int
     */
    public function sendEmailMessage($uriTemplate, $parameters = array(), $toEmail = null, $fromEmail = null, $ccEmail = null, $bccEmail = null)
    {
        $message = $this->createEmailMessage($uriTemplate, $parameters, $toEmail, $fromEmail, $ccEmail, $bccEmail);

        return $this->mailer->send($message);
    }

    /**
     * @return EngineInterface
     */
    public function getTemplating() {
        return $this->templating;
    }

    /**
     * Créer un Swift_Mime_Message
     *
     * @param $uriTemplate
     * @param array $parameters
     * @param null $toEmail
     * @param null $fromEmail
     * @param null $ccEmail
     * @param null $bccEmail
     * @return \Swift_Mime_MimePart
     */
    public function createEmailMessage($uriTemplate, $parameters = array(), $toEmail = null, $fromEmail = null, $ccEmail = null, $bccEmail = null)  {
        $template = $this->twig->loadTemplate($uriTemplate); // Define your own schema

        $subject  = $template->renderBlock('subject',   $parameters);
        $bodyText = $template->renderBlock('body_text', $parameters);
        $bodyHtml = $template->renderBlock('body_html', $parameters);

        $message = \Swift_Message::newInstance()
            ->setSubject($subject)
            ->setFrom(($fromEmail) ? $fromEmail : $this->settings->setting('mail_from', 'OruMailBundle'))
            ->setSender($this->settings->setting('mail_sender', 'OruMailBundle'))
            ->setTo(($toEmail) ? $toEmail : $this->settings->setting('mail_rcpt', 'OruMailBundle'))
            ->setBody($bodyText, 'text/plain')
        ;
        if($bodyHtml AND strlen($bodyHtml) > 1){
            $message->addPart($bodyHtml, 'text/html');
        }

        if($ccEmail)
            $message->setCc($ccEmail);

        if($bccEmail)
            $message->setBcc($bccEmail);

        return $message;
    }

    /**
     * Créer une entité Email depuis un Swift_Mime_Message
     *
     * @param \Swift_Mime_Message $message
     * @return Email
     */
    public function createMessageEntity(\Swift_Mime_Message $message)
    {
        $mailObject = new Email();
        $mailObject->setMessage(serialize($message));
        $mailObject->setStatus(EmailInterface::STATUS_READY);
        $mailObject->setEnvironment($this->environment);
        return $mailObject;
    }

    /**
     * Envoi un Swift_Mime_Message
     *
     * @param \Swift_Mime_Message $message
     * @return int
     */
    public function sendMessage(\Swift_Mime_Message $message)
    {
        return $this->mailer->send($message);
    }
} 