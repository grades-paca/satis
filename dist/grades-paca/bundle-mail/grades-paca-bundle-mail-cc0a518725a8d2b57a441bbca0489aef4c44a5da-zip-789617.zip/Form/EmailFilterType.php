<?php

namespace Oru\Bundle\MailBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EmailFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('createdAt', 'date', array('required' => false, 'label' => 'Email.createdSince', 'translation_domain' => 'OruMailBundle', 'widget' => 'single_text'))
            ->add('filter', 'submit', array('label' => 'listing.action.filter', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-primary')))
            ->add('reset', 'submit', array('label' => 'listing.action.reset', 'translation_domain' => 'messages','attr' => array('class' => 'btn btn-default')))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\MailBundle\Filter\EmailFilter'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_mailbundle_emailfilter';
    }
}
