<?php

namespace Oru\Bundle\MailBundle\Mailer;

use Mso\IdnaConvert\IdnaConvert;
use Mso\IdnaConvert\Punycode;
use Swift_Mime_SimpleMessage;

/**
 * Class Message.
 *
 * @author Michaël VEROUX
 */
class Message extends \Swift_Message
{
    /**
     * @param null $subject
     * @param null $body
     * @param null $contentType
     * @param null $charset
     *
     * @throws \ErrorException
     *
     * @author Michaël VEROUX
     */
    public static function newInstance($subject = null, $body = null, $contentType = null, $charset = null)
    {
        throw new \ErrorException('Not allowed method to keep compatibility (usage of new self instead of new static in parent class)');
    }

    /**
     * Set the to addresses of this message.
     *
     * If multiple recipients will receive the message an array should be used.
     * Example: array('receiver@domain.org', 'other@domain.org' => 'A name')
     *
     * If $name is passed and the first parameter is a string, this name will be
     * associated with the address.
     *
     * @param mixed  $addresses
     * @param string $name      optional
     *
     * @return Swift_Mime_SimpleMessage
     */
    public function setTo($addresses, $name = null)
    {
        $addresses = $this->adressesToEncoded($addresses, $name);

        return parent::setTo($addresses);
    }

    /**
     * Set the Cc addresses of this message.
     *
     * If $name is passed and the first parameter is a string, this name will be
     * associated with the address.
     *
     * @param mixed  $addresses
     * @param string $name      optional
     *
     * @return Swift_Mime_SimpleMessage
     */
    public function setCc($addresses, $name = null)
    {
        $addresses = $this->adressesToEncoded($addresses, $name);

        return parent::setCc($addresses, $name);
    }

    /**
     * Set the Bcc addresses of this message.
     *
     * If $name is passed and the first parameter is a string, this name will be
     * associated with the address.
     *
     * @param mixed  $addresses
     * @param string $name      optional
     *
     * @return Swift_Mime_SimpleMessage
     */
    public function setBcc($addresses, $name = null)
    {
        $addresses = $this->adressesToEncoded($addresses, $name);

        return parent::setBcc($addresses, $name);
    }

    /**
     * Set the from address of this message.
     *
     * You may pass an array of addresses if this message is from multiple people.
     *
     * If $name is passed and the first parameter is a string, this name will be
     * associated with the address.
     *
     * @param string|array $addresses
     * @param string       $name      optional
     *
     * @return Swift_Mime_SimpleMessage
     */
    public function setFrom($addresses, $name = null)
    {
        $addresses = $this->adressesToEncoded($addresses, $name);

        return parent::setFrom($addresses, $name);
    }

    /**
     * Set the reply-to address of this message.
     *
     * You may pass an array of addresses if replies will go to multiple people.
     *
     * If $name is passed and the first parameter is a string, this name will be
     * associated with the address.
     *
     * @param mixed  $addresses
     * @param string $name      optional
     *
     * @return Swift_Mime_SimpleMessage
     */
    public function setReplyTo($addresses, $name = null)
    {
        $addresses = $this->adressesToEncoded($addresses, $name);

        return parent::setReplyTo($addresses, $name);
    }

    /**
     * Set the return-path (the bounce address) of this message.
     *
     * @param string $address
     *
     * @return Swift_Mime_SimpleMessage
     */
    public function setReturnPath($address)
    {
        return parent::setReturnPath($this->encodeAddress($address));
    }

    /**
     * Set the sender of this message.
     *
     * This does not override the From field, but it has a higher significance.
     *
     * @param string $address
     * @param string $name    optional
     *
     * @return Swift_Mime_SimpleMessage
     */
    public function setSender($address, $name = null)
    {
        return parent::setSender($this->encodeAddress($address), $name);
    }

    /**
     * Ask for a delivery receipt from the recipient to be sent to $addresses.
     *
     * @param array $addresses
     *
     * @return Swift_Mime_SimpleMessage
     */
    public function setReadReceiptTo($addresses)
    {
        $addresses = $this->adressesToEncoded($addresses);

        return parent::setReadReceiptTo($addresses);
    }

    /**
     * @param array|string $addresses
     * @param null|string  $name
     *
     * @return array
     *
     * @author Michaël VEROUX
     */
    private function adressesToEncoded($addresses, $name = null)
    {
        $encoded = array();

        if (is_array($addresses)) {
            foreach ($addresses as $key => $mixed) {
                if (is_int($key)) {
                    $address = $this->encodeAddress($mixed);
                    if ($address) {
                        $encoded[$key] = $address;
                    }
                } else {
                    $address = $this->encodeAddress($key);
                    if ($address) {
                        $encoded[$address] = $mixed;
                    }
                }
            }
        }

        if (!is_array($addresses) && isset($name)) {
            $address = $this->encodeAddress($addresses);
            if ($address) {
                $encoded = array($address => $name);
            }
        } elseif (!is_array($addresses)) {
            $address = $this->encodeAddress($addresses);
            if ($address) {
                $encoded = array($address);
            }
        }

        return $encoded;
    }

    /**
     * @param string $address
     *
     * @throws \Swift_RfcComplianceException
     *
     * @return string
     *
     * @author Michaël VEROUX
     */
    private function encodeAddress($address)
    {
        $limitPartsPos = strrpos($address, '@');
        if (false === $limitPartsPos) {
            throw new \Swift_RfcComplianceException('Unexpected address '.$address);
        }

        $localePart = trim(substr($address, 0, $limitPartsPos), "\xC2\xA0\n");
        $domainPart = trim(substr($address, $limitPartsPos + 1), "\xC2\xA0\n");

        try {
            $IDN = new IdnaConvert();
            if (0 !== strpos($localePart, Punycode::punycodePrefix)) {
                $encodedLocalePart = $IDN->encode($localePart);
            } else { // already encoded
                $encodedLocalePart = $localePart;
            }
            if (0 !== strpos($domainPart, Punycode::punycodePrefix)) {
                $encodedDomainPart = $IDN->encode($domainPart);
            } else { // already encoded
                $encodedDomainPart = $domainPart;
            }

            $encoded = sprintf('%s@%s', $encodedLocalePart, $encodedDomainPart);
        } catch (\Exception $e) {
            return false;
        }

        return $encoded;
    }
}
