<?php
namespace Oru\Bundle\MailBundle\Entity;


use WhiteOctober\SwiftMailerDBBundle\EmailInterface;

class Email implements EmailInterface
{

    /**
     * @var string
     */
    private $status;

    /**
     * @var string
     */
    private $message;

    /**
     * @var string
     */
    private $environment;

    /**
     * @var \Datetime
     */
    private $createdAt;

    /**
     * @var \Datetime
     */
    private $updatedAt;

    /**
     * @var string
     */
    private $createdBy;

    /**
     * @var string
     */
    private $updatedBy;

    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $subject;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * @param mixed $message
     */
    public function setMessage($message)
    {
        $this->message = $message;
    }

    /**
     * @return \Datetime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * @param \Datetime $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    }

    /**
     * @return string
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * @param string $createdBy
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;
    }

    /**
     * @return \Datetime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * @param \Datetime $updatedAt
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
    }

    /**
     * @return string
     */
    public function getUpdatedBy()
    {
        return $this->updatedBy;
    }

    /**
     * @param string $updatedBy
     */
    public function setUpdatedBy($updatedBy)
    {
        $this->updatedBy = $updatedBy;
    }

    /**
     * @return string
     */
    public function getSubject()
    {
        return $this->getUnserializedMessage()->getSubject();
    }

    public function getFrom()
    {
        if(is_array($this->getUnserializedMessage()->getFrom()))
            return array_keys($this->getUnserializedMessage()->getFrom());
        return array();
    }

    public function getTo()
    {
        if(is_array($this->getUnserializedMessage()->getTo()))
            return array_keys($this->getUnserializedMessage()->getTo());
        return array();
    }

    public function getCc()
    {
        if(is_array($this->getUnserializedMessage()->getCc()))
            return array_keys($this->getUnserializedMessage()->getCc());
        return array();
    }

    public function getBcc()
    {
        if(is_array($this->getUnserializedMessage()->getBcc()))
            return array_keys($this->getUnserializedMessage()->getBcc());
        return array();
    }

    public function getBody()
    {
        return $this->getUnserializedMessage()->getBody();
    }

    public function getUnserializedMessage()
    {
        $message = unserialize($this->message);
        foreach($message->getChildren() as $object) {
            if ($object instanceof \Swift_Attachment) {
                $object->setBody(base64_decode($object->getBody()));
            }
        }

        return $message;
    }

    /**
     * @return string
     */
    public function getEnvironment()
    {
        return $this->environment;
    }

    /**
     * @param string $environment
     */
    public function setEnvironment($environment)
    {
        $this->environment = $environment;
    }
}