<?php
/**
 * Created by PhpStorm.
 * User: andre
 * Date: 18/09/14
 * Time: 09:29
 */

namespace Oru\Bundle\MailBundle\Entity;


use Doctrine\ORM\EntityRepository;

class EmailRepository extends EntityRepository {

    /**
     * @param \Oru\Bundle\MailBundle\Filter\EmailFilter $filter
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function findList(\Oru\Bundle\MailBundle\Filter\EmailFilter $filter)
    {
        $builder = $this->createQueryBuilder("u");

        if($filter->getCreatedAt())
        {
            $builder->andWhere("u.createdAt > :createdAt")->setParameter("createdAt","{$filter->getCreatedAt()->format('Y-m-d H:i:s')}");
        }
        if($filter->getUpdatedAt())
        {
            $builder->andWhere("u.updatedAt > :updatedAt AND u.updatedAt != u.createdAt")->setParameter("updatedAt","{$filter->getUpdatedAt()->format('Y-m-d H:i:s')}");
        }
        $builder->orderBy('u.createdAt', 'DESC');

        return $builder;
    }
} 