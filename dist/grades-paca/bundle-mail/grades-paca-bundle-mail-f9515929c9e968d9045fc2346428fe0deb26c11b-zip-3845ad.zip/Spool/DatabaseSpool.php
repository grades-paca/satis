<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\MailBundle\Spool;

use Symfony\Bridge\Doctrine\RegistryInterface;
use WhiteOctober\SwiftMailerDBBundle\EmailInterface;

class DatabaseSpool extends \WhiteOctober\SwiftMailerDBBundle\Spool\DatabaseSpool
{
    /**
     * @var string
     */
    protected $environment;

    /**
     * {@inheritdoc}
     */
    public function __construct(RegistryInterface $doc, $entityClass, $environment, $keepSentMessages = false)
    {
        parent::__construct($doc, $entityClass, $environment, $keepSentMessages);
        $this->environment = $environment;
    }

    /**
     * {@inheritdoc}
     */
    public function flushQueue(\Swift_Transport $transport, &$failedRecipients = null)
    {
        if (!$transport->isStarted()) {
            $transport->start();
        }

        $repoClass = $this->doc->getManager()->getRepository($this->entityClass);
        $limit = $this->getMessageLimit();
        $limit = $limit > 0 ? $limit : null;
        $emails = $repoClass->findBy(
            array('status' => EmailInterface::STATUS_READY, 'environment' => $this->environment),
            null,
            $limit
        );
        if (!count($emails)) {
            return 0;
        }

        $failedRecipients = (array) $failedRecipients;
        $count = 0;
        $time = time();
        foreach ($emails as $email) {
            $email->setStatus(EmailInterface::STATUS_PROCESSING);
            $this->doc->getManager()->persist($email);
            $this->doc->getManager()->flush();

            $message = $email->getUnserializedMessage();
            $count += $transport->send($message, $failedRecipients);
            if ($this->keepSentMessages === true) {
                $email->setStatus(EmailInterface::STATUS_COMPLETE);
                $this->doc->getManager()->persist($email);
            } else {
                $this->doc->getManager()->remove($email);
            }
            $this->doc->getManager()->flush();

            if ($this->getTimeLimit() && (time() - $time) >= $this->getTimeLimit()) {
                break;
            }
        }

        return $count;
    }
}
