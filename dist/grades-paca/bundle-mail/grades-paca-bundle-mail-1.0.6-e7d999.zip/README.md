Bundle OruMailBundle
======================

Description
-----------

Ce bundle configure la gestion des mails via base de données.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/mail":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new \WhiteOctober\SwiftMailerDBBundle\WhiteOctoberSwiftMailerDBBundle();
$bundles[] = new Oru\Bundle\MailBundle\OruMailBundle();
```

Dans le config.yml, importer la configuration de ce bundle :

```
imports:
    ...
    - { resource: @OruMailBundle/Resources/config/config.yml }
    ...
```

Vider le cache de Symfony2

Utilisation
-----------

Pour l'instant, la gestion en base est gérée via WhiteOctoberSwiftMailerDBBundle : https://github.com/whiteoctober/WhiteOctoberSwiftMailerDBBundle.
L'url /email permet d'accéder à la liste des emails envoyés.