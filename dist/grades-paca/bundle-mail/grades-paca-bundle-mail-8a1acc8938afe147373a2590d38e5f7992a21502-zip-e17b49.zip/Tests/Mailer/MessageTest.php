<?php

namespace Oru\Bundle\MailBundle\Tests\Mailer;

use Oru\Bundle\MailBundle\Mailer\Message;

/**
 * Class MessageTest
 *
 * @package Oru\Bundle\MailBundle\Tests\Mailer
 * @author Michaël VEROUX
 */
class MessageTest extends \PHPUnit_Framework_TestCase
{
    /**
     * @return void
     * @author Michaël VEROUX
     */
    public function testEncodeAddress()
    {
        $encodeAddress = self::getMethod('encodeAddress');
        $message = new Message();

        $noIdnAddress = 'test@test.com';
        $idnAddress = 'test@frencé.fr';
        $intlNoIdnAddress = 'hervé@test.com';
        $intlIdnAddress = 'hervé@frencé.fr';
        $multipleIntl = 'jéssé.une.fôte@cécompliqué.fr';

        $this->assertSame(
            $encodeAddress->invokeArgs($message, array($noIdnAddress)),
            $noIdnAddress
        );
        $this->assertSame(
            $encodeAddress->invokeArgs($message, array($idnAddress)),
            'test@xn--frenc-fsa.fr'
        );
        $this->assertSame(
            $encodeAddress->invokeArgs($message, array($intlNoIdnAddress)),
            'xn--herv-epa@test.com'
        );
        $this->assertSame(
            $encodeAddress->invokeArgs($message, array($intlIdnAddress)),
            'xn--herv-epa@xn--frenc-fsa.fr'
        );
        $this->assertSame(
            $encodeAddress->invokeArgs($message, array($multipleIntl)),
            'xn--jss-bmac.une.xn--fte-kna@xn--ccompliqu-b4ai.fr'
        );
    }

    /**
     * @return void
     * @author Michaël VEROUX
     */
    public function testAdressesToEncoded()
    {
        $adressesToEncoded = self::getMethod('adressesToEncoded');
        $message = new Message();

        $inputArgs = array('test@test.fr', 'TEST');
        $output = array('test@test.fr' => 'TEST');
        $this->assertSame(
            $output,
            $adressesToEncoded->invokeArgs($message, $inputArgs)
        );

        $inputArgs = array(array('test@test.fr' => 'lol'), 'TEST');
        $output = array('test@test.fr' => 'lol');
        $this->assertSame(
            $output,
            $adressesToEncoded->invokeArgs($message, $inputArgs)
        );

        $inputArgs = array(array('test@test.fr' => 'lol', 'salut@sansnom.fr', 'unautre@test.com' => 'UN AUTRE'));
        $output = array('test@test.fr' => 'lol', 'salut@sansnom.fr', 'unautre@test.com' => 'UN AUTRE');
        $this->assertSame(
            $output,
            $adressesToEncoded->invokeArgs($message, $inputArgs)
        );

        $inputArgs = array('test@testé.fr', 'TEST');
        $output = array('test@xn--test-epa.fr' => 'TEST');
        $this->assertSame(
            $output,
            $adressesToEncoded->invokeArgs($message, $inputArgs)
        );

        $inputArgs = array(array('test@testé.fr' => 'lolé'), 'TEST');
        $output = array('test@xn--test-epa.fr' => 'lolé');
        $this->assertSame(
            $output,
            $adressesToEncoded->invokeArgs($message, $inputArgs)
        );

        $inputArgs = array(array('test@testé.fr' => 'lolé', 'saluté@sansnom.fr', 'unautre@test.com' => 'UN AUTRÉ'));
        $output = array('test@xn--test-epa.fr' => 'lolé', 'xn--salut-fsa@sansnom.fr', 'unautre@test.com' => 'UN AUTRÉ');
        $this->assertSame(
            $output,
            $adressesToEncoded->invokeArgs($message, $inputArgs)
        );
    }

    /**
     * @param $name
     *
     * @return \ReflectionMethod
     * @author Michaël VEROUX
     */
    protected static function getMethod($name)
    {
        $class = new \ReflectionClass('Oru\Bundle\MailBundle\Mailer\Message');
        $method = $class->getMethod($name);
        $method->setAccessible(true);

        return $method;
    }
}
