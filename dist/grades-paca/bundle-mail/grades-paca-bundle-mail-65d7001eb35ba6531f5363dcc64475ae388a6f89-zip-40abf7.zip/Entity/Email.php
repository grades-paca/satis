<?php
namespace Oru\Bundle\MailBundle\Entity;


use WhiteOctober\SwiftMailerDBBundle\EmailInterface;

class Email implements EmailInterface
{

    /**
     * @var string
     */
    private $status;

    /**
     * @var string
     */
    private $message;

    /**
     * @var string
     */
    private $environment;

    /**
     * @var \Datetime
     */
    private $createdAt;

    /**
     * @var \Datetime
     */
    private $updatedAt;

    /**
     * @var string
     */
    private $createdBy;

    /**
     * @var string
     */
    private $updatedBy;

    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $subject;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * @param mixed $message
     */
    public function setMessage($message)
    {
        $this->message = $message;
    }

    /**
     * @return \Datetime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * @param \Datetime $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    }

    /**
     * @return string
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * @param string $createdBy
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;
    }

    /**
     * @return \Datetime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * @param \Datetime $updatedAt
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
    }

    /**
     * @return string
     */
    public function getUpdatedBy()
    {
        return $this->updatedBy;
    }

    /**
     * @param string $updatedBy
     */
    public function setUpdatedBy($updatedBy)
    {
        $this->updatedBy = $updatedBy;
    }

    /**
     * @return string
     */
    public function getSubject()
    {
        return unserialize($this->message)->getSubject();
    }

    public function getFrom()
    {
        if(is_array(unserialize($this->message)->getFrom()))
            return array_keys(unserialize($this->message)->getFrom());
        return array();
    }

    public function getTo()
    {
        if(is_array(unserialize($this->message)->getTo()))
            return array_keys(unserialize($this->message)->getTo());
        return array();
    }

    public function getCc()
    {
        if(is_array(unserialize($this->message)->getCc()))
            return array_keys(unserialize($this->message)->getCc());
        return array();
    }

    public function getBcc()
    {
        if(is_array(unserialize($this->message)->getBcc()))
            return array_keys(unserialize($this->message)->getBcc());
        return array();
    }

    public function getBody()
    {
        return unserialize($this->message)->getBody();
    }

    public function getUnserializedMessage() {
        return unserialize($this->message);
    }

    /**
     * @return string
     */
    public function getEnvironment()
    {
        return $this->environment;
    }

    /**
     * @param string $environment
     */
    public function setEnvironment($environment)
    {
        $this->environment = $environment;
    }
}