<?php

namespace Oru\Bundle\MailBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Oru\Bundle\MailBundle\Entity\Email;
use Oru\Bundle\MailBundle\Listing\EmailListingType;
use Oru\Bundle\MailBundle\Form\EmailFilterType;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * Email controller.
 *
 */
class EmailController extends Controller
{

    /**
     * Lists all Email entities.
     *
     */
    public function indexAction(Request $request)
    {
        $defaultFilters = array();
        $this->credentialCheck();
        $form = $this->createForm(new EmailFilterType())->submit($request->getSession()->get('email.filter', $defaultFilters));
        $listing = $this->container->get('paginator.factory')->create(
            new EmailListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruMailBundle:Email')->findList($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('OruMailBundle:Email:index.html.twig', array(
            'listing' => $listing,
            'form' => $this->createForm(new EmailFilterType(), $form->getData())->createView()
        ));
    }
    /**
     * Filters Email entities.
     *
     */
    public function filterAction(Request $request)
    {
        $this->credentialCheck();
        $form = $this->createForm(new EmailFilterType())->handleRequest($request);

        if ($form->get('reset')->isClicked()) {
            $request->getSession()->remove('email.filter');
            return $this->redirect($this->generateUrl('oru_email'));
        }

        if($form->isValid()) {
            $request->getSession()->set('email.filter', $request->get($form->getName()));
            return $this->redirect($this->generateUrl('oru_email'));
        }

        $listing = $this->container->get('paginator.factory')->create(
            new EmailListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruMailBundle:Email')->findList($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('OruMailBundle:Email:index.html.twig', array(
            'listing' => $listing,
            'form' => $form->createView()
        ));
    }

    /**
     * Finds and displays a Email entity.
     *
     */
    public function showAction($id)
    {
        $this->credentialCheck();
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruMailBundle:Email')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Email entity.');
        }

        return $this->render('OruMailBundle:Email:show.html.twig', array(
            'entity'      => $entity,
        ));
    }

    /**
     * @return bool
     * @throws AccessDeniedHttpException
     * @author Michaël VEROUX
     */
    private function credentialCheck()
    {
        if ($this->has('oru_ror_credentials.credentials_checker')) {
            if ($this->get('oru_ror_credentials.credentials_checker')->checkCurrentUser('ORU_MAIL')) {
                return true;
            }
        }

        throw new AccessDeniedHttpException();
    }
}
