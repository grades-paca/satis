$(function() {
    $('.bootstrap-popover').popover({'html':true});
});