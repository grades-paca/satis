<?php

namespace Oru\Bundle\MailBundle;

use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Oru\Bundle\SettingBundle\Bundle\OruBundle;

class OruMailBundle extends OruBundle
{
    public function __construct()
    {
        DynamicLoader::addYaml('@OruMailBundle/Resources/config/routing.yml');
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public static function getFriendlyName()
    {
        return 'Mails';
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public static function getDescription()
    {
        return 'Gestion des mails';
    }
}
