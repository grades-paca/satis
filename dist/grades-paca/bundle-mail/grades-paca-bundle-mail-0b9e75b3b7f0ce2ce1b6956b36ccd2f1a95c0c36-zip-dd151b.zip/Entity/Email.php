<?php
namespace Oru\Bundle\MailBundle\Entity;

use WhiteOctober\SwiftMailerDBBundle\EmailInterface;

class Email implements EmailInterface
{
    /**
     * @var string
     */
    private $status;

    /**
     * @var string
     */
    private $message;

    /**
     * @var string
     */
    private $environment;

    /**
     * @var \Datetime
     */
    private $createdAt;

    /**
     * @var \Datetime
     */
    private $updatedAt;

    /**
     * @var string
     */
    private $createdBy;

    /**
     * @var string
     */
    private $updatedBy;

    /**
     * @var int
     */
    private $id;

    /**
     * @var string
     */
    private $subject;

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * @param mixed $message
     */
    public function setMessage($message)
    {
        $this->message = $message;
    }

    /**
     * @return \Datetime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * @param \Datetime $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    }

    /**
     * @return string
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * @param string $createdBy
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;
    }

    /**
     * @return \Datetime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * @param \Datetime $updatedAt
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
    }

    /**
     * @return string
     */
    public function getUpdatedBy()
    {
        return $this->updatedBy;
    }

    /**
     * @param string $updatedBy
     */
    public function setUpdatedBy($updatedBy)
    {
        $this->updatedBy = $updatedBy;
    }

    /**
     * @return string
     */
    public function getSubject()
    {
        $unserialized = $this->getUnserializedMessage();
        if ($unserialized) {
            return $unserialized->getSubject();
        }

        return false;
    }

    public function getFrom()
    {
        $unserialized = $this->getUnserializedMessage();
        if ($unserialized) {
            if (is_array($unserialized->getFrom())) {
                return array_keys($unserialized->getFrom());
            }
        }

        return array();
    }

    public function getTo()
    {
        $unserialized = $this->getUnserializedMessage();
        if ($unserialized) {
            if (is_array($unserialized->getTo())) {
                return array_keys($unserialized->getTo());
            }
        }

        return array();
    }

    public function getCc()
    {
        $unserialized = $this->getUnserializedMessage();
        if ($unserialized) {
            if (is_array($unserialized->getCc())) {
                return array_keys($unserialized->getCc());
            }
        }

        return array();
    }

    public function getBcc()
    {
        $unserialized = $this->getUnserializedMessage();
        if ($unserialized) {
            if (is_array($unserialized->getBcc())) {
                return array_keys($unserialized->getBcc());
            }
        }

        return array();
    }

    public function getBody()
    {
        $unserialized = $this->getUnserializedMessage();
        if ($unserialized) {
            return $unserialized->getBody();
        }

        return false;
    }

    /**
     * Récupération du message déserialisé
     * Les pièces sont décodés de base64 si elles étaient encodées sous ce format.
     *
     * @return mixed
     */
    public function getUnserializedMessage()
    {
        $message = unserialize($this->message);
        if ($message && $message->getChildren() && count($message->getChildren())) {
            foreach ($message->getChildren() as $object) {
                if ($object instanceof \Swift_Attachment) {
                    $decoded = base64_decode($object->getBody(), true);
                    $return = $decoded;
                    if (false === $decoded) {
                        $return = $object->getBody();
                    } elseif (base64_encode($decoded) !== $object->getBody()) {
                        $return = $object->getBody();
                    }
                    $object->setBody($return);
                }
            }
        }

        return $message;
    }

    /**
     * @return string
     */
    public function getEnvironment()
    {
        return $this->environment;
    }

    /**
     * @param string $environment
     */
    public function setEnvironment($environment)
    {
        $this->environment = $environment;
    }
}
