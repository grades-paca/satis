<?php

namespace Oru\Bundle\MailBundle;

use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruMailBundle extends OruBundle
{
    public function boot()
    {
        $collection = $this
            ->container
            ->get('routing.loader')
            ->load(__DIR__.'/Resources/config/routing.yml')
        ;

        $this
            ->container
            ->get('router')
            ->getRouteCollection()
            ->addCollection($collection)
        ;
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getFriendlyName()
    {
        return "Mails";
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getDescription()
    {
        return "Gestion des mails";
    }
}
