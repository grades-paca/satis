<?php

namespace Oru\Bundle\MailBundle\Filter;

use Oru\Bundle\MailBundle\Entity\Email;


class EmailFilter extends Email
{
}