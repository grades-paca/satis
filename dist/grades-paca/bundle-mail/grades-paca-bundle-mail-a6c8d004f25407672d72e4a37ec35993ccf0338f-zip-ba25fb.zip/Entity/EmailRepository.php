<?php
/**
 * Created by PhpStorm.
 * User: andre
 * Date: 18/09/14
 * Time: 09:29
 */

namespace Oru\Bundle\MailBundle\Entity;

use Doctrine\ORM\EntityRepository;
use DateInterval;

class EmailRepository extends EntityRepository {

    /**
     * @param \Oru\Bundle\MailBundle\Filter\EmailFilter $filter
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function findList(\Oru\Bundle\MailBundle\Filter\EmailFilter $filter)
    {
        $builder = $this->createQueryBuilder("u");

        if ($filter->getCreatedFrom()) {
            $builder->andWhere('u.createdAt >= :createdFrom');
            $builder->setParameter('createdFrom', $filter->getCreatedFrom()->format('Y-m-d H:i:s'));
        }
        if ($filter->getCreatedTo()) {
            $builder->andWhere('u.createdAt < :createdTo');
            $dateTo = $filter->getCreatedTo()->add(new DateInterval('P1D'));
            $builder->setParameter('createdTo', $$dateTo);
        }
        if ($filter->getSearchInMessage()) {
            $builder->andWhere('u.message LIKE :searchInMessage');
            $builder->setParameter('searchInMessage', sprintf('%%%s%%', $filter->getSearchInMessage()));
        }

        $builder->orderBy('u.createdAt', 'DESC');

        return $builder;
    }
} 