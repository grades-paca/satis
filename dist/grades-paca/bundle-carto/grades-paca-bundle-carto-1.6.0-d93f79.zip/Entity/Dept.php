<?php

namespace Oru\Bundle\CartoBundle\Entity;

/**
 * Dept.
 */
class Dept
{
    /**
     * @var string
     */
    private $idGeofla;

    /**
     * @var string
     */
    private $codeDept;

    /**
     * @var string
     */
    private $nomDept;

    /**
     * @var string
     */
    private $codeChf;

    /**
     * @var string
     */
    private $nomChf;

    /**
     * @var int
     */
    private $xChfLieu;

    /**
     * @var int
     */
    private $yChfLieu;

    /**
     * @var int
     */
    private $xCentroid;

    /**
     * @var int
     */
    private $yCentroid;

    /**
     * @var string
     */
    private $codeReg;

    /**
     * @var string
     */
    private $nomReg;

    /**
     * @var geometry
     */
    private $theGeom;

    /**
     * @var int
     */
    private $gid;

    /**
     * Set idGeofla.
     *
     * @param string $idGeofla
     *
     * @return Dept
     */
    public function setIdGeofla($idGeofla)
    {
        $this->idGeofla = $idGeofla;

        return $this;
    }

    /**
     * Get idGeofla.
     *
     * @return string
     */
    public function getIdGeofla()
    {
        return $this->idGeofla;
    }

    /**
     * Set codeDept.
     *
     * @param string $codeDept
     *
     * @return Dept
     */
    public function setCodeDept($codeDept)
    {
        $this->codeDept = $codeDept;

        return $this;
    }

    /**
     * Get codeDept.
     *
     * @return string
     */
    public function getCodeDept()
    {
        return $this->codeDept;
    }

    /**
     * Set nomDept.
     *
     * @param string $nomDept
     *
     * @return Dept
     */
    public function setNomDept($nomDept)
    {
        $this->nomDept = $nomDept;

        return $this;
    }

    /**
     * Get nomDept.
     *
     * @return string
     */
    public function getNomDept()
    {
        return $this->nomDept;
    }

    /**
     * Set codeChf.
     *
     * @param string $codeChf
     *
     * @return Dept
     */
    public function setCodeChf($codeChf)
    {
        $this->codeChf = $codeChf;

        return $this;
    }

    /**
     * Get codeChf.
     *
     * @return string
     */
    public function getCodeChf()
    {
        return $this->codeChf;
    }

    /**
     * Set nomChf.
     *
     * @param string $nomChf
     *
     * @return Dept
     */
    public function setNomChf($nomChf)
    {
        $this->nomChf = $nomChf;

        return $this;
    }

    /**
     * Get nomChf.
     *
     * @return string
     */
    public function getNomChf()
    {
        return $this->nomChf;
    }

    /**
     * Set xChfLieu.
     *
     * @param int $xChfLieu
     *
     * @return Dept
     */
    public function setXChfLieu($xChfLieu)
    {
        $this->xChfLieu = $xChfLieu;

        return $this;
    }

    /**
     * Get xChfLieu.
     *
     * @return int
     */
    public function getXChfLieu()
    {
        return $this->xChfLieu;
    }

    /**
     * Set yChfLieu.
     *
     * @param int $yChfLieu
     *
     * @return Dept
     */
    public function setYChfLieu($yChfLieu)
    {
        $this->yChfLieu = $yChfLieu;

        return $this;
    }

    /**
     * Get yChfLieu.
     *
     * @return int
     */
    public function getYChfLieu()
    {
        return $this->yChfLieu;
    }

    /**
     * Set xCentroid.
     *
     * @param int $xCentroid
     *
     * @return Dept
     */
    public function setXCentroid($xCentroid)
    {
        $this->xCentroid = $xCentroid;

        return $this;
    }

    /**
     * Get xCentroid.
     *
     * @return int
     */
    public function getXCentroid()
    {
        return $this->xCentroid;
    }

    /**
     * Set yCentroid.
     *
     * @param int $yCentroid
     *
     * @return Dept
     */
    public function setYCentroid($yCentroid)
    {
        $this->yCentroid = $yCentroid;

        return $this;
    }

    /**
     * Get yCentroid.
     *
     * @return int
     */
    public function getYCentroid()
    {
        return $this->yCentroid;
    }

    /**
     * Set codeReg.
     *
     * @param string $codeReg
     *
     * @return Dept
     */
    public function setCodeReg($codeReg)
    {
        $this->codeReg = $codeReg;

        return $this;
    }

    /**
     * Get codeReg.
     *
     * @return string
     */
    public function getCodeReg()
    {
        return $this->codeReg;
    }

    /**
     * Set nomReg.
     *
     * @param string $nomReg
     *
     * @return Dept
     */
    public function setNomReg($nomReg)
    {
        $this->nomReg = $nomReg;

        return $this;
    }

    /**
     * Get nomReg.
     *
     * @return string
     */
    public function getNomReg()
    {
        return $this->nomReg;
    }

    /**
     * Set theGeom.
     *
     * @param geometry $theGeom
     *
     * @return Dept
     */
    public function setTheGeom($theGeom)
    {
        $this->theGeom = $theGeom;

        return $this;
    }

    /**
     * Get theGeom.
     *
     * @return geometry
     */
    public function getTheGeom()
    {
        return $this->theGeom;
    }

    /**
     * Get gid.
     *
     * @return int
     */
    public function getGid()
    {
        return $this->gid;
    }
}
