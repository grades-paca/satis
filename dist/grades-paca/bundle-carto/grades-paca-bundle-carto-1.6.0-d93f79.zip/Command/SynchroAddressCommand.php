<?php
/**
 * Created by PhpStorm.
 * User: tdepreaumont
 * Date: 26/11/2015
 * Time: 09:32
 */

namespace Oru\Bundle\CartoBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class SynchroAddressCommand extends ContainerAwareCommand
{
    /**
     * @author Michaël VEROUX
     */
    protected function configure()
    {
        $this
            ->setName('oru:address:synchro-all')
            ->setDescription('Nouvelle synchronisation des adresses dans la base postgre (suppression des données)')
        ;
    }

    /**
     * Executes the current command.
     *
     * This method is not abstract because you can use this class
     * as a concrete class. In this case, instead of defining the
     * execute() method, you set the code to execute by passing
     * a Closure to the setCode() method.
     *
     * @param InputInterface  $input  An InputInterface instance
     * @param OutputInterface $output An OutputInterface instance
     *
     * @throws \LogicException When this abstract method is not implemented
     *
     * @return null|int null or 0 if everything went fine, or an error code
     *
     * @see setCode()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->getContainer()->get('oru_carto.geo_address_synchro')->synchroAll($output);
    }
}
