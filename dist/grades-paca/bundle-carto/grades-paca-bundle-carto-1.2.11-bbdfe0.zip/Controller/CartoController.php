<?php
/**
 * Created by PhpStorm.
 * User: bphilippot
 * Date: 10/07/14
 * Time: 13:49
 */

namespace Oru\Bundle\CartoBundle\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Cookie;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

class CartoController extends Controller {

    public function indexAction(Request $request){
        return $this->render("OruCartoBundle:Map:sig.html.twig");
    }

    /*
     * Renvoie un json des identifiants d'adresses des établissements filtrés
     * Paramètres :
     * type : type de filtre
     * type_value : valeur du filtre
     */
    public function filterAction(Request $request)
    {
        $type = $request->query->get("type");
        $type_value = $request->query->get("type_value");
        $array_type_values = array();
        if(isset($type_value)){
            $array_type_values = explode(",", $type_value);
        }

        $etabRep = $this->getDoctrine()->getRepository('OruRorBundle:Etablissement');

        $adr_ids = array();

        switch($type){
            case "categorie_etablissement":
                //$adr_attributes = $etabRep->findAddressesByCategorie($array_type_values);
                $inQuery = implode(',', array_fill(0, count($array_type_values), '?'));
                $em = $this->getDoctrine()->getManager();
                $connection = $em->getConnection();
                $statement = $connection->prepare("SELECT adresse_id AS adr_id, e.id AS etab_id, e.nom as etab_nom FROM oru_ror_etablissement e LEFT JOIN oru_ror_lst_categorie_etablissement c ON e.categorie_etablissement_id = c.id WHERE c.code IN (".$inQuery.") AND e.deleted IS NULL ORDER BY adr_id");
                $statement->execute($array_type_values);
                $adr_attributes = $statement->fetchAll();
                for($i=0; $i < count($adr_attributes); $i++){
                    $adr_ids[$i] = $adr_attributes[$i]["adr_id"];
                    $adr_attributes[$i]["etab_route"] = $this->generateUrl('etablissement_show',array('id'=> $adr_attributes[$i]["etab_id"]));
                }
                break;
            case "type_unite":
                $adr_attributes = $etabRep->findAddressesByTypeUnite($array_type_values);
                for($i=0; $i < count($adr_attributes); $i++){
                    $adr_ids[$i] = $adr_attributes[$i]["adr_id"];
                    $adr_attributes[$i]["etab_route"] = $this->generateUrl('etablissement_show',array('id'=> $adr_attributes[$i]["etab_id"]));
                    $adr_attributes[$i]["unite_route"] = $this->generateUrl('unite_show',array('id'=> $adr_attributes[$i]["unite_id"]));
                }
                break;
            case "competence":
                $adr_attributes = $etabRep->findAddressesByCompetencePro($array_type_values);
                for($i=0; $i < count($adr_attributes); $i++){
                    $adr_ids[$i] = $adr_attributes[$i]["adr_id"];
                    $adr_attributes[$i]["etab_route"] = $this->generateUrl('etablissement_show',array('id'=> $adr_attributes[$i]["etab_id"]));
                    $adr_attributes[$i]["pro_route"] = $this->generateUrl('professionnel_show',array('id'=> $adr_attributes[$i]["pro_id"]));
                }
                break;
            default:
                $adr_attributes = $etabRep->getAddressesIds(null);
                for($i=0; $i < count($adr_attributes); $i++){
                    $adr_ids[$i] = $adr_attributes[$i]["adr_id"];
                    $adr_attributes[$i]["etab_route"] = $this->generateUrl('etablissement_show',array('id'=> $adr_attributes[$i]["etab_id"]));
                }
                break;
        }

        if(count($adr_ids) != 0){
            return new JsonResponse(array(
                "adr_ids" => $adr_ids,
                "adr_attributes" => array_values($adr_attributes)
        ));
        } else {
            return new JsonResponse("no_results",400);
        }

    }

    public function getInterventionsSmurAction(Request $request)
    {
        $data['loginws'] = 'ror';
        $data['passwordws'] = md5('tahghaenip2Eib');

        if($request->query->has('typeIntervention')){
            $data['typeIntervention'] = $request->query->get('typeIntervention');
        }
        if($request->query->has('typeVehicule')){
            $data['typeVehicule'] = $request->query->get('typeVehicule');
        }

        $url = 'https://eai.orupaca.fr/public/samu/getInterventions/';
        $proxyClient = $this->get('oru_webclient.client');
        $options = $proxyClient->getOptions();
        $options->set(CURLOPT_SSL_VERIFYHOST, false);
        $options->set(CURLOPT_SSL_VERIFYPEER, false);
        $options->set(CURLOPT_HTTPAUTH, CURLAUTH_ANY);

        $xmlInters = $proxyClient->post($url, $data);
        $xmlInters = preg_replace('/&(?!#?[a-z0-9]+;)/', '&amp;', $xmlInters);

        $simpleXml = simplexml_load_string($xmlInters);

        $interventions_encours = array(
            "type" => "FeatureCollection",
            "features" => array()
        );

        $ignHelper = $this->get('oru_carto.helper.ign');

        foreach($simpleXml->intervention as $inter){
            $adresse = $inter->adresse . " " . $inter->code_postal ." " . $inter->commune;
            if($inter->commune == "") continue;
            $geocodeInter = $ignHelper->geocodeAdresse($adresse);
            $geocode_result = $inter->addChild("geocodage_inter");
            $geocode_result->addChild("adresse",$geocodeInter["adresse"]);
            $geocode_result->addChild("lon",$geocodeInter["lon"]);
            $geocode_result->addChild("lat",$geocodeInter["lat"]);
            if($geocodeInter["niveau"] == "Street number"){
                $niveau = "N° de rue";
            } else if ($geocodeInter["niveau"] == "Street enhanced" || $geocodeInter["niveau"] == "Street"){
                $niveau = "Rue";
            } else {
                $niveau = "Ville";
            }
            $geocode_result->addChild("niveau",$niveau . " (" . round(floatval($geocodeInter["precision"])*100) . "%)");

            foreach($inter->victimes->victime->destination as $destination){
                if ($destination->commune == "") continue;
                $adresse_dest = $destination->adresse . " " . $destination->code_postal ." " . $destination->commune;
                $res = $ignHelper->geocodeAdresse($adresse_dest);
                $geocode_result = $destination->addChild("geocodage_destination");
                $geocode_result->addChild("adresse",$res["adresse"]);
                $geocode_result->addChild("lon",$res["lon"]);
                $geocode_result->addChild("lat",$res["lat"]);
                if($res["niveau"] == "Street number"){
                    $niveau = "N° de rue";
                } else if ($res["niveau"] == "Street enhanced" || $res["niveau"] == "Street"){
                    $niveau = "Rue";
                } else {
                    $niveau = "Ville";
                }
                $geocode_result->addChild("niveau",$niveau . " (" . round(floatval($res["precision"])*100) . "%)");
            }

            $interventions_encours["features"][] = array(
                "type" => "Feature",
                "geometry" => array(
                    "type" => "Point",
                    "coordinates" => [floatval($geocodeInter["lon"]), floatval($geocodeInter["lat"])],
                ),
                "properties" => (array) $inter
            );

        }
        return new JsonResponse($interventions_encours);
    }

    /*
     * Transforme une couleur hexadécimale en rgb
     */
    private function hex2rgb($hex) {
        $hex = str_replace("#", "", $hex);

        if(strlen($hex) == 3) {
            $r = hexdec(substr($hex,0,1).substr($hex,0,1));
            $g = hexdec(substr($hex,1,1).substr($hex,1,1));
            $b = hexdec(substr($hex,2,1).substr($hex,2,1));
        } else {
            $r = hexdec(substr($hex,0,2));
            $g = hexdec(substr($hex,2,2));
            $b = hexdec(substr($hex,4,2));
        }
        $rgb = array($r, $g, $b);
        //return implode(",", $rgb); // returns the rgb values separated by commas
        return $rgb; // returns an array with the rgb values
    }

    /*
     * Dessine une ellipse avec imagearc pour prendre en compte l'épaisseur
     */
    private function myimageellipse($image, $x, $y, $rx, $ry, $color)
    {
        // We don't use imageellipse because the imagesetthickness function has
        // no effect. So the better workaround is to use imagearc.
        imagearc($image,$x,$y,$rx,$ry, 0,359,$color);

        // If we stop here, we don't have a properly closed ellipse.
        // Using imagefill at this point will flood outside the ellipse (actually arc).

        // We have to close the arc to make it a real ellipse.
        $cos359=0.99984769;
        $sin359=-0.01745240;

        $x1=round($x+$rx/2*$cos359);
        $y1=round($y+$ry/2*$sin359);

        $x2=round($x+$rx/2);
        $y2=round($y);

        // imageline is sensitive to imagesetthickness as well.
        imageline($image,$x1,$y1,$x2,$y2,$color);
    }

    /*
     * Imprime la carte avec les fonds de plan et les features
     */
    public function printAction(Request $request)
    {
        $TEMP_DIR = $this->container->getParameter('kernel.cache_dir');

        // fetch the request params, and generate the name of the tempfile and its URL
        $width    = $request->request->get('width');  if (!$width) $width = 1024;
        $height   = $request->request->get('height'); if (!$height) $height = 768;
        $tiles    = json_decode($request->request->get('tiles'));
        $features = json_decode($request->request->get('features'));
        $viewport = json_decode($request->request->get('viewport'));
        $contentDisposition = $request->request->get('contentDisposition');

        //$tiles    = json_decode(stripslashes(@$_REQUEST['tiles'])); // use this if you use magic_quotes_gpc
        $random   = md5(microtime().mt_rand());
        $file     = sprintf("%s/%s.jpg", $TEMP_DIR, $random );
        $tmpFiles = array();

        // lay down an image canvas
        // Notice: in MapServer if you have set a background color
        // (eg. IMAGECOLOR 60 100 145) that color is your transparent value
        // $transparent = imagecolorallocatealpha($image,60,100,145,127);
        $image = imagecreatetruecolor($width,$height);
        imagefill($image,0,0, imagecolorallocate($image,255,255,255) ); // fill with white

        $proxyClient = $this->get('oru_webclient.client');
        // loop through the tiles, blitting each one onto the canvas
        foreach ($tiles as $tile) {
            // try to convert relative URLs into full URLs
            // this could probably use some improvement
            $tile->url = urldecode($tile->url);
            if (substr($tile->url,0,4)!=='http') {
                $tile->url = preg_replace('/^\.\//',dirname($_SERVER['REQUEST_URI']).'/',$tile->url);
                $tile->url = preg_replace('/^\.\.\//',dirname($_SERVER['REQUEST_URI']).'/../',$tile->url);
                $tile->url = sprintf("%s://%s:%d/%s", isset($_SERVER['HTTPS'])?'https':'http', $_SERVER['SERVER_ADDR'], $_SERVER['SERVER_PORT'], $tile->url);
            }
            $tile->url = str_replace(' ','+',$tile->url);

            $context = null;
            if(strstr($tile->url,"wxs.ign.fr")){
                $proxyClient->getHeader()->set('Referer', $request->getHost());
            }

            // fetch the tile into a temp file, and analyze its type; bail if it's invalid
            $tempfile =  sprintf("%s/%s.img", $TEMP_DIR, md5(microtime().mt_rand()) );
            file_put_contents($tempfile, $proxyClient->get($tile->url));
            list($tilewidth,$tileheight,$tileformat) = @getimagesize($tempfile);
            if (!$tileformat) continue;

            // load the tempfile's image, and blit it onto the canvas
            switch ($tileformat) {
                case IMAGETYPE_GIF:
                    $tileimage = imagecreatefromgif($tempfile);
                    break;
                case IMAGETYPE_JPEG:
                    $tileimage = imagecreatefromjpeg($tempfile);
                    break;
                case IMAGETYPE_PNG:
                    $tileimage = imagecreatefrompng($tempfile);
                    break;
            }
            imagecopymerge($image, $tileimage, $tile->x, $tile->y, 0, 0, $tilewidth, $tileheight, $tile->opacity);
            $tmpFiles[] = $tempfile;
        }

        foreach($features as $feature_array) {
            if(count($feature_array) > 0) {
                foreach($feature_array as $feature) {
                    if($feature->type == "point") {
                        if($feature->style) {
                            $dst_x = $feature->x + $viewport->left;
                            $dst_y = $feature->y + $viewport->top;
                            if(isset($feature->style->externalGraphic)) {
                                // Draw the external graphic
                                $tempfilename = basename($feature->style->externalGraphic);
                                $tempfile =  sprintf("%s", $this->get('kernel')->getRootDir()."/../web/bundles/orucarto/images/". $tempfilename);
                                if(!file_exists($tempfile)) {
                                    $tempfiles[] = $tempfile;
                                    file_put_contents($tempfile, $proxyClient->get($this->relative_to_absolute_url($feature->style->externalGraphic)));
                                }
                                list($fwidth, $fheight, $fformat) = @getimagesize($tempfile);
                                switch ($fformat) {
                                    case IMAGETYPE_GIF:
                                        $feature_image = imagecreatefromgif($tempfile);
                                        break;
                                    case IMAGETYPE_JPEG:
                                        $feature_image = imagecreatefromjpeg($tempfile);
                                        break;
                                    case IMAGETYPE_PNG:
                                        $feature_image = imagecreatefrompng($tempfile);
                                        break;
                                }
                                $x = $dst_x - ($feature->style->graphicWidth / 2);
                                $y = $dst_y - ($feature->style->graphicHeight / 2);
                                imagecopyresampled($image, $feature_image, $dst_x, $dst_y, 0, 0,$feature->style->graphicWidth, $feature->style->graphicHeight, $fwidth, $fheight);
                            } else {
                                $color_rgb = $this->hex2rgb($feature->style->fillColor);
                                if(isset($feature->style->fillOpacity)){
                                    $opacity = (1 - $feature->style->fillOpacity)*127;
                                } else {
                                    $opacity = 100;
                                }
                                $color = imagecolorallocatealpha($image, $color_rgb[0], $color_rgb[1], $color_rgb[2], $opacity);
                                $radius = $feature->style->pointRadius * 2;
                                imagefilledellipse($image, $dst_x, $dst_y, $radius, $radius, $color);
                                if(isset($feature->style->strokeWidth)){
                                    imagesetthickness($image, floatval($feature->style->strokeWidth)+1);
                                    $strokeColorRgb = $this->hex2rgb($feature->style->strokeColor);
                                    $strokeColor = imagecolorallocate($image,$strokeColorRgb[0],$strokeColorRgb[1],$strokeColorRgb[2]);
                                    $this->myimageellipse($image, $dst_x, $dst_y, $radius, $radius,$strokeColor);
                                }

                            }
                            if(isset($feature->style->label)) {
                                if ($feature->style->fontColor == "white"){
                                    $fontColor = imagecolorallocate($image, 255, 255, 255);
                                }else {
                                    $fontColor = imagecolorallocate($image, 0, 0, 0);
                                }
                                if(isset($feature->style->graphicWidth)&&isset($feature->style->graphicHeight)){
                                    $x = $dst_x -($feature->style->graphicWidth / 8);
                                    $y = $dst_y -($feature->style->graphicHeight / 4);
                                } else {
                                    $x = $dst_x - $feature->style->pointRadius/8;
                                    $y = $dst_y - $feature->style->pointRadius/4;
                                }
                                imagestring($image, 5, $x, $y, $feature->style->label, $fontColor);
                            }
                        }
                    }
                }
            }
        }
        //delete tmp files
        foreach($tmpFiles as $tmpFile){
            unlink($tmpFile);
        }

        // save to disk and tell the client where they can pick it up
        imagejpeg($image,$file,100);

        $response = new Response();
        $response->headers->set('Content-Type', "image/jpeg");
        $response->headers->set('Content-Disposition', $contentDisposition.'; filename='.$file);
        $response->headers->set('Cache-Control','max-age=60, must-revalidate');
        $response->headers->setCookie(new Cookie('fileDownload',"true",0,'/',null, false, false));

        $response->setContent(($contentDisposition == 'inline') ? base64_encode(file_get_contents($file)) : file_get_contents($file));
        $response->setStatusCode(200);

        return $response;
    }

    public function getAsynchronousAction(Request $request)
    {
        return $this->render('OruCartoBundle::carto.html.twig', array());
    }

    /*
     * Retourne une liste d'identifiants d'adresses triés par proximité d'un point d'intérêt
     * adr_ids : array la liste d'identifiants à trier
     * poi_adr_id : interger l'identifiant de l'adresse recherchée
     * poi_coord : array les coordonnées GPS de l'adresse recherchée
     */
    public function orderAction(Request $request){
        $adr_ids = $request->request->get("adr_ids");
        $poi_adr_id = $request->request->get("poi_adr_id");
        $poi_coord = $request->request->get("poi_coord");

        $distanceHelper = $this->container->get('oru_carto.helper.distance');
        $orderedResult = $distanceHelper->orderByDistance($adr_ids, $poi_adr_id, $poi_coord);

        if(count($orderedResult) != 0){
            return new JsonResponse(array(
                "adr_ids" => $orderedResult
            ));
        } else {
            return new JsonResponse("no_results",400);
        }
    }

} 