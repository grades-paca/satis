<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 20/04/2016
 * Time: 10:40
 */

use Doctrine\ORM\EntityManager;

class AddressGeocoding {

    protected $em;
    protected $ror;

    public function __construct(EntityManager $em, EntityManager $ror){
        $this->em = $em;
        $this->ror = $ror;
    }

    public function geocode(\Oru\Bundle\AddressBundle\Entity\Address $address){
        $id = $address->getId();
        /** @var \Oru\Bundle\CartoBundle\Entity\GeoAddress $geoAddress */
        $geoAddress = $this->em->getRepository('OruCartoBundle:GeoAddress')->find($id);

        if(!$geoAddress){
            return null;
        }

        $tvSpacePos = strpos($geoAddress->getGeoAdrVoie(), ' ');
        $typeVoieIN = substr($geoAddress->getGeoAdrVoie(), 0, $tvSpacePos);
        $typeVoie = $this->ror->getRepository('OruAddressBundle:LstTypeVoie')->findOneByCode(strtoupper($typeVoieIN));$
        $address->setTypeVoie($typeVoie ? $typeVoie : null);

        $voieIN = substr($geoAddress->getGeoAdrVoie(),$tvSpacePos, strlen($geoAddress->getGeoAdrVoie()) - $tvSpacePos);
        $address->setVoie($voieIN ? $voieIN : null);

        $address->setNumero($geoAddress->getGeoAdrNum());
        $address->setCode($geoAddress->getGeoAdrCp());
        $address->setCommune($geoAddress->getGeoAdrVille());

        return $address;
    }
} 