<?php

namespace Oru\Bundle\CartoBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Commune
 */
class Commune
{
    /**
     * @var string
     */
    private $idGeofla;

    /**
     * @var string
     */
    private $codeCom;

    /**
     * @var string
     */
    private $inseeCom;

    /**
     * @var string
     */
    private $nomCom;

    /**
     * @var string
     */
    private $statut;

    /**
     * @var integer
     */
    private $xChfLieu;

    /**
     * @var integer
     */
    private $yChfLieu;

    /**
     * @var integer
     */
    private $xCentroid;

    /**
     * @var integer
     */
    private $yCentroid;

    /**
     * @var integer
     */
    private $zMoyen;

    /**
     * @var integer
     */
    private $superficie;

    /**
     * @var integer
     */
    private $population;

    /**
     * @var string
     */
    private $codeCant;

    /**
     * @var string
     */
    private $codeArr;

    /**
     * @var string
     */
    private $codeDept;

    /**
     * @var string
     */
    private $nomDept;

    /**
     * @var string
     */
    private $codeReg;

    /**
     * @var string
     */
    private $nomRegion;

    /**
     * @var geometry
     */
    private $theGeom;

    /**
     * @var integer
     */
    private $id;


    /**
     * Set idGeofla
     *
     * @param string $idGeofla
     * @return Commune
     */
    public function setIdGeofla($idGeofla)
    {
        $this->idGeofla = $idGeofla;

        return $this;
    }

    /**
     * Get idGeofla
     *
     * @return string
     */
    public function getIdGeofla()
    {
        return $this->idGeofla;
    }

    /**
     * Set inseeCom
     *
     * @param string $inseeCom
     * @return Commune
     */
    public function setInseeCom($inseeCom)
    {
        $this->inseeCom = $inseeCom;

        return $this;
    }

    /**
     * Get inseeCom
     *
     * @return string
     */
    public function getInseeCom()
    {
        return $this->inseeCom;
    }

    /**
     * Set codeCom
     *
     * @param string $codeCom
     * @return Commune
     */
    public function setCodeCom($codeCom)
    {
        $this->codeCom = $codeCom;

        return $this;
    }

    /**
     * Get codeCom
     *
     * @return string
     */
    public function getCodeCom()
    {
        return $this->codeCom;
    }

    /**
     * Set nomCom
     *
     * @param string $nomCom
     * @return Commune
     */
    public function setNomCom($nomCom)
    {
        $this->nomCom = $nomCom;

        return $this;
    }

    /**
     * Get nomCom
     *
     * @return string
     */
    public function getNomCom()
    {
        return $this->nomCom;
    }

    /**
     * Set statut
     *
     * @param string $statut
     * @return Commune
     */
    public function setStatut($statut)
    {
        $this->statut = $statut;

        return $this;
    }

    /**
     * Get statut
     *
     * @return string
     */
    public function getStatut()
    {
        return $this->statut;
    }

    /**
     * Set xChfLieu
     *
     * @param integer $xChfLieu
     * @return Commune
     */
    public function setXChfLieu($xChfLieu)
    {
        $this->xChfLieu = $xChfLieu;

        return $this;
    }

    /**
     * Get xChfLieu
     *
     * @return integer
     */
    public function getXChfLieu()
    {
        return $this->xChfLieu;
    }

    /**
     * Set yChfLieu
     *
     * @param integer $yChfLieu
     * @return Commune
     */
    public function setYChfLieu($yChfLieu)
    {
        $this->yChfLieu = $yChfLieu;

        return $this;
    }

    /**
     * Get yChfLieu
     *
     * @return integer
     */
    public function getYChfLieu()
    {
        return $this->yChfLieu;
    }

    /**
     * Set xCentroid
     *
     * @param integer $xCentroid
     * @return Commune
     */
    public function setXCentroid($xCentroid)
    {
        $this->xCentroid = $xCentroid;

        return $this;
    }

    /**
     * Get xCentroid
     *
     * @return integer
     */
    public function getXCentroid()
    {
        return $this->xCentroid;
    }

    /**
     * Set yCentroid
     *
     * @param integer $yCentroid
     * @return Commune
     */
    public function setYCentroid($yCentroid)
    {
        $this->yCentroid = $yCentroid;

        return $this;
    }

    /**
     * Get yCentroid
     *
     * @return integer
     */
    public function getYCentroid()
    {
        return $this->yCentroid;
    }

    /**
     * Set zMoyen
     *
     * @param integer $zMoyen
     * @return Commune
     */
    public function setZMoyen($zMoyen)
    {
        $this->zMoyen = $zMoyen;

        return $this;
    }

    /**
     * Get zMoyen
     *
     * @return integer
     */
    public function getZMoyen()
    {
        return $this->zMoyen;
    }

    /**
     * Set superficie
     *
     * @param integer $superficie
     * @return Commune
     */
    public function setSuperficie($superficie)
    {
        $this->superficie = $superficie;

        return $this;
    }

    /**
     * Get superficie
     *
     * @return integer
     */
    public function getSuperficie()
    {
        return $this->superficie;
    }

    /**
     * Set population
     *
     * @param integer $population
     * @return Commune
     */
    public function setPopulation($population)
    {
        $this->population = $population;

        return $this;
    }

    /**
     * Get population
     *
     * @return integer
     */
    public function getPopulation()
    {
        return $this->population;
    }

    /**
     * Set codeCant
     *
     * @param string $codeCant
     * @return Commune
     */
    public function setCodeCant($codeCant)
    {
        $this->codeCant = $codeCant;

        return $this;
    }

    /**
     * Get codeCant
     *
     * @return string
     */
    public function getCodeCant()
    {
        return $this->codeCant;
    }

    /**
     * Set codeArr
     *
     * @param string $codeArr
     * @return Commune
     */
    public function setCodeArr($codeArr)
    {
        $this->codeArr = $codeArr;

        return $this;
    }

    /**
     * Get codeArr
     *
     * @return string
     */
    public function getCodeArr()
    {
        return $this->codeArr;
    }

    /**
     * Set codeDept
     *
     * @param string $codeDept
     * @return Commune
     */
    public function setCodeDept($codeDept)
    {
        $this->codeDept = $codeDept;

        return $this;
    }

    /**
     * Get codeDept
     *
     * @return string
     */
    public function getCodeDept()
    {
        return $this->codeDept;
    }

    /**
     * Set nomDept
     *
     * @param string $nomDept
     * @return Commune
     */
    public function setNomDept($nomDept)
    {
        $this->nomDept = $nomDept;

        return $this;
    }

    /**
     * Get nomDept
     *
     * @return string
     */
    public function getNomDept()
    {
        return $this->nomDept;
    }

    /**
     * Set codeReg
     *
     * @param string $codeReg
     * @return Commune
     */
    public function setCodeReg($codeReg)
    {
        $this->codeReg = $codeReg;

        return $this;
    }

    /**
     * Get codeReg
     *
     * @return string
     */
    public function getCodeReg()
    {
        return $this->codeReg;
    }

    /**
     * Set nomRegion
     *
     * @param string $nomRegion
     * @return Commune
     */
    public function setNomRegion($nomRegion)
    {
        $this->nomRegion = $nomRegion;

        return $this;
    }

    /**
     * Get nomRegion
     *
     * @return string
     */
    public function getNomRegion()
    {
        return $this->nomRegion;
    }

    /**
     * Set theGeom
     *
     * @param geometry $theGeom
     * @return Commune
     */
    public function setTheGeom($theGeom)
    {
        $this->theGeom = $theGeom;

        return $this;
    }

    /**
     * Get theGeom
     *
     * @return geometry
     */
    public function getTheGeom()
    {
        return $this->theGeom;
    }

    /**
     * Get gid
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
}