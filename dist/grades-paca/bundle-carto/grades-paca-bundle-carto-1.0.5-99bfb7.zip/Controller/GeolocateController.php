<?php
/**
 * Created by PhpStorm.
 * User: bphilippot
 * Date: 02/09/14
 * Time: 11:39
 */

namespace Oru\Bundle\CartoBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

class GeolocateController extends Controller
{

    public function showAction(Request $request)
    {
        $address_id = $request->get("address_id");

        $em = $this->getDoctrine()->getManager('pg_connection');
        $geoAddress = $em->getRepository('OruCartoBundle:GeoAddress')->find($address_id);

        $msg = $this->setFlashPrecision($geoAddress);

        $twigParameters = array(
            "geo_address" => $geoAddress
        );
        if (isset($msg)){
            $twigParameters["geocodeMessage"] = $msg;
        }
        return $this->render("OruCartoBundle:GeolocateMap:show.html.twig", $twigParameters);
    }

    public function editAction(Request $request)
    {
        $address_id = $request->get("address_id");

        $em = $this->getDoctrine()->getManager('pg_connection');
        if($address_id)
        {
            $geoAddress = $em->getRepository('OruCartoBundle:GeoAddress')->find($address_id);
        }
        else
        {
            $geoAddress = null;
        }

        $msg = $this->setFlashPrecision($geoAddress);

        $twigParameters = array(
            "form_geoaddress_json" => $request->get("address_json", 'address_geojson'),
            "form_adresse" => $request->get("form_adresse"),
            "form_numero" => $request->get("form_numero"),
            "form_numeroComplement" => $request->get("form_numeroComplement"),
            "form_typeVoie" => $request->get("form_typeVoie"),
            "form_voie" => $request->get("form_voie"),
            "form_code" => $request->get("form_code"),
            "form_commune" => $request->get("form_commune"),
        );

        if (isset($msg)){
            $msg .= ' Essayez de déplacer manuellement le point.';
            $twigParameters["geocodeMessage"] = $msg;
        }

        return $this->render("OruCartoBundle:GeolocateMap:edit.html.twig", $twigParameters);
    }

    /*
     * Affiche une notification sur la précision du positionnement de l'adresse
     */
    private function setFlashPrecision($geoAddress)
    {
        $msg = null;

        if($geoAddress) {
            $prec = $geoAddress->getPrecision();
            $niv_geocodage = $geoAddress->getNivGeocodage();
            $geocode_adr = $geoAddress->getGeocodeAdr();

            if (isset($prec) && $prec < 0.75) {
                $msg = sprintf('Cet établissement est sûrement positionné approximativement (précision du géocodage %.2f / 1) : %s', $prec, $geocode_adr);
            } elseif (isset($niv_geocodage) && $niv_geocodage == 'Street' || $niv_geocodage == 'City') {
                ($niv_geocodage == 'Street') ? $niveau = 'la rue' : $niveau = 'la ville';
                $msg = sprintf('Cet établissement est positionné approximativement au niveau de %s : %s', $niveau, $geocode_adr);
            }
        }
        return $msg;
    }

    public function geocodeAction(Request $request)
    {
        if($request->request->has('voie')){
            $voie = $request->request->get('voie');
            $cp = $request->request->get('cp');
            $ville = $request->request->get('ville');
        } else {
            return new JsonResponse('Aucune adresse rentrée', 400);
        }

        $ignHelper = $this->container->get('oru_carto.helper.ign');
        $ville = $ignHelper->correctCity($ville);
        $adresse = $voie . " " . $cp . " " . $ville;

        $res = $ignHelper->geocodeAdresse($adresse);

        if(isset($res['error'])){
            return new JsonResponse($res['error'],400);
        } else {
            return new JsonResponse(json_encode($res));
        }
    }

} 