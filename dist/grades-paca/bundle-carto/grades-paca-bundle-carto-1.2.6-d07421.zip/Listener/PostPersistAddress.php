<?php

namespace Oru\Bundle\CartoBundle\Listener;

use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\LifecycleEventArgs;
use Oru\Bundle\AddressBundle\Entity\Address;
use Oru\Bundle\CartoBundle\Entity\GeoAddress;
use Oru\Bundle\CartoBundle\Event\SynchroNowEvent;
use Oru\Bundle\SpoolBundle\Entity\Spool;
use Oru\Bundle\SpoolBundle\Event\Events;
use Oru\Bundle\SpoolBundle\Event\SpoolEvent;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;

/**
 * Class PostPersistAddress
 * @package Oru\Bundle\CartoBundle\Listener
 * @author Michaël VEROUX
 */
class PostPersistAddress implements EventSubscriber
{
    const SYNCHRONIZER_SERVICE = 'oru_carto.geo_address_synchro';
    /**
     * @var EventDispatcherInterface
     */
    protected $eventDispatcher;

    /**
     * @var bool
     */
    protected $enabled = true;

    /**
     * @param EventDispatcherInterface $eventDispatcher
     * @param $disabledBundles
     */
    public function __construct(EventDispatcherInterface $eventDispatcher, $disabledBundles)
    {
        $this->eventDispatcher = $eventDispatcher;
        if(is_array($disabledBundles) && in_array('OruCartoBundle', $disabledBundles))
        {
            $this->enabled = false;
        }
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    public function getSubscribedEvents()
    {
        return array(
            'postPersist',
            'postUpdate',
        );
    }

    /**
     * @param LifecycleEventArgs $eventArgs
     * @author Michaël VEROUX
     */
    public function postUpdate(LifecycleEventArgs $eventArgs)
    {
        if(!$this->enabled)
        {
            return;
        }

        $entity = $eventArgs->getEntity();

        if(!$entity instanceof Address && !$entity instanceof GeoAddress)
        {
            return;
        }

        if($entity instanceof Address && $entity->getCarto() && !$entity->getCarto()->getId())
        {
            $eventSynchro = new SynchroNowEvent($entity);
            $this->eventDispatcher->dispatch(\Oru\Bundle\CartoBundle\Event\Events::SYNCHRO_NOW, $eventSynchro);
        }

        $event = new SpoolEvent(static::SYNCHRONIZER_SERVICE);
        $event->setServiceCalls(array(
                'synchro'   =>  array((int)$entity->getId()),
            )
        );
        $event->setPriority(Spool::PRIORITY_VERY_LOW);

        $this->eventDispatcher->dispatch(Events::SPOOL_ADD, $event);
    }

    /**
     * @param LifecycleEventArgs $args
     * @author Michaël VEROUX
     */
    public function postPersist(LifecycleEventArgs $args)
    {
        $this->postUpdate($args);
    }
}