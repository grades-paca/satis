<?php
/**
 * Created by PhpStorm.
 * User: bphilippot
 * Date: 22/07/14
 * Time: 09:58
 */

namespace Oru\Bundle\CartoBundle\Twig\Extension;

use CrEOF\Geo\WKB\Parser;
use CrEOF\Spatial\PHP\Types\Geometry\Polygon;
use Symfony\Component\Config\ConfigCache;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Filesystem\Filesystem;

class MapExtension extends \Twig_Extension implements \Twig_Extension_GlobalsInterface
{
    protected $container;

    protected $options;

    public function __construct(ContainerInterface $container, $options)
    {
        $this->container = $container;
        if (PHP_SAPI == 'cli') {
            $this->container->enterScope('request');
            $this->container->set('request', new Request(), 'request');
        }

        $this->options = array(
            'cache_dir' => null,
        );

        if ($diff = array_diff(array_keys($options), array_keys($this->options))) {
            throw new \InvalidArgumentException(sprintf('The Carto MapExtension does not support the following options: \'%s\'.', implode('\', \'', $diff)));
        }

        $this->options = array_merge($this->options, $options);
    }

    public function getName(){
        return 'map_extension';
    }

    /*
     * Retrieve apiIgnKey from application settings and hostname
     */
    public function getGlobals()
    {
        $cacheDataMap = new ConfigCache($this->options['cache_dir'].'/data.map', false);
        if(!$cacheDataMap->isFresh()) {
            $mapFile = ms_newMapObj(__DIR__."/../../Mapfile/data.map");
            for ($i = 0; $i < $mapFile->numlayers; $i++) {
                $layer = $mapFile->getLayer($i);
                $pgHost = $this->container->getParameter("database2_host");
                $pgPort = $this->container->getParameter("database2_port");
                $pgUser = $this->container->getParameter("database2_user");
                $pgDb = $this->container->getParameter("database2_name");
                $pgPassword = $this->container->getParameter("database2_password");
                $layer->set("connection", "user=" . $pgUser . " password=" . $pgPassword . " dbname=" . $pgDb . " host=" . $pgHost . " port=" . $pgPort);
                switch ($layer->name) {
                    case "dept":
                        $deptTable = $this->container->get('doctrine')->getManager('pg_connection')->getClassMetadata('OruCartoBundle:Dept')->getTableName();
                        $deptGeom = $this->container->get('doctrine')->getManager('pg_connection')->getClassMetadata('OruCartoBundle:Dept')->getColumnName('theGeom');
                        $layer->set('data', $deptGeom . " FROM " . $deptTable . " USING UNIQUE gid USING srid=3857");
                        break;
                    case "region":
                        $regionTable = $this->container->get('doctrine')->getManager('pg_connection')->getClassMetadata('OruCartoBundle:Region')->getTableName();
                        $regionGeom = $this->container->get('doctrine')->getManager('pg_connection')->getClassMetadata('OruCartoBundle:Region')->getColumnName('theGeom');
                        $layer->set('data', $regionGeom . " FROM " . $regionTable . " USING UNIQUE code_reg USING srid=3857");
                        break;
                    case "adresses":
                        $adrTable = $this->container->get('doctrine')->getManager('pg_connection')->getClassMetadata('OruCartoBundle:GeoAddress')->getTableName();
                        $adrGeom = $this->container->get('doctrine')->getManager('pg_connection')->getClassMetadata('OruCartoBundle:GeoAddress')->getColumnName('theGeom');
                        $layer->set('data', $adrGeom . " FROM " . $adrTable . " USING UNIQUE id USING srid=4326");
                        break;
                }

            }
            $logPath = $this->container->getParameter('kernel.logs_dir') . "/";
            $mapFile->metadata->set("ows_service_onlineresource", "/bundles/orucarto/cgi-bin/mapserv.cgi?map=" . $this->options['cache_dir'] . "/data.map");
            $mapFile->setconfigoption("MS_ERRORFILE", $logPath . "mapserver.log");
            $mapFile->web->set("imagepath", $logPath);
            $mapFile->web->set("imageurl", $logPath);

            if(ms_GetVersionInt() < 60400){
                $fileSystem = new Filesystem();
                if(!$fileSystem->exists($this->options['cache_dir']))
                {
                    $fileSystem->mkdir($this->options['cache_dir'], 0775);
                }
                $mapFile->save($this->options['cache_dir'].'/data.map');
            } else {
                $cacheDataMap->write($mapFile->convertToString());
            }
        }

        $cache = new ConfigCache($this->options['cache_dir'].'/map-extension.php', false);

        if($cache->isFresh())
        {
            $cartoVars = include $cache;
        }
        if (!$cache->isFresh() || $cartoVars["uriPrefix"] == '')
        {
            // Retrieve the Request object form the container and get the hostname
            $hostname = $this->container->get('request')->getHost();

            $uriPrefix = $hostname . $this->container->get('request')->getBaseUrl();
            $apiIgnKey = "";
            $api_keys = $this->container->get('oru_setting')->setting('api_ign_key', 'OruCartoBundle');
            if(count($api_keys) != 0){
                foreach($api_keys as $key => $val){
                    $keyUrl = str_replace("http://","",$key);
                    $keyUrl = str_replace("https://","",$keyUrl);
                    //si l'index du tableau de clé correspond à l'hostname, on récupère la clé
                    if(stripos($hostname,$keyUrl) !== false)
                        $apiIgnKey = $val;
                }
            }

            $code_reg = null;
            //extent de la France
            $xMin = -1953634.155686;
            $yMin = 5114605.5846931;
            $xMax = 2639925.4955005;
            $yMax = 6777875.3199471;
            if($this->container->hasParameter("code_insee_region")){
                $code_reg = $this->container->getParameter("code_insee_region");
                $rp = $this->container->get('doctrine')->getRepository("OruCartoBundle:Region",'pg_connection');
                $centroidQuery = $rp->createQueryBuilder('r')
                    ->select('ST_Envelope(r.theGeom)')
                    ->where('r.codeReg = :code_reg')
                    ->setParameter('code_reg',$code_reg)
                    ->getQuery();
                $centroidResult = $centroidQuery->getResult();
                if (!empty($centroidResult)){
                    $envelopeGeom= $centroidResult[0][1];
                    $envelopeGeom    = pack('H*', $envelopeGeom);
                    $parser   = new Parser($envelopeGeom);
                    $envelopePolygon = new Polygon($parser->parse()["value"]);
                    $envelope = $envelopePolygon->toArray();

                    $bb0 = $envelope[0][0];
                    $bb1 = $envelope[0][1];
                    $bb2 = $envelope[0][2];
                    $bb3 = $envelope[0][3];
                    $bb0[0] < $bb1[0] ? $xMin = $bb0[0] : $xMin = $bb1[0];
                    $bb0[1] < $bb3[1] ? $yMin = $bb0[1] : $yMin = $bb3[1];
                    $bb2[0] < $bb3[0] ? $xMax = $bb2[0] : $xMax = $bb3[0];
                    $bb1[1] < $bb2[1] ? $yMax = $bb1[1] : $yMax = $bb2[1];
                }
            }

            $cartoVars = array(
                'apiIgnKey' => $apiIgnKey,
                'uriPrefix' => $uriPrefix,
                'mapfilePath' => $this->options['cache_dir']."/data.map",
                'code_reg'  => $code_reg,
                'xMin'      => $xMin,
                'yMin'      => $yMin,
                'xMax'      => $xMax,
                'yMax'      => $yMax,
            );

            $content = sprintf(<<<EOF
<?php

\$cartoVars = %s;

return \$cartoVars;

EOF
            , var_export($cartoVars, true)
            );
            $cache->write($content);
        }

        return $cartoVars;
    }

}