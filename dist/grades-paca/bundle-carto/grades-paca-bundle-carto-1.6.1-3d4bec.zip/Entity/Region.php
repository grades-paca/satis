<?php

namespace Oru\Bundle\CartoBundle\Entity;

/**
 * Region.
 */
class Region
{
    /**
     * @var string
     */
    private $codeReg;

    /**
     * @var string
     */
    private $nomReg;

    /**
     * @var geometry
     */
    private $theGeom;

    /**
     * Set codeReg.
     *
     * @param string $codeReg
     *
     * @return Region
     */
    public function setCodeReg($codeReg)
    {
        $this->codeReg = $codeReg;

        return $this;
    }

    /**
     * Get codeReg.
     *
     * @return string
     */
    public function getCodeReg()
    {
        return $this->codeReg;
    }

    /**
     * Set nomReg.
     *
     * @param string $nomReg
     *
     * @return Region
     */
    public function setNomReg($nomReg)
    {
        $this->nomReg = $nomReg;

        return $this;
    }

    /**
     * Get nomReg.
     *
     * @return string
     */
    public function getNomReg()
    {
        return $this->nomReg;
    }

    /**
     * Set theGeom.
     *
     * @param geometry $theGeom
     *
     * @return Region
     */
    public function setTheGeom($theGeom)
    {
        $this->theGeom = $theGeom;

        return $this;
    }

    /**
     * Get theGeom.
     *
     * @return geometry
     */
    public function getTheGeom()
    {
        return $this->theGeom;
    }
}
