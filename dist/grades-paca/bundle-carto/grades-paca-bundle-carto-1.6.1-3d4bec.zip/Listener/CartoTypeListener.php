<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\CartoBundle\Listener;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\AddressBundle\Entity\Address;
use Oru\Bundle\CartoBundle\Entity\GeoAddress;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;

class CartoTypeListener implements EventSubscriberInterface
{
    /**
     * @var EntityManager
     */
    private $entityManager;

    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    public static function getSubscribedEvents()
    {
        return array(
            FormEvents::PRE_SET_DATA => 'onPreSetData',
            FormEvents::POST_SUBMIT => 'onPostSubmit',
        );
    }

    public function onPreSetData(FormEvent $event)
    {
        $data = $event->getData();
        $form = $event->getForm();
        $carto = null;
        $id = null;

        if ($data instanceof Address) {
            $id = $data->getId();
            $carto = $this->entityManager->getRepository('OruCartoBundle:GeoAddress')->find($id);
        }

        if (!$carto) {
            $carto = new GeoAddress();
            $carto->setId($id);
            if ($id) {
                $this->entityManager->persist($carto);
            }
        }

        $form->add('carto', 'oru_carto', array('label' => 'Address.cartographie', 'translation_domain' => 'OruAddressBundle', 'data' => $carto));
    }

    public function onPostSubmit(FormEvent $event)
    {
        $data = $event->getData();

        if ($data && $data instanceof Address && $this->entityManager->contains($data->getCarto())) {
            $this->entityManager->flush($data->getCarto());
        }
    }
}
