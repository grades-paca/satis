<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 16/01/14
 * Time: 10:57
 */

namespace Oru\Bundle\CartoBundle\DependencyInjection\Compiler;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class FormPass implements CompilerPassInterface
{
    /**
     * You can modify the container here before it is dumped to PHP code.
     *
     * @param ContainerBuilder $container
     *
     * @api
     */
    public function process(ContainerBuilder $container)
    {
        $resources = $container->getParameter('twig.form.resources');
        $resources[] = 'OruCartoBundle:Form:carto_layout.html.twig';
        $container->setParameter('twig.form.resources', $resources);
    }
}