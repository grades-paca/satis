<?php

namespace Oru\Bundle\CartoBundle\Listener;

use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\LifecycleEventArgs;
use Oru\Bundle\AddressBundle\Entity\Address;
use Oru\Bundle\CartoBundle\Entity\GeoAddress;
use Oru\Bundle\CartoBundle\Event\SynchroNowEvent;
use Oru\Bundle\TaskBundle\Entity\Task;
use Oru\Bundle\TaskBundle\Event\Events;
use Oru\Bundle\TaskBundle\Event\PushEvent;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;

/**
 * Class PostPersistAddress.
 *
 * @author Michaël VEROUX
 */
class PostPersistAddress implements EventSubscriber
{
    const SYNCHRONIZER_SERVICE = 'oru_carto.geo_address_synchro';
    /**
     * @var EventDispatcherInterface
     */
    protected $eventDispatcher;

    /**
     * @var bool
     */
    protected $enabled = true;

    /**
     * @param EventDispatcherInterface $eventDispatcher
     * @param $disabledBundles
     */
    public function __construct(EventDispatcherInterface $eventDispatcher, $disabledBundles)
    {
        $this->eventDispatcher = $eventDispatcher;
        if (is_array($disabledBundles) && in_array('OruCartoBundle', $disabledBundles, true)) {
            $this->enabled = false;
        }
    }

    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function getSubscribedEvents()
    {
        return array(
            'postPersist',
            'postUpdate',
        );
    }

    /**
     * @param LifecycleEventArgs $eventArgs
     *
     * @author Michaël VEROUX
     */
    public function postUpdate(LifecycleEventArgs $eventArgs)
    {
        if (!$this->enabled) {
            return;
        }

        $entity = $eventArgs->getEntity();

        if (!$entity instanceof Address && !$entity instanceof GeoAddress) {
            return;
        }

        if ($entity instanceof Address && $entity->getCarto() && !$entity->getCarto()->getId()) {
            $eventSynchro = new SynchroNowEvent($entity);
            $this->eventDispatcher->dispatch(\Oru\Bundle\CartoBundle\Event\Events::SYNCHRO_NOW, $eventSynchro);
        }

        $serviceCalls = array(
            'synchro' => array((int) $entity->getId()),
        );
        $event = new PushEvent(static::SYNCHRONIZER_SERVICE, $serviceCalls, Task::PRIORITY_VERY_LOW);

        $this->eventDispatcher->dispatch(Events::QUEUE_PUSH, $event);
    }

    /**
     * @param LifecycleEventArgs $args
     *
     * @author Michaël VEROUX
     */
    public function postPersist(LifecycleEventArgs $args)
    {
        $this->postUpdate($args);
    }
}
