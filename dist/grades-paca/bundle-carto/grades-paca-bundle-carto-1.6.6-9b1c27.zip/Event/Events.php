<?php
/**
 * Author: Michaël VEROUX
 * Date: 03/03/15
 * Time: 10:21
 */

namespace Oru\Bundle\CartoBundle\Event;

final class Events
{
    const SYNCHRO_NOW = 'carto.synchro.now';
}
