<?php
/**
 * Author: Michaël VEROUX
 * Date: 03/03/15
 * Time: 10:22
 */

namespace Oru\Bundle\CartoBundle\Event;

use Oru\Bundle\AddressBundle\Entity\Address;
use Symfony\Component\EventDispatcher\Event;

/**
 * Class SynchroNowEvent.
 *
 * @author Michaël VEROUX
 */
class SynchroNowEvent extends Event
{
    /**
     * @var Address
     */
    protected $address;

    /**
     * @param Address $address
     */
    public function __construct(Address $address)
    {
        $this->address = $address;
    }

    /**
     * @return \Oru\Bundle\AddressBundle\Entity\Address
     */
    public function getAddress()
    {
        return $this->address;
    }
}
