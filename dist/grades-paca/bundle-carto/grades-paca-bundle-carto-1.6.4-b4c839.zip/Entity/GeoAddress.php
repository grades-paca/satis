<?php

namespace Oru\Bundle\CartoBundle\Entity;

use CrEOF\Spatial\PHP\Types\Geometry\Point;
use Doctrine\Common\Inflector\Inflector;

/**
 * GeoAddress.
 */
class GeoAddress
{
    /**
     * @var array
     */
    private $jsonProperties = array(
        'niv_geocodage',
        'precision',
        'geocode_adr',
        'geoadr_num',
        'geoadr_voie',
        'geoadr_cp',
        'geoadr_ville',
        'geoadr_insee',
        'lng',
        'lat',
    );

    /**
     * @var string
     */
    private $adr;

    /**
     * @var string
     */
    private $cp;

    /**
     * @var string
     */
    private $ville;

    /**
     * @var float
     */
    private $precision;

    /**
     * @var string
     */
    private $geocodeAdr;

    /**
     * @var string
     */
    private $geoAdrNum;

    /**
     * @var string
     */
    private $geoAdrVoie;

    /**
     * @var string
     */
    private $geoAdrCp;

    /**
     * @var string
     */
    private $geoAdrVille;

    /**
     * @var string
     */
    private $geoAdrInsee;

    /**
     * @var string
     */
    private $nivGeocodage;

    /**
     * @var string
     */
    private $lng;

    /**
     * @var string
     */
    private $lat;

    /**
     * @var geometry
     */
    private $theGeom;

    /**
     * @var string
     */
    private $json;

    /**
     * @var int
     */
    private $id;

    /**
     * Set adr.
     *
     * @param string $adr
     *
     * @return GeoAddress
     */
    public function setAdr($adr)
    {
        $this->adr = $adr;

        return $this;
    }

    /**
     * Get adr.
     *
     * @return string
     */
    public function getAdr()
    {
        return $this->adr;
    }

    /**
     * Set cp.
     *
     * @param string $cp
     *
     * @return GeoAddress
     */
    public function setCp($cp)
    {
        $this->cp = $cp;

        return $this;
    }

    /**
     * Get cp.
     *
     * @return string
     */
    public function getCp()
    {
        return $this->cp;
    }

    /**
     * Set ville.
     *
     * @param string $ville
     *
     * @return GeoAddress
     */
    public function setVille($ville)
    {
        $this->ville = $ville;

        return $this;
    }

    /**
     * Get ville.
     *
     * @return string
     */
    public function getVille()
    {
        return $this->ville;
    }

    /**
     * Set precision.
     *
     * @param float $precision
     *
     * @return GeoAddress
     */
    public function setPrecision($precision)
    {
        $this->precision = $precision;

        return $this;
    }

    /**
     * Get precision.
     *
     * @return float
     */
    public function getPrecision()
    {
        return $this->precision;
    }

    /**
     * Set geocodeAdr.
     *
     * @param string $geocodeAdr
     *
     * @return GeoAddress
     */
    public function setGeocodeAdr($geocodeAdr)
    {
        $this->geocodeAdr = $geocodeAdr;

        return $this;
    }

    /**
     * Get geocodeAdr.
     *
     * @return string
     */
    public function getGeocodeAdr()
    {
        return $this->geocodeAdr;
    }

    /**
     * Set geoAdrNum.
     *
     * @param string $geoAdrNum
     *
     * @return GeoAddress
     */
    public function setGeoAdrNum($geoAdrNum)
    {
        $this->geoAdrNum = $geoAdrNum;

        return $this;
    }

    /**
     * Get geoAdrNum.
     *
     * @return string
     */
    public function getGeoAdrNum()
    {
        return $this->geoAdrNum;
    }

    /**
     * Set geoAdrVoie.
     *
     * @param string $geoAdrVoie
     *
     * @return GeoAddress
     */
    public function setGeoAdrVoie($geoAdrVoie)
    {
        $this->geoAdrVoie = $geoAdrVoie;

        return $this;
    }

    /**
     * Get geoAdrVoie.
     *
     * @return string
     */
    public function getGeoAdrVoie()
    {
        return $this->geoAdrVoie;
    }

    /**
     * Set geoAdrCp.
     *
     * @param string $geoAdrCp
     *
     * @return GeoAddress
     */
    public function setGeoAdrCp($geoAdrCp)
    {
        $this->geoAdrCp = $geoAdrCp;

        return $this;
    }

    /**
     * Get geoAdrCp.
     *
     * @return string
     */
    public function getGeoAdrCp()
    {
        return $this->geoAdrCp;
    }

    /**
     * Set geoAdrVille.
     *
     * @param string $geoAdrVille
     *
     * @return GeoAddress
     */
    public function setGeoAdrVille($geoAdrVille)
    {
        $this->geoAdrVille = $geoAdrVille;

        return $this;
    }

    /**
     * Get geoAdrVille.
     *
     * @return string
     */
    public function getGeoAdrVille()
    {
        return $this->geoAdrVille;
    }

    /**
     * Set geoAdrInsee.
     *
     * @param string $geoAdrInsee
     *
     * @return GeoAddress
     */
    public function setGeoAdrInsee($geoAdrInsee)
    {
        $this->geoAdrInsee = $geoAdrInsee;

        return $this;
    }

    /**
     * Get geoAdrInsee.
     *
     * @return string
     */
    public function getGeoAdrInsee()
    {
        return $this->geoAdrInsee;
    }

    /**
     * Set nivGeocodage.
     *
     * @param string $nivGeocodage
     *
     * @return GeoAddress
     */
    public function setNivGeocodage($nivGeocodage)
    {
        $this->nivGeocodage = $nivGeocodage;

        return $this;
    }

    /**
     * Get nivGeocodage.
     *
     * @return string
     */
    public function getNivGeocodage()
    {
        return $this->nivGeocodage;
    }

    /**
     * Set lng.
     *
     * @param string $lng
     *
     * @return GeoAddress
     */
    public function setLng($lng)
    {
        $this->lng = $lng;

        return $this;
    }

    /**
     * Get lng.
     *
     * @return string
     */
    public function getLng()
    {
        return $this->lng;
    }

    /**
     * Set lat.
     *
     * @param string $lat
     *
     * @return GeoAddress
     */
    public function setLat($lat)
    {
        $this->lat = $lat;

        return $this;
    }

    /**
     * Get lat.
     *
     * @return string
     */
    public function getLat()
    {
        return $this->lat;
    }

    /**
     * Set theGeom.
     *
     * @param geometry $theGeom
     *
     * @return GeoAddress
     */
    public function setTheGeom($theGeom)
    {
        $this->theGeom = $theGeom;

        return $this;
    }

    /**
     * Get theGeom.
     *
     * @return geometry
     */
    public function getTheGeom()
    {
        return $this->theGeom;
    }

    /**
     * Set id.
     *
     * @param int $id
     *
     * @return GeoAddress
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param string $json
     *
     * @return $this
     */
    public function setJson($json)
    {
        $this->json = $json;

        $jsonObject = json_decode($this->json);

        if (!$jsonObject instanceof \stdClass) {
            return $this;
        }

        if (!property_exists($jsonObject, 'properties')) {
            return $this;
        }

        $jsonProperties = $jsonObject->properties;

        foreach ($this->jsonProperties as $property) {
            if (property_exists($jsonProperties, $property)) {
                $setter = sprintf('set%s', ucfirst(Inflector::camelize($property)));
                if (method_exists($this, $setter)) {
                    $this->$setter($jsonProperties->{$property});
                }
            }
        }

        if (empty($jsonProperties->lng) or empty($jsonProperties->lat)) {
            return $this;
        }

        $point = new Point($jsonProperties->lng, $jsonProperties->lat, 4326);
        $this->setTheGeom($point);

        return $this;
    }

    /**
     * @return string
     */
    public function getJson()
    {
        if (!$this->json) {
            $properties = new \stdClass();
            foreach ($this->jsonProperties as $property) {
                $getter = sprintf('get%s', ucfirst(Inflector::camelize($property)));
                if (method_exists($this, $getter)) {
                    $properties->{$property} = $this->$getter();
                }
            }
            $json = new \stdClass();
            $json->properties = $properties;

            $this->json = json_encode($json);
        }

        return $this->json;
    }
}
