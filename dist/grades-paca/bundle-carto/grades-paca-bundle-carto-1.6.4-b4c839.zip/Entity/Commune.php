<?php

namespace Oru\Bundle\CartoBundle\Entity;

/**
 * Commune.
 */
class Commune
{
    /**
     * @var string
     */
    private $idGeofla;

    /**
     * @var string
     */
    private $codeCom;

    /**
     * @var string
     */
    private $inseeCom;

    /**
     * @var string
     */
    private $nomCom;

    /**
     * @var string
     */
    private $statut;

    /**
     * @var int
     */
    private $xChfLieu;

    /**
     * @var int
     */
    private $yChfLieu;

    /**
     * @var int
     */
    private $xCentroid;

    /**
     * @var int
     */
    private $yCentroid;

    /**
     * @var int
     */
    private $zMoyen;

    /**
     * @var int
     */
    private $superficie;

    /**
     * @var int
     */
    private $population;

    /**
     * @var string
     */
    private $codeCant;

    /**
     * @var string
     */
    private $codeArr;

    /**
     * @var string
     */
    private $codeDept;

    /**
     * @var string
     */
    private $nomDept;

    /**
     * @var string
     */
    private $codeReg;

    /**
     * @var string
     */
    private $nomRegion;

    /**
     * @var geometry
     */
    private $theGeom;

    /**
     * @var int
     */
    private $id;

    /**
     * Set idGeofla.
     *
     * @param string $idGeofla
     *
     * @return Commune
     */
    public function setIdGeofla($idGeofla)
    {
        $this->idGeofla = $idGeofla;

        return $this;
    }

    /**
     * Get idGeofla.
     *
     * @return string
     */
    public function getIdGeofla()
    {
        return $this->idGeofla;
    }

    /**
     * Set inseeCom.
     *
     * @param string $inseeCom
     *
     * @return Commune
     */
    public function setInseeCom($inseeCom)
    {
        $this->inseeCom = $inseeCom;

        return $this;
    }

    /**
     * Get inseeCom.
     *
     * @return string
     */
    public function getInseeCom()
    {
        return $this->inseeCom;
    }

    /**
     * Set codeCom.
     *
     * @param string $codeCom
     *
     * @return Commune
     */
    public function setCodeCom($codeCom)
    {
        $this->codeCom = $codeCom;

        return $this;
    }

    /**
     * Get codeCom.
     *
     * @return string
     */
    public function getCodeCom()
    {
        return $this->codeCom;
    }

    /**
     * Set nomCom.
     *
     * @param string $nomCom
     *
     * @return Commune
     */
    public function setNomCom($nomCom)
    {
        $this->nomCom = $nomCom;

        return $this;
    }

    /**
     * Get nomCom.
     *
     * @return string
     */
    public function getNomCom()
    {
        return $this->nomCom;
    }

    /**
     * Set statut.
     *
     * @param string $statut
     *
     * @return Commune
     */
    public function setStatut($statut)
    {
        $this->statut = $statut;

        return $this;
    }

    /**
     * Get statut.
     *
     * @return string
     */
    public function getStatut()
    {
        return $this->statut;
    }

    /**
     * Set xChfLieu.
     *
     * @param int $xChfLieu
     *
     * @return Commune
     */
    public function setXChfLieu($xChfLieu)
    {
        $this->xChfLieu = $xChfLieu;

        return $this;
    }

    /**
     * Get xChfLieu.
     *
     * @return int
     */
    public function getXChfLieu()
    {
        return $this->xChfLieu;
    }

    /**
     * Set yChfLieu.
     *
     * @param int $yChfLieu
     *
     * @return Commune
     */
    public function setYChfLieu($yChfLieu)
    {
        $this->yChfLieu = $yChfLieu;

        return $this;
    }

    /**
     * Get yChfLieu.
     *
     * @return int
     */
    public function getYChfLieu()
    {
        return $this->yChfLieu;
    }

    /**
     * Set xCentroid.
     *
     * @param int $xCentroid
     *
     * @return Commune
     */
    public function setXCentroid($xCentroid)
    {
        $this->xCentroid = $xCentroid;

        return $this;
    }

    /**
     * Get xCentroid.
     *
     * @return int
     */
    public function getXCentroid()
    {
        return $this->xCentroid;
    }

    /**
     * Set yCentroid.
     *
     * @param int $yCentroid
     *
     * @return Commune
     */
    public function setYCentroid($yCentroid)
    {
        $this->yCentroid = $yCentroid;

        return $this;
    }

    /**
     * Get yCentroid.
     *
     * @return int
     */
    public function getYCentroid()
    {
        return $this->yCentroid;
    }

    /**
     * Set zMoyen.
     *
     * @param int $zMoyen
     *
     * @return Commune
     */
    public function setZMoyen($zMoyen)
    {
        $this->zMoyen = $zMoyen;

        return $this;
    }

    /**
     * Get zMoyen.
     *
     * @return int
     */
    public function getZMoyen()
    {
        return $this->zMoyen;
    }

    /**
     * Set superficie.
     *
     * @param int $superficie
     *
     * @return Commune
     */
    public function setSuperficie($superficie)
    {
        $this->superficie = $superficie;

        return $this;
    }

    /**
     * Get superficie.
     *
     * @return int
     */
    public function getSuperficie()
    {
        return $this->superficie;
    }

    /**
     * Set population.
     *
     * @param int $population
     *
     * @return Commune
     */
    public function setPopulation($population)
    {
        $this->population = $population;

        return $this;
    }

    /**
     * Get population.
     *
     * @return int
     */
    public function getPopulation()
    {
        return $this->population;
    }

    /**
     * Set codeCant.
     *
     * @param string $codeCant
     *
     * @return Commune
     */
    public function setCodeCant($codeCant)
    {
        $this->codeCant = $codeCant;

        return $this;
    }

    /**
     * Get codeCant.
     *
     * @return string
     */
    public function getCodeCant()
    {
        return $this->codeCant;
    }

    /**
     * Set codeArr.
     *
     * @param string $codeArr
     *
     * @return Commune
     */
    public function setCodeArr($codeArr)
    {
        $this->codeArr = $codeArr;

        return $this;
    }

    /**
     * Get codeArr.
     *
     * @return string
     */
    public function getCodeArr()
    {
        return $this->codeArr;
    }

    /**
     * Set codeDept.
     *
     * @param string $codeDept
     *
     * @return Commune
     */
    public function setCodeDept($codeDept)
    {
        $this->codeDept = $codeDept;

        return $this;
    }

    /**
     * Get codeDept.
     *
     * @return string
     */
    public function getCodeDept()
    {
        return $this->codeDept;
    }

    /**
     * Set nomDept.
     *
     * @param string $nomDept
     *
     * @return Commune
     */
    public function setNomDept($nomDept)
    {
        $this->nomDept = $nomDept;

        return $this;
    }

    /**
     * Get nomDept.
     *
     * @return string
     */
    public function getNomDept()
    {
        return $this->nomDept;
    }

    /**
     * Set codeReg.
     *
     * @param string $codeReg
     *
     * @return Commune
     */
    public function setCodeReg($codeReg)
    {
        $this->codeReg = $codeReg;

        return $this;
    }

    /**
     * Get codeReg.
     *
     * @return string
     */
    public function getCodeReg()
    {
        return $this->codeReg;
    }

    /**
     * Set nomRegion.
     *
     * @param string $nomRegion
     *
     * @return Commune
     */
    public function setNomRegion($nomRegion)
    {
        $this->nomRegion = $nomRegion;

        return $this;
    }

    /**
     * Get nomRegion.
     *
     * @return string
     */
    public function getNomRegion()
    {
        return $this->nomRegion;
    }

    /**
     * Set theGeom.
     *
     * @param geometry $theGeom
     *
     * @return Commune
     */
    public function setTheGeom($theGeom)
    {
        $this->theGeom = $theGeom;

        return $this;
    }

    /**
     * Get theGeom.
     *
     * @return geometry
     */
    public function getTheGeom()
    {
        return $this->theGeom;
    }

    /**
     * Get gid.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }
}
