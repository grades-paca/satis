<?php
/**
 * Created by PhpStorm.
 * User: bphilippot
 * Date: 22/07/14
 * Time: 10:38
 */

namespace Oru\Bundle\CartoBundle\DependencyInjection;

use Symfony\Component\Config\Definition\Builder\TreeBuilder;
use Symfony\Component\Config\Definition\ConfigurationInterface;

class Configuration implements ConfigurationInterface
{
    public function getConfigTreeBuilder()
    {
        $treeBuilder = new TreeBuilder();
        $root_node = $treeBuilder->root('oru_carto');

        /*$root_node->children()
            ->scalarNode("api_key")->defaultValue("")->end()
            ->scalarNode("referer")->defaultValue("")->end()
            ->end();*/

        return $treeBuilder;
    }
}