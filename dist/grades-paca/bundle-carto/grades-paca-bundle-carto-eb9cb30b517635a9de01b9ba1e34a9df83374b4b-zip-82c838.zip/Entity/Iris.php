<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 21/06/2016
 * Time: 10:02
 */

namespace Oru\Bundle\CartoBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

class Iris
{
    private $id;
    private $theGeom;
    private $depcom;
    private $nomCom;
    private $iris;
    private $nomIris;
    private $typeIris;
    private $origin;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getOrigin()
    {
        return $this->origin;
    }

    /**
     * @param mixed $origin
     */
    public function setOrigin($origin)
    {
        $this->origin = $origin;
    }

    /**
     * @return mixed
     */
    public function getTheGeom()
    {
        return $this->theGeom;
    }

    /**
     * @param mixed $theGeom
     */
    public function setTheGeom($theGeom)
    {
        $this->theGeom = $theGeom;
    }

    /**
     * @return mixed
     */
    public function getDepcom()
    {
        return $this->depcom;
    }

    /**
     * @param mixed $depcom
     */
    public function setDepcom($depcom)
    {
        $this->depcom = $depcom;
    }

    /**
     * @return mixed
     */
    public function getNomCom()
    {
        return $this->nomCom;
    }

    /**
     * @param mixed $nomCom
     */
    public function setNomCom($nomCom)
    {
        $this->nomCom = $nomCom;
    }

    /**
     * @return mixed
     */
    public function getIris()
    {
        return $this->iris;
    }

    /**
     * @param mixed $iris
     */
    public function setIris($iris)
    {
        $this->iris = $iris;
    }

    /**
     * @return mixed
     */
    public function getNomIris()
    {
        return $this->nomIris;
    }

    /**
     * @param mixed $nomIris
     */
    public function setNomIris($nomIris)
    {
        $this->nomIris = $nomIris;
    }

    /**
     * @return mixed
     */
    public function getTypeIris()
    {
        return $this->typeIris;
    }

    /**
     * @param mixed $typeIris
     */
    public function setTypeIris($typeIris)
    {
        $this->typeIris = $typeIris;
    }
}