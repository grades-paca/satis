<?php
/**
 * Created by PhpStorm.
 * User: bphilippot
 * Date: 10/07/14
 * Time: 11:12
 */
namespace Oru\Bundle\CartoBundle;

use Oru\Bundle\CartoBundle\DependencyInjection\Compiler\FormPass;
use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class OruCartoBundle extends OruBundle{
    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getDescription()
    {
        return "Cartographie du ROR";
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getFriendlyName()
    {
        // TODO: Implement getFriendlyName() method.
        return "Cartographie";
    }

    public function boot() {
        $collection = $this
            ->container
            ->get('routing.loader')
            ->load(__DIR__.'/Resources/config/routing.xml')
        ;

        $this
            ->container
            ->get('router')
            ->getRouteCollection()
            ->addCollection($collection)
        ;
    }

    public function build(ContainerBuilder $container)
    {
        parent::build($container);
        $container->addCompilerPass(new FormPass());
    }
}