<?php
/**
 * Created by PhpStorm.
 * User: bphilippot
 * Date: 18/05/15
 * Time: 14:26
 */

namespace Oru\Bundle\CartoBundle\Helper;

use Doctrine\ORM\EntityManager;
use CrEOF\Spatial\PHP\Types\Geometry\Point;

class DistanceHelper {

    /**
     * @var EntityManager
     */
    private $entityManager;

    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }
    /*
     * Retourne une liste d'identifiants d'adresses triés par proximité d'un point d'intérêt + la distance en km
     * adr_ids : array la liste d'identifiants à trier (optionnel, si non spécifié retourne toute la table oru_address_geo)
     * poi_adr_id : integer l'identifiant de l'adresse recherchée (optionnel mais l'un des 2 arguments poi doit être renseigné)
     * poi_coord : array les coordonnées GPS de l'adresse recherchée (optionnel mais l'un des 2 arguments poi doit être renseigné)
     */
    public function orderByDistance($adr_ids, $poi_adr_id, $poi_coord, $distance_max = null){
        $rp = $this->entityManager->getRepository("OruCartoBundle:GeoAddress");

        if (isset($poi_adr_id)) {
            $poiEntity = $rp->find($poi_adr_id);
            $poiGeom = $poiEntity->getTheGeom();
        } else if (isset($poi_coord)) {
            $poiGeom = new Point($poi_coord[0], $poi_coord[1], 4326);
        } else {
            throw new InvalidArgumentException("vous devez renseigner les coordonnées ou l'identifiant de l'adresse recherchée");
        }

        $orderStatement = $rp->createQueryBuilder('r')
            ->select('r.id')
            ->addselect('(ST_Distance_Sphere(r.theGeom, ST_GeomFromText(:p1)))/1000 AS dist')
            ->setParameter('p1', $poiGeom, 'point')
            ->orderBy('dist');
        if(isset($adr_ids)){
            $orderStatement
                ->andWhere('r.id in (:adr_ids)')
                ->setParameter('adr_ids', $adr_ids);
        }
        if($distance_max){
            $orderStatement
                ->andWhere('(ST_Distance_Sphere(r.theGeom, ST_GeomFromText(:p1)))/1000 < :distance_max')
                ->setParameter('distance_max', $distance_max);
        }
        $orderedResult = $orderStatement->getQuery()->getResult();

        return $orderedResult;
    }

    /*
       * Retourne une liste d'identifiants d'adresses de la commune en argument
       * adr_ids : array la liste d'identifiants à  trier (optionnel, si non spécifié retourne toute la table oru_address_geo)
       * code_insee : string, le code insee de la commune
       */
    public function getByCodeInsee($adr_ids, $code_insee){
        $rp = $this->entityManager->getRepository("OruCartoBundle:GeoAddress");

        $getByInseeStatement = $rp->createQueryBuilder('r')
            ->select('r.id')
            ->andWhere('r.geoAdrInsee = :code_insee')
            ->setParameter('code_insee',$code_insee);

        if(isset($adr_ids)){
            $getByInseeStatement
                ->andWhere('r.id in (:adr_ids)')
                ->setParameter('adr_ids', $adr_ids);
        }
        $lstResult = $getByInseeStatement ->getQuery()->getResult();

        return $lstResult ;
    }


    /**
     * @param $code_com
     * @param $dist
     * @return array
     * @throws \InvalidArgumentException
     */
    public function findRegionByCommuneDistance($code_com, $dist){
        $rp = $this->entityManager->getRepository("OruCartoBundle:Commune");

        if (!isset($code_com) || !isset($dist)) {
            throw new \InvalidArgumentException("vous devez renseigner le code insee de la commune et le rayon de la recherche en km");
        }

        $findRegionStatement = $rp->createQueryBuilder('c')
            ->select('DISTINCT c.codeReg')
            ->leftJoin('OruCartoBundle:Commune','c2','with','ST_DWithin(c.theGeom, c2.theGeom, :pdist) = true')
            ->where("c2.inseeCom = :pinsee")
            ->setParameters(array('pinsee' => $code_com, 'pdist' => $dist*1000));

        $regionResult = $findRegionStatement->getQuery()->getResult();

        return $regionResult;
    }


}