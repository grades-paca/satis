<?php
/**
 * Created by PhpStorm.
 * User: bphilippot
 * Date: 10/07/14
 * Time: 11:12
 */

namespace Oru\Bundle\CartoBundle;

use Oru\Bundle\CartoBundle\DependencyInjection\Compiler\FormPass;
use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class OruCartoBundle extends OruBundle
{
    /**
     * PHP 5 allows developers to declare constructor methods for classes.
     * Classes which have a constructor method call this method on each newly-created object,
     * so it is suitable for any initialization that the object may need before it is used.
     *
     * Note: Parent constructors are not called implicitly if the child class defines a constructor.
     * In order to run a parent constructor, a call to parent::__construct() within the child constructor is required.
     *
     * param [ mixed $args [, $... ]]
     *
     * @see http://php.net/manual/en/language.oop5.decon.php
     */
    public function __construct()
    {
        DynamicLoader::addXml('@OruCartoBundle/Resources/config/routing.xml');
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public static function getDescription()
    {
        return 'Cartographie du ROR';
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public static function getFriendlyName()
    {
        // TODO: Implement getFriendlyName() method.
        return 'Cartographie';
    }

    public function build(ContainerBuilder $container)
    {
        parent::build($container);
        $container->addCompilerPass(new FormPass());
    }
}
