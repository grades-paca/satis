<?php
/**
 * Created by PhpStorm.
 * User: tdepreaumont
 * Date: 26/11/2015
 * Time: 09:32
 */

namespace Oru\Bundle\CartoBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Application;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Input\InputDefinition;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;

class SynchroAddressCommand extends ContainerAwareCommand
{

    /**
     * @author Michaël VEROUX
     */
    protected function configure()
    {
        $this
            ->setName('oru:address:synchro-all')
            ->setDescription('Nouvelle synchronisation des adresses dans la base postgre (suppression des données)')
        ;
    }

    /**
     * Executes the current command.
     *
     * This method is not abstract because you can use this class
     * as a concrete class. In this case, instead of defining the
     * execute() method, you set the code to execute by passing
     * a Closure to the setCode() method.
     *
     * @param InputInterface $input An InputInterface instance
     * @param OutputInterface $output An OutputInterface instance
     *
     * @return null|int null or 0 if everything went fine, or an error code
     *
     * @throws \LogicException When this abstract method is not implemented
     *
     * @see setCode()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->getContainer()->get('oru_carto.geo_address_synchro')->synchroAll($output);
    }

} 