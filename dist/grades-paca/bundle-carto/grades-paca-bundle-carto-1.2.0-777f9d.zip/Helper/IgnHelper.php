<?php

namespace Oru\Bundle\CartoBundle\Helper;

use Oru\Bundle\SettingBundle\Setting\Setting;
use Oru\Bundle\WebClientBundle\Lib\OruWebClient;

class IgnHelper
{
    /**
     * @var string
     */
    const ENDPOINT_URL = 'http://gpp3-wxs.ign.fr/%s/geoportail/ols?output=xml&xls=';

    /**
     * @var string
     */
    const ENDPOINT_QUERY = '<xls:XLS xmlns:xls="http://www.opengis.net/xls" version="1.2">
    <xls:RequestHeader/>
        <xls:Request methodName="LocationUtilityService" version="1.2" maximumResponses="%d">
            <xls:GeocodeRequest returnFreeForm="false">
                <xls:Address countryCode="StreetAddress">
                <xls:freeFormAddress>%s</xls:freeFormAddress>
                </xls:Address>
            </xls:GeocodeRequest>
        </xls:Request>
        </xls:XLS>';

    /**
     * @var Setting
     */
    protected $setting;

    /**
     * @var OruWebClient
     */
    protected $webClient;

    /**
     * @var integer
     */
    protected $codeInseeRegion;

    public function __construct(Setting $setting, OruWebClient $webClient, $codeInseeRegion)
    {
        $this->setting = $setting;
        $this->maxResults = 1;
        $this->webClient = $webClient;
        $this->codeInseeRegion = $codeInseeRegion;
    }

    /**
     * Renvoie la première clé paramétrée avec le referer associé
     * Sert quand on ne connaît pas le referer. ex : migration
     */
    public function getArrayApiIgnKey()
    {
        $api_keys = $this->setting->setting('api_ign_key', 'OruCartoBundle');
        if (count($api_keys) != 0) {
            foreach ($api_keys as $key => $val) {
                return array(
                    "referer" => $key,
                    "apiKey" => $val
                );
            }
        }
        return null;
    }

    /**
     * Renvoie la clé IGN correspondant au referer passé en paramètre
     */
    public function getApiIgnKey($referer)
    {
        $apiIgnKey = "";
        $api_keys = $this->setting->setting('api_ign_key', 'OruCartoBundle');
        if (count($api_keys) != 0) {
            foreach ($api_keys as $key => $val) {
                $keyUrl = str_replace("http://", "", $key);
                //si l'index du tableau de clé correspond au referer, on récupère la clé
                if (stripos($referer, $keyUrl) !== false)
                    $apiIgnKey = $val;
            }
        }
        return $apiIgnKey;
    }

    /**
     * Renvoie un tableau des résultats de géocodage
     * $adresse = adresse géographique (rue, avenue...)
     */
    public function geocodeAdresse($adresse)
    {
        $array_referer_key = $this->getArrayApiIgnKey();
        $referer = $array_referer_key["referer"];
        $apiIgnKey = $array_referer_key["apiKey"];

        $xmlAnswer = $this->geocodageIGN($referer, $apiIgnKey, $adresse);

        $res = $this->xmlToGeocodedFields($xmlAnswer);

        return $res;

    }
    /**
 * Envoie une requête POST à l'IGN pour géocoder l'adresse en argument
 * Retourne un document XML
 * Paramètres :
 *   - $referer = adresse du site déclarée à l'IGN
 *   - $clef     = clé attribuée par l'IGN
 *   - $adresse = adresse géographique (rue, avenue...)
 */
    private function geocodageIGN($referer, $clef, $adresse)
    {
        $url = sprintf(self::ENDPOINT_URL, $clef);
        $data = sprintf(self::ENDPOINT_QUERY, $this->maxResults, htmlspecialchars($adresse));
        $c = $this->webClient->getCurlRessource();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_URL, $url);
        curl_setopt($c, CURLOPT_REFERER, $referer);
        curl_setopt($c, CURLOPT_POST, 1);
        curl_setopt($c, CURLOPT_POSTFIELDS, $data);
        curl_setopt($c, CURLOPT_HTTPHEADER, array(
            'Content-type: application/xml',
            'Content-length: ' . strlen($data)
        ));
        $content = curl_exec($c);
        curl_close($c);

        return $content;
    }

    /**
     * Traite la réponse XML pour récuperer les champs utiles dans un tableau
     */
    static private function xmlToGeocodedFields($xmlResponse)
    {
        $doc = new \DOMDocument;
        if (!@$doc->loadXML($xmlResponse)) {
            return array("error" => "Impossible d'exécuter la requête");
        }

        $excep = $doc->getElementsByTagName('Exception');
        if (isset($excep)) {
            foreach ($excep as $exc) {
                return array("error" => $exc->firstChild->nodeValue);
            }
        }

        $xml = new \SimpleXMLElement($xmlResponse);

        if (isset($xml->ErrorList->Error) || null === $xml->Response->GeocodeResponse) {
            return array("error" => "Impossible d'exécuter la requête");
        }

        $numberOfGeocodedAddresses = (int) $xml->Response
            ->GeocodeResponse
            ->GeocodeResponseList['numberOfGeocodedAddresses'];

        if (isset($numberOfGeocodedAddresses) && 0 === $numberOfGeocodedAddresses) {
            return array("error" => "Impossible d'exécuter la requête");
        }

        $geocodeResults = array();

        $xml->registerXPathNamespace('gml', 'http://www.opengis.net/gml');

        for ($i = 0; $i < $numberOfGeocodedAddresses; $i++) {
            $positions = $xml->xpath('//gml:pos');
            $positions = explode(' ', $positions[$i]);

            $zipcode      = $xml->xpath('//xls:PostalCode');
            $city         = $xml->xpath('//xls:Place[@type="Municipality"]');
            $insee         = $xml->xpath('//xls:Place[@type="INSEE"]');
            $streetNumber = $xml->xpath('//xls:Building');
            $cityDistrict = $xml->xpath('//xls:Street');
            $matchCode = $xml->xpath('//xls:GeocodeMatchCode');

            $num = isset($streetNumber[$i]) ? (string) $streetNumber[$i]->attributes() : null;
            $voie = isset($cityDistrict[$i]) ? (string) $cityDistrict[$i] : null;
            $cp = isset($zipcode[$i]) ? (string) $zipcode[$i] : null;
            $ville = isset($city[$i]) ? (string) $city[$i] : null;

            $geocodeResults = array(
                'geoAdrNum'   => $num,
                'geoAdrVoie'  => $voie,
                'geoAdrCp'    => $cp,
                'geoAdrVille' => $ville,
                'geoAdrInsee' => isset($insee[$i]) ? (string) $insee[$i] : null,
                'adresse'     => $num . " " . $voie . " " . $cp . " " . $ville,
                'lon'         => isset($positions[1]) ? (float) $positions[1] : null,
                'lat'         => isset($positions[0]) ? (float) $positions[0] : null,
                "precision"   => isset($matchCode[$i]) ? (string) $matchCode[$i]->attributes()['accuracy'] : null,
                "niveau"      => isset($matchCode[$i]) ? (string) $matchCode[$i]->attributes()['matchType'] : null
            );
        }

        return $geocodeResults;
    }

    /**
     * Corrige le nom de la ville pour une meilleure reconnaissance par le service OpenLS de l'IGN
     * Hotfix dans l'attente d'une amélioration du webservice de l'IGN
     */
    public function correctCity($ville)
    {
        //Correction implémentée uniquement en PACA
        if($this->codeInseeRegion != 93) {
            return $ville;
        }

        $ville = str_replace("-"," ",$ville);
        switch ($ville){
            case "AGAY":
                $ville = "SAINT RAPHAEL";
                break;
            case "AURON":
                $ville = "SAINT ETIENNE DE TINEE";
                break;
            case "CANNES LA BOCCA":
                $ville = "CANNES";
                break;
            case "ENTRESSEN":
                $ville = "ISTRES";
                break;
            case "GIENS":
                $ville = "HYERES";
                break;
            case "JUAN LES PINS":
                $ville = "ANTIBES";
                break;
            case "LA GAVOTTE":
                $ville = "LES PENNES MIRABEAU";
                break;
            case "LAVERA":
                $ville = "MARTIGUES";
                break;
            case "LE BRUSC":
                $ville = "SIX-FOURS";
                break;
            case "LE GOLFE JUAN":
                $ville = "ANTIBES";
                break;
            case "LES ISSAMBRES":
                $ville = "ROQUEBRUNE SUR ARGENS";
                break;
            case "LES MILLES":
                $ville = "AIX EN PROVENCE";
                break;
            case "LUYNES":
                $ville = "AIX EN PROVENCE";
                break;
            case "MAGAGNOSC":
                $ville = "GRASSE";
                break;
            case "MAS THIBERT":
                $ville = "ARLES";
                break;
            case "MONTFAVET":
                $ville = "AVIGNON";
                break;
            case "PUYRICARD":
                $ville = "AIX EN PROVENCE";
                break;
            case "SALIN DE GIRAUD":
                $ville = "ARLES";
                break;
            case "SOPHIA ANTIPOLIS CEDEX":
                $ville = "VALBONNE";
                break;
            case "ST AYGULF":
                $ville = "FREJUS";
                break;
        }
        return $ville;
    }
}