<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 15/09/14
 */

namespace Oru\Bundle\CartoBundle\Form\Type;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CartoType extends AbstractType  {

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('id', 'hidden')
            ->add('json', 'hidden')
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\CartoBundle\Entity\GeoAddress'
        ));
        $resolver->setDefined(array('adresse', 'numero', 'numeroComplement', 'type_voie', 'voie', 'code', 'commune'));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);
        $view->vars['adresse'] = (isset($options['adresse'])) ? $options['adresse'] : 'adresse';
        $view->vars['numero'] = (isset($options['numero'])) ? $options['numero'] : 'numero';
        $view->vars['numeroComplement'] = (isset($options['numeroComplement'])) ? $options['numeroComplement'] : 'numeroComplement';
        $view->vars['type_voie'] = (isset($options['type_voie'])) ? $options['type_voie'] : 'type_voie';
        $view->vars['voie'] = (isset($options['voie'])) ? $options['voie'] : 'voie' ;
        $view->vars['code'] = (isset($options['code'])) ? $options['code'] : 'code';
        $view->vars['commune'] = (isset($options['commune'])) ? $options['commune'] : 'commune';
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_carto';
    }

} 