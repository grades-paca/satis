<?php
/**
 * Created by PhpStorm.
 * User: bphilippot
 * Date: 12/09/14
 * Time: 11:19
 */

namespace Oru\Bundle\CartoBundle\Helper;

class CurlHelper
{
    public function performPostRequest($url, $data)
    {
        $c = curl_init();
        curl_setopt($c, CURLOPT_URL, $url);
        curl_setopt($c, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($c, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($c, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
        curl_setopt($c, CURLOPT_PORT, 443);
        curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($c, CURLOPT_HEADER, false);
        curl_setopt($c, CURLOPT_POST, true);
        curl_setopt($c, CURLOPT_POSTFIELDS, $data);
        $ret = curl_exec($c);
        if(!$ret && PROXY){
            curl_setopt($c, CURLOPT_PROXY, PROXY );
            $ret = curl_exec($c);
        }
        return $ret;
    }
}