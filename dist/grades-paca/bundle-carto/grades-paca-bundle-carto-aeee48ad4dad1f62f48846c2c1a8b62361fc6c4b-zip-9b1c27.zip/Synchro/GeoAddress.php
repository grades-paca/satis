<?php
/**
 * Author: Michaël VEROUX
 * Date: 18/02/15
 * Time: 16:37
 */

namespace Oru\Bundle\CartoBundle\Synchro;

use CrEOF\Spatial\PHP\Types\Geometry\Point;
use Doctrine\Common\Persistence\ObjectManager;
use Oru\Bundle\AddressBundle\Entity\Address;
use Oru\Bundle\CartoBundle\Event\Events;
use Oru\Bundle\CartoBundle\Event\SynchroNowEvent;
use Oru\Bundle\CartoBundle\Helper\IgnHelper;
use Oru\Bundle\WebClientBundle\Exception\RuntimeException;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Class GeoAddress.
 *
 * @author Michaël VEROUX
 */
class GeoAddress implements EventSubscriberInterface
{
    /**
     * @var ObjectManager
     */
    protected $em;

    /**
     * @var ObjectManager
     */
    protected $emCarto;

    /**
     * @var IgnHelper
     */
    protected $ignHelper;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @param ObjectManager   $em
     * @param ObjectManager   $emCarto
     * @param IgnHelper       $ignHelper
     * @param LoggerInterface $logger
     */
    public function __construct(ObjectManager $em, ObjectManager $emCarto, IgnHelper $ignHelper, LoggerInterface $logger)
    {
        $this->em = $em;
        $this->emCarto = $emCarto;
        $this->ignHelper = $ignHelper;
        $this->logger = $logger;
    }

    /**
     * Returns an array of event names this subscriber wants to listen to.
     *
     * The array keys are event names and the value can be:
     *
     *  * The method name to call (priority defaults to 0)
     *  * An array composed of the method name to call and the priority
     *  * An array of arrays composed of the method names to call and respective
     *    priorities, or 0 if unset
     *
     * For instance:
     *
     *  * array('eventName' => 'methodName')
     *  * array('eventName' => array('methodName', $priority))
     *  * array('eventName' => array(array('methodName1', $priority), array('methodName2'))
     *
     * @return array The event names to listen to
     *
     * @api
     */
    public static function getSubscribedEvents()
    {
        return array(Events::SYNCHRO_NOW => 'synchroNow');
    }

    /**
     * @param $addressId
     *
     * @author Michaël VEROUX
     */
    public function synchro($addressId)
    {
        $address = $this->em->getRepository('OruAddressBundle:Address')->find($addressId);

        if (!$address) {
            // Mais que fait-on donc là ?
            return;
        }

        $geoAddress = $this->emCarto->getRepository('OruCartoBundle:GeoAddress')->find($addressId);
        if (!$geoAddress) {
            $geoAddress = new \Oru\Bundle\CartoBundle\Entity\GeoAddress();
            $geoAddress->setId($addressId);
            $this->emCarto->persist($geoAddress);
        }

        if ($address->getTypeVoie() !== null && $address->getVoie() !== null) {
            $addressVoieStr = sprintf('%s %s %s %s',
                $address->getNumero(),
                $address->getNumeroComplement(),
                $address->getTypeVoie(),
                $address->getVoie()
            );
            $geoAddress->setAdr($addressVoieStr);
        } elseif ($address->getAdresse() !== null) {
            $geoAddress->setAdr($address->getAdresse());
        }
        $geoAddress->setCp($address->getCode());
        $geoAddress->setVille($address->getCommune());

        $this->geoCode($geoAddress, $address);

        $this->emCarto->flush($geoAddress);
    }

    public function synchroNow(SynchroNowEvent $event)
    {
        $address = $event->getAddress();
        $geoAddress = $address->getCarto();
        if ($geoAddress) {
            $geoAddress->setId($address->getId());
            if (!$this->emCarto->contains($geoAddress)) {
                $this->emCarto->persist($geoAddress);
            }
            $this->emCarto->flush($geoAddress);
        }
    }

    public function synchroAll(OutputInterface $output)
    {
        //todo effacer toute la base postgré
        $output->writeln('<info>Début du script de synchronisation des adresses avec la base postgis</info>', OutputInterface::OUTPUT_PLAIN);
        @ini_set('memory_limit', -1); //supprime la limite de dépassement mémoire
        @ini_set('max_execution_time', -1);
        $this->em->getConnection()->getConfiguration()->setSQLLogger(null);
        if (array_key_exists('softdeleteable', $this->em->getFilters()->getEnabledFilters())) {
            $this->em->getFilters()->disable('softdeleteable');
        }

        $query = $this->em->createQueryBuilder()
            ->select('a.id id, a.numero numero, a.numeroComplement numeroComplement, a.voie voie, a.code code, a.adresse adresse, a.commune commune, t.libelle as typeVoie')
            ->from('OruAddressBundle:Address', 'a')
            ->leftJoin('a.typeVoie', 't')
            ->getQuery();
        $addresses = $query->getScalarResult();

        $output->writeln('<info>Récupération des adresses (mysql)</info>', OutputInterface::OUTPUT_PLAIN);

        $output->writeln('<info>Vidange de la base oru_address_geo (postgis)</info>', OutputInterface::OUTPUT_PLAIN);
        $connC = $this->emCarto->getConnection();
        $sql = 'DELETE FROM oru_address_geo'; // On efface tout
        $connC->query($sql);

        $output->writeln("<info>Début de l'ajout des adresses oru_address_geo (postgis)</info>", OutputInterface::OUTPUT_PLAIN);

        $progress = new ProgressBar($output, count($addresses));
        $progress->start();

        $i = 1;
        foreach ($addresses as $address) {
            $geoAddress = new \Oru\Bundle\CartoBundle\Entity\GeoAddress();
            $geoAddress->setId($address['id']);

            if ($address['typeVoie'] !== null && $address['voie'] !== null) {
                $addressVoieStr = sprintf('%s %s %s %s',
                    $address['numero'],
                    $address['numeroComplement'],
                    $address['typeVoie'],
                    $address['voie']
                );
                $geoAddress->setAdr($addressVoieStr);
            } elseif ($address['adresse'] !== null) {
                $geoAddress->setAdr($address['adresse']);
            }

            if (strlen($address['code']) <= 5) {
                $geoAddress->setCp($address['code']);
            }

            $geoAddress->setVille($address['commune']);

            $this->geoCode($geoAddress, $address);

            $this->emCarto->persist($geoAddress);
            if ((($i % 100) === 0)) {
                $this->emCarto->flush();
            }
            ++$i;
            $progress->advance();
        }

        $this->emCarto->flush(); // On flush les derniers
        $progress->finish();
        if (array_key_exists('softdeleteable', $this->em->getFilters()->getEnabledFilters())) {
            $this->em->getFilters()->enable('softdeleteable');
        }
        $output->writeln('<info>Fin du script</info>', OutputInterface::OUTPUT_PLAIN);
    }

    /**
     * @param \Oru\Bundle\CartoBundle\Entity\GeoAddress $geoAddress
     * @param mixed                                     $address
     *
     * @author Michaël VEROUX
     */
    protected function geoCode(\Oru\Bundle\CartoBundle\Entity\GeoAddress $geoAddress, $address)
    {
        if (!$geoAddress->getTheGeom()) {
            //Correction des villes type lieux-dits
            try {
                if (is_array($address)) {
                    $address['commune'] = ($this->ignHelper->correctCity($address['commune']));
                    $properties = $this->ignHelper->geocodeAdresse($this->addressArrayToString($address));
                } else {
                    $address->setCommune($this->ignHelper->correctCity($address->getCommune()));
                    $properties = $this->ignHelper->geocodeAdresse((string) $address);
                }
            } catch (RuntimeException $e) {
                // ne pas interrompre le traitement
            }

            if (!isset($properties) || !is_array($properties) || count(
                   array_diff(
                       array('precision', 'adresse', 'geoAdrNum', 'geoAdrVoie', 'geoAdrCp', 'geoAdrVille', 'geoAdrInsee', 'niveau', 'lon', 'lat'),
                       array_keys($properties)
                   )
                )
            ) {
                $this->logger->error(sprintf('Carto: Something wrong in %s::%s at line %s',
                        __CLASS__,
                        __METHOD__,
                        __LINE__
                    )
                );

                return;
            }

            $geoAddress->setPrecision($properties['precision']);
            $geoAddress->setGeocodeAdr($properties['adresse']);
            $geoAddress->setGeoAdrNum($properties['geoAdrNum']);
            $geoAddress->setGeoAdrVoie($properties['geoAdrVoie']);
            $geoAddress->setGeoAdrCp($properties['geoAdrCp']);
            $geoAddress->setGeoAdrVille($properties['geoAdrVille']);
            $geoAddress->setGeoAdrInsee($properties['geoAdrInsee']);
            $geoAddress->setNivGeocodage($properties['niveau']);
            $geoAddress->setLng($properties['lon']);
            $geoAddress->setLat($properties['lat']);
            $point = new Point($properties['lon'], $properties['lat'], 4326);
            $geoAddress->setTheGeom($point);
        }
    }

    private function addressArrayToString(array $address) //Pour travailler avec des array et réduire les délais d'execution
    {
        $delimiter = "\n";
        $adresseComplete = '';

        if ($address['adresse'] !== '' && $address['voie'] === '') {
            $adresseComplete .= $address['adresse']."$delimiter";
        }

        if ($address['voie'] !== '') {
            if ($address['numero'] !== '') {
                $adresseComplete .= $address['numero'].$address['numeroComplement'].' ';
            }
            $adresseComplete .= $address['typeVoie'].' '.$address['voie']."$delimiter";
        }

        if ($address['numeroComplement'] !== '') {
            $adresseComplete .= $address['numeroComplement']."$delimiter";
        }

        $adresseComplete .= $address['code'].' '.$address['commune'];

        return $adresseComplete;
    }
}
