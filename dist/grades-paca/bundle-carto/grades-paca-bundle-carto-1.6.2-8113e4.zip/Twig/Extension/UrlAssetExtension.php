<?php
/**
 * Created by PhpStorm.
 * User: bphilippot
 * Date: 22/07/14
 * Time: 09:58
 */

namespace Oru\Bundle\CartoBundle\Twig\Extension;

class UrlAssetExtension extends \Twig_Extension
{
    public function getFilters()
    {
        return array(
            new \Twig_SimpleFilter('urlAsset', array($this, 'urlAssetFilter')),
        );
    }

    public function getName()
    {
        return 'urlAsset';
    }

    public function urlAssetFilter($string)
    {
        if (preg_match('/^(.*)\/([^\/]*)$/', $string, $tabRes)) {
            return $tabRes[1].'/';
        }

        return $string;
    }
}
