Bundle OruCartoBundle
======================

Description
-----------

Ce bundle regroupe des fonctionnalités liées à la cartographie.

* Outils régionaux/Cartographie : Affichage d'une page dédiée à la cartographie avec fonds de plan, couches prédéfinies (SAU, SMUR, etc) et Activité des SMUR
* Affichage de la position d'une adresse dans les fiches établissement et structure
* Géolocalisation de l'adresse et repositionnement manuel d'une adresse en mode édition des fiches
* Affichage des résultats de recherche sur une carte
* Affichage de la synthèse régionale des lits disponibles

### Liste des pages

[Pages](./OruCartoBundle/Resources/config/pages.xml)

### Liste des paramètres

[Paramètres](./OruCartoBundle/Resources/settings/OruCartoBundle.generic.orm)


Installation du Bundle
------------

Importer le paquet via composer  
+ le paquet permettant à doctrine de gérer les géométries  
+ ajouter dans repositories : { "type": "vcs", "url": "https://github.com/bphilippot/doctrine2-spatial" }

    ./composer.phar require "creof/doctrine2-spatial":dev-master  
    ./composer.phar require "oru/carto":dev-master

Dans le AppKernel.php, activer ce bundle

    $bundles[] = new Oru\Bundle\CartoBundle\OruCartoBundle();

Dans le config.yml, ajouter ce bundle aux paramètres imports :

    imports:
    ...
    - { resource: @OruCartoBundle/Resources/config/config.yml }

Dans le routing.yml, ajouter la nouvelle route :

```
oru_carto:
    resource: "@OruCartoBundle/Resources/config/routing.xml"
    prefix: /carto
```

Vider le cache de Symfony2

**Pré-requis**

* Php extension mapscript
* Php extension pgsql
* Php extension gd

Installation de MapServer
------------

Programme CGI permettant d'afficher des tuiles cartographiques et des objets géolocalisés à partir des webservices WMS et WFS liés à la base de données PostGis

1. Installer le paquet cgi-mapserver

2. Copier le fichier mapserv créé dans le répertoire cgi-bin par défaut (/usr/lib/cgi-bin) et le coller dans vendor/oru/carto/Oru/Bundle/CartoBundle/Resources/public/cgi-bin

Création de la base de données
------------

1. Installer le paquet postgresql-postgis ou [Installer postgis manuellement](http://postgis.net/install)
2. Se connecter avec le super utilisateur postgres  
     
    `sudo su postgres`
    
3. Créer l'utilisateur login (mot de passe)  
     `createuser -P ror_user
     (password : rorWeb puis répondre non 3fois)`
4. Créer la base de données postgis  
     `createdb -O ror_user ror_carto -l fr_FR.UTF8 -E UTF8 -T template0`  
     
   EN VERSION 1.5 :  
   
    createlang plpgsql ror_carto  
    psql -d ror_carto -f /usr/share/postgresql/9.*/contrib/postgis-1.5/postgis.sql  
    (ou selon l'installation : psql -d ror_carto -f /usr/share/postgresql/*.*/contrib/postgis.sql)  
    psql -d ror_carto -f /usr/share/postgresql/9.*/contrib/postgis-1.5/spatial_ref_sys.sql  
    (ou selon l'installation : psql -d ror_carto -f /usr/share/postgresql/*.*/contrib/spatial_ref_sys.sql) 
    
   EN VERSION 2.0 :  
   
    psql ror_carto  
     CREATE EXTENSION postgis;  
     \q
     
Accorder les droits sur les tables postgis à ror_user  

    psql -d ror_carto -c 'GRANT CREATE ON DATABASE ror_carto TO ror_user';  
    psql -d ror_carto -c 'GRANT SELECT ON TABLE spatial_ref_sys TO ror_user';  
    EN VERSION 1.5, lancer en plus :  
    psql -d ror_carto -c 'GRANT ALL ON TABLE geometry_columns TO ror_user';  


Import d'un jeu de données
------------

NB : pour que le chargement des fixtures de la base de données MySQL du ROR se déroule correctement, il est nécessaire de désactiver le bundle OruCartoBundle dans le fichier parameters.yml (disabled_bundles)  
Pb du aux 2 entity managers et à l'autoLoader

Pour charger les fixtures carto régions et départements, vérifier que le bundle Carto est activé et lancer la commande suivante :

    php app/console doctrine:schema:create --em=pg_connection
    php app/console doctrine:fixtures:load --fixtures=vendor/oru/carto/Oru/Bundle/CartoBundle/ --em=pg_connection
    
Pour migrer les adresses de la base ROR2 carto vers la base ror 3, renseigner les paramètres d'accès à la base V2 dans parameters.yml

    migration_postgisdatabase_host: carto.orupaca.fr
    migration_postgisdatabase_port: 5432
    migration_postgisdatabase_name: ror_carto
    migration_postgisdatabase_user: ror_user
    migration_postgisdatabase_password: rorWeb

Et lancer la commande suivante :

    php app/console oru:migrate address_postgis

Configuration
-----------


**Paramètres du ROR (parameters.yml)**  

Connexion à la base de données postgis
(Par défaut sur le serveur ovh, voir ci-dessous pour uen création locale de la base de données)

    database2_driver: pdo_pgsql
    database2_host: carto.orupaca.fr
    database2_port: 5432
    database2_name: ror3_carto
    database2_user: ror_user

Code insee de la région  
(PACA par défaut)

    code_insee_region: 93

**Paramètres du bundle (OruCartoBundle.generic.orm)**

Clé IGN pour accéder aux services de fond de plan et de géolocalisation.  
L'index du tableau doit être égale au referer et la valeur à la clé ign.
La demande doit être faite sur le site professionnels.ign.fr (hotline@orupaca.fr)

    array:
        api_ign_key:
            value:
                "ror3": "cl5044hn60sdl619feo1o4u0"
            description: "Clés IGN liées à un referer"
            role: ROLE_SETTING_ADMIN

**Initialisation du mapFile**

Les données de PostGis sont affichées sur la carte via des webservices WFS et WMS délivrés par le logiciel MapServer.

