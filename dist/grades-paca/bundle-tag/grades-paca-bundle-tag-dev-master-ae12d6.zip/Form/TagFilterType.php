<?php

namespace Oru\Bundle\TagBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class TagFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', SearchType::class, array('required' => false, 'label' => 'Tag.name', 'translation_domain' => 'OruTagBundle'))
            ->add('slug', SearchType::class, array('required' => false, 'label' => 'Tag.slug', 'translation_domain' => 'OruTagBundle'))
            ->add('type', SearchType::class, array('required' => false, 'label' => 'Tag.type', 'translation_domain' => 'OruTagBundle'))
            ->add('filter', SubmitType::class, array('label' => 'listing.action.filter', 'translation_domain' => 'messages'))
            ->add('reset', SubmitType::class, array('label' => 'listing.action.reset', 'translation_domain' => 'messages'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\TagBundle\Filter\TagFilter',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_tagbundle_tagfilter';
    }
}
