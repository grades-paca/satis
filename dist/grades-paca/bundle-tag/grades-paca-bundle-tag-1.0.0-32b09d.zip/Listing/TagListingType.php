<?php

namespace Oru\Bundle\TagBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class TagListingType extends AbstractListingType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('name', null, array('sort'=> 'u.name','label' => 'listing.name', 'translation_domain' => 'OruTagBundle'))
            ->add('slug', null, array('sort'=> 'u.slug','label' => 'listing.slug', 'translation_domain' => 'OruTagBundle'))
            ->add('type', null, array('sort'=> 'u.type','label' => 'listing.type', 'translation_domain' => 'OruTagBundle'))
            ->add('edit', 'object_action', array('route' => 'tag_edit', 'label' => 'listing.action.edit'))
            ->add('show', 'object_action', array('route' => 'tag_show', 'label' => 'listing.action.show'))
            ->add('new', 'list_action', array('route' => 'tag_new', 'label' => 'listing.action.new'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\TagBundle\Entity\Tag'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_tagbundle_taglisting';
    }
}
