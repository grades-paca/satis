<?php

namespace Oru\Bundle\TagBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class TagFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', 'search', array('required' => false, 'label' => 'Tag.name', 'translation_domain' => 'OruTagBundle'))
            ->add('slug', 'search', array('required' => false, 'label' => 'Tag.slug', 'translation_domain' => 'OruTagBundle'))
            ->add('type', 'search', array('required' => false, 'label' => 'Tag.type', 'translation_domain' => 'OruTagBundle'))
            ->add('filter', 'submit', array('label' => 'listing.action.filter', 'translation_domain' => 'messages'))
            ->add('reset', 'submit', array('label' => 'listing.action.reset', 'translation_domain' => 'messages'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\TagBundle\Filter\TagFilter'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_tagbundle_tagfilter';
    }
}
