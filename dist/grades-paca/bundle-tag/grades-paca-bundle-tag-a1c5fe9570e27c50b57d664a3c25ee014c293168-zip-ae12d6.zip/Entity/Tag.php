<?php

namespace Oru\Bundle\TagBundle\Entity;

use FPN\TagBundle\Entity\Tag as BaseTag;

/**
 * Tag.
 */
class Tag extends BaseTag
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var \Doctrine\Common\Collections\Collection
     */
    protected $tagging;

    protected $type;

    /**
     * @var \DateTime
     */
    protected $deletedAt;

    /**
     * Constructor.
     *
     * @param null|mixed $name
     */
    public function __construct($name = null)
    {
        parent::__construct($name);
        $this->tagging = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Add tagging.
     *
     * @param \Oru\Bundle\TagBundle\Entity\Tagging $tagging
     *
     * @return Tag
     */
    public function addTagging(\Oru\Bundle\TagBundle\Entity\Tagging $tagging)
    {
        $this->tagging[] = $tagging;

        return $this;
    }

    /**
     * Remove tagging.
     *
     * @param \Oru\Bundle\TagBundle\Entity\Tagging $tagging
     */
    public function removeTagging(\Oru\Bundle\TagBundle\Entity\Tagging $tagging)
    {
        $this->tagging->removeElement($tagging);
    }

    /**
     * Get tagging.
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTagging()
    {
        return $this->tagging;
    }

    /**
     * @param mixed $type
     */
    public function setType($type)
    {
        $this->type = $type;
    }

    /**
     * @return mixed
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }

    /**
     * @param \DateTime $deletedAt
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;
    }
}
