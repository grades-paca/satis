<?php

namespace Oru\Bundle\TagBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Oru\Bundle\TagBundle\Entity\Tag;
use Oru\Bundle\TagBundle\Listing\TagListingType;
use Oru\Bundle\TagBundle\Form\TagFilterType;
use Oru\Bundle\TagBundle\Form\TagType;

/**
 * Tag controller.
 *
 */
class TagController extends Controller
{

    /**
     * Lists all Tag entities.
     *
     */
    public function indexAction(Request $request)
    {
        $form = $this->createForm(new TagFilterType())->submit($request->getSession()->get('tag.filter'));
        $listing = $this->container->get('paginator.factory')->create(
            new TagListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruTagBundle:Tag')->findList($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('@OruTag/Tag/index.html.twig', array(
            'listing' => $listing,
            'form' => $this->createForm(new TagFilterType(), $form->getData())->createView()
        ));
    }
    /**
     * Filters Tag entities.
     *
     */
    public function filterAction(Request $request)
    {
        $form = $this->createForm(new TagFilterType())->handleRequest($request);

        if ($form->get('reset')->isClicked())
        {
            $request->getSession()->set('tag.filter', array());
            return $this->redirect($this->generateUrl('tag'));
        }

        if($form->isValid()) {
            $request->getSession()->set('tag.filter', $request->get($form->getName()));
            return $this->redirect($this->generateUrl('tag'));
        }

        $listing = $this->container->get('paginator.factory')->create(
            new TagListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruTagBundle:Tag')->findList($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('@OruTag/Tag/index.html.twig', array(
            'listing' => $listing,
            'form' => $form->createView()
        ));
    }
    /**
     * Creates a new Tag entity.
     *
     */
    public function createAction(Request $request)
    {
        $entity = new Tag();
        $form = $this->createCreateForm($entity);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $tagManager = $this->get('fpn_tag.tag_manager');
            $tag = $tagManager->loadOrCreateTag($entity->getName());
            $data = $form->getData();
            $tag->setType($data->getType());
            $this->getDoctrine()->getManager()->flush();

            return $this->redirect($this->generateUrl('tag_show', array('id' => $tag->getId())));
        }

        return $this->render('@OruTag/Tag/edit.html.twig', array(
            'entity' => $entity,
            'form'   => $form->createView(),
        ));
    }

    /**
    * Creates a form to create a Tag entity.
    *
    * @param Tag $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    */
    private function createCreateForm(Tag $entity)
    {
        $form = $this->createForm(new TagType(), $entity, array(
            'action' => $this->generateUrl('tag_create'),
            'method' => 'POST',
        ));

        $form->add('submit', 'submit', array('label' => $this->get('translator')->trans('listing.action.create')));

        return $form;
    }

    /**
     * Displays a form to create a new Tag entity.
     *
     */
    public function newAction()
    {
        $entity = new Tag();
        $form   = $this->createCreateForm($entity);

        return $this->render('@OruTag/Tag/edit.html.twig', array(
            'entity' => $entity,
            'form'   => $form->createView(),
        ));
    }

    /**
     * Finds and displays a Tag entity.
     *
     */
    public function showAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruTagBundle:Tag')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Tag entity.');
        }

        $deleteForm = $this->createDeleteForm($id);

        return $this->render('@OruTag/Tag/show.html.twig', array(
            'entity'      => $entity,
            'delete_form' => $deleteForm->createView(),        ));
    }

    /**
     * Displays a form to edit an existing Tag entity.
     *
     */
    public function editAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruTagBundle:Tag')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Tag entity.');
        }

        $editForm = $this->createEditForm($entity);

        return $this->render('@OruTag/Tag/edit.html.twig', array(
            'entity'      => $entity,
            'form'   => $editForm->createView(),
        ));
    }

    /**
    * Creates a form to edit a Tag entity.
    *
    * @param Tag $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    */
    private function createEditForm(Tag $entity)
    {
        $form = $this->createForm(new TagType(), $entity, array(
            'action' => $this->generateUrl('tag_update', array('id' => $entity->getId())),
            'method' => 'PUT',
        ));

        $form->add('submit', 'submit', array('label' => $this->get('translator')->trans('listing.action.update')));

        return $form;
    }
    /**
     * Edits an existing Tag entity.
     *
     */
    public function updateAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruTagBundle:Tag')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Tag entity.');
        }

        $editForm = $this->createEditForm($entity);
        $editForm->handleRequest($request);

        if ($editForm->isValid()) {
            $em->flush();

            return $this->redirect($this->generateUrl('tag_edit', array('id' => $id)));
        }

        return $this->render('@OruTag/Tag/edit.html.twig', array(
            'entity'      => $entity,
            'form'   => $editForm->createView(),
        ));
    }
    /**
     * Deletes a Tag entity.
     *
     */
    public function deleteAction(Request $request, $id)
    {
        $form = $this->createDeleteForm($id);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $entity = $em->getRepository('OruTagBundle:Tag')->find($id);

            if (!$entity) {
                throw $this->createNotFoundException('Unable to find Tag entity.');
            }

            $em->remove($entity);
            $em->flush();
        }

        return $this->redirect($this->generateUrl('tag'));
    }

    /**
     * Creates a form to delete a Tag entity by id.
     *
     * @param mixed $id The entity id
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm($id)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('tag_delete', array('id' => $id)))
            ->setMethod('DELETE')
            ->add('submit', 'submit', array('label' => $this->get('translator')->trans('listing.action.delete')))
            ->getForm()
        ;
    }
}
