OruTagBundle
============

Description
-----------

Ce bundle fournit une gestion des tags en s'appuyant sur le bundle FPNTagBundle : https://github.com/FabienPennequin/FPNTagBundle.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/tag":dev-master
```

Dans le AppKernel.php, activer ces bundles :

```php
$bundles[] = new FPN\TagBundle\FPNTagBundle();
$bundles[] = new Oru\Bundle\TagBundle\OruTagBundle();
```

Dans le config.yml, ajouter ce bundle au paramètre imports :

```yaml
imports:
    ...
    - { resource: @OruTagBundle/Resources/config/config.yml }
```

Dans le routing.yml, ajouter la nouvelle route :

```yaml
oru_tag:
    resource: "@OruTagBundle/Resources/config/routing.yml"
```

Utilisation
-----------

La gestion des tags est disponible à l'adresse /tag.
Plus d'informations ici : http://knpbundles.com/FabienPennequin/FPNTagBundle et un exemple d'utilisation dans le bundle OruNewsBundle.
