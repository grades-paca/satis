<?php
/**
 * Created by PhpStorm.
 * User: andre
 * Date: 23/01/14
 * Time: 09:13
 */

namespace Oru\Bundle\TagBundle\Entity;

use DoctrineExtensions\Taggable\Entity\TagRepository;
use Oru\Bundle\TagBundle\Filter\TagFilter;

class OruTagRepository extends TagRepository {
    protected $tagQueryField = 'slug';

    public function findList(TagFilter $filter)
    {
        $builder = $this->createQueryBuilder("u");

        if($filter->getName())
        {
            $builder->andWhere("u.name like :name")->setParameter("name","%{$filter->getName()}%");
        }
        if($filter->getSlug())
        {
            $builder->andWhere("u.slug like :slug")->setParameter("slug","%{$filter->getSlug()}%");
        }
        if($filter->getType())
        {
            $builder->andWhere("u.type like :type")->setParameter("type","%{$filter->getType()}%");
        }
        if($filter->getCreatedAt())
        {
            $builder->andWhere("u.createdAt > :createdAt")->setParameter("createdAt","%{$filter->getCreatedAt()->format('Y-m-d H:i:s')}%");
        }
        if($filter->getUpdatedAt())
        {
            $builder->andWhere("u.updatedAt < :updatedAt")->setParameter("updatedAt","%{$filter->getUpdatedAt()->format('Y-m-d H:i:s')}%");
        }
        return $builder;
    }
} 