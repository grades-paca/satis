<?php

namespace Oru\Bundle\TagBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruTagBundle extends Bundle
{
}
