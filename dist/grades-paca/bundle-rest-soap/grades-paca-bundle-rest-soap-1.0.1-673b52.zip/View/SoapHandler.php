<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 02/12/13
 * Time: 15:19
 */

namespace Oru\Bundle\RestSoapBundle\View;


use BeSimple\SoapBundle\Soap\SoapResponse;
use FOS\RestBundle\View\View;
use FOS\RestBundle\View\ViewHandler;
use JMS\Serializer\scalar;
use JMS\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerAware;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Class SoapHandler
 * @package Oru\Bundle\RestSoapBundle\View
 */
class SoapHandler extends ContainerAware
{

    /**
     * Get the serializer service
     *
     * @return object that must provide a "serialize()" method
     */
    protected function getSerializer()
    {
        return $this->container->get('fos_rest.serializer');
    }

    /**
     * @param ViewHandler $handler
     * @param View $view
     * @param Request $request
     * @param $format
     * @return SoapResponse
     */
    public function createResponse(ViewHandler $handler, View $view, Request $request, $format)
    {
        $response = new SoapResponse();
        $response->setReturnValue( $view->getData() );

        return $response;
    }
}