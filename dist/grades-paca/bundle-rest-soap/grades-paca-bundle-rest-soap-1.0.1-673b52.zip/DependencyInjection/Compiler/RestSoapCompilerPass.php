<?php
/**
 * Author: Michaël VEROUX
 * Date: 06/02/15
 * Time: 15:02
 */

namespace Oru\Bundle\RestSoapBundle\DependencyInjection\Compiler;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class RestSoapCompilerPass implements CompilerPassInterface
{

    /**
     * You can modify the container here before it is dumped to PHP code.
     *
     * @param ContainerBuilder $container
     *
     * @api
     */
    public function process(ContainerBuilder $container)
    {
        $this->overrideSoapClientBuilder($container);
    }

    protected function overrideSoapClientBuilder(ContainerBuilder $container)
    {
        if($container->hasDefinition('besimple.soap.client.builder'))
        {
            $definition = $container->getDefinition('besimple.soap.client.builder');

            $secondArg = $definition->getArgument(1);
            $secondArg['soap_version'] = SOAP_1_2;

            $definition->replaceArgument(1, $secondArg);
        }
    }
}