<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 02/12/13
 * Time: 15:19
 */

namespace Oru\Bundle\RestSoapBundle\View;

use BeSimple\SoapBundle\Soap\SoapResponse;
use FOS\RestBundle\View\View;
use FOS\RestBundle\View\ViewHandler;
use Symfony\Component\DependencyInjection\ContainerAwareTrait;
use Symfony\Component\HttpFoundation\Request;

/**
 * Class SoapHandler.
 */
class SoapHandler
{
    use ContainerAwareTrait;

    /**
     * @param ViewHandler $handler
     * @param View        $view
     * @param Request     $request
     * @param $format
     *
     * @return SoapResponse
     */
    public function createResponse(ViewHandler $handler, View $view, Request $request, $format)
    {
        $response = new SoapResponse();
        $response->setReturnValue($view->getData());

        return $response;
    }

    /**
     * Get the serializer service.
     *
     * @return object that must provide a "serialize()" method
     */
    protected function getSerializer()
    {
        return $this->container->get('fos_rest.serializer');
    }
}
