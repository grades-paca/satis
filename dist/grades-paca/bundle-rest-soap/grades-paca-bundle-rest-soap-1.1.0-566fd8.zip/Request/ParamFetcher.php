<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 09/12/13
 * Time: 10:47
 */

namespace Oru\Bundle\RestSoapBundle\Request;

use FOS\RestBundle\Request\ParamFetcher as BaseParamFetcher;
use FOS\RestBundle\Request\ParamReader;
use FOS\RestBundle\Util\ViolationFormatterInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Validator\Validator\ValidatorInterface;

/**
 * Class ParamFetcher.
 */
class ParamFetcher extends BaseParamFetcher
{
    /**
     * @var \Symfony\Component\HttpFoundation\Request
     */
    private $request;

    public function __construct(ParamReader $paramReader, Request $request, ViolationFormatterInterface $violationFormatter, ValidatorInterface $validator = null)
    {
        $this->request = $request;

        parent::__construct($paramReader, $request, $violationFormatter, $validator);
    }

    /**
     * @param string $name
     * @param null   $strict
     *
     * @return array|mixed|null|string
     */
    public function get($name, $strict = null)
    {
        if ('soap' === strtolower($this->request->getRequestFormat())) {
            return $this->request->get($name);
        }

        return parent::get($name, $strict);
    }
}
