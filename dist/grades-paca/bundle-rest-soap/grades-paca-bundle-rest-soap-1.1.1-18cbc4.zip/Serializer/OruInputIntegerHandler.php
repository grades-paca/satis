<?php
/**
 * Created by PhpStorm.
 * User: Michaël GONZALEZ
 * Date: 26/10/2018
 * Time: 08:52
 */

namespace Oru\Bundle\RestSoapBundle\Serializer;


use JMS\Serializer\Context;
use JMS\Serializer\GraphNavigator;
use JMS\Serializer\Handler\SubscribingHandlerInterface;
use JMS\Serializer\JsonDeserializationVisitor;
use JMS\Serializer\JsonSerializationVisitor;

/**
 * Type de désérialisation permettant d'éviter la conversion d'une chaine de caractère en entier et ainsi permettre la validation des données réelles après désérialisation.
 * Exemples:
 * - "test" => deserialize => "test"
 * - "10" => deserialize => 10
 *
 * Class OruInputIntegerHandler
 * @package Oru\Bundle\RestSoapBundle\Serializer
 */
class OruInputIntegerHandler implements SubscribingHandlerInterface
{
    public static function getSubscribingMethods()
    {
        return [
            [
                'direction' => GraphNavigator::DIRECTION_DESERIALIZATION,
                'format' => 'json',
                'type' => 'OruInputInteger',
                'method' => 'deserializeFromJSON',
            ],
            [
                'direction' => GraphNavigator::DIRECTION_SERIALIZATION,
                'format' => 'json',
                'type' => 'OruInputInteger',
                'method' => 'serializeToJSON',
            ],
        ];
    }

    public function deserializeFromJSON(JsonDeserializationVisitor $visitor, $data, array $type)
    {
        //Si la valeur est numérique, on la convertit en entier
        if(is_numeric($data)){
            return intval($data);
        }

        //Dans le cas contraire on la renvoie telle quelle
        return $data;
    }

    public function serializeToJSON(JsonSerializationVisitor $visitor, $data, array $type, Context $context)
    {
        return $visitor->visitInteger($data, $type, $context);
    }
}