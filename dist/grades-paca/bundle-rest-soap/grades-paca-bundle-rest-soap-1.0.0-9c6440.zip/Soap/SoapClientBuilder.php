<?php
/**
 * Author: Michaël VEROUX
 * Date: 06/02/15
 * Time: 14:18
 */

namespace Oru\Bundle\RestSoapBundle\Soap;

use BeSimple\SoapBundle\Soap\SoapClientBuilder as BaseSoapClientBuilder;
use BeSimple\SoapCommon\Classmap;
use BeSimple\SoapCommon\Converter\TypeConverterCollection;

class SoapClientBuilder extends BaseSoapClientBuilder
{
    public function __construct($wsdl, array $options, Classmap $classmap = null, TypeConverterCollection $converters = null)
    {
        if(isset($options['soap_version']))
        {
            if(SOAP_1_2 === $options['soap_version'])
            {
                $this->withSoapVersion12();
            }
            else
            {
                $this->withSoapVersion11();
            }

            unset($options['soap_version']);
        }

        parent::__construct($wsdl, $options, $classmap, $converters);
    }

} 