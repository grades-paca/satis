<?php
/**
 * Created by PhpStorm.
 * User: Michaël GONZALEZ
 * Date: 18/10/2018
 * Time: 16:52
 */

namespace Oru\Bundle\RestSoapBundle\Serializer;


use FOS\RestBundle\Context\Context;
use FOS\RestBundle\Serializer\Serializer;
use JMS\Serializer\Context as JMSContext;
use JMS\Serializer\DeserializationContext as JMSDeserializationContext;
use JMS\Serializer\SerializationContext as JMSSerializationContext;
use JMS\Serializer\SerializerInterface;

/**
 * Adapter to plug the JMS serializer into the FOSRestBundle Serializer API.
 *
 * @author Christian Flothmann <christian.flothmann@xabbuh.de>
 */
class JMSSerializerAdapter implements Serializer
{
    /**
     * @internal
     */
    const SERIALIZATION = 0;
    /**
     * @internal
     */
    const DESERIALIZATION = 1;

    private $serializer;

    public function __construct(SerializerInterface $serializer)
    {
        $this->serializer = $serializer;
    }

    /**
     * @param SerializerInterface $serializer
     * Override ORUPACA
     * Permet de d'affecter un serializer JMS de manière dynamique
     * NOTE IMPORTANTE: Attention en écrasant le sérializer:
     * - les handlers enregistrés doivent être redéclarés via le SerializerBuilder avant le build (comportement normal)
     * - L'injection du Serializer à cet endroit semble générer AU MOINS UN COMPORTEMENT INCONSISTANT (nécessité d'avoir les handlers à la fois déclarés en tant que service + nécessité de les ajouter au nouveau Serializer SIMULTANEMENT, si l'un ou l'autre n'est pas fait, Le serializer ne connaîtra pas un des handlers (serialize ou deserialize selon où est faite la déclaration)
     */
    public function setSerializer(SerializerInterface $serializer)
    {
        $this->serializer = $serializer;
    }

    /**
     * {@inheritdoc}
     */
    public function serialize($data, $format, Context $context)
    {
        $context = $this->convertContext($context, self::SERIALIZATION);

        return $this->serializer->serialize($data, $format, $context);
    }

    /**
     * {@inheritdoc}
     */
    public function deserialize($data, $type, $format, Context $context)
    {
        $context = $this->convertContext($context, self::DESERIALIZATION);

        return $this->serializer->deserialize($data, $type, $format, $context);
    }

    /**
     * @param Context $context
     * @param int     $direction {@see self} constants
     *
     * @return JMSContext
     */
    private function convertContext(Context $context, $direction)
    {
        if ($direction === self::SERIALIZATION) {
            $jmsContext = JMSSerializationContext::create();
        } else {
            $jmsContext = JMSDeserializationContext::create();
            $maxDepth = $context->getMaxDepth();
            if (null !== $maxDepth) {
                for ($i = 0; $i < $maxDepth; ++$i) {
                    $jmsContext->increaseDepth();
                }
            }
        }

        foreach ($context->getAttributes() as $key => $value) {
            $jmsContext->attributes->set($key, $value);
        }

        if (null !== $context->getVersion()) {
            $jmsContext->setVersion($context->getVersion());
        }
        $groups = $context->getGroups();
        if (!empty($groups)) {
            $jmsContext->setGroups($context->getGroups());
        }
        if (null !== $context->getMaxDepth()) {
            $jmsContext->enableMaxDepthChecks();
        }
        if (null !== $context->getSerializeNull()) {
            $jmsContext->setSerializeNull($context->getSerializeNull());
        }

        return $jmsContext;
    }
}