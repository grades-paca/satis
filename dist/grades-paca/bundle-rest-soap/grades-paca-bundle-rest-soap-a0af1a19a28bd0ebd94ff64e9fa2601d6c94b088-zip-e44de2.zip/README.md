Bundle RestSoapBundle
=====================

Installation
------------

Dans le AppKernel.php, activer ce bundle

    $bundles[] = new Oru\Bundle\RestSoapBundle\OruRestSoapBundle();

Dans le routing.yml, ajouter les routes :

    oru_rest_soap:
        resource: "@OruRestSoapBundle/Resources/config/routing.yml"
        prefix:   /

Dans le config.yml, ajouter ce bundle aux paramètres imports :

    imports:
    ...
    - { resource: @OruRestSoapBundle/Resources/config/config.yml }

Vider le cache de Symfony

Description
-----------

Ce bundle complète le bundle FosRest pour prendre en charge le format SOAP pour interroger l'API REST.
