<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 23/05/14
 */

namespace Oru\Bundle\StatsBundle\Twig;


use Oru\Bundle\SettingBundle\Setting\Setting;

class StatsExtension extends \Twig_Extension implements \Twig_Extension_GlobalsInterface
{

    /**
     * @var \Oru\Bundle\SettingBundle\Entity\Setting
     */
    private $settings;

    /**
     * @param Setting $settings
     */
    public function __construct(Setting $settings)
    {
        $this->settings = $settings;
    }

    /**
     * @return array
     */
    public function getGlobals()
    {
        return array(
            'bp_analytics_id'       => $this->settings->setting('bp_analytics_id', 'OruStatsBundle'),
            'bp_analytics_domain'   => $this->settings->setting('bp_analytics_domain', 'OruStatsBundle')
        );
    }

    /**
     * Returns the name of the extension.
     *
     * @return string The extension name
     */
    public function getName()
    {
        return 'stats_extension';
    }


} 