OruStatsBundle
================

Description
-----------

Utilisation du service d'analyse d'audience de Google Analytics.

Installation
------------


Importer le paquet via composer

```
./composer.phar require "oru/stats":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\StatsBundle\OruStatsBundle();
```

Vider le cache de Symfony2

Utilisation
-----------

Initalisation de deux paramètres bp_analytics_id et bp_analytics_domain dans les templates twig de manière à rendre le block body_js_analytics du bundle OryzoneBoilerplateBundle.
