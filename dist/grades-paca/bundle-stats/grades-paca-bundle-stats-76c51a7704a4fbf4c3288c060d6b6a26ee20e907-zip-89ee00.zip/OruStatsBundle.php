<?php

namespace Oru\Bundle\StatsBundle;

use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Oru\Bundle\StatsBundle\DependencyInjection\Compiler\StatsCompilerPass;
use Symfony\Component\DependencyInjection\Compiler\PassConfig;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class OruStatsBundle extends OruBundle
{
    /**
     * {@inheritdoc}
     */
    public static function getFriendlyName()
    {
        return 'Statistiques';
    }

    /**
     * {@inheritdoc}
     */
    public static function getDescription()
    {
        return "Utilisation du service d'analyse d'audience de Google Analytics";
    }



}
