OruStatsBundle
================

Description
-----------

Utilisation du service d'analyse d'audience de Google Analytics.

Installation
------------


Importer le paquet via composer

```
./composer.phar require "oru/stats":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\StatsBundle\OruStatsBundle();
```

Vider le cache de Symfony2

### Liste des paramètres

Il suffit de configurer les deux paramètres bp_analytics_id et bp_analytics_domain :

[Paramètres](./oru_stats_bundle/revisions/master/entry/Resources/settings/OruStatsBundle.generic.orm)

