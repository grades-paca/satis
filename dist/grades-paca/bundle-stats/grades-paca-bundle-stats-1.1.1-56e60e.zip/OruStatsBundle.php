<?php

namespace Oru\Bundle\StatsBundle;

use Oru\Bundle\SettingBundle\Bundle\OruBundle;

class OruStatsBundle extends OruBundle
{
    /**
     * {@inheritdoc}
     */
    public static function getFriendlyName()
    {
        return 'Statistiques';
    }

    /**
     * {@inheritdoc}
     */
    public static function getDescription()
    {
        return "Utilisation du service d'analyse d'audience de Google Analytics";
    }
}
