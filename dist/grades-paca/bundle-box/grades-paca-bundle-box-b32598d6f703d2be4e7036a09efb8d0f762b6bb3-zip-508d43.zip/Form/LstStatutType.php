<?php

namespace Oru\Bundle\BoxBundle\Form;

use Oru\Bundle\LstBundle\Form\LstType;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class LstStatutType extends LstType
{

    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\BoxBundle\Entity\LstStatut'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_boxbundle_lststatut';
    }
}
