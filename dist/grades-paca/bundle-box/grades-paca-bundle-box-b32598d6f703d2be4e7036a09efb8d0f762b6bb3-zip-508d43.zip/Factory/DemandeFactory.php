<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 25/08/14
 */

namespace Oru\Bundle\BoxBundle\Factory;


use Doctrine\ORM\EntityManager;
use Oru\Bundle\BoxBundle\Entity\Demande;
use Oru\Bundle\BoxBundle\Entity\Orubox;
use Oru\Bundle\PatientBundle\Entity\Patient;

class DemandeFactory {

    protected $entityManager;

    /**
     * @param EntityManager $entityManager
     */
    public function __construct(EntityManager $entityManager) {
        $this->entityManager = $entityManager;
    }

    /**
     * @param Orubox $orubox
     * @param $demandeOruboxId
     * @return Demande
     */
    public function get(Orubox $orubox, $demandeOruboxId, Patient $patient) {
        $demande = $this->entityManager->getRepository('OruBoxBundle:Demande')->findBy(array('orubox' => $orubox, 'demandeId' => $demandeOruboxId));
        switch(count($demande)) {
            case 1 :
                return reset($demande);

            case 0 :
                $demande = new Demande();
                $demande->setOrubox($orubox);
                $demande->setDemandeId($demandeOruboxId);
                $demande->setPatient($patient);
                $this->entityManager->persist($demande);
                $this->entityManager->flush($demande);

                return $demande;

            default: return false;
        }

    }
} 