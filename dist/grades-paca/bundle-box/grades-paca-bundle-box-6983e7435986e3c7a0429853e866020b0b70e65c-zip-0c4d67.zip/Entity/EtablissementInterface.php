<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 21/05/14
 */

namespace Oru\Bundle\BoxBundle\Entity;

interface EtablissementInterface
{
    public function getNom();
}
