<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 25/08/14
 */

namespace Oru\Bundle\BoxBundle\Factory;

use Doctrine\ORM\EntityManager;

class OruboxFactory
{
    protected $entityManager;

    /**
     * @param EntityManager $entityManager
     */
    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    public function getByUrl($url)
    {
        return $this->entityManager->getRepository('OruBoxBundle:Orubox')->searchByUrl("$url");
    }
}
