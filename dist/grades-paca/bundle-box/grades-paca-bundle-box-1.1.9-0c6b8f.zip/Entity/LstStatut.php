<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\BoxBundle\Entity;


use Oru\Bundle\LstBundle\Entity\Lst;

class LstStatut extends Lst
{

}