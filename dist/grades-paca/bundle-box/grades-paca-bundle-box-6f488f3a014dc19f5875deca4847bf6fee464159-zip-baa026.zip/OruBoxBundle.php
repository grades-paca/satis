<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\BoxBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruBoxBundle extends Bundle
{
    public function boot() {
        $collection = $this
            ->container
            ->get('routing.loader')
            ->load(__DIR__.'/Resources/config/routing.xml')
        ;

        $this
            ->container
            ->get('router')
            ->getRouteCollection()
            ->addCollection($collection)
        ;
    }
}
