<?php

namespace Oru\Bundle\BoxBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class OruboxListingType extends AbstractListingType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('statut', null, array('important' => false, 'label' => 'listing.statut', 'translation_domain' => 'OruBoxBundle'))
            ->add('libelle', null, array('sort' => 'u.libelle', 'label' => 'listing.libelle', 'translation_domain' => 'OruBoxBundle'))
            ->add('active', null, array('label' => 'listing.active', 'translation_domain' => 'OruBoxBundle'))
            ->add('version', null, array('label' => 'listing.version', 'translation_domain' => 'OruBoxBundle', 'template' => '@OruBox/Orubox/version.html.twig'))
            ->add('url', 'url', array('label' => 'listing.url', 'translation_domain' => 'OruBoxBundle'))
            ->add('etablissements', null, array('label' => 'listing.etablissements', 'translation_domain' => 'OruBoxBundle'))
            ->add('typesDemandes', null, array('important' => false, 'label' => 'listing.typesDemandes', 'translation_domain' => 'OruBoxBundle'))
            ->add('hasSSH', 'checkbox', array('important' => false, 'label' => 'listing.hasSSH', 'translation_domain' => 'OruBoxBundle'))
            ->add('show', 'object_action', array('route' => 'orubox_show', 'label' => 'listing.action.show'))
            ->add('edit', 'object_action', array('route' => 'orubox_edit', 'label' => 'listing.action.edit'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\BoxBundle\Entity\Orubox'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_boxbundle_oruboxlisting';
    }
}
