<?php

namespace Oru\Bundle\BoxBundle\Form;

use Oru\Bundle\FormBundle\Form\Type\ConditionalType;
use Oru\Bundle\FormBundle\Form\Type\PurifiedCkeditorType;
use Oru\Bundle\RorBundle\Form\Type\EtablissementAutocompleteType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class OruboxType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('etablissements', EtablissementAutocompleteType::class, array('label' => 'Orubox.etablissements', 'translation_domain' => 'OruBoxBundle', 'multiple' => true))
            ->add('libelle', null, array('label' => 'Orubox.libelle', 'translation_domain' => 'OruBoxBundle'))
            ->add('commentaire', null, array('label' => 'Orubox.commentaire', 'translation_domain' => 'OruBoxBundle'))
            ->add('url', null, array('label' => 'Orubox.url', 'translation_domain' => 'OruBoxBundle'))
            ->add('active', ConditionalType::class, array(
                'choices' => array(
                    0 => 'Non',
                    1 => 'Oui',
                ),
                'conditionals' => array(
                    0 => array('maintenance'),
                ),
                'label' => 'Orubox.active',
                'translation_domain' => 'OruBoxBundle',
            ))
            ->add('maintenance', null, array('label' => 'Orubox.maintenance', 'translation_domain' => 'OruBoxBundle'))
            ->add('typesDemandes', null, array('label' => 'Orubox.typesDemandes', 'translation_domain' => 'OruBoxBundle'))
            ->add('statut', null, array('label' => 'Orubox.statut', 'translation_domain' => 'OruBoxBundle'))
            ->add('ssh', null, array('label' => 'Orubox.ssh', 'translation_domain' => 'OruBoxBundle'))
            ->add('description', PurifiedCkeditorType::class, array('label' => 'Orubox.description', 'translation_domain' => 'OruBoxBundle', 'attr' => array('rows' => 20, 'columns' => 10)))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\BoxBundle\Entity\Orubox',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_boxbundle_orubox';
    }
}
