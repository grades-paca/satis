<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 21/05/14
 */

namespace Oru\Bundle\BoxBundle\Entity;


interface TypeDemandeInterface {
    public function getLibelle();
    public function hasOrubox();
    public function addOrubox();
    public function getOruboxs();
}