<?php

namespace Oru\Bundle\BoxBundle\Form;

use Oru\Bundle\LstBundle\Form\LstType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class LstStatutType extends LstType
{
    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\BoxBundle\Entity\LstStatut',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_boxbundle_lststatut';
    }
}
