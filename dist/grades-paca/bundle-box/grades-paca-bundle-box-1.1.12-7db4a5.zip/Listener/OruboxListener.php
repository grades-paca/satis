<?php

namespace Oru\Bundle\BoxBundle\Listener;


use Doctrine\ORM\Event\LifecycleEventArgs;
use Oru\Bundle\BoxBundle\Entity\Orubox;
use Symfony\Component\DependencyInjection\Container;

class OruboxListener {

    /**
     * @var TypeDemandeManager
     */
    private $container;

    /**
     * @param Container $container
     */
    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    public function postPersist(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $manager = $args->getEntityManager();
        if ($entity instanceof Orubox) {
            $clientManager = $this->container->get('fos_oauth_server.client_manager.default');
            $client = $clientManager->createClient();
            $client->setRedirectUris(array($entity->getUrl()));
            $client->setAllowedGrantTypes(array('authorization_code', 'refresh_token'));
            if(method_exists($client, "setName"))
                $client->setName($entity->getLibelle());
            if(method_exists($client, "setLocal"))
                $client->setLocal(true);
            $clientManager->updateClient($client);
            $entity->setClient($client);
            $manager->flush();
        }
    }

    public function postUpdate(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $manager = $args->getEntityManager();
        if ($entity instanceof Orubox && $entity->getClient()) {
            $entity->getClient()->setRedirectUris(array($entity->getUrl()));
            $manager->flush();
        }
    }
} 