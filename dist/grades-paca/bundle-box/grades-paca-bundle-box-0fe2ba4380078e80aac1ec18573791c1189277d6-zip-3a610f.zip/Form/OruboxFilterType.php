<?php

namespace Oru\Bundle\BoxBundle\Form;

use Oru\Bundle\FormBundle\Form\Type\OuiNonType;
use Oru\Bundle\RorBundle\Form\Type\EtablissementAutocompleteType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class OruboxFilterType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('typesDemandes', EntityType::class, array('class' => 'Oru\Bundle\TelemedecineBundle\Entity\TypeDemande', 'multiple' => true, 'required' => false, 'label' => 'Orubox.typesDemandes', 'translation_domain' => 'OruBoxBundle'))
            ->add('etablissement', EtablissementAutocompleteType::class, array('required' => false, 'label' => 'Orubox.etablissement', 'translation_domain' => 'OruBoxBundle'))
            ->add('libelle', SearchType::class, array('required' => false, 'label' => 'Orubox.libelle', 'translation_domain' => 'OruBoxBundle'))
            ->add('url', SearchType::class, array('required' => false, 'label' => 'Orubox.url', 'translation_domain' => 'OruBoxBundle'))
            ->add('active', ChoiceType::class, array('choices_as_values' => true, 'choices' => OuiNonType::CHOICES, 'required' => false, 'label' => 'Orubox.active', 'translation_domain' => 'OruBoxBundle'))
            ->add('version', SearchType::class, array('required' => false, 'label' => 'Orubox.version', 'translation_domain' => 'OruBoxBundle'))
            ->add('statut', EntityType::class, array('class' => 'Oru\Bundle\BoxBundle\Entity\LstStatut', 'required' => false, 'label' => 'Orubox.statut', 'translation_domain' => 'OruBoxBundle'))
            ->add('commentaire', SearchType::class, array('required' => false, 'label' => 'Orubox.commentaire', 'translation_domain' => 'OruBoxBundle'))
            ->add('description', SearchType::class, array('required' => false, 'label' => 'Orubox.description', 'translation_domain' => 'OruBoxBundle'))
            ->add('deleted', ChoiceType::class, array('choices' => array('1' => 'Oui', '0' => 'Non'), 'empty_data' => null, 'required' => false, 'label' => 'entity.deleted'))
            ->add('filter', SubmitType::class, array('label' => 'listing.action.filter', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-primary')))
            ->add('reset', SubmitType::class, array('label' => 'listing.action.reset', 'translation_domain' => 'messages', 'attr' => array('class' => 'btn btn-default')))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\BoxBundle\Filter\OruboxFilter',
        ));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_bundle_boxbundle_oruboxfilter';
    }
}
