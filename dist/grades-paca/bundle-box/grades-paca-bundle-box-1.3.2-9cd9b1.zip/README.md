Bundle OruBoxBundle
===================

Description
-----------

Bundle de gestion des oruboxs.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/box":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\BoxBundle\OruBoxBundle();
```

Dans le config.yml, ajouter ce bundle aux paramètres imports :

```
imports:
    ...
    - { resource: @OruBoxBundle/Resources/config/config.yml }
```

Vider le cache de Symfony2

### Liste des pages 

[Pages](./oru_box_bundle/revisions/master/entry/Resources/config/pages.xml)

Utilisation
-----------

Gestion des oruboxs via la route /orubox.