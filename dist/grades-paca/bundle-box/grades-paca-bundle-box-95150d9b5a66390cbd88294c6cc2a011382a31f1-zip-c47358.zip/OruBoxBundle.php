<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\BoxBundle;

use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruBoxBundle extends Bundle
{
    public function boot()
    {
        DynamicLoader::addXml('@OruBoxBundle/Resources/config/routing.xml');
    }
}
