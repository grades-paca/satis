<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 22/05/14
 */

namespace Oru\Bundle\BoxBundle\Manager;


use Doctrine\ORM\EntityManager;
use Oru\Bundle\BoxBundle\Entity\Demande;
use Oru\Bundle\BoxBundle\Entity\Orubox;

class OruboxManager {

    /**
     * @var EntityManager
     */
    private $em;

    /**
     * @var string
     */
    private $typeDemandeClass;

    /**
     * OruboxType constructor.
     */
    public function __construct(EntityManager $em, $typeDemandeClass)
    {
        $this->em = $em;
        $this->typeDemandeClass = $typeDemandeClass;
    }



    public function getRunning(Orubox &$orubox)
    {
        $ch = curl_init($orubox->getUrl());
        //if(TblSettingTable::getValue('proxy_http_address') && TblSettingTable::getValue('proxy_http_port'))
        //    curl_setopt($ch, CURLOPT_PROXY, TblSettingTable::getValue('proxy_http_address') . ':' . TblSettingTable::getValue('proxy_http_port'));
        curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,15);
        curl_setopt($ch,CURLOPT_HEADER,true);
        curl_setopt($ch,CURLOPT_NOBODY,true);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_SSLVERSION, 0);
        $retcode = curl_exec($ch);
        curl_close($ch);
        if ($retcode) {
            $orubox->setRunning(true);
        } else {
            $orubox->setRunning(false);
        }
    }

    public function getUrlForImport(Orubox $orubox, $attributes) {
        return $orubox->getUrl() . '/demandes/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForImport(Orubox $orubox) {
        return $orubox->getEtablissement() .'-'. $orubox->getLibelle() . (($orubox->getCommentaire()) ? ' ('. $orubox->getCommentaire().')' : '');
    }

    public function getUrlForImages(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        return $demande->getOrubox()->getUrl() . '/navicom/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForImages(Demande $demande) {
        return "visualiser les images importées le {$demande->getCreated()->format('d/m/Y H:i')}";
    }

    public function getUrlForImagesHtml5(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        return $demande->getOrubox()->getUrl() . '/dwv/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForImagesHtml5(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForImagesHtml5Simple(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        return $demande->getOrubox()->getUrl() . '/dwv/indexSimple' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForImagesHtml5Simple(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForVideos(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        return $demande->getOrubox()->getUrl() . '/navivid/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForVideos(Demande $demande) {
        return "visualiser les vidéos importées le {$demande->getCreated()->format('d/m/Y H:i')}";
    }

    public function getUrlForNeuroscapeScanner(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        $attributes['application'] = 'neuroscape_scanner';
        return $demande->getOrubox()->getUrl() . '/ulteo/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForNeuroscapeScanner(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForPerfscapeScanner(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        $attributes['application'] = 'perfscape_scanner';
        return $demande->getOrubox()->getUrl() . '/ulteo/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForPerfscapeScanner(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForNeuroscapeIrm(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        $attributes['application'] = 'neuroscape_irm';
        return $demande->getOrubox()->getUrl() . '/ulteo/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForNeuroscapeIrm(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForPerfscapeIrm(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        $attributes['application'] = 'perfscape_irm';
        return $demande->getOrubox()->getUrl() . '/ulteo/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForPerfscapeIrm(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForPapaya(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        $attributes['application'] = 'papaya';
        return $demande->getOrubox()->getUrl() . '/viewer/papaya' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForPapaya(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    /**
     * Gestion de l'association ORUBOX - Type de demandes côté ORUBOX (inverse side)
     * cf : http://doctrine-orm.readthedocs.org/en/latest/reference/unitofwork-associations.html
     *
     * @param Orubox $orubox
     */
    public function checkTypeDemande(Orubox $orubox) {
        $typesDemandes = $this->em->getRepository($this->typeDemandeClass)->findAll();
        foreach($typesDemandes as $typeDemande) {
            if($orubox->getTypesDemandes()->contains($typeDemande)) {
                if(!$typeDemande->getOruboxs()->contains($orubox)) {
                    $typeDemande->addOrubox($orubox);
                }
            } else {
                if($typeDemande->getOruboxs()->contains($orubox)) {
                    $typeDemande->removeOrubox($orubox);
                }
            }
        }
    }
} 