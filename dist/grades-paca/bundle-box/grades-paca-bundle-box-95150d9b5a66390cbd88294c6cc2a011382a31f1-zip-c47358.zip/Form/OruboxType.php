<?php

namespace Oru\Bundle\BoxBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class OruboxType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('etablissement', 'oru_etablissement_autocomplete', array('label' => 'Orubox.etablissement', 'translation_domain' => 'OruBoxBundle'))
            ->add('libelle', null, array('label' => 'Orubox.libelle', 'translation_domain' => 'OruBoxBundle'))
            ->add('commentaire', null, array('label' => 'Orubox.commentaire', 'translation_domain' => 'OruBoxBundle'))
            ->add('url', null, array('label' => 'Orubox.url', 'translation_domain' => 'OruBoxBundle'))
            ->add('active', 'choice', array('choices' => array(0 => 'Non', 1 => 'Oui'), 'label' => 'Orubox.active', 'translation_domain' => 'OruBoxBundle'))
            ->add('typesDemandes', null, array('label' => 'Orubox.typesDemandes', 'translation_domain' => 'OruBoxBundle'))
            ->add('statut', null, array('label' => 'Orubox.statut', 'translation_domain' => 'OruBoxBundle'))
            ->add('ssh', null, array('label' => 'Orubox.ssh', 'translation_domain' => 'OruBoxBundle'))
            ->add('description', 'ckeditor', array('label' => 'Orubox.description', 'translation_domain' => 'OruBoxBundle', 'attr' => array('rows' => 20, 'columns' => 10)))
        ;
    }
    
    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\BoxBundle\Entity\Orubox'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_boxbundle_orubox';
    }
}
