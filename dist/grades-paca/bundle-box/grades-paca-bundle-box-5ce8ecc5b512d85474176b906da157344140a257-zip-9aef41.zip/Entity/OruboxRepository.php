<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 21/05/14
 */

namespace Oru\Bundle\BoxBundle\Entity;


use Doctrine\ORM\EntityRepository;

class OruboxRepository extends EntityRepository {

    /**
     * @param \Oru\Bundle\BoxBundle\Filter\OruboxFilter $filter
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function findList(\Oru\Bundle\BoxBundle\Filter\OruboxFilter $filter)
    {
        $builder = $this->createQueryBuilder("u")->leftJoin('u.typesDemandes', 'td')->leftJoin('u.etablissements', 'e');

        if($filter->getUrl())
        {
            $builder->andWhere("u.url like :url")->setParameter("url","%{$filter->getUrl()}%");
        }
        if($filter->getLibelle())
        {
            $builder->andWhere("u.libelle like :libelle")->setParameter("libelle","%{$filter->getLibelle()}%");
        }
        if($filter->getActive() !== null)
        {
            $builder->andWhere("u.active = :active")->setParameter("active","{$filter->getActive()}");
        }
        if($filter->getEtablissement())
        {
            $builder->andWhere("e.id = :etablissement")->setParameter("etablissement","{$filter->getEtablissement()->getId()}");
        }
        if($filter->getTypesDemandes()->count()) {
            $builder->andWhere("td.id IN (:typesDemandes)")->setParameter("typesDemandes",array_map(function($element) {return $element->getId();}, $filter->getTypesDemandes()->toArray()));
        }
        if($filter->getStatut()) {
            $builder->andWhere("u.statut = :statut")->setParameter("statut",$filter->getStatut());
        }
        if($filter->getCommentaire()) {
            $builder->andWhere("u.commentaire LIKE :commentaire")->setParameter("commentaire","%{$filter->getCommentaire()}%");
        }
        if($filter->getDescription()) {
            $builder->andWhere("u.description LIKE :description")->setParameter("description","%{$filter->getDescription()}%");
        }

        return $builder;
    }

    public function searchByUrl($url) {
        $builder = $this
            ->createQueryBuilder("u")
            ->andWhere("u.url like :url")->setParameter("url","%$url%")
            ->andWhere('u.active = 1')
        ;

        return $builder->getQuery()->getResult();
    }

} 