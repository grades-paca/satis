<?php

namespace Oru\Bundle\BoxBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\OAuthBundle\Entity\Client;

/**
 * Orubox
 */
class Orubox
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $url;

    /**
     * @var boolean
     */
    private $active;

    /**
     * @var string
     */
    private $commentaire;

    /**
     * @var string
     */
    private $libelle;
    /**
     * @var boolean
     */
    private $running;

    /**
     * @var \DateTime
     */
    private $created;

    /**
     * @var \DateTime
     */
    private $updated;

    /**
     * @var Client
     */
    private $client;

    /**
     * @var \Doctrine\Common\Collections\Collection
     */
    private $typesDemandes;

    /**
     * @var integer
     */
    private $statut;

    /**
     * @var string
     */
    private $ssh;

    /**
     * @var string
     */
    private $description;

    /**
     * @var \Doctrine\Common\Collections\Collection
     */
    private $etablissements;

    /**
     * @var \Doctrine\Common\Collections\Collection
     */
    private $demandes;

    /**
     * @var string
     */
    private $maintenance;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->demandes = new \Doctrine\Common\Collections\ArrayCollection();
        $this->typesDemandes = new \Doctrine\Common\Collections\ArrayCollection();
        $this->etablissements = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set url
     *
     * @param string $url
     * @return Orubox
     */
    public function setUrl($url)
    {
        $this->url = $url;
    
        return $this;
    }

    /**
     * Get url
     *
     * @return string 
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * Set active
     *
     * @param boolean $active
     * @return Orubox
     */
    public function setActive($active)
    {
        $this->active = $active;
    
        return $this;
    }

    /**
     * Get active
     *
     * @return boolean 
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set commentaire
     *
     * @param string $commentaire
     * @return Orubox
     */
    public function setCommentaire($commentaire)
    {
        $this->commentaire = $commentaire;
    
        return $this;
    }

    /**
     * Get commentaire
     *
     * @return string 
     */
    public function getCommentaire()
    {
        return $this->commentaire;
    }

    /**
     * Set libelle
     *
     * @param string $libelle
     * @return Orubox
     */
    public function setLibelle($libelle)
    {
        $this->libelle = $libelle;
    
        return $this;
    }

    /**
     * Get libelle
     *
     * @return string 
     */
    public function getLibelle()
    {
        return $this->libelle;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getLibelle();
    }

    /**
     * @param boolean $running
     */
    public function setRunning($running)
    {
        $this->running = $running;
    }

    /**
     * @return boolean
     */
    public function getRunning()
    {
        return $this->running;
    }
    
    /**
     * Add demandes
     *
     * @param \Oru\Bundle\BoxBundle\Entity\Demande $demandes
     * @return Orubox
     */
    public function addDemande(\Oru\Bundle\BoxBundle\Entity\Demande $demandes)
    {
        $this->demandes[] = $demandes;
    
        return $this;
    }

    /**
     * Remove demandes
     *
     * @param \Oru\Bundle\BoxBundle\Entity\Demande $demandes
     */
    public function removeDemande(\Oru\Bundle\BoxBundle\Entity\Demande $demandes)
    {
        $this->demandes->removeElement($demandes);
    }

    /**
     * Get demandes
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getDemandes()
    {
        return $this->demandes;
    }

    /**
     * @param \Oru\Bundle\BoxBundle\Entity\DateTime $created
     */
    public function setCreated($created)
    {
        $this->created = $created;
    }

    /**
     * @return \Oru\Bundle\BoxBundle\Entity\DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param \Oru\Bundle\BoxBundle\Entity\DateTime $updated
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;
    }

    /**
     * @return \Oru\Bundle\BoxBundle\Entity\DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * @return Client
     */
    public function getClient()
    {
        return $this->client;
    }

    /**
     * @param Client $client
     */
    public function setClient(Client $client)
    {
        $this->client = $client;
    }

    /**
     * @return array
     */
    public function getTypesDemandes()
    {
        return $this->typesDemandes;
    }

    /**
     * @return int
     */
    public function getStatut()
    {
        return $this->statut;
    }

    /**
     * @param int $statut
     */
    public function setStatut($statut)
    {
        $this->statut = $statut;
    }

    /**
     * @return string
     */
    public function getSsh()
    {
        return $this->ssh;
    }

    /**
     * @param string $ssh
     */
    public function setSsh($ssh)
    {
        $this->ssh = $ssh;
    }

    public function getSshRoot() {
        return preg_replace('/([a-zA-Z0-9]*)(@[a-zA-Z0-9]*[:]*.[0-9]*)/', 'root$2', $this->ssh, 1);
    }

    /**
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param string $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * @return boolean
     */
    public function hasSSH()
    {
        return trim($this->ssh) != '';
    }

    /**
     * Add etablissement
     *
     * @param $etablissement
     * @return Orubox
     */
    public function addEtablissement($etablissement)
    {
        $this->etablissements[] = $etablissement;

        return $this;
    }

    /**
     * Remove etablissement
     *
     * @param $etablissement
     */
    public function removeEtablissement($etablissement)
    {
        $this->etablissements->removeElement($etablissement);
    }

    /**
     * Get etablissements
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getEtablissements()
    {
        return $this->etablissements;
    }

    /**
     * @return string
     */
    public function getNomEtablissements() {
        $etabs = $this->etablissements->toArray();
        uasort($etabs, function($a, $b) {
            if(!is_object($a)) return 1;
            if(!is_object($b)) return -1;

            if($a->getNom() == $b->getNom())
                return 0;

            return ($a->getNom() < $b->getNom()) ? -1 : 1;
        });

        return implode(" / ", $etabs);
    }

    /**
     * @return string
     */
    public function getMaintenance()
    {
        return $this->maintenance;
    }

    /**
     * @param string $maintenance
     */
    public function setMaintenance($maintenance)
    {
        $this->maintenance = $maintenance;
    }
}