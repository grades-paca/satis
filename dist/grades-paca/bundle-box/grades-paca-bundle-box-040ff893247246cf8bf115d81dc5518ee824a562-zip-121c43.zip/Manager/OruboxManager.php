<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 22/05/14
 */

namespace Oru\Bundle\BoxBundle\Manager;


use Doctrine\ORM\EntityManager;
use Oru\Bundle\BoxBundle\Entity\Demande;
use Oru\Bundle\BoxBundle\Entity\Orubox;
use Oru\Bundle\WebClientBundle\Client\ProxyClient;
use Oru\Bundle\WebClientBundle\Exception\RuntimeException;

class OruboxManager {

    /**
     * @var EntityManager
     */
    private $em;

    /**
     * @var string
     */
    private $typeDemandeClass;

    /**
     * @var ProxyClient
     */
    private $webClient;

    /**
     * OruboxType constructor.
     */
    public function __construct(EntityManager $em, $typeDemandeClass, ProxyClient $webClient)
    {
        $this->em = $em;
        $this->typeDemandeClass = $typeDemandeClass;
        $this->webClient = $webClient;
    }

    /**
     * L'orubox est-elle visible ?
     *
     * @param Orubox $orubox
     */
    public function getRunning(Orubox &$orubox)
    {
        $options = $this->webClient->getOptions();
        $options->set(CURLOPT_CONNECTTIMEOUT, 15);
        $options->set(CURLOPT_NOBODY, true);
        $options->set(CURLOPT_RETURNTRANSFER, true);
        $options->set(CURLOPT_SSLVERSION, 0);

        try {
            $retcode = $this->webClient->get($orubox->getUrl());
        } catch (RuntimeException $e) {
            $retcode = false;
        }

        if (false !== $retcode) {
            $orubox->setRunning(true);
        } else {
            $orubox->setRunning(false);
        }
    }

    public function getUrlForImport(Orubox $orubox, $attributes) {
        return $orubox->getUrl() . '/demandes/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForImport(Orubox $orubox) {
        return $orubox->getNomEtablissements() .' - '. $orubox->getLibelle() . (($orubox->getCommentaire()) ? ' ('. $orubox->getCommentaire().')' : '');
    }

    public function getUrlForImages(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        return $demande->getOrubox()->getUrl() . '/navicom/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForImages(Demande $demande) {
        return "visualiser les images importées le {$demande->getCreated()->format('d/m/Y H:i')}";
    }

    public function getUrlForImagesHtml5(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        return $demande->getOrubox()->getUrl() . '/dwv/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForImagesHtml5(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForImagesHtml5Simple(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        return $demande->getOrubox()->getUrl() . '/dwv/indexSimple' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForImagesHtml5Simple(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForVideos(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        return $demande->getOrubox()->getUrl() . '/navivid/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForVideos(Demande $demande) {
        return "visualiser les vidéos importées le {$demande->getCreated()->format('d/m/Y H:i')}";
    }

    public function getUrlForNeuroscapeScanner(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        $attributes['application'] = 'neuroscape_scanner';
        return $demande->getOrubox()->getUrl() . '/ulteo/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForNeuroscapeScanner(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForPerfscapeScanner(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        $attributes['application'] = 'perfscape_scanner';
        return $demande->getOrubox()->getUrl() . '/ulteo/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForPerfscapeScanner(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForNeuroscapeIrm(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        $attributes['application'] = 'neuroscape_irm';
        return $demande->getOrubox()->getUrl() . '/ulteo/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForNeuroscapeIrm(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForPerfscapeIrm(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        $attributes['application'] = 'perfscape_irm';
        return $demande->getOrubox()->getUrl() . '/ulteo/index' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForPerfscapeIrm(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForPapaya(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        $attributes['application'] = 'papaya';
        return $demande->getOrubox()->getUrl() . '/viewer/papaya' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForPapaya(Demande $demande) {
        return $this->getHelpForImages($demande);
    }

    public function getUrlForStudyDownload(Demande $demande, $attributes) {
        $attributes['orubox_demande_id'] = $demande->getDemandeId();
        $attributes['application'] = 'orthanc';
        return $demande->getOrubox()->getUrl() . '/rorthanc/download' . ((!empty($attributes)) ? '?' . http_build_query($attributes) : '');
    }

    public function getHelpForStudyDownload(Demande $demande) {
        return "télécharger l'examen du {$demande->getCreated()->format('d/m/Y H:i')}";
    }

    /**
     * Gestion de l'association ORUBOX - Type de demandes côté ORUBOX (inverse side)
     * cf : http://doctrine-orm.readthedocs.org/en/latest/reference/unitofwork-associations.html
     *
     * @param Orubox $orubox
     */
    public function checkTypeDemande(Orubox $orubox) {
        $typesDemandes = $this->em->getRepository($this->typeDemandeClass)->findAll();
        foreach($typesDemandes as $typeDemande) {
            if($orubox->getTypesDemandes()->contains($typeDemande)) {
                if(!$typeDemande->getOruboxs()->contains($orubox)) {
                    $typeDemande->addOrubox($orubox);
                }
            } else {
                if($typeDemande->getOruboxs()->contains($orubox)) {
                    $typeDemande->removeOrubox($orubox);
                }
            }
        }
    }
} 