<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 22/08/14
 */

namespace Oru\Bundle\BoxBundle\Entity;


class Demande {

    /**
     * @var integer
     */
    private $demandeId;

    /**
     * @var integer
     */
    private $id;

    /**
     * @var \Oru\Bundle\BoxBundle\Entity\Orubox
     */
    private $orubox;

    /**
     * @var DateTime
     */
    private $created;

    /**
     * @var DateTime
     */
    private $updated;

    /**
     * @var \Oru\Bundle\PatientBundle\Entity\Patient
     */
    private $patient;

    /**
     * Set demandeId
     *
     * @param integer $demandeId
     * @return Demande
     */
    public function setDemandeId($demandeId)
    {
        $this->demandeId = $demandeId;
    
        return $this;
    }

    /**
     * Get demandeId
     *
     * @return integer 
     */
    public function getDemandeId()
    {
        return $this->demandeId;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set orubox
     *
     * @param \Oru\Bundle\BoxBundle\Entity\Orubox $orubox
     * @return Demande
     */
    public function setOrubox(\Oru\Bundle\BoxBundle\Entity\Orubox $orubox = null)
    {
        $this->orubox = $orubox;
    
        return $this;
    }

    /**
     * Get orubox
     *
     * @return \Oru\Bundle\BoxBundle\Entity\Orubox 
     */
    public function getOrubox()
    {
        return $this->orubox;
    }

    /**
     * @param \Oru\Bundle\BoxBundle\Entity\DateTime $created
     */
    public function setCreated($created)
    {
        $this->created = $created;
    }

    /**
     * @return \Oru\Bundle\BoxBundle\Entity\DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param \Oru\Bundle\BoxBundle\Entity\DateTime $updated
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;
    }

    /**
     * @return \Oru\Bundle\BoxBundle\Entity\DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * @return \Oru\Bundle\PatientBundle\Entity\Patient
     */
    public function getPatient()
    {
        return $this->patient;
    }

    /**
     * @param \Oru\Bundle\PatientBundle\Entity\Patient $patient
     */
    public function setPatient($patient)
    {
        $this->patient = $patient;
    }
}