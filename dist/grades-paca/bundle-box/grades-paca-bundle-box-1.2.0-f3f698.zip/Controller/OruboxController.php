<?php

namespace Oru\Bundle\BoxBundle\Controller;

use Exporter\Handler;
use Exporter\Source\ArraySourceIterator;
use Exporter\Writer\CsvWriter;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Oru\Bundle\BoxBundle\Entity\Orubox;
use Oru\Bundle\BoxBundle\Listing\OruboxListingType;
use Oru\Bundle\BoxBundle\Form\OruboxFilterType;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * Orubox controller.
 *
 */
class OruboxController extends Controller
{

    /**
     * Lists all Orubox entities.
     *
     */
    public function indexAction(Request $request)
    {
        $form = $this->createForm(new OruboxFilterType())->submit($request->getSession()->get('orubox.filter', array()));
        $listing = $this->container->get('paginator.factory')->create(
            new OruboxListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruBoxBundle:Orubox')->findList($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('@OruBox/Orubox/index.html.twig', array(
            'listing' => $listing,
            'form' => $this->createForm(new OruboxFilterType(), $form->getData())->createView()
        ));
    }
    /**
     * Filters Orubox entities.
     *
     */
    public function filterAction(Request $request)
    {
        $form = $this->createForm(new OruboxFilterType())->handleRequest($request);

        if ($form->get('reset')->isClicked())
        {
            $request->getSession()->remove('orubox.filter');
            return $this->redirect($this->generateUrl('orubox'));
        }

        if($form->isValid()) {
            $request->getSession()->set('orubox.filter', $request->get($form->getName()));
            return $this->redirect($this->generateUrl('orubox'));
        }

        $listing = $this->container->get('paginator.factory')->create(
            new OruboxListingType(),
            $this->getDoctrine()->getManager()->getRepository('OruBoxBundle:Orubox')->findList($form->getData()),
            $request->query->get('page', 1)
        );

        return $this->render('@OruBox/Orubox/index.html.twig', array(
            'listing' => $listing,
            'form' => $form->createView(),
            'attachments'   => array()
        ));
    }

    public function exportAction(Request $request, $root = 0) {
        $form = $this->createForm(new OruboxFilterType())->submit($request->getSession()->get('orubox.filter', array()));
        $oruboxs = $this->getDoctrine()->getManager()->getRepository('OruBoxBundle:Orubox')->findList($form->getData())->getQuery()->execute();
        $source = new ArraySourceIterator(array_map(function($elm) use ($root) {return array(($root) ? $elm->getSshRoot() : $elm->getSsh());}, $oruboxs));
        $writer = new CsvWriter('php://output', ',', '"', '\\', false);

        $callback = function() use ($source, $writer) {
            $handler = Handler::create($source, $writer);
            $handler->export();
        };

        return new StreamedResponse($callback, 200, array(
            'Content-Type'        => 'text/csv',
            'Content-Disposition' => sprintf('attachment; filename="%s"', 'oruboxs' . (($root) ? '_root': ''))
        ));
    }

    /**
     * Creates a new Orubox entity.
     *
     */
    public function createAction(Request $request)
    {
        $entity = new Orubox();
        $form = $this->createCreateForm($entity);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($entity);
            $this->get('oru_box.orubox_manager')->checkTypeDemande($entity);
            $em->flush();
            $this->get('oru_attachment.context')->linkEntities($request->get('attachments'), $entity);

            return $this->redirect($this->generateUrl('orubox_show', array('id' => $entity->getId())));
        }

        return $this->render('@OruBox/Orubox/edit.html.twig', array(
            'entity' => $entity,
            'form'   => $form->createView(),
            'attachments'   => $request->get('attachments')
        ));
    }

    /**
    * Creates a form to create a Orubox entity.
    *
    * @param Orubox $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    */
    private function createCreateForm(Orubox $entity)
    {
        $form = $this->createForm($this->get('oru_box.form'), $entity, array(
            'action' => $this->generateUrl('orubox_create'),
            'method' => 'POST',
        ));

        return $form;
    }

    /**
     * Displays a form to create a new Orubox entity.
     *
     */
    public function newAction()
    {
        $entity = new Orubox();
        $form   = $this->createCreateForm($entity);

        return $this->render('@OruBox/Orubox/edit.html.twig', array(
            'entity' => $entity,
            'form'   => $form->createView(),
            'attachments'   => array()
        ));
    }

    /**
     * Finds and displays a Orubox entity.
     *
     */
    public function showAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruBoxBundle:Orubox')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Orubox entity.');
        }

        $deleteForm = $this->createDeleteForm($id);

        return $this->render('@OruBox/Orubox/show.html.twig', array(
            'entity'      => $entity,
            'delete_form' => $deleteForm->createView(),        ));
    }

    /**
     * Displays a form to edit an existing Orubox entity.
     *
     */
    public function editAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruBoxBundle:Orubox')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Orubox entity.');
        }

        $editForm = $this->createEditForm($entity);

        return $this->render('@OruBox/Orubox/edit.html.twig', array(
            'entity'      => $entity,
            'form'   => $editForm->createView(),
            'attachments'   => array()
        ));
    }

    /**
    * Creates a form to edit a Orubox entity.
    *
    * @param Orubox $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    */
    private function createEditForm(Orubox $entity)
    {
        $form = $this->createForm($this->get('oru_box.form'), $entity, array(
            'action' => $this->generateUrl('orubox_update', array('id' => $entity->getId())),
            'method' => 'PUT',
        ));

        return $form;
    }
    /**
     * Edits an existing Orubox entity.
     *
     */
    public function updateAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('OruBoxBundle:Orubox')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Orubox entity.');
        }

        $editForm = $this->createEditForm($entity);
        $editForm->handleRequest($request);

        if ($editForm->isValid()) {
            $this->get('oru_box.orubox_manager')->checkTypeDemande($entity);
            $em->flush();
            $this->get('oru_attachment.context')->linkEntities($request->get('attachments'), $entity);

            return $this->redirect($this->generateUrl('orubox_show', array('id' => $id)));
        }

        return $this->render('@OruBox/Orubox/edit.html.twig', array(
            'entity'      => $entity,
            'form'   => $editForm->createView(),
            'attachments'   => $request->get('attachments')
        ));
    }
    /**
     * Deletes a Orubox entity.
     *
     */
    public function deleteAction(Request $request, $id)
    {
        $form = $this->createDeleteForm($id);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $entity = $em->getRepository('OruBoxBundle:Orubox')->find($id);

            if (!$entity) {
                throw $this->createNotFoundException('Unable to find Orubox entity.');
            }

            $em->remove($entity);
            $em->flush();
        }

        return $this->redirect($this->generateUrl('orubox'));
    }

    /**
     * Creates a form to delete a Orubox entity by id.
     *
     * @param mixed $id The entity id
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm($id)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('orubox_delete', array('id' => $id)))
            ->setMethod('DELETE')
            ->add('submit', 'submit', array('label' => $this->get('translator')->trans('listing.action.delete')))
            ->getForm()
        ;
    }

    /**
     * Creates a new Session entity.
     *
     */
    public function runningAction(Request $request, $id)
    {
        session_write_close();
        $entity = $this->getDoctrine()->getRepository('OruBoxBundle:Orubox')->find($id);
        $this->get('oru_box.orubox_manager')->getRunning($entity);

        if($this->has('_format') && $this->get('_format') == 'json')
            return new JsonResponse(($entity->getRunning()) ? $this->get('translator')->trans('yes') : $this->get('translator')->trans('no'));

        return $this->render('@OruListing/Listing/Type/listing_checkbox_type.html.twig', array(
            'entity' => $entity,
            'label' => 'running'
        ));
    }
}
