<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Form\DataTransformer;


use Exercise\HTMLPurifierBundle\Form\HTMLPurifierTransformer;

class PurifierTransformer extends HTMLPurifierTransformer
{
    /**
     * @inheritdoc
     */
    public function reverseTransform($value)
    {
        if('' === $value)
            return null;

        return parent::reverseTransform($value);
    }
}