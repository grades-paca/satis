<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 23/11/2016
 * Time: 16:52
 */

namespace Oru\Bundle\FormBundle\Form\Type;

/**
 * Class PurifiedTextType
 * @package Oru\Bundle\FormBundle\Form\Type
 */
class PurifiedTextType extends PurifiedAbstractType
{
    /**
     * @return string
     */
    public function getParent()
    {
        return 'textarea';
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_purified_text';
    }
}