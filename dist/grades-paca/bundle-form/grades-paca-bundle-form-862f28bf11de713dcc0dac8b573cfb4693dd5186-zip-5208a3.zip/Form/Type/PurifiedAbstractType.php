<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 24/11/2016
 * Time: 13:39
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\DataTransformerInterface;

/**
 * Class PurifiedAbstractType
 * @package Oru\Bundle\FormBundle\Form\Type
 */
abstract class PurifiedAbstractType extends AbstractType
{
    /**
     * @var DataTransformerInterface
     */
    private $purifierTransformer;

    /**
     * PurifiedTextType constructor.
     * @param DataTransformerInterface $purifierTransformer
     */
    public function __construct(DataTransformerInterface $purifierTransformer)
    {
        $this->purifierTransformer = $purifierTransformer;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        if($options['purified']){
            $builder->addViewTransformer($this->purifierTransformer);
        }
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefined(array('purified'));
        $resolver->setDefaults(array('purified' => true));
    }

    /**
     * @return string
     * Cette méthode devrait toujours être surchargée
     */
    public function getName()
    {
        return 'oru_purified_abstract';
    }
}