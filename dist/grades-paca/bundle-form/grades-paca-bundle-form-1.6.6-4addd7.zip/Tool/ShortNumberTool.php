<?php

namespace Oru\Bundle\FormBundle\Tool;

use libphonenumber\PhoneNumber;
use Oru\Bundle\FormBundle\Exception\NotShortNumberException;

/**
 * Class ShortNumberTool
 *
 * @package Oru\Bundle\FormBundle\Tool
 * @author Michaël VEROUX
 */
class ShortNumberTool
{
    static public $short_2_3 = array(
        '15',
        '17',
        '18',
        '110',
        '112',
        '115',
        '119',
    );

    /**
     * @param PhoneNumber $phoneNumber
     *
     * @return null|string
     * @throws NotShortNumberException
     * @author Michaël VEROUX
     */
    static public function getShortNumber(PhoneNumber $phoneNumber)
    {
        if(self::isShort($phoneNumber->getNationalNumber())) {
            return $phoneNumber->getNationalNumber();
        }

        throw new NotShortNumberException('Number is not a short one!');
    }

    /**
     * @param string $string
     *
     * @return PhoneNumber
     * @throws NotShortNumberException
     * @author Michaël VEROUX
     */
    static public function getPhoneNumber($string)
    {
        $string = preg_replace('#[^0-9]#', '', $string);

        if(self::isShort($string)) {
            $phoneNumber = new PhoneNumber();
            $phoneNumber->setNationalNumber($string);

            return $phoneNumber;
        }

        throw new NotShortNumberException('Number is not a short one!');
    }

    /**
     * @param string $number
     *
     * @return bool
     * @author Michaël VEROUX
     */
    static public function isShort($number)
    {
        if(preg_match("/^([0-9]{2,5})$/", $number)) {
            if (3 >= strlen($number) && !in_array($number, self::$short_2_3)) {
                return false;
            }

            return true;
        }

        return false;
    }
}
