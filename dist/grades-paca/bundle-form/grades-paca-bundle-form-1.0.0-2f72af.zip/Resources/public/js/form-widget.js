function odd_even_rows(selector)
{
    if(typeof selector == 'undefined' || selector == null)
    {
        odd_even_rows_locked = true;
        selector = 'form div > .form_row:visible';
    }

    var odd_even = 1;
    if(jQuery(selector).hasClass('odd'))
        odd_even = 1;

    jQuery(selector).each(function(){
        jQuery(this).removeClass('.ui-widget-content').addClass('.ui-widget-content');
        if(odd_even % 2)
        {
            jQuery(this).removeClass('odd').removeClass('even').addClass('odd');
        }
        else
        {
            jQuery(this).removeClass('odd').removeClass('even').addClass('even');
        }
        odd_even++;
        odd_even_rows(jQuery(this).children('.form_row:visible'), true);
    });
}
function oui_non_detail_State(id, parent_id, detail, on_no)
{
    var selectedVal = '';
    var selected = jQuery('div#' + id + ' input[type="radio"]:checked, select#' + id);
    if(selected.length > 0)
    {
        if(jQuery('select#' + id).length > 0)
            selectedVal = jQuery('select#' + id).val();
        else
            selectedVal = selected.val();
    }

    var expected = (! on_no) << 0;
    expected = expected.toString();

    var detail_selector = '#' + parent_id + '_' + detail;

    if(selectedVal ===  expected)
    {
        jQuery(detail_selector).removeClass('form_hidden').parents('.form_row:first').show();
    }
    else
    {
        jQuery(detail_selector).addClass('form_hidden').parents('.form_row:first').hide();
    }
}
function checked_detail_State(id, parent_id, detail)
{
    var selectedVal = jQuery('input#' + id).is(':checked');

    var detail_selector = '#' + parent_id + '_' + detail;

    if(selectedVal)
    {
        jQuery(detail_selector).removeClass('form_hidden').parents('.form_row:first').show();
    }
    else
    {
        jQuery(detail_selector).addClass('form_hidden').parents('.form_row:first').hide();
    }
}
function sum_of(id, class_type)
{
    var sum = 0;
    jQuery('.' + class_type).each(function() {
        var current_val = $(this).val().replace(',','.').replace(' ','');
        if('' == current_val){ current_val = '0'; }
        sum += parseFloat(current_val);
    });
    sum = sum.toString().replace('.',',');
    jQuery('#' + id).val(sum);
    jQuery('#' + id).change();
}
function percent_calc(id, type_class, type_class_total)
{
    var sum_total = 0;
    jQuery('.' + type_class_total).each(function() {
        var current_val = $(this).val().replace(',','.').replace(' ','');
        if('' == current_val){ current_val = '0'; }
        sum_total += parseFloat(current_val);
    });

    if(sum_total === 0){
        jQuery('#' + id).val('');
        jQuery('#' + id).change();
        return;
    }

    var sum = 0;
    jQuery('.' + type_class).each(function() {
        var current_val = $(this).val().replace(',','.').replace(' ','');
        if('' == current_val){ current_val = '0'; }
        sum += parseFloat(current_val);
    });
    var percent = sum * 100 / sum_total;
    percent = percent.toString().replace('.',',');
    jQuery('#' + id).val(percent);
    jQuery('#' + id).change();
}
jQuery( document ).ready(function(){
    jQuery('form').submit(function(){
        jQuery('.form_hidden').prop('disabled', true);
    });
    jQuery('form div.form_row:not(:has("div.form_row"))').addClass('final_row');
});

// jQuery plugin to prevent double submission of forms
jQuery.fn.preventDoubleSubmission = function() {
    $(this).on('submit',function(e){
        var $form = $(this);

        if ($form.data('submitted') === true) {
            // Previously submitted - don't submit again
            e.preventDefault();
        } else {
            // Mark it so that the next submit can be ignored
            $form.data('submitted', true);
        }
    });

    // Keep chainability
    return this;
};

function select2_popover_tooltip() {
    jQuery("div.select2-container").each( function(){
        switch($(this).next().attr("data-toggle")) {
            case "popover":
                $(this).popover({
                    title: $(this).next().attr("title"),
                    content: $(this).next().attr("data-content"),
                    trigger: $(this).next().attr("data-trigger"),
                    animation: $(this).next().attr("data-animation"),
                    delay: $(this).next().attr("data-delay"),
                    html: $(this).next().attr("data-html"),
                    placement: $(this).next().attr("data-placement"),
                    selector: $(this).next().attr("data-selector"),
                    template: $(this).next().attr("data-template"),
                    viewport: $(this).next().attr("data-viewport")
                });
                break;
            case "tooltip":
                $(this).tooltip({
                    title: $(this).next().attr("title"),
                    trigger: $(this).next().attr("data-trigger"),
                    animation: $(this).next().attr("data-animation"),
                    delay: $(this).next().attr("data-delay"),
                    html: $(this).next().attr("data-html"),
                    placement: $(this).next().attr("data-placement"),
                    selector: $(this).next().attr("data-selector"),
                    template: $(this).next().attr("data-template"),
                    viewport: $(this).next().attr("data-viewport"),
                    container: $(this).next().attr("data-container")
                });
                break;
        }
    });
}

/**
* Permet d'injecter les options de bootstrap tooltip et popover aux champs select2
*/
$(document).ready(function () {
    select2_popover_tooltip();

    // jQuery plugin to prevent double submission of forms
    $('form.prevent-dbl-submit:not(.allow-dbl-submit)').preventDoubleSubmission();
});