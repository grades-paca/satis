<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 20/01/14
 * Time: 11:54
 */

namespace Oru\Bundle\FormBundle\Form\Type;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class PercentCalcType extends AbstractType
{
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setRequired(array('type_class','type_class_total'));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        $view->vars['type_class'] = $options['type_class'];
        $view->vars['type_class_total'] = $options['type_class_total'];
        $view->vars['precision'] = empty($options['precision']) ? 0 : $options['precision'];
    }

    public function getParent()
    {
        return 'percent';
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_percent_calc';
    }
}