<?php

namespace Oru\Bundle\FormBundle\Validator\Constraints;

use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;

/**
 * Class FullUniqueEntity
 *
 * @package Oru\Bundle\FormBundle\Validator\Constraints
 * @author Michaël VEROUX
 */
class FullUniqueEntity extends UniqueEntity
{
    public $service = 'oru_form.full_unique_entity';
}
