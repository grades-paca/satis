OruFormBundle
=============

Description
-----------

Ce bundle regroupe des fonctionnalités utiles à tous les formulaires. Le but de celui-ci est de regrouper toutes les surcharges de champs, widgets, validators de manière à avoir un comportement uniforme sur différentes plateformes tout en gardant la possibilité de remplacer ou retirer facilement un comportement.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/form":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\FormBundle\OruFormBundle();
$bundles[] = new Ivory\CKEditorBundle\IvoryCKEditorBundle();
$bundles[] = new FM\ElfinderBundle\FMElfinderBundle();
$bundles[] = new Gregwar\CaptchaBundle\GregwarCaptchaBundle();
$bundles[] = new Misd\PhoneNumberBundle\MisdPhoneNumberBundle();
$bundles[] = new Exercise\HTMLPurifierBundle\ExerciseHTMLPurifierBundle();
```

Dans le config.yml, ajouter ce bundle aux paramètres imports (seulement si le bundle est utilisé séparément de OruDesignBundle) :

```
imports:
    ...
    - { resource: @OruFormBundle/Resources/config/config.yml }
```

Configurer le paramètre upload_mime_types dans le fichier parameters.yml. Ce paramètre doit contenir un tableau des types mimes acceptés.

Suivre la documentation d'installation du bundle OruSettingBundle.

Vider le cache de Symfony2

Utilisation
-----------

### Guesser

    La classe Guesser\OruTypeGuesser.php permet de surcharger le type de champ qui sera affiché pour un formulaire lié à une entité.

### Validators

#### LengthParameter
    
        Même fonctionnement que le validator Length avec les paramètres min et max mais l'argument est un paramètre de l'application. Exemple d'un fichier validation.yml :
        
```yaml
plainPassword:
    - Oru\Bundle\FormBundle\Validator\Constraints\LengthParameter: { min: professionnel_password_min_length }
```

#### PhoneNumber
    
        Même fonctionnement que le validator dont il hérite mais avec le support des numéros magiques (4 chiffres)  :
        
```yaml
telephone:
    - Oru\Bundle\FormBundle\Validator\Constraints\PhoneNumber: { message: 'phone.value.invalid' }
```

### Widgets

#### - oru\_oui\_non

```
Est un simple widget pour représenter un booléen, il est "expanded" par défaut.
expanded = true => il est représenté par 2 boutons radio
expanded = false => il est représenté par un select, si l'on renseigne le paramètre "placeholder", il peut ne pas être renseigné (si le validator du champ le permet), le libellé de placeholder est affiché par défaut.
```

Exemples d'utilisation :

```php
$builder
    ->add('my_field', 'oru_oui_non', array(
                        'placeholder'       =>  'Ne sais pas',
                        'expanded'          =>  false,
        )
    )
;
$builder
    ->add('my_field', 'oru_oui_non'
    )
;
```
#### - oru\_oui\_non_detail

```
Est une extension de oru_oui_non qui permet de désigner un widget qui contient le détail suivant la réponse.
Par défaut, le détail est affiché quand le non est sélectionné. S'il doit être sur le oui, le paramètre on_no qui est à true par défaut peut-être mis à false.
```

Exemples d'utilisation :

```php
$builder
    ->add('my_field', 'oru_oui_non_detail', array(
                        'detail'       =>  'my_field_detail',
        )
    )
    ->add('my_field_detail'
    )
;

$builder
    ->add('my_field', 'oru_oui_non_detail', array(
                        'on_no'        =>  false,
                        'detail'       =>  'my_field_detail',
        )
    )
    ->add('my_field_detail'
    )
;
```

#### - oru\_conditional

```
Est un widget qui permet de désigner des widgets qui seront affichés ou masqués selon les réponses données.
```

Exemple d'utilisation :

```php
$builder
    ->add('my_field', 'oru_conditional', array(
            'placeholder'       =>  '---choix---',
            'choices'           =>  array(
                '1'         =>  'oui',
                '0'         =>  'non',
                '2'         =>  'en cours',
                '3'         =>  'en projet',
            ),
            'conditionals'          =>  array(
                '1'         =>  array('my_field_1','my_field_2'),
                '2'         =>  array('my_field_3'),
            ),
        )
    )
;
```

#### - oru\_sum

```
Ce widget permet d'afficher la somme de widgets de type numérique. Si l'information est juste visuelle et ne doit pas être mappées, ajouter le paramètre "mapped = false".
```

Exemple d'utilisation :

```php
$builder
    ->add('sum_my_field', 'oru_sum', array(
            'mapped'        => false,
            'type_class'    => 'sum_my_field',
            'attr'          => array('disabled' => 'disabled'),
        )
    )
    ->add('my_field_1', 'number', array(
            'attr'          => array('class' => 'sum_my_field'),
        )
    )
    ->add('my_field_2', 'number', array(
            'attr'          => array('class' => 'sum_my_field'),
        )
    )
;
```

#### - oru\_percent\_calc

```
Ce widget permet de calculer un pourcentage à partir de 2 sommes de widgets, comme oru_sum, le mapping peut-être conservé ou désactivé (mapped).
```

Exemple d'utilisation :

```php
$builder
    ->add('percent_my_field', 'oru_percent_calc', array(
            'type_class'        => 'my_field_percent',
            'type_class_total'  => 'my_field_percent_total',
        )
    )
    ->add('my_field_1', 'number', array(
            'attr'          => array('class' => 'my_field_percent'),
        )
    )
    ->add('my_field_2', 'number', array(
            'attr'          => array('class' => 'my_field_percent'),
        )
    )
    ->add('my_field_3', 'number', array(
            'attr'          => array('class' => 'my_field_percent_total'),
        )
    )
;
```

Sera affiché le résultat de : ( my\_field\_1 + my\_field\_2 ) * 100 / my\_field\_3

#### - oru\_choices\_to\_string

        Ce widget est une extension de choices qui permet de stocker en base des choix multiples dans un même champ texte concaténés avec un retour à la ligne.

#### - oru\_section

        Permet d'ajouter un séparateur avec un libellé à l'affichage du formulaire. Ce champ n'est pas mappé, il est utilisé qu'à des fins visuelles.
        Exemple d'utilisation :

```php
$builder
    ->add('my_section', 'oru_section', array(
            'label'        => 'Les champs qui suivent ont tous un rapport entre eux...',
        )
    )
    ->add('my_field_1'
    )
    ->add('my_field_2'
    )
    ->add('my_field_3'
    )
    ->add('my_section_end', 'oru_section', array(
            'label'        => ' ',
        )
    )
;
```

#### - hidden\_entity

        Ce widget permet de représenter une entité dans un champ de type hidden, particulièrement utile pour des champs autocomplétés.

```php
$builder
    //...
    ->add('my_section', 'hidden_entity', array(
            'class'        => 'OruProfessionnelBundle:Professionnel',
        )
    )
;
```

#### - oru\_text\_entity

        Ce widget permet de représenter une entité dans un champ de type hidden, particulièrement utile pour des champs autocomplétés.

```php
$builder
    //...
    ->add('my_section', 'oru_text_entity', array(
            'class'        => 'OruProfessionnelBundle:Professionnel',
        )
    )
;
```

#### - oru\_captcha

        Ce widget permet de générer un captcha.

```php
$builder
    //...
    ->add('captcha', 'oru_captcha')
;
```

#### - ckeditor

        Widget permettant de bénéficier d'un champ ckeditor.

#### - purified\_ckeditor

        Widget permettant de bénéficier d'un champ ckeditor qui sera nettoyé via la librairie http://htmlpurifier.org/.

#### - oru\_email\_verify

        Nouveau champ doctrine oru_email_verify qui permet d'envoyer un mail de confirmation de l'adresse email lors de l'ajout ou la mise à jour de ce champ.
        L'affichage côté twig se fait via la macro 'email' disponible dans le bundle oru/design.

### Divers

#### Multiples soumissions de formulaires

Pour éviter la multiple soumission d'un formulaire, il suffit de donner à l'élement HTML form la class .prevent-dbl-submit.
L'inverse est possible via la classe .allow-dbl-submit le but étant à terme de retirer toutes les classes .prevent-dbl-submit et de restreindre par défaut la double soumission.

```php
$resolver->setDefaults(array(
    ...
    'attr' => array('class' => 'prevent-dbl-submit')
));
```