<?php

/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */


namespace Oru\Bundle\FormBundle\Doctrine\DBAL\Types;

use Doctrine\DBAL\Platforms\AbstractPlatform;
use Doctrine\DBAL\Types\Type;

/**
 * Email Doctrine mapping type.
 */
class OruEmailType extends Type
{
    /**
     * {@inheritdoc}
     */
    public function getSQLDeclaration(array $fieldDeclaration, AbstractPlatform $platform)
    {
        return $platform->getVarcharTypeDeclarationSQL(array('type' => 'string', 'length' => 255));
    }

    /**
     * Email type name.
     */
    const NAME = 'oru_email';

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return self::NAME;
    }

    /**
     * {@inheritdoc}
     */
    public function requiresSQLCommentHint(AbstractPlatform $platform)
    {
        return true;
    }
}
