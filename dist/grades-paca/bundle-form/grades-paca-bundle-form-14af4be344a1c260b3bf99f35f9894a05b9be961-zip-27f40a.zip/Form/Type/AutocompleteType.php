<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 31/07/14
 */

namespace Oru\Bundle\FormBundle\Form\Type;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

abstract class AutocompleteType extends AbstractType  {

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefined(array( 'results', 'infinite_scroll', 'minimum', 'allow_clear', 'placeholder', 'closeOnSelect', 'disable_isValidate'));
        $resolver->setDefaults(array('results' => 10, 'infinite_scroll' => true, 'minimum' => 3, 'placeholder' => 'Chercher', 'closeOnSelect' => false, 'disable_isValidate' => true));
        $resolver->setRequired(array('class'));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        $view->vars['multiple'] = ($options['multiple']) ? true : false;
        $view->vars['allow_clear'] = ($options['required']) ? 'false' : 'true';
        $view->vars['results'] = $options['results'];
        $view->vars['infinite_scroll'] = ($options['infinite_scroll']) ? 'true' : 'false';
        $view->vars['minimum'] = $options['minimum'];
        $view->vars['placeholder'] = $options['placeholder'];
        $view->vars['required'] = $options['required'];
        $view->vars['closeOnSelect'] = $options['closeOnSelect'];
        $view->vars['disable_isValidate'] = ($options['disable_isValidate']) ? 'true' : 'false';
        
        if ($options['multiple'] && strcmp($this->getParent(),'oru_text_entities') === 0) {
            // Add "[]" to the name in case a select tag with multiple options is
            // displayed. Otherwise only one of the selected options is sent in the
            // POST request.
            $view->vars['full_name'] .= '[]';
        }
    }

    /**
     * @return string
     */
    public function getParent()
    {
        return 'oru_text_entities';
    }

} 