<?php

namespace Oru\Bundle\FormBundle\Form\Type;


use Oru\Bundle\FormBundle\Form\DataTransformer\HoursMinutesTransformer;
use Oru\Bundle\FormBundle\Form\DataTransformer\PhoneNumberToArrayTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;

class HoursMinutesType extends AbstractType
{

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $class = null;
        if(isset($options['attr']['class'])){
            $class = $options['attr']['class'];
            unset($options['attr']['class']);
        }
        $builder
            ->add('hours', 'text', array(
                'attr' => array_merge(array('class'=>'hours '.$class), $options['attr']), //Peut changer le comportement dans les fichiers show.js (plancBlanc/Bleu, cruqpc)
                'required' => false,
            ))
            ->add('minutes', 'text', array(
                'error_bubbling' => false,
                'error_mapping' => true,
                'attr' => array_merge(array('class'=>'minutes '.$class), $options['attr']), //Peut changer le comportement dans les fichiers show.js (plancBlanc/Bleu, cruqpc)
                'required' => $options['required'],
            ));

        $builder->addViewTransformer(
            new HoursMinutesTransformer()
        );
    }

    /**
     * @return string
     * @inheritdoc
     */
    public function getName()
    {
        return 'oru_hours_minutes';
    }
}