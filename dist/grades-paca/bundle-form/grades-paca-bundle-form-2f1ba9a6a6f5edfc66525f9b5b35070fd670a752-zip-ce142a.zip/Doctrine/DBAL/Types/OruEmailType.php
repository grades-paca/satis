<?php

/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */


namespace Oru\Bundle\FormBundle\Doctrine\DBAL\Types;

use Doctrine\DBAL\Platforms\AbstractPlatform;
use Doctrine\DBAL\Types\Type;
use Mso\IdnaConvert\IdnaConvert;

/**
 * Email Doctrine mapping type.
 */
class OruEmailType extends Type
{
    /**
     * {@inheritdoc}
     */
    public function getSQLDeclaration(array $fieldDeclaration, AbstractPlatform $platform)
    {
        return $platform->getVarcharTypeDeclarationSQL(array('type' => 'string', 'length' => 255));
    }

    /**
     * Email type name.
     */
    const NAME = 'oru_email';

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return self::NAME;
    }

    /**
     * {@inheritdoc}
     */
    public function requiresSQLCommentHint(AbstractPlatform $platform)
    {
        return true;
    }

    /**
     * Converts a value from its PHP representation to its database representation
     * of this type.
     *
     * @param mixed                                     $value The value to convert.
     * @param \Doctrine\DBAL\Platforms\AbstractPlatform $platform The currently used database platform.
     *
     * @return mixed The database representation of the value.
     */
    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
        if (null === $value) {
            return null;
        }

        $IDN = new IdnaConvert();

        $value = $IDN->decode($value);

        return parent::convertToDatabaseValue($value, $platform);
    }
}
