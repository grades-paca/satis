<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Form\Type;


use Oru\Bundle\FormBundle\Manager\EtherpadManager;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage;

class EtherpadType extends AbstractType
{
    /**
     * @var EtherpadManager
     */
    private $em;

    /**
     * @var TokenStorage
     */
    private $ts;

    /**
     * EtherpadType constructor.
     * @param EtherpadManager $manager
     */
    public function __construct(EtherpadManager $em, TokenStorage $ts)
    {
        $this->em = $em;
        $this->ts = $ts;
    }

    /**
     * @inheritdoc
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefined(array('showControls', 'showChat', 'showLineNumbers', 'height', 'width', 'user_color', 'no_colors'));
        $resolver->setDefaults(array(
            'host' => $this->em->getUrl(),
            'show_controls' => true,
            'show_chat' => true,
            'show_line_numbers' => true,
            'user_color' => '#' . $this->randomColor(),
            'no_colors' => false,
            'height' => '500px'
        ));
    }

    /**
     * @inheritdoc
     */
    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        $view->vars['host'] = $options['host'];
        $user = null;
        if($this->ts->getToken() && $this->ts->getToken()->getUser()) {
            $user = $this->ts->getToken()->getUser();
        }
        $view->vars['user'] = (string) $user;
        $view->vars['type'] = 'hidden';
        $view->vars['showControls'] = $options['show_controls'];
        $view->vars['showChat'] = $options['show_chat'];
        $view->vars['showLineNumbers'] = $options['show_line_numbers'];
        $view->vars['height'] = (isset($options['height'])) ? $options['height'] : null;
        $view->vars['width'] = (isset($options['width'])) ? $options['width'] : null;
        $view->vars['empty_data'] = uniqid('ror_' . time() . '_');
        $view->vars['userColor'] = $options['user_color'];
        $view->vars['noColors'] = $options['no_colors'];
    }

    /**
     * @inheritdoc
     */
    public function getParent()
    {
        return 'text';
    }

    /**
     * @inheritdoc
     */
    public function getName()
    {
        return 'oru_etherpad';
    }

    /**
     * @return string
     */
    private function randomColorPart()
    {
        return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
    }

    /**
     * @return string
     */
    private function randomColor()
    {
        return $this->randomColorPart() . $this->randomColorPart() . $this->randomColorPart();
    }
}