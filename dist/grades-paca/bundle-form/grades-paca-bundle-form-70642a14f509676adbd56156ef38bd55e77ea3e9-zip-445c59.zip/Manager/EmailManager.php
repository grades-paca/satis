<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Manager;


use Doctrine\ORM\EntityManager;
use Oru\Bundle\FormBundle\Entity\Email;
use Oru\Bundle\MailBundle\Mailer\Mailer;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Routing\Router;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class EmailManager
{
    /**
     * @var EntityManager
     */
    private $em;

    /**
     * @var bool
     */
    private $useOpenSsl;

    /**
     * @var Session
     */
    private $session;

    /**
     * @var Mailer
     */
    private $mailer;

    /**
     * @var Router
     */
    private $router;

    /**
     * @var ValidatorInterface
     */
    private $validator;

    /**
     * @var Setting
     */
    private $setting;

    /**
     * EmailManager constructor.
     */
    public function __construct(EntityManager $em, Session $session, Mailer $mailer, Router $router, ValidatorInterface $validator, Setting $setting)
    {
        $this->em = $em;
        $this->session = $session;
        $this->mailer = $mailer;
        $this->router = $router;
        $this->validator = $validator;
        $this->setting = $setting;

        // determine whether to use OpenSSL
        if (defined('PHP_WINDOWS_VERSION_BUILD') && version_compare(PHP_VERSION, '5.3.4', '<')) {
            $this->useOpenSsl = false;
        } elseif (!function_exists('openssl_random_pseudo_bytes')) {
            $this->useOpenSsl = false;
        } else {
            $this->useOpenSsl = true;
        }
    }

    /**
     * Envoi du mail de confirmation de l'adresse email
     * 
     * @param $email
     * @param bool $force
     * @param bool $save
     */
    public function send($email, $force = false)
    {
        $formEmail = $this->getFormEmail($email, $force);

        if($formEmail) {
            $formEmail->setEmail($email);
            $formEmail->setConfirmationToken($this->generateToken());
            if ($formEmail->getId()) {
                $formEmail->setConfirmation(false);
            } else {
                $this->em->persist($formEmail);
            }
            $this->em->flush($formEmail);

            $parameters = array(
                'email' => $formEmail->getEmail(),
                'confirmationUrl' => $this->router->generate(
                    'oru_form_email_confirm',
                    array('confirmationToken' => $formEmail->getConfirmationToken()),
                    UrlGeneratorInterface::ABSOLUTE_URL
                ),
                'application' => $this->setting->setting('application_title', 'OruDesignBundle')
            );

            if ($this->mailer->sendEmailMessage('OruFormBundle:Email:validate_email.txt.twig', $parameters, $formEmail->getEmail())) {
                $this->session->getFlashBag()->add('success', "Une notification a été envoyée pour valider l'adresse email : $email.");
            }
        }
        
        return $formEmail;
    }

    /**
     * Crée une confirmation qui ne sera pas envoyée
     * Utile en cas d'utilisation du implicit confirm
     *
     * @param $email
     * @param bool $force
     * @param bool $save
     */
    public function fake($email, $force = false)
    {
        $formEmail = $this->getFormEmail($email, $force);

        if($formEmail) {
            $formEmail->setEmail($email);
            $formEmail->setConfirmationToken($this->generateToken());
            if ($formEmail->getId()) {
                $formEmail->setConfirmation(false);
            } else {
                $this->em->persist($formEmail);
            }
            $this->em->flush($formEmail);
        }

        return $formEmail;
    }

    /**
     * Confirmation de l'adresse email
     * 
     * @param $confirmationToken
     * @return bool
     */
    public function confirm($confirmationToken) {
        $instance = $this->em->getRepository('OruFormBundle:Email')->findOneByConfirmationToken($confirmationToken);
        if($instance) {
            $instance->setConfirmation(true);
            $this->em->flush($instance);

            $this->session->getFlashBag()->add('success', "L'adresse email {$instance->getEmail()} a été validée.");
            return true;
        }

        return false;
    }

    /**
     * Permet de connaître si l'adresse email a été confirmée.
     * 
     * @param $email
     * @return bool|null Renvoi null si la confirmation n'a pas été demandé et la valeur sinon
     */
    public function isValid($email) {
        $instance = $this->em->getRepository('OruFormBundle:Email')->findOneByEmail($email);
        if($instance) {
            return (bool) $instance->getConfirmation();
        }
        return null;
    }

    /**
     * Force la validation d'un email sans passer par une confirmation
     *
     * @param $email
     */
    public function implicitConfirm($email) {
        $formEmail = $this->getFormEmail($email, true);
        if($formEmail) {
            $formEmail->setEmail($email);
            $formEmail->setConfirmation(true);
            if (!$formEmail->getId()) {
                $formEmail->setConfirmationToken($this->generateToken());
                $this->em->persist($formEmail);
            }
            $this->em->flush($formEmail);
            $this->session->getFlashBag()->add('success', "L'adresse email {$formEmail->getEmail()} a été validée.");
        }
    }

    /**
     * @return string
     */
    private function generateToken()
    {
        return rtrim(strtr(base64_encode($this->getRandomNumber()), '+/', '-_'), '=');
    }

    /**
     * @return string
     */
    private function getRandomNumber()
    {
        $nbBytes = 32;

        // try OpenSSL
        if ($this->useOpenSsl) {
            $bytes = openssl_random_pseudo_bytes($nbBytes, $strong);

            if (false !== $bytes && true === $strong) {
                return $bytes;
            }

            if (null !== $this->logger) {
                $this->logger->info('OpenSSL did not produce a secure random number.');
            }
        }

        return hash('sha256', uniqid(mt_rand(), true), true);
    }

    /**
     * @param $email
     * @param $force
     * @return mixed|null|Email
     */
    private function getFormEmail($email, $force = false)
    {
        // adresse email valide ?
        $emailConstraint = array();
        $emailConstraint[] = new \Symfony\Component\Validator\Constraints\Email();
        $emailConstraint[] = new \Symfony\Component\Validator\Constraints\NotBlank();
        $errors = $this->validator->validate($email, $emailConstraint);
        if($errors->count()) {
            return false;
        }

        $formEmail = null;
        $countEmail = $this->em->getRepository('OruFormBundle:Email')->findByEmail($email);
        if(!count($countEmail)) {
            $formEmail = new Email();
        } else if(count($countEmail) == 1 && $force) {
            $formEmail = end($countEmail);
        }
        return $formEmail;
    }
}