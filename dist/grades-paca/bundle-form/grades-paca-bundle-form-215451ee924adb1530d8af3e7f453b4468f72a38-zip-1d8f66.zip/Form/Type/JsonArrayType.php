<?php
/**
 * Author: tdepreaumont
 * Date: 10/12/14
 * Time: 13:28
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Oru\Bundle\FormBundle\Form\DataTransformer\KeyValueArrayTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;


class JsonArrayType extends AbstractType
{
    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            array(
                'options' => array(
                    'data_class' => 'Oru\Bundle\FormBundle\Model\KeyValueArray',
                    'label' => false
                ),
                'type' => 'oru_key_value_array',
                'required' => false,
                'allow_add' => true,
                'allow_delete' => true,
                'attr' => array('class' => 'jsonRow'),
            )
        );
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
       $builder ->addModelTransformer(new KeyValueArrayTransformer());
    }


    public function getParent()
    {
        return 'collection';
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_json_array';
    }
}