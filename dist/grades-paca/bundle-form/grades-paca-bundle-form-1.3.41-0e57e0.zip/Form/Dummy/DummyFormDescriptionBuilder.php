<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 26/06/2017
 * Time: 15:14
 */

namespace Oru\Bundle\FormBundle\Form\Dummy;

class DummyFormDescriptionBuilder extends DummyFormBuilder
{
    private $deniedFields = array();

    public function deny($name){
        if(!in_array($name, $this->deniedFields)){
            $this->deniedFields[] = $name;
        }
    }

    public function addConditional($bool, $name, $type = null, $options = array()){
        if($bool){
            $this->add($name, $type, $options);
        }else{
            $this->deny($name);
        }

        return $this;
    }

    /**
     * @return array
     */
    public function getDeniedFields()
    {
        return $this->deniedFields;
    }
}