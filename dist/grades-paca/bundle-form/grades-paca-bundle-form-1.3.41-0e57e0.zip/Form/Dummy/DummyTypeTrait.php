<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 21/06/2017
 * Time: 11:08
 */

namespace Oru\Bundle\FormBundle\Form\Dummy;


use Doctrine\Common\Util\Debug;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;

trait DummyTypeTrait
{
    /**
     * @var DummyFormBuilder
     * Utilisé pour la construction du Form
     */
    protected $_builder;

    /**
     * @var DummyFormDescriptionBuilder
     * Utilisé pour la description générique des champs
     */
    protected $_fields;

    public function inflateDummyBuilder(FormEvent $event){

        foreach($this->getDummyBuilder()->getFields() as $name => $field){

            $fieldType = $field['type'];
            $fieldOptions = $field['options'];
            if($this->getDescriptionBuilder()->has($name)){
                $described = $this->getDescriptionBuilder()->getField($name);
                if(!$fieldType){
                    $fieldType = $described['type'];
                }
                $fieldOptions = array_merge($fieldOptions, $described['options']);
            }

            if(!in_array($name, $this->getDescriptionBuilder()->getDeniedFields())){
                $event->getForm()->add($name, $fieldType, $fieldOptions);
            }
        }
    }

    /**
     * @return DummyFormBuilder
     */
    public function getDummyBuilder()
    {
        if(!$this->_builder){
            $this->_builder = new DummyFormBuilder();
        }
        return $this->_builder;
    }

    /**
     * @return DummyFormBuilder
     */
    public function createDummyBuilder(){
        $this->_builder = new DummyFormBuilder();
        return $this->_builder;
    }

    /**
     * @return DummyFormDescriptionBuilder
     */
    public function getDescriptionBuilder()
    {
        if(!$this->_fields){
            $this->_fields = new DummyFormDescriptionBuilder();
        }
        return $this->_fields;
    }

    /**
     * @return DummyFormDescriptionBuilder
     */
    public function createDescriptionBuilder(){
        $this->_fields = new DummyFormDescriptionBuilder();
        return $this->_fields;
    }
}