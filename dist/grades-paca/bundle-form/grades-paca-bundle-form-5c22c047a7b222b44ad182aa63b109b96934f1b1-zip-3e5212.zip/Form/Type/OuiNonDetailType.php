<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 14/01/14
 * Time: 15:34
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

class OuiNonDetailType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setRequired(array('detail'));
        $resolver->setDefined(array('on_no'));

        $resolver->setDefaults(array(
            'on_no'     =>  true,
        ));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        $view->vars['detail'] = $options['detail'];
        $view->vars['on_no'] = (int) $options['on_no'];
    }

    public function getParent()
    {
        return 'oru_oui_non';
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_oui_non_detail';
    }
}