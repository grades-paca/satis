<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 16/01/14
 * Time: 10:57
 */

namespace Oru\Bundle\FormBundle\DependencyInjection\Compiler;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class FormPass implements  CompilerPassInterface
{
    /**
     * You can modify the container here before it is dumped to PHP code.
     *
     * @param ContainerBuilder $container
     *
     * @api
     */
    public function process(ContainerBuilder $container)
    {
        $resources = $container->getParameter('twig.form.resources');

        foreach (array('fields_table', 'fields_div', 'jquery') as $template) {
            $resources[] = '@OruForm/Form/' . $template . '_layout.html.twig';
        }

        $container->setParameter('twig.form.resources', $resources);

        // utilisation du proxy pour les requêtes liées à recaptcha
        $proxy = $container->getParameter('proxy');
        $proxyParams = array('host' => '', 'port' => '', 'auth' => '');
        if ($proxy) {
            if (preg_match('/([^:]+):(.+)@([^:]+):([^:]+)/', $proxy, $tabMatch)) {
                $proxyParams['host'] = $tabMatch[3];
                $proxyParams['port'] = $tabMatch[4];
                $proxyParams['auth'] = $tabMatch[1] . ':' . $tabMatch[2];
            } else {
                list($proxyHost, $proxyPort) = explode(':', $proxy);
                $proxyParams['host'] =  $proxyHost;
                $proxyParams['port'] = $proxyPort;
            }
        }
        $container->setParameter('ewz_recaptcha.http_proxy', $proxyParams);
    }
}