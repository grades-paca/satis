<?php

namespace Oru\Bundle\FormBundle\Form\DataTransformer;

use libphonenumber\NumberParseException;
use libphonenumber\PhoneNumber;
use libphonenumber\PhoneNumberFormat;
use libphonenumber\PhoneNumberUtil;
use Oru\Bundle\FormBundle\Exception\NotShortNumberException;
use Oru\Bundle\FormBundle\Tool\ShortNumberTool;
use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\Exception\TransformationFailedException;


class HoursMinutesTransformer implements DataTransformerInterface
{
    /**
     * {@inheritdoc}
     */
    public function transform($value)
    {
        if (!$value) {
            return;
        }else if($value === 0){
            return 0;
        }

        $hours = floor($value / 60);
        $minutes = ($value % 60);

        if($hours < 10){
            $hours = '0'.$hours;
        }
        if($minutes < 10){
            $minutes = '0'.$minutes;
        }

        return array('hours' => $hours, 'minutes' => $minutes);
    }

    /**
     * {@inheritdoc}
     */
    public function reverseTransform($array)
    {
        try {
            $minutes = intval($array['hours']) * 60 + intval($array['minutes']);
            return($minutes);
        } catch (\Exception $e) {
            return null;
        }
    }
}
