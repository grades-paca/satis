<?php

namespace Oru\Bundle\FormBundle\Guesser;

use Symfony\Component\Form\FormTypeGuesserInterface;
use Symfony\Component\Form\Guess;
use Symfony\Component\Validator\Mapping\ClassMetadataInterface;
use Symfony\Component\Validator\Mapping\Factory\MetadataFactoryInterface;

/**
 * Class OruValidatorGuesser
 *
 * @package Oru\Bundle\FormBundle\Guesser
 * @author Michaël VEROUX
 */
class OruValidatorGuesser implements FormTypeGuesserInterface
{
    /**
     * @var MetadataFactoryInterface
     */
    protected $metadataFactory;

    /**
     * OruValidatorGuesser constructor.
     *
     * @param MetadataFactoryInterface $metadataFactory
     */
    public function __construct(MetadataFactoryInterface $metadataFactory)
    {
        $this->metadataFactory = $metadataFactory;
    }

    /**
     * Returns a field guess for a property name of a class.
     *
     * @param string $class The fully qualified class name
     * @param string $property The name of the property to guess for
     *
     * @return Guess\TypeGuess|null A guess for the field's type and options
     */
    public function guessType($class, $property)
    {
        $classMetadata = $this->metadataFactory->getMetadataFor($class);

        if ($classMetadata instanceof ClassMetadataInterface && $classMetadata->hasPropertyMetadata($property)) {
            $memberMetadatas = $classMetadata->getPropertyMetadata($property);

            foreach ($memberMetadatas as $memberMetadata) {
                $constraints = $memberMetadata->getConstraints();

                foreach ($constraints as $constraint) {
                    $constraintClass = get_class($constraint);

                    if ('Symfony\Component\Validator\Constraints\Email' == $constraintClass) {
                        return new Guess\TypeGuess('oru_email', array(), Guess\Guess::HIGH_CONFIDENCE);
                    }
                }
            }
        }

        return null;
    }

    /**
     * Returns a guess whether a property of a class is required.
     *
     * @param string $class The fully qualified class name
     * @param string $property The name of the property to guess for
     *
     * @return Guess\ValueGuess A guess for the field's required setting
     */
    public function guessRequired($class, $property)
    {
        return null;
    }

    /**
     * Returns a guess about the field's maximum length.
     *
     * @param string $class The fully qualified class name
     * @param string $property The name of the property to guess for
     *
     * @return Guess\ValueGuess|null A guess for the field's maximum length
     */
    public function guessMaxLength($class, $property)
    {
        return null;
    }

    /**
     * Returns a guess about the field's pattern.
     *
     * - When you have a min value, you guess a min length of this min (LOW_CONFIDENCE) , lines below
     * - If this value is a float type, this is wrong so you guess null with MEDIUM_CONFIDENCE to override the previous guess.
     * Example:
     *  You want a float greater than 5, 4.512313 is not valid but length(4.512314) > length(5)
     *
     * @link https://github.com/symfony/symfony/pull/3927
     *
     * @param string $class The fully qualified class name
     * @param string $property The name of the property to guess for
     *
     * @return Guess\ValueGuess|null A guess for the field's required pattern
     */
    public function guessPattern($class, $property)
    {
        return null;
    }
}
