<?php

namespace Oru\Bundle\FormBundle\Form\Type;

use Symfony\Component\Form\Extension\Core\Type\PasswordType as BasePasswordType;
use Symfony\Component\OptionsResolver\Options;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class PasswordType.
 *
 * @author Michaël VEROUX
 */
class PasswordType extends BasePasswordType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);

        $resolver->setDefault('attr', function (Options $options, $previousValue) {
            if (!is_array($previousValue)) {
                $previousValue = array();
            }

            if (!isset($previousValue['autocomplete'])) {
                $previousValue['autocomplete'] = 'off';
            }

            return $previousValue;
        });
    }
}
