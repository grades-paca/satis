<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraints\Email;

/**
 * Class MultipleEmails
 * @package Oru\Bundle\FormBundle\Validator\Constraints
 * @Annotation
 */
class MultipleEmails extends Email
{
    public $delimiter = ',';
}
