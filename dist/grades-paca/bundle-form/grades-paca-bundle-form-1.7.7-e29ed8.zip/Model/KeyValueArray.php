<?php
/**
 * Author: tdepreaumont
 * Date: 10/12/14
 * Time: 15:44
 */

namespace Oru\Bundle\FormBundle\Model;

class KeyValueArray
{
    /**
     * @var null
     */
    protected $key;

    /**
     * @var null
     */
    protected $value;

    /**
     * @param null $key
     * @param null $value
     */
    public function __construct($key = null, $value = null)
    {
        $this->key = $key;
        $this->value = $value;
    }

    /**
     * @return mixed
     */
    public function __toString()
    {
        return (string) $this->getValue();
    }

    /**
     * @param $key
     *
     * @return $this
     */
    public function setKey($key)
    {
        $this->key = $key;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getKey()
    {
        return $this->key;
    }

    /**
     * @param $value
     *
     * @return $this
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @return array
     */
    public function toArray()
    {
        return array($this->key => $this->value);
    }
}
