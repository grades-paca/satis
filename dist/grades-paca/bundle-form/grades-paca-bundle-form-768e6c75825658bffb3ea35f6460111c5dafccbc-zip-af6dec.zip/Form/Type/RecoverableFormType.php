<?php
/**
 * Author: Michaël VEROUX
 * Date: 06/01/15
 * Time: 11:04
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Doctrine\Common\Persistence\ObjectManager;
use Oru\Bundle\FormBundle\Form\EventListener\RecoverableListener;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class RecoverableFormType extends AbstractType
{
    /**
     * @var TokenStorageInterface
     */
    protected $securityContext;

    /**
     * @var ObjectManager
     */
    protected $em;

    /**
     * @param TokenStorageInterface $securityContext
     * @param ObjectManager $em
     */
    public function __construct(TokenStorageInterface $securityContext, ObjectManager $em)
    {
        $this->securityContext = $securityContext;
        $this->em = $em;
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->addEventSubscriber(new RecoverableListener($this->securityContext, $this->em));
    }

    public function getParent()
    {
        return 'form';
    }

    public function getName()
    {
        return 'oru_recoverable_form';
    }
} 