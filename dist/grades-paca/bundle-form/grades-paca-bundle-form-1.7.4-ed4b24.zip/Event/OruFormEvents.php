<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Event;

final class OruFormEvents
{
    /**
     * The EMAIL_CONFIRMATION event occurs after a user confirms his email.
     */
    const EMAIL_CONFIRMATION = 'form.email.confirmation';

    /**
     * The EMAIL_CONFIRMATION_SEND event occurs before sending a confirmation check email.
     */
    const EMAIL_CONFIRMATION_SEND = 'form.email.confirmation.send';
}
