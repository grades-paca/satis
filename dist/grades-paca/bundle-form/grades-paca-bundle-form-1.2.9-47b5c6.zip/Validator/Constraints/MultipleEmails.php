<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Validator\Constraints;


use Symfony\Component\Validator\Constraints\Email;

class MultipleEmails extends Email
{
    public $delimiter = ",";
}