<?php
/**
 * Author: tdepreaumont
 * Date: 10/12/14
 * Time: 13:28
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Oru\Bundle\FormBundle\Form\DataTransformer\PhoneNumberToArrayTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use libphonenumber\PhoneNumberFormat;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;


/**
 * Class TelType
 * @package Oru\Bundle\FormBundle\Form\Type
 */
class TelType extends AbstractType
{
    /**
     * @var
     */
    private $defaultIndicatif;

    /**
     * @var
     */
    private $phoneNumberFormat;

    /**
     * @param $defaultIndicatif
     * @param $setting
     */
    function __construct($defaultIndicatif, $setting)
    {
        $this->defaultIndicatif = $defaultIndicatif;
        if($setting->setting('tel_format','OruRorDesignBundle') == 'NATIONAL'){
            $this->phoneNumberFormat =  PhoneNumberFormat::NATIONAL;
        }else{
            $this->phoneNumberFormat =  PhoneNumberFormat::INTERNATIONAL;
        }
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        if(!isset($options['attr']['class'])){
            $options['attr']['class']= null;
        }
        $builder->add('indicatif', 'text', array(
            'attr' => array('class'=>'form_indicatif '.$options['attr']['class']), //Peut changer le comportement dans les fichiers show.js (plancBlanc/Bleu, cruqpc)
            'required' => true,
        ))
        ->add('phone', 'text', array(
                'error_bubbling' => false,
                'error_mapping' => true,
                'attr' => array('class'=>'form_compound_tel phone_number '.$options['attr']['class'] //Peut changer le comportement dans les fichiers show.js (plancBlanc/Bleu, cruqpc)
            ),
            'required' => true,
        ));

        $builder->addViewTransformer(
            new PhoneNumberToArrayTransformer($options['default_region'], $options['format'])
        );
    }

    /**
     * {@inheritdoc}
     */
    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        $view->vars['type'] = 'phone';
    }

    /**
     * {@inheritdoc}
     *
     * @deprecated To be removed when the Symfony Form component compatibility
     *             is bumped to at least 2.7.
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $this->configureOptions($resolver);
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            array(
                'compound' => true,
                'default_region' => $this->defaultIndicatif,
                'format' => $this->phoneNumberFormat,
                //todo rajouter un service pour récupérer le paramètre
                'invalid_message' => 'Ce numéro de téléphone n\'est pas correct.',
            )
        );
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_tel';
    }

}