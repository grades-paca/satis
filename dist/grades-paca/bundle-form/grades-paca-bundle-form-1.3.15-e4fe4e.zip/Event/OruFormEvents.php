<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Event;


final class OruFormEvents
{
    /**
     * The EMAIL_CONFIRMATION event occurs after a user confirms his email.
     */
    const EMAIL_CONFIRMATION = 'form.email.confirmation';
}