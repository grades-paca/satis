<?php
/**
 * Author: tdepreaumont
 * Date: 10/12/14
 * Time: 13:28
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Oru\Bundle\FormBundle\Form\DataTransformer\KeyValueArrayTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;


class PasswordStrengthType extends AbstractType
{
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(
            array(
                'first_options' => array(
                    'label' => 'form.password',
                    'attr' => array('class' => 'password-strength', 'title'),
                ),
                'second_options' => array('label' => 'form.password_confirmation'),
                'type' => 'password'
            )
        );
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
       $builder ->addModelTransformer(new KeyValueArrayTransformer());
    }


    public function getParent()
    {
        return 'repeated';
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_password_strength';
    }
}