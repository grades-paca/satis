<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraints\Luhn;

class Siret extends Luhn
{
    public $message = "La chaîne {{ value }} n'est pas un SIRET valide.";
    public $charset = 'UTF-8';

    public function validatedBy()
    {
        return get_class($this).'Validator';
    }
}
