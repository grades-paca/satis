<?php
/**
 * Created by PhpStorm.
 * User: ecervetti
 * Date: 02/05/2016
 * Time: 14:35
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use FOS\CKEditorBundle\Form\Type\CKEditorType;
use Oru\Bundle\FormBundle\Form\DataTransformer\UrlTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Routing\RouterInterface;

/**
 * Class PurifiedCkeditorType.
 */
class PurifiedCkeditorType extends AbstractType
{
    /**
     * @var DataTransformerInterface
     */
    private $purifierTransformer;

    /**
     * @var RouterInterface
     */
    private $router;

    /**
     * PurifiedCkeditorType constructor.
     *
     * @param DataTransformerInterface $purifierTransformer
     * @param RouterInterface          $router
     */
    public function __construct(DataTransformerInterface $purifierTransformer, RouterInterface $router)
    {
        $this->purifierTransformer = $purifierTransformer;
        $this->router = $router;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->addViewTransformer($this->purifierTransformer)
            ->addModelTransformer(new UrlTransformer($this->router))
        ;
    }

    /**
     * @return null|string|\Symfony\Component\Form\FormTypeInterface
     */
    public function getParent()
    {
        return CKEditorType::class;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefined(array('config_name'));
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'purified_ckeditor';
    }
}
