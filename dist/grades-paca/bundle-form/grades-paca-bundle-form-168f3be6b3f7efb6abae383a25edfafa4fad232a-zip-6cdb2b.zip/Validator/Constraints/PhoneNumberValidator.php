<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Validator\Constraints;


use Symfony\Component\Validator\Constraint;
use libphonenumber\PhoneNumber as PhoneNumberObject;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;

class PhoneNumberValidator extends \Misd\PhoneNumberBundle\Validator\Constraints\PhoneNumberValidator
{
    public function validate($value, Constraint $constraint)
    {
        if (null === $value || '' === $value) {
            return;
        }

        if (!is_scalar($value) && !(is_object($value) && method_exists($value, '__toString'))) {
            throw new UnexpectedTypeException($value, 'string');
        }

        if($value instanceof PhoneNumberObject) {
            if (preg_match('/^([0-9 ]{4,5})$/', $value->getNationalNumber(), $matches)) {
                return;
            }
        } else {
            if (preg_match('/^([0-9 ]{4,5})$/', $value, $matches)) {
                return;
            }
        }

        parent::validate($value, $constraint);
    }
}