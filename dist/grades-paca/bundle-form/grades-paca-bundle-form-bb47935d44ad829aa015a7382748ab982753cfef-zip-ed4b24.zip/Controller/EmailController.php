<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Controller;

use Oru\Bundle\FormBundle\Event\FilterEmailResponseEvent;
use Oru\Bundle\FormBundle\Event\OruFormEvents;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Controlleur EmailController permettant de valider une adresse email.
 */
class EmailController extends Controller
{
    /**
     * Send confirmation email ?
     *
     * @param $email
     *
     * @return JsonResponse
     */
    public function sendAction($email)
    {
        $entity = $this->get('oru_form.email.manager')->send($email, true);
        if (!$entity) {
            $this->get('session')->getFlashBag()->add('error', "Une erreur s'est produite lors de l'envoi du mail de confirmation.");

            return new JsonResponse(false);
        }

        return new JsonResponse(true);
    }

    /**
     * Confirm email.
     *
     * @param $confirmationToken
     *
     * @return RedirectResponse
     */
    public function confirmAction($confirmationToken)
    {
        $this->get('oru_form.email.manager')->confirm($confirmationToken);

        $response = new RedirectResponse('/');
        $this->get('event_dispatcher')->dispatch(OruFormEvents::EMAIL_CONFIRMATION, new FilterEmailResponseEvent($response));

        return $this->redirect('/');
    }

    /**
     * Is valid email ?
     *
     * @param $email
     *
     * @return JsonResponse
     */
    public function validAction($email)
    {
        return new JsonResponse($this->get('oru_form.email.manager')->isValid($email));
    }
}
