<?php

namespace Oru\Bundle\FormBundle\DependencyInjection\Compiler;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

/**
 * Class ValidatorPass.
 *
 * @author Michaël VEROUX
 */
class ValidatorPass implements CompilerPassInterface
{
    /**
     * You can modify the container here before it is dumped to PHP code.
     *
     * @param ContainerBuilder $container
     */
    public function process(ContainerBuilder $container)
    {
        $emailValidatorDefinition = $container->getDefinition('validator.email');
        $emailValidatorDefinition->replaceArgument(0, true);
    }
}
