<?php
/**
 * Author: Michaël VEROUX
 * Date: 01/02/16
 * Time: 09:59
 */

namespace Oru\Bundle\FormBundle\Subscriber;

use Oru\Bundle\FormExportBundle\Export\ChoiceTypeDisplay;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Class FormExportSubscriber.
 *
 * @author Michaël VEROUX
 */
class FormExportSubscriber implements EventSubscriberInterface
{
    /**
     * @var ChoiceTypeDisplay
     */
    protected $choiceDisplay;

    /**
     * FormExportSubscriber constructor.
     *
     * @param ChoiceTypeDisplay $choiceDisplay
     */
    public function __construct(ChoiceTypeDisplay $choiceDisplay)
    {
        $this->choiceDisplay = $choiceDisplay;
    }

    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public static function getSubscribedEvents()
    {
        if (class_exists('\\Oru\\Bundle\\FormExportBundle\\Event\\FormExportEvents')) {
            return array(
                \Oru\Bundle\FormExportBundle\Event\FormExportEvents::CUSTOM_TYPE_CONVERT => 'customType',
            );
        }

        return array();
    }

    /**
     * @param \Oru\Bundle\FormExportBundle\Event\CustomTypeEvent $event
     *
     * @author Michaël VEROUX
     */
    public function customType(\Oru\Bundle\FormExportBundle\Event\CustomTypeEvent $event)
    {
        $type = $event->getTypeName();
        $formView = $event->getFormView();
        $value = $formView->vars['value'];

        $choiceTypes = array(
            'oru_conditional',
            'oru_oui_non_detail',
            'oru_oui_non',
            'oru_choices_to_string',
        );
        if (in_array($type, $choiceTypes, true)) {
            if ('oru_choices_to_string' === $type) {
                $formView->vars['multiple'] = true;
            }
            $display = $this->choiceDisplay->get($formView);
            $event->setDisplayable($display);
            $event->stopPropagation();

            return;
        }

        if ('oru_tel' === $type) {
            $display = '';
            if ($value['phone']) {
                $display = sprintf('%s %s', $value['indicatif'], substr($value['phone'], 1));
            }
            $event->setDisplayable($display);
            $event->stopPropagation();

            return;
        }

        if ('oru_sum' === $type) {
            $class = $formView->vars['type_class'];
            $display = 0;
            $pattern = sprintf('#\b%s\b#', $class);
            foreach ($formView->parent->children as $view) {
                if (isset($view->vars['attr']['class']) && preg_match($pattern, $view->vars['attr']['class'])) {
                    $display += (float) ($view->vars['value']);
                }
            }
            $event->setDisplayable($display);
            $event->stopPropagation();

            return;
        }

        if ('oru_percent_calc' === $type) {
            $class = $formView->vars['type_class'];
            $classTotal = $formView->vars['type_class_total'];
            $display = $sum = $sumTotal = 0;
            $pattern = sprintf('#\b%s\b#', $class);
            $patternTotal = sprintf('#\b%s\b#', $classTotal);
            foreach ($formView->parent->children as $view) {
                if (isset($view->vars['attr']['class']) && preg_match($pattern, $view->vars['attr']['class'])) {
                    $sum += (float) ($view->vars['value']);
                }
                if (isset($view->vars['attr']['class']) && preg_match($patternTotal, $view->vars['attr']['class'])) {
                    $sumTotal += (float) ($view->vars['value']);
                }
            }
            if ($sumTotal !== 0) {
                $display = $sum * 100 / $sumTotal;
            }
            $event->setDisplayable($display);
            $event->stopPropagation();

            return;
        }
    }
}
