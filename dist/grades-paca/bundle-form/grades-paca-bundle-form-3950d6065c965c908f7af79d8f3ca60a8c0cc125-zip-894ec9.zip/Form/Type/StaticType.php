<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 20/01/14
 * Time: 11:54
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class StaticType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        if ($options['view_transformer'] instanceof DataTransformerInterface) {
            $builder->addViewTransformer(
                $options['view_transformer']
            );
        }
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            array(
                'view_transformer' => null,
            )
        );
    }

    public function getParent()
    {
        return TextType::class;
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_static';
    }
}
