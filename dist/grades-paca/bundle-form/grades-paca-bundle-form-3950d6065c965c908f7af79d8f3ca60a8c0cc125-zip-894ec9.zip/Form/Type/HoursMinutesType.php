<?php

namespace Oru\Bundle\FormBundle\Form\Type;

use Oru\Bundle\FormBundle\Form\DataTransformer\HoursMinutesTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;

class HoursMinutesType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $class = null;
        if (isset($options['attr']['class'])) {
            $class = $options['attr']['class'];
            unset($options['attr']['class']);
        }
        $builder
            ->add('hours', TextType::class, array(
                'attr' => array_merge(array('class' => 'hours '.$class), $options['attr']), //Peut changer le comportement dans les fichiers show.js (plancBlanc/Bleu, cruqpc)
                'required' => false,
            ))
            ->add('minutes', TextType::class, array(
                'error_bubbling' => false,
                'error_mapping' => true,
                'attr' => array_merge(array('class' => 'minutes '.$class), $options['attr']), //Peut changer le comportement dans les fichiers show.js (plancBlanc/Bleu, cruqpc)
                'required' => $options['required'],
            ));

        $builder->addViewTransformer(
            new HoursMinutesTransformer()
        );
    }

    /**
     * @return string
     *                {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'oru_hours_minutes';
    }
}
