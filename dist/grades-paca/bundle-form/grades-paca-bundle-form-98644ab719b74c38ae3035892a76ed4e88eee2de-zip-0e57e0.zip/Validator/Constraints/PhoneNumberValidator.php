<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Validator\Constraints;


use libphonenumber\PhoneNumberUtil;
use Oru\Bundle\FormBundle\Tool\ShortNumberTool;
use Symfony\Component\Validator\Constraint;
use libphonenumber\PhoneNumber as PhoneNumberObject;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;

class PhoneNumberValidator extends \Misd\PhoneNumberBundle\Validator\Constraints\PhoneNumberValidator
{
    public function validate($value, Constraint $constraint)
    {
        /** @var PhoneNumber $constraint */
        if (null === $value || '' === $value) {
            return;
        }

        if (!is_scalar($value) && !(is_object($value) && method_exists($value, '__toString'))) {
            throw new UnexpectedTypeException($value, 'string');
        }

        $phoneUtil = PhoneNumberUtil::getInstance();

        if($value instanceof PhoneNumberObject) {
            $constraint->defaultRegion = $phoneUtil->getRegionCodeForNumber($value);
            $rawValue = preg_replace('#[^0-9]#', '', $value->getNationalNumber());
        } else {
            $rawValue = preg_replace('#[^0-9]#', '', $value);
        }

        if (PhoneNumber::SHORT_ACCEPT === $constraint->getType()) {
            if (ShortNumberTool::isShort($rawValue)) {
                return;
            }
        }

        parent::validate($value, $constraint);
    }
}