<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 22/06/2017
 * Time: 09:09
 */

namespace Oru\Bundle\FormBundle\Form\Dummy;


interface DummyTypeInterface
{
    public function getDummyBuilder();
    public function getDescriptionBuilder();
    public function inflateDummyBuilder($formBuilder, $options = array());
}