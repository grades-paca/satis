<?php

/*
 * This file is part of the GenemuFormBundle package.
 *
 * (c) Olivier Chauvel <olivier@generation-multiple.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Oru\Bundle\FormBundle\Twig\Extension;

use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\Form\FormView;
use Symfony\Bridge\Twig\Form\TwigRendererInterface;

/**
 * FormExtension extends Twig with form capabilities.
 *
 * @author Olivier Chauvel <olivier@generation-multiple.com>
 */
class FormExtension extends \Twig_Extension
{
    /**
     * This property is public so that it can be accessed directly from compiled
     * templates without having to call a getter, which slightly decreases performance.
     *
     * @var \Symfony\Component\Form\FormRendererInterface
     */
    public $renderer;

    /**
     * @var Container
     */
    private $container;

    public function __construct(TwigRendererInterface $renderer, Container $container)
    {
        $this->renderer = $renderer;
        $this->container = $container;
    }

    /**
     * {@inheritdoc}
     */
    public function getFunctions()
    {
        return array(
            'form_javascript' => new \Twig_Function_Method($this, 'renderJavascript', array('is_safe' => array('html'))),
            'form_stylesheet' => new \Twig_Function_Node('Symfony\Bridge\Twig\Node\SearchAndRenderBlockNode', array('is_safe' => array('html'))),
            'email_is_valid' => new \Twig_Function_Method($this, 'emailIsValid', array('is_safe' => array('html'))),
            'pad_content' => new \Twig_Function_Method($this, 'padContent', array('is_safe' => array('html'))),
        );
    }

    /**
     * Render Function Form Javascript
     *
     * @param FormView $view
     * @param bool $prototype
     *
     * @return string
     */
    public function renderJavascript(FormView $view, $prototype = false)
    {
        $block = $prototype ? 'javascript_prototype' : 'javascript';

        return $this->renderer->searchAndRenderBlock($view, $block);
    }

    /**
     * @param $email
     * @return bool|null
     */
    public function emailIsValid($email)
    {
        return $this->container->get('oru_form.email.manager')->isValid($email);
    }

    /**
     * @param $email
     * @return bool|null
     */
    public function padContent($padId)
    {
        return $this->container->get('oru_form.etherpad.manager')->getHTMLContent($padId);
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'oru_form.twig.extension.form';
    }
}
