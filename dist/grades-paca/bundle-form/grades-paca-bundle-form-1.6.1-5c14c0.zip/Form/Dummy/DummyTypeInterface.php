<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 22/06/2017
 * Time: 09:09
 */

namespace Oru\Bundle\FormBundle\Form\Dummy;

use Symfony\Component\Form\FormEvent;

/**
 * Interface DummyTypeInterface.
 */
interface DummyTypeInterface
{
    /**
     * @return DummyFormBuilder
     */
    public function getDummyBuilder();

    /**
     * @return DummyFormDescriptionBuilder
     */
    public function getDescriptionBuilder();

    /**
     * @param FormEvent $event
     */
    public function inflateDummyBuilder(FormEvent $event);
}