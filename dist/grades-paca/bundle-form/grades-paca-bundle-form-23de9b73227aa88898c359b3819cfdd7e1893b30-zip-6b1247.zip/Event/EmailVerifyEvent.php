<?php

namespace Oru\Bundle\FormBundle\Event;

use Symfony\Component\EventDispatcher\Event;

/**
 * Class EmailVerifyEvent
 *
 * @package Oru\Bundle\FormBundle\Event
 * @author Michaël VEROUX
 */
class EmailVerifyEvent extends Event
{
    /**
     * @var bool
     */
    private $send = true;

    /**
     * @var object
     */
    private $entity;

    /**
     * EmailVerifyEvent constructor.
     *
     * @param object $entity
     */
    public function __construct($entity)
    {
        $this->entity = $entity;
    }

    /**
     * @return object
     */
    public function getEntity()
    {
        return $this->entity;
    }

    /**
     * @return void
     * @author Michaël VEROUX
     */
    public function disable()
    {
        $this->send = false;
    }

    /**
     * @return bool
     * @author Michaël VEROUX
     */
    public function isEnabled()
    {
        return $this->send;
    }
}
