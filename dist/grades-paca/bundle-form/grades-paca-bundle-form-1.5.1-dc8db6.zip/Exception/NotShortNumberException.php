<?php

namespace Oru\Bundle\FormBundle\Exception;

/**
 * Class NotShortNumberException
 *
 * @package Oru\Bundle\FormBundle\Exception
 * @author Michaël VEROUX
 */
class NotShortNumberException extends \LengthException
{

}
