<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Manager;


use EtherpadLite\Client;
use Oru\Bundle\SettingBundle\Setting\Setting;

class EtherpadManager
{
    /**
     * @var
     */
    private $apiKey;

    /**
     * @var
     */
    private $url;

    /**
     * EtherpadManager constructor.
     * @param Setting $setting
     */
    public function __construct(Setting $setting)
    {
        $this->apiKey = $setting->setting('etherpad_api_key', 'OruFormBundle');
        $this->url = trim($setting->setting('etherpad_url', 'OruFormBundle'), '/');
    }

    /**
     * @return mixed
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * @return null|string
     */
    public function checkAccess()
    {
        return $this->getClient()->checkToken();
    }

    /**
     * @return Client
     */
    private function getClient()
    {
        return new Client($this->apiKey, $this->url . '/api');
    }

    /**
     * @param $pdaId
     * @return null|string
     */
    public function getHTMLContent($pdaId)
    {
        try {
            $content = $this->getClient()->getHTML($pdaId);
            if(isset($content->html)) {
                return $content->html;
            }
        } catch(\Exception $e) {
            return $e->getMessage();
        }

        return null;
    }
}