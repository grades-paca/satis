<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 23/11/2016
 * Time: 16:52
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\DataTransformerInterface;

/**
 * Class PurifiedTextType
 * @package Oru\Bundle\FormBundle\Form\Type
 */
class PurifiedTextType extends AbstractType
{
    /**
     * @var DataTransformerInterface
     */
    private $purifierTransformer;

    /**
     * @var string
     */
    private $type;

    /**
     * PurifiedTextType constructor.
     * @param DataTransformerInterface $purifierTransformer
     */
    public function __construct(DataTransformerInterface $purifierTransformer, $type = "text")
    {
        $this->purifierTransformer = $purifierTransformer;
        $this->type = $type;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->addViewTransformer($this->purifierTransformer);
    }

    /**
     * @return string
     */
    public function getParent()
    {
        if($this->type == 'textarea'){
            return 'textarea';
        }else{
            return 'text';
        }
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        if($this->type == 'textarea'){
            return 'oru_purified_text';
        }else{
            return 'oru_purified_string';
        }
    }
}