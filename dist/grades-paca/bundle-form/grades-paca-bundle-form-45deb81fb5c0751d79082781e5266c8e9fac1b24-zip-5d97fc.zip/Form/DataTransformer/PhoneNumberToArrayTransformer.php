<?php

/*
 * This file is part of the Symfony2 PhoneNumberBundle.
 *
 * (c) University of Cambridge
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Oru\Bundle\FormBundle\Form\DataTransformer;

use libphonenumber\NumberParseException;
use libphonenumber\PhoneNumber;
use libphonenumber\PhoneNumberFormat;
use libphonenumber\PhoneNumberUtil;
use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\Exception\TransformationFailedException;

/**
 * Phone number to string transformer.
 *
 * @author Chris Wilkinson <chris.wilkinson@admin.cam.ac.uk>
 */
class PhoneNumberToArrayTransformer implements DataTransformerInterface
{
    /**
     * Default region code.
     *
     * @var string
     */
    private $defaultRegion;

    /**
     * Display format.
     *
     * @var int
     */
    private $format;

    /**
     * Constructor.
     *
     * @param string $defaultRegion Default region code.
     * @param int    $format        Display format.
     */
    public function __construct(
        $defaultRegion = PhoneNumberUtil::UNKNOWN_REGION,
        $format = PhoneNumberFormat::INTERNATIONAL
    ) {
        $this->defaultRegion = $defaultRegion;
        $this->format = $format;
    }

    /**
     * {@inheritdoc}
     */
    public function transform($phoneNumber)
    {
        $util = PhoneNumberUtil::getInstance();
        if (null === $phoneNumber) {
            return array('indicatif' => '+'.$util->getCountryCodeForRegion($this->defaultRegion), 'phone' => null);
        } elseif (false === $phoneNumber instanceof PhoneNumber) {
            throw new TransformationFailedException('Expected a \libphonenumber\PhoneNumber.');
        }
        // /!\ Attention une modification de l'affichage à une incidence sur le mode show de planBlanc/Bleu et cruqpc (show.js) /!\
        return  array('indicatif' => '+'.$phoneNumber->getCountryCode(), 'phone' =>'0'.$util->getNationalSignificantNumber($phoneNumber));
    }

    /**
     * {@inheritdoc}
     */
    public function reverseTransform($array)
    {
        if (!$array || !isset($array['phone']) ||empty($array['phone'])) {
            return null;
        }

        $util = PhoneNumberUtil::getInstance();

        try {
            return $util->parse(str_replace(' ','',$array['indicatif'].$array['phone']), PhoneNumberFormat::INTERNATIONAL);
        } catch (NumberParseException $e) {
            throw new TransformationFailedException($e->getMessage(), $e->getCode(), $e);
        }
    }
}
