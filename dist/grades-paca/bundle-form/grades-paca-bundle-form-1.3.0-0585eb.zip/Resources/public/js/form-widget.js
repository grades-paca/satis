function odd_even_rows(selector)
{
    if(typeof selector == 'undefined' || selector == null)
    {
        odd_even_rows_locked = true;
        selector = 'form div > .form_row:visible';
    }

    var odd_even = 1;
    if(jQuery(selector).hasClass('odd'))
        odd_even = 1;

    jQuery(selector).each(function(){
        jQuery(this).removeClass('.ui-widget-content').addClass('.ui-widget-content');
        if(odd_even % 2)
        {
            jQuery(this).removeClass('odd').removeClass('even').addClass('odd');
        }
        else
        {
            jQuery(this).removeClass('odd').removeClass('even').addClass('even');
        }
        odd_even++;
        odd_even_rows(jQuery(this).children('.form_row:visible'), true);
    });
}
function oui_non_detail_State(id, parent_id, detail, on_no)
{
    var selectedVal = '';
    var selected = jQuery('div#' + id + ' input[type="radio"]:checked, select#' + id);
    if(selected.length > 0)
    {
        if(jQuery('select#' + id).length > 0)
            selectedVal = jQuery('select#' + id).val();
        else
            selectedVal = selected.val();
    }

    var expected = (! on_no) << 0;
    expected = expected.toString();

    var detail_selector = '#' + parent_id + '_' + detail;

    if(selectedVal ===  expected)
    {
        jQuery(detail_selector).removeClass('form_hidden').parents('.form_row:first').show();
    }
    else
    {
        jQuery(detail_selector).addClass('form_hidden').parents('.form_row:first').hide();
    }
}
function checked_detail_State(id, parent_id, detail)
{
    var selectedVal = jQuery('input#' + id).is(':checked');

    var detail_selector = '#' + parent_id + '_' + detail;

    if(selectedVal)
    {
        jQuery(detail_selector).removeClass('form_hidden').parents('.form_row:first').show();
    }
    else
    {
        jQuery(detail_selector).addClass('form_hidden').parents('.form_row:first').hide();
    }
}
function sum_of(id, class_type)
{
    var sum = 0;
    jQuery('.' + class_type).each(function() {
        var current_val = $(this).val().replace(',','.').replace(' ','');
        if('' == current_val){ current_val = '0'; }
        sum += parseFloat(current_val);
    });
    sum = sum.toString().replace('.',',');
    jQuery('#' + id).val(sum);
    jQuery('#' + id).change();
}
function percent_calc(id, type_class, type_class_total)
{
    var sum_total = 0;
    jQuery('.' + type_class_total).each(function() {
        var current_val = $(this).val().replace(',','.').replace(' ','');
        if('' == current_val){ current_val = '0'; }
        sum_total += parseFloat(current_val);
    });

    if(sum_total === 0){
        jQuery('#' + id).val('');
        jQuery('#' + id).change();
        return;
    }

    var sum = 0;
    jQuery('.' + type_class).each(function() {
        var current_val = $(this).val().replace(',','.').replace(' ','');
        if('' == current_val){ current_val = '0'; }
        sum += parseFloat(current_val);
    });
    var percent = sum * 100 / sum_total;
    percent = percent.toString().replace('.',',');
    jQuery('#' + id).val(percent);
    jQuery('#' + id).change();
}
function oru_checkall(idController, classManaged, checked) {
    if (typeof checked != 'undefined' && checked) {
        jQuery('#' + idController).prop('checked', true);
    }
    jQuery('#' + idController).click(function () {
        if (jQuery(this).is(':checked')) {
            jQuery('.' + classManaged).prop('checked', true);
        } else {
            jQuery('.' + classManaged).prop('checked', false);
        }
    });
}
jQuery( document ).ready(function(){
    jQuery('form').submit(function(){
        jQuery('.form_hidden').prop('disabled', true);
    });
    jQuery('form div.form_row:not(:has("div.form_row"))').addClass('final_row');
});

// jQuery plugin to prevent double submission of forms
jQuery.fn.preventDoubleSubmission = function() {
    $(this).on('submit',function(e){
        var $form = $(this);

        if ($form.data('submitted') === true) {
            // Previously submitted - don't submit again
            e.preventDefault();
        } else {
            // Mark it so that the next submit can be ignored
            $form.data('submitted', true);
        }
    });

    // Keep chainability
    return this;
};

function select2_popover_tooltip() {
    jQuery(".select2-container").each( function(){
        switch($(this).prev().attr("data-toggle")) {
            case "popover":
                $(this).popover({
                    title: $(this).prev().attr("title"),
                    content: $(this).prev().attr("data-content"),
                    trigger: $(this).prev().attr("data-trigger"),
                    animation: $(this).prev().attr("data-animation"),
                    delay: $(this).prev().attr("data-delay"),
                    html: $(this).prev().attr("data-html"),
                    placement: $(this).prev().attr("data-placement"),
                    selector: $(this).prev().attr("data-selector"),
                    template: $(this).prev().attr("data-template"),
                    viewport: $(this).prev().attr("data-viewport")
                });
                break;
            case "tooltip":
                $(this).tooltip({
                    title: $(this).prev().attr("title"),
                    trigger: $(this).prev().attr("data-trigger"),
                    animation: $(this).prev().attr("data-animation"),
                    delay: $(this).prev().attr("data-delay"),
                    html: $(this).prev().attr("data-html"),
                    placement: $(this).prev().attr("data-placement"),
                    selector: $(this).prev().attr("data-selector"),
                    template: $(this).prev().attr("data-template"),
                    viewport: $(this).prev().attr("data-viewport"),
                    container: $(this).prev().attr("data-container")
                });
                break;
        }
    });
}

/**
 * Gestion des widgets périodes
 */

function periodes_applyPOToAll(periodesType)
{
    day = periodes_getDayForField($('select[id$="_'+periodesType+'_1_jour"]'));
    fermeChecked = $(day).find('input[type="checkbox"][id$="'+periodesType+'_1_ferme"]').is(':checked');
    h24Checked = $(day).find('input[type="checkbox"][id$="'+periodesType+'_1_h24"]').is(':checked');

    p1Debut = $(day).find('[id$="_p1Debut"]').val();
    p1Fin = $(day).find('[id$="_p1Fin"]').val();
    p2Debut = $(day).find('[id$="_p2Debut"]').val();
    p2Fin = $(day).find('[id$="_p2Fin"]').val();
    p3Debut = $(day).find('[id$="_p3Debut"]').val();
    p3Fin = $(day).find('[id$="_p3Fin"]').val();

    $(day).nextAll('.periode').each(function(e) {
        nextDay = periodes_getDayForField($(this));
        $(nextDay).find('input[type="checkbox"][id$="_ferme"]').removeAttr("disabled");
        $(nextDay).find('input[type="checkbox"][id$="_h24"]').removeAttr("disabled");
        $(nextDay).find('input[type="checkbox"][id$="_ferme"]').prop('checked',fermeChecked);
        $(nextDay).find('input[type="checkbox"][id$="_h24"]').prop('checked',h24Checked);
        periodes_checkFerme($(nextDay).find('input[type="checkbox"][id$="_ferme"]'));
        periodes_checkH24($(nextDay).find('input[type="checkbox"][id$="_h24"]'));

        periodes_updatePeriodeValue(nextDay,1,p1Debut,p1Fin);
        periodes_updatePeriodeValue(nextDay,2,p2Debut,p2Fin);
        periodes_updatePeriodeValue(nextDay,3,p3Debut,p3Fin);

    });
}

function periodes_unlock(element)
{
    jour = periodes_getDayForField(element);
    periode = $(element).attr('id').match(/p([1-3])LockAction/);
    periodes_updatePeriodeLock(jour,periode[1],1);
}
function periodes_lock(element)
{
    jour = periodes_getDayForField(element);
    periode = $(element).attr('id').match(/p([1-3])UnlockAction/);
    periodes_updatePeriodeValue(jour,periode[1],'','')
    periodes_updatePeriodeLock(jour,periode[1],0);
}

function periodes_updatePeriodeValue(jour, periode, begin, end) {
    $(jour).find('input[id$="p'+periode+'Debut"]').val(begin);
    $(jour).find('input[id$="p'+periode+'Fin"]').val(end);
}

function periodes_updatePeriodeLock(jour, periode, display) {
    $(jour).find('[class^="periodes_p'+periode+'"] input[type="time"]').each(function() {
        if(display) {
            $(this).removeAttr("readonly");
        } else {
            $(this).attr("readonly", true);
        }
    });
}

function periodes_checkFerme(element)
{
    jour = periodes_getDayForField(element);
    display = !$(element).prop('checked');
    periodes_updateH24(jour,display);
    if(display) {
        periodes_updatePeriodeLock(jour,1,display);
        periodes_updatePeriodeLock(jour,2,display);
        periodes_updatePeriodeLock(jour,3,display);
    } else {
        periodes_updatePeriodeValue(jour,1,'','')
        periodes_updatePeriodeLock(jour,1,display);
        periodes_updatePeriodeValue(jour,2,'','')
        periodes_updatePeriodeLock(jour,2,display);
        periodes_updatePeriodeValue(jour,3,'','')
        periodes_updatePeriodeLock(jour,3,display);
    }
}

function periodes_updateFerme(jour, display) {
    $(jour).find('input[id$="ferme"]').each(function() {
        if(!display) {
            $(this).attr('checked', false);
        }
    });
}

function periodes_checkH24(element)
{
    jour = periodes_getDayForField(element);
    display = !$(element).prop('checked');
    periodes_updateFerme(jour,display);
    if(display) {
        periodes_updatePeriodeLock(jour,1,display);
        periodes_updatePeriodeLock(jour,2,display);
        periodes_updatePeriodeLock(jour,3,display);
    } else {
        periodes_updatePeriodeValue(jour,1,'00:00','23:59');
        periodes_updatePeriodeLock(jour,1,display);
        periodes_updatePeriodeValue(jour,2,'','')
        periodes_updatePeriodeLock(jour,2,display);
        periodes_updatePeriodeValue(jour,3,'','')
        periodes_updatePeriodeLock(jour,3,display);
    }
}

function periodes_updateH24(jour, display) {
    $(jour).find('input[id$="_h24"]').each(function() {
        if(!display) {
            $(this).attr('checked', false);
        }
    });
}

function periodes_checkP3(group)
{
    p3 = $('#periodesP3_'+group).prop('checked');
    $('.oru_periode .periodes_p3[data-group="'+group+'"]').each(function() {
        if(p3)
            $(this).css('display','table-row');
        else {
            $(this).css('display', 'none');
        }
    });
}

function periodes_updateP3(value,group)
{
    $('#periodesP3_'+group).prop('checked',value);
    periodes_checkP3(group);
}

function periodes_getDayForField(field) {
    return $(field).closest('.periode');
}

function periodes_updatePO()
{
    $('.oru_periode .periodes_ferme input[type="checkbox"]:checked').each(function() {
        periodes_checkFerme(this);
    });

    $('.oru_periode .periodes_h24 input[type="checkbox"]:checked').each(function() {
        periodes_checkH24(this);
    });

    // ferme
    $('.oru_periode .periodes_ferme input[type="checkbox"]').click(function() {
        periodes_checkFerme(this);
    });

    // h24
    $('.oru_periode .periodes_h24 input[type="checkbox"]').click(function() {
        periodes_checkH24(this);
    });

    // h24
    $('.oru_periode .apply_all').click(function(e) {
        periodes_applyPOToAll($(this).attr('data-group'));
        e.preventDefault();
    });

    $('.oru_periode input[id$="_p3Plage"]').each(function() {
        if($(this).val()) {
            periodes_updateP3(true, $(this).closest('.periodes_p3').attr('data-group'));
        }
        else
            periodes_updateP3(false, $(this).closest('.periodes_p3').attr('data-group'));
    });

    $('.periodesP3').click(function() {
        periodes_checkP3($(this).attr('data-group'));
    });

    $('.periodesP3').each(function(){
        periodes_checkP3($(this).attr('data-group'));
    });
}


/**
* Permet d'injecter les options de bootstrap tooltip et popover aux champs select2 (1)
* Permet la préparation des champs de type Période (2)
*/
$(document).ready(function () {

    /**
     * (1)
     */
    select2_popover_tooltip();

    // jQuery plugin to prevent double submission of forms
    $('form.prevent-dbl-submit:not(.allow-dbl-submit)').preventDoubleSubmission();

    /**
     * (2)
     */
    periodes_updatePO();
});