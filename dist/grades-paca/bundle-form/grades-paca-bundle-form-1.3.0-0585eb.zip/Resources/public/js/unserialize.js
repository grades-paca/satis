// Unserialize (to) form plugin
// Version 1.0.8
// Copyright (C) 2010-2012 Christopher Thielen, others (see ChangeLog below)
// Dual-licensed under GPLv2 and the MIT open source licenses

// Usage:
//        var s = $("form").serialize(); // save form settings
//        $("form").unserializeForm(s);  // restore form settings

// Notes:
//        * Recurses fieldsets, p tags, etc.
//        * Form elements must have a 'name' attribute.

// Alternate Usage:
//        var s = $("form").serialize();
//        $("form").unserializeForm(s, {
//          'callback'        : function(key, value, [element]) { $(input[name=key]).val(val); },
//          'override-values' : false
//        });
//
//        callback (optional):
//          The above callback is given the element and value, allowing you to build
//          dynamic forms via callback. If you return false, unserializeForm will
//          try to find and set the DOM element, otherwise, (on true) it assumes you've
//          handled that attribute and moves onto the next.
//          The callback will be passed the key and value and, if found, the DOM object it
//          will use should you return false. If the DOM object is not found, the third parameter
//          will be the empty array jQuery returns when it cannot find an element.
//        override-values (optional, default is false):
//          Controls whether elements already set (e.g. an input tag with a non-zero length value)
//          will be touched by the unserializer. Does not apply to radio fields or checkboxes.
//          If you have a use case for radio fields or checkboxes, please file an issue at
//          https://github.com/cthielen/unserialize-to-form/issues/ . Also note this option
//          does not apply to a callback, i.e. a callback would still have the opportunity
//          to override a value even if this option is set to false. It is up to you as
//          the callback author to enforce the behavior you wish.

// Custom changes by Michael Veroux for ROR 3.x

(function($) {
    var methods = {
        _changeEl : function( el, _value) {
            var oldValue = $(el).val();
            $(el).val(_value);
            if(oldValue != _value)
            {
                $(el).trigger('change')
            }
        },
        _unserializeFormSetValue : function( el, _value, override ) {

            if($(el).length > 1) {
                // Assume multiple elements of the same name are radio buttons
                $.each(el, function(i) {
                    var match = ($.isArray(_value)
                        ? ($.inArray(this.value, _value) != -1)
                        : (this.value == _value)
                        );

                    this.checked = match;
                });
            } else {
                // Assume, if only a single element, it is not a radio button
                if($(el).attr("type") == "checkbox") {
                    $(el).prop("checked", true);
                } else {
                    if(override) {
                        methods._changeEl(el, _value);
                    } else {
                        if (!$(el).val()) {
                            methods._changeEl(el, _value);
                        }
                    }
                }
            }
        },

        _pushValue : function( obj, key, val ) {
            if (null == obj[key])
                obj[key] = val;
            else if (obj[key].push)
                obj[key].push(val);
            else
                obj[key] = [obj[key], val];
        }
    };

    // takes a GET-serialized string, e.g. first=5&second=3&a=b and sets input tags (e.g. input name="first") to their values (e.g. 5)
    $.fn.unserializeForm = function( _values, _options ) {
        recoverableOnAir = true;
        // Set up defaults
        var settings = $.extend( {
            'callback'         : undefined,
            'override-values'  : false
        }, _options);

        this.each(function() {
            // this small bit of unserializing borrowed from James Campbell's "JQuery Unserialize v1.0"
            _values = _values.split("&");
            _callback = settings["callback"];
            _override_values = settings["override-values"];

            if(_callback && typeof(_callback) !== "function") {
                _callback = undefined; // whatever they gave us wasn't a function, act as though it wasn't given
            }

            var serialized_values = new Array();
            var properties;
            while(_values.length)
            {
                properties = _values.shift().replace(/\+/g, " ").split('=');

                methods._pushValue(serialized_values, properties[0], decodeURIComponent(properties[1]));
            }

            // _values is now a proper array with values[hash_index] = associated_value
            _values = serialized_values;

            // Start with all checkboxes and radios unchecked, since an unchecked box will not show up in the serialized form
            $(this).find(":checked").attr("checked", false);

            // Iterate through each saved element and set the corresponding element
            for(var key in _values) {
                var el = $(this).find("[name=\"" + decodeURIComponent(key) + "\"]");

                if(_callback == undefined) {
                    // No callback specified - assume DOM elements exist
                    methods._unserializeFormSetValue(el, _values[key], _override_values);
                } else {
                    // Callback specified - don't assume DOM elements already exist
                    var result = _callback.call(this, decodeURIComponent(key), _values[key], el);

                    // If they return true, it means they handled it. If not, we will handle it.
                    // Returning false then allows for DOM building without setting values.
                    if(result == false) {
                        var el = $(this).find("[name=\"" + decodeURIComponent(key) + "\"]");
                        // Try and find the element again as it may have just been created by the callback
                        methods._unserializeFormSetValue(el, _values[key], _override_values);
                    }
                }
            }
        });
        recoverableOnAir = false;
    }
})(jQuery);