<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Component\Validator\Tests\Constraints;

use Oru\Bundle\FormBundle\Validator\Constraints\LengthParameter;
use Oru\Bundle\TestBundle\Tests\ModelTestCase;

class LengthParameterValidatorTest extends ModelTestCase
{
    protected $context;
    protected $validator;

    public function setUp()
    {
        parent::setUp();
        $this->context = $this->createMock('Symfony\Component\Validator\ExecutionContext');
        $this->validator = $this->getContainer()->get('oru_form.validator.length_parameter');
        $this->validator->initialize($this->context);
    }

    public function testNullIsValid()
    {
        $this->context->expects($this->never())
            ->method('addViolation');

        $this->validator->validate(null, new LengthParameter('oru_form_validator_length_parameter_testfive'));
    }

    public function testEmptyStringIsValid()
    {
        $this->context->expects($this->never())
            ->method('addViolation');

        $this->validator->validate('', new LengthParameter('oru_form_validator_length_parameter_testfive'));
    }

    public function testExpectsStringCompatibleType()
    {
        $this->validator->validate(new \stdClass(), new LengthParameter('oru_form_validator_length_parameter_testfive'));
    }

    public function getThreeOrLessCharacters()
    {
        return array(
            array(12),
            array('12'),
            array('üü', true),
            array('éé', true),
            array(123),
            array('123'),
            array('üüü', true),
            array('ééé', true),
        );
    }

    public function getFourCharacters()
    {
        return array(
            array(1234),
            array('1234'),
            array('üüüü', true),
            array('éééé', true),
        );
    }

    public function getNotFourCharacters()
    {
        return array_merge(
            $this->getThreeOrLessCharacters(),
            $this->getFiveOrMoreCharacters()
        );
    }

    public function getFiveOrMoreCharacters()
    {
        return array(
            array(12345),
            array('12345'),
            array('üüüüü', true),
            array('ééééé', true),
            array(123456),
            array('123456'),
            array('üüüüüü', true),
            array('éééééé', true),
        );
    }

    /**
     * @dataProvider getFiveOrMoreCharacters
     *
     * @param mixed $value
     * @param mixed $mbOnly
     */
    public function testValidValuesMin($value, $mbOnly = false)
    {
        if ($mbOnly && !function_exists('mb_strlen')) {
            $this->markTestSkipped('mb_strlen does not exist');
        }

        $this->context->expects($this->never())
            ->method('addViolation');

        $constraint = new LengthParameter(array('min' => 'oru_form_validator_length_parameter_testfive'));
        $this->validator->validate($value, $constraint);
    }

    /**
     * @dataProvider getThreeOrLessCharacters
     *
     * @param mixed $value
     * @param mixed $mbOnly
     */
    public function testValidValuesMax($value, $mbOnly = false)
    {
        if ($mbOnly && !function_exists('mb_strlen')) {
            $this->markTestSkipped('mb_strlen does not exist');
        }

        $this->context->expects($this->never())
            ->method('addViolation');

        $constraint = new LengthParameter(array('max' => 'oru_form_validator_length_parameter_testthree'));
        $this->validator->validate($value, $constraint);
    }

    /**
     * @dataProvider getFourCharacters
     *
     * @param mixed $value
     * @param mixed $mbOnly
     */
    public function testValidValuesExact($value, $mbOnly = false)
    {
        if ($mbOnly && !function_exists('mb_strlen')) {
            $this->markTestSkipped('mb_strlen does not exist');
        }

        $this->context->expects($this->never())
            ->method('addViolation');

        $constraint = new LengthParameter(array('max' => 'oru_form_validator_length_parameter_testfour'));
        $this->validator->validate($value, $constraint);
    }

    /**
     * @dataProvider getThreeOrLessCharacters
     *
     * @param mixed $value
     * @param mixed $mbOnly
     */
    public function testInvalidValuesMin($value, $mbOnly = false)
    {
        if ($mbOnly && !function_exists('mb_strlen')) {
            $this->markTestSkipped('mb_strlen does not exist');
        }

        $constraint = new LengthParameter(array(
            'min' => 'oru_form_validator_length_parameter_testfour',
            'minMessage' => 'myMessage',
        ));

        $this->context->expects($this->once())
            ->method('addViolation')
            ->with('myMessage', $this->identicalTo(array(
                '{{ value }}' => (string) $value,
                '{{ limit }}' => 4,
            )), $this->identicalTo($value), 4);

        $this->validator->validate($value, $constraint);
    }

    /**
     * @dataProvider getFiveOrMoreCharacters
     *
     * @param mixed $value
     * @param mixed $mbOnly
     */
    public function testInvalidValuesMax($value, $mbOnly = false)
    {
        if ($mbOnly && !function_exists('mb_strlen')) {
            $this->markTestSkipped('mb_strlen does not exist');
        }

        $constraint = new LengthParameter(array(
            'max' => 'oru_form_validator_length_parameter_testfour',
            'maxMessage' => 'myMessage',
        ));

        $this->context->expects($this->once())
            ->method('addViolation')
            ->with('myMessage', $this->identicalTo(array(
                '{{ value }}' => (string) $value,
                '{{ limit }}' => 4,
            )), $this->identicalTo($value), 4);

        $this->validator->validate($value, $constraint);
    }

    /**
     * @dataProvider getNotFourCharacters
     *
     * @param mixed $value
     * @param mixed $mbOnly
     */
    public function testInvalidValuesExact($value, $mbOnly = false)
    {
        if ($mbOnly && !function_exists('mb_strlen')) {
            $this->markTestSkipped('mb_strlen does not exist');
        }

        $constraint = new LengthParameter(array(
            'min' => 'oru_form_validator_length_parameter_testfour',
            'max' => 'oru_form_validator_length_parameter_testfour',
            'exactMessage' => 'myMessage',
        ));

        $this->context->expects($this->once())
            ->method('addViolation')
            ->with('myMessage', $this->identicalTo(array(
                '{{ value }}' => (string) $value,
                '{{ limit }}' => 4,
            )), $this->identicalTo($value), 4);

        $this->validator->validate($value, $constraint);
    }

    public function testConstraintGetDefaultOption()
    {
        $constraint = new LengthParameter('oru_form_validator_length_parameter_testfive');

        $this->assertSame('oru_form_validator_length_parameter_testfive', $constraint->min);
        $this->assertSame('oru_form_validator_length_parameter_testfive', $constraint->max);
    }
}
