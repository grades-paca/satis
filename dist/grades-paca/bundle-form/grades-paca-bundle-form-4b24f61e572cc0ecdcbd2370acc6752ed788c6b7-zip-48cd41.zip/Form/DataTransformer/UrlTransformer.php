<?php
/**
 * Author: tdepreau
 * Date: 21/02/18
 * Time: 15:34
 */

namespace Oru\Bundle\FormBundle\Form\DataTransformer;

use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Routing\RouterInterface;

/**
 * Class UrlTransformer.
 */
class UrlTransformer implements DataTransformerInterface
{
    /**
     * @var RouterInterface
     */
    private $router;

    /**
     * PurifiedCkeditorType constructor.
     *
     * @param DataTransformerInterface $purifierTransformer
     * @param RouterInterface          $router
     */
    public function __construct(RouterInterface $router)
    {
        $this->router = $router;
    }

    /**
     * @param mixed $value
     *
     * @return mixed
     */
    public function transform($value)
    {
        return $value;
    }

    /**
     * @param mixed $value
     *
     * @return mixed|null|string|string[]
     */
    public function reverseTransform($value)
    {
        return $this->makeClickable($value);
    }

    /**
     * @param $ret
     *
     * @return null|string|string[]
     */
    public function makeClickable($ret)
    {
        $ret = ' '.$ret;
        // in testing, using arrays here was found to be faster
        $ret = preg_replace_callback('#([\s>])([\w]+?://[\w\\x80-\\xff\#$%&~/.\-;:=,?@\[\]+]*)#is', array($this, 'makeUrlClickable'), $ret);
        $ret = preg_replace_callback('#([\s>])([.0-9a-z_+-]+)@(([0-9a-z-]+\.)+[0-9a-z]{2,})#i', array($this, 'makeEmailClickable'), $ret);

        // this one is not in an array because we need it to run last, for cleanup of accidental links within links
        $ret = preg_replace('#(<a( [^>]+?>|>))<a [^>]+?>([^>]+?)</a></a>#i', '$1$3</a>', $ret);
        $ret = trim($ret);

        return $ret;
    }

    /**
     * @param $matches
     *
     * @return string
     */
    public function makeUrlClickable($matches)
    {
        $ret = '';
        $url = $matches[2];

        if (empty($url)) {
            return $matches[0];
        }
        // removed trailing [.,;:] from URL
        if (in_array(substr($url, -1), array('.', ',', ';', ':'), true) === true) {
            $ret = substr($url, -1);
            $url = substr($url, 0, strlen($url) - 1);
        }
        $externalUrl = $this->router->generate('oru_security_external', array('url' => strip_tags($url)));

        return $matches[1]."<a href=\"$externalUrl\" rel=\"nofollow\" data-external=\"1\">$url</a>".$ret;
    }

    /**
     * @param $matches
     *
     * @return string
     */
    public function makeEmailClickable($matches)
    {
        $email = $matches[2].'@'.$matches[3];

        return $matches[1]."<a href=\"mailto:$email\" data-external=\"1\">$email</a>";
    }
}
