<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 21/06/2017
 * Time: 11:08
 */

namespace Oru\Bundle\FormBundle\Form\Dummy;

use Oru\Bundle\DeniedFieldBundle\Manager\DeniedFieldManager;
use Oru\Bundle\DeniedFieldBundle\DeniedField\DeniedFields;
use Symfony\Component\Form\FormEvent;

/**
 * Trait DummyTypeTrait.
 */
trait DummyTypeTrait
{
    /**
     * @var DummyFormBuilder
     * Utilisé pour la construction du Form
     */
    protected $dummyBuilder;

    /**
     * @var DummyFormDescriptionBuilder
     * Utilisé pour la description générique des champs
     */
    protected $dummyFields;

    /**
     * @var DeniedFieldManager
     */
    protected $deniedFieldManager;

    /**
     * @var DeniedFields|null
     */
    protected $deniedFields;

    /**
     * @param FormEvent $event
     */
    public function inflateDummyBuilder(FormEvent $event)
    {
        $entity = $event->getData();
        $deniedFields = call_user_func($this->getDeniedFields(), $entity);

        foreach ($this->getDummyBuilder()->getFields() as $name => $field) {

            $fieldType = $field['type'];
            $fieldOptions = $field['options'];
            if ($this->getDescriptionBuilder()->has($name)) {
                $described = $this->getDescriptionBuilder()->getField($name);
                if (!$fieldType) {
                    $fieldType = $described['type'];
                }

                if (isset($fieldOptions['closure'])) {
                    $closure = $fieldOptions['closure'];
                    if (is_callable($closure)) {
                        call_user_func($closure);
                    }
                    unset($fieldOptions['closure']);
                }
                $fieldOptions = array_merge($fieldOptions, $described['options']);
            }

            if (!$deniedFields->isDenied($name, DeniedFields::VIEW)) {
                $event->getForm()->add($name, $fieldType, $fieldOptions);
            }
        }
    }

    /**
     * @return DummyFormBuilder
     */
    public function getDummyBuilder()
    {
        if (!$this->dummyBuilder) {
            $this->createDummyBuilder();
        }

        return $this->dummyBuilder;
    }

    /**
     * @return DummyFormBuilder
     */
    public function createDummyBuilder()
    {
        $this->dummyBuilder = new DummyFormBuilder();

        return $this->dummyBuilder;
    }

    /**
     * @return DummyFormDescriptionBuilder
     */
    public function getDescriptionBuilder()
    {
        if (!$this->dummyFields) {
            $this->createDescriptionBuilder();
        }

        return $this->dummyFields;
    }

    /**
     * @return DummyFormDescriptionBuilder
     */
    public function createDescriptionBuilder()
    {
        $this->dummyFields = new DummyFormDescriptionBuilder();

        return $this->dummyFields;
    }

    /**
     * @return \Closure
     *
     * @author Michaël VEROUX
     */
    public function getDeniedFields()
    {
        $deniedFieldManager = &$this->deniedFieldManager;
        $deniedFields = &$this->deniedFields;
        $func = function ($entity) use (&$deniedFieldManager, &$deniedFields) {
            $key = null;
            if ($entity) {
                $key = $entity->getId();
            }
            if (!$key) {
                $key = 'null';
            }
            if (!is_array($deniedFields) || !isset($deniedFields[$key])) {
                $deniedFields[$key] = $deniedFieldManager->getDeniedFields($entity);
            }

            return $deniedFields[$key];
        };

        return $func;
    }
}