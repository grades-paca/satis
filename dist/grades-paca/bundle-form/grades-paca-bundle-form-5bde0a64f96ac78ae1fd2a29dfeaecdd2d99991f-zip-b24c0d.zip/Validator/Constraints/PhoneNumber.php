<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Validator\Constraints;


class PhoneNumber extends \Misd\PhoneNumberBundle\Validator\Constraints\PhoneNumber
{

}