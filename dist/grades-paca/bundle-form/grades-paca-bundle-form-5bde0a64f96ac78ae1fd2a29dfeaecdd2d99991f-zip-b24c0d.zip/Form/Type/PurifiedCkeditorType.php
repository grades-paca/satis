<?php
/**
 * Created by PhpStorm.
 * User: ecervetti
 * Date: 02/05/2016
 * Time: 14:35
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\AbstractType ;


class PurifiedCkeditorType  extends AbstractType
{
    private $purifierTransformer;

    
    public function __construct(DataTransformerInterface $purifierTransformer)
    {
        $this->purifierTransformer = $purifierTransformer;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->addViewTransformer($this->purifierTransformer);
    }

    public function getParent()
    {
        return 'ckeditor';
    }


    public function getName()
    {
        return 'purified_ckeditor';
    }
}