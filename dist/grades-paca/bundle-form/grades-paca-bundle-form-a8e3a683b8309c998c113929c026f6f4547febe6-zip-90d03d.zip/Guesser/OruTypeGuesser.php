<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 16/01/14
 * Time: 16:37
 */

namespace Oru\Bundle\FormBundle\Guesser;


use Symfony\Bridge\Doctrine\ManagerRegistry;
use Symfony\Component\Form\FormTypeGuesserInterface;
use Symfony\Component\Form\Guess\Guess;
use Symfony\Component\Form\Guess\TypeGuess;
use Symfony\Component\Security\Core\Util\ClassUtils;
use Symfony\Component\Validator\Exception\MappingException;

class OruTypeGuesser implements FormTypeGuesserInterface {

    protected $registry;

    private $cache;

    public function __construct(ManagerRegistry $registry)
    {
        $this->registry = $registry;
        $this->cache = array();
    }

    /**
     * {@inheritDoc}
     */
    public function guessType($class, $property)
    {
        if (!$ret = $this->getMetadata($class)) {
            return null;
        }

        list($metadata, $name) = $ret;

        switch ($metadata->getTypeOfField($property)) {
            // surcharge des textarea en ckeditor
            //case 'text':
            //    return new TypeGuess('ckeditor', array(), Guess::HIGH_CONFIDENCE);

            // surcharche des champs de type date, time et datetime en champs de type texte
            case 'datetime':
            case 'vardatetime':
            case 'datetimetz':
                return new TypeGuess(
                    'datetime',
                    array(
                        'date_widget'=> 'single_text',
                        'time_widget'=> 'single_text'
                    ),
                    Guess::VERY_HIGH_CONFIDENCE
                );
            case 'date':
                return new TypeGuess(
                    'date',
                    array(
                        'widget'=> 'single_text'
                    ),
                    Guess::VERY_HIGH_CONFIDENCE
                );
            case 'time':
                return new TypeGuess(
                    'time',
                    array(
                        'widget'=> 'single_text'
                    ),
                    Guess::VERY_HIGH_CONFIDENCE
                );
            case 'phone_number':
                return new TypeGuess(
                    'oru_tel',
                    array(
                        'error_bubbling' => false,
                        'attr'  => array('class' => 'phone_number', ),
                    ),
                    Guess::VERY_HIGH_CONFIDENCE
                );
            case 'json_array':
                return new TypeGuess(
                    'oru_json_array',
                    array(
                    ),
                    Guess::VERY_HIGH_CONFIDENCE
                );
            default:
                return null;
        }
    }

    /**
     * {@inheritDoc}
     */
    public function guessRequired($class, $property)
    {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public function guessMaxLength($class, $property)
    {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public function guessPattern($class, $property)
    {
        return null;
    }

    protected function getMetadata($class)
    {
        // normalize class name
        $class = ClassUtils::getRealClass(ltrim($class, '\\'));

        if (array_key_exists($class, $this->cache)) {
            return $this->cache[$class];
        }

        $this->cache[$class] = null;
        foreach ($this->registry->getManagers() as $name => $em) {
            try {
                return $this->cache[$class] = array($em->getClassMetadata($class), $name);
            } catch (MappingException $e) {
                // not an entity or mapped super class
            } catch (LegacyMappingException $e) {
                // not an entity or mapped super class, using Doctrine ORM 2.2
            }
        }
    }
}