<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 02/04/14
 */

namespace Oru\Bundle\FormBundle\Form;


class DummyFormBuilder
{
    /**
     * @var array
     */
    private $fields = array();

    /**
     * @param $name
     * @param $type
     * @param $options
     * @return $this
     */
    public function add($name, $type, $options)
    {
        $this->fields[$name] = array('type' => $type, 'options' => $options);

        return $this;
    }

    /**
     * @return array
     */
    public function getFields()
    {
        return $this->fields;
    }

    /**
     * @param $field
     * @return bool
     */
    public function hasField($field)
    {
        return (array_key_exists($field,$this->fields) !== FALSE);
    }

    /**
     * @param $field
     * @return bool
     */
    public function getField($field)
    {
        if($this->hasField($field))
            return $this->fields[$field];

        return false;
    }
} 