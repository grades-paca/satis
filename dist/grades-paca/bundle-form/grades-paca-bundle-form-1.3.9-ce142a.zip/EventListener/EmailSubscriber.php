<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\EventListener;


use Doctrine\Common\EventArgs;
use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\LifecycleEventArgs;
use Doctrine\ORM\Event\PostFlushEventArgs;
use Doctrine\ORM\Event\PreUpdateEventArgs;
use Symfony\Component\DependencyInjection\Container;

class EmailSubscriber implements EventSubscriber
{
    /**
     * @var Container
     */
    private $container;

    /**
     * @var array
     */
    private $emails;

    /**
     * EmailSubscriber constructor.
     */
    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->emails = array();
    }

    /**
     * Specifies the list of events to listen
     *
     * @return array
     */
    public function getSubscribedEvents()
    {
        return array(
            'prePersist',
            'preUpdate',
            'postFlush'
        );
    }

    /**
     * Looks for oru_email fields being initialized
     *
     * @param LifecycleEventArgs $args
     */
    public function prePersist(LifecycleEventArgs $args)
    {
        $em = $args->getEntityManager();
        $uow = $em->getUnitOfWork();
        $fields = $this->searchEmailFields($em);
        foreach($fields as $field) {
            $email = call_user_func(array($field['object'], 'get' . ucfirst($field['field'])));
            if($email) {
                $this->emails[] = $email;
            }
            
        }
    }

    /**
     * Looks for oru_email fields being updated
     *
     * @param EventArgs $args
     *
     * @return void
     */
    public function preUpdate(PreUpdateEventArgs $args)
    {
        $em = $args->getEntityManager();
        $uow = $em->getUnitOfWork();
        $fields = $this->searchEmailFields($em);
        foreach($fields as $field) {
            $email = call_user_func(array($field['object'], 'get' . ucfirst($field['field'])));
            if($email && $args->hasChangedField($field['field'])) {
                $this->emails[] = $email;
            }

        }
    }

    /**
     * Save emails notifications
     *
     * @param PostFlushEventArgs $event
     */
    public function postFlush(PostFlushEventArgs $event)
    {
        if(!empty($this->emails)) {
            foreach ($this->emails as $email) {
                $this->container->get('oru_form.email.manager')->send($email);
            }

            $this->emails = array();
        }
    }
    
    /**
     * @param \Doctrine\ORM\EntityManager $em
     * @return array
     */
    private function searchEmailFields(\Doctrine\ORM\EntityManager $em) {

        $fields = array();
        $uow = $em->getUnitOfWork();
        foreach($uow->getScheduledEntityInsertions($uow) as $object) {
            $meta = $em->getClassMetadata(get_class($object));
            foreach($this->searchEmailFieldsMetadata($meta) as $field) {
                $fields[] = array('object' => $object, 'field' => $field);
            }
        }

        foreach ($uow->getScheduledEntityUpdates($uow) as $object) {
            $meta = $em->getClassMetadata(get_class($object));
            foreach($this->searchEmailFieldsMetadata($meta) as $field) {
                $fields[] = array('object' => $object, 'field' => $field);
            }
        }
        return $fields;
    }

    /**
     * @param \Doctrine\ORM\Mapping\ClassMetadata $md
     * @return array
     */
    private function searchEmailFieldsMetadata(\Doctrine\ORM\Mapping\ClassMetadata $md)
    {
        $fields = array();
        foreach($md->getFieldNames() as $field) {
            $mapping = $md->getFieldMapping($field);
            if(isset($mapping['type']) && $mapping['type'] == 'oru_email') {
                $fields[] = $field;
            }
        }
        return $fields;
    }



}