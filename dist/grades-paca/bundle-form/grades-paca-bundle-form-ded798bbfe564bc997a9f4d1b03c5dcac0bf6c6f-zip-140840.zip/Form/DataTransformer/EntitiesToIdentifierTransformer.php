<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 31/07/14
 */

namespace Oru\Bundle\FormBundle\Form\DataTransformer;


use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\Util\Debug;
use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\Exception\TransformationFailedException;

class EntitiesToIdentifierTransformer implements DataTransformerInterface {

    private $om;
    private $entityRepository;
    private $multiple;
    private $delimiter;

    /**
     * @param ObjectManager $om
     * @param bool $multiple
     * @param string $delimiter
     */
    public function __construct(ObjectManager $om, $multiple = false, $delimiter = ',')
    {
        $this->om = $om;
        $this->multiple = $multiple;
        $this->delimiter = $delimiter;
    }

    /**
     * @param $entities
     * @return string
     */
    public function transform($entities)
    {
        if(!$this->multiple) {
            if (is_null($entities) || !is_object($entities) || !method_exists($entities, 'getId')) {
                return '';
            }

            return $entities->getId();
        } else {
            if (is_null($entities) || !(is_array($entities) || $entities instanceof \ArrayAccess)) {
                return '';
            }

            $entitiesIds = array();
            foreach($entities as $entitie)
            {
                if(!method_exists($entitie, 'getId'))
                    continue;

                $entitiesIds[] =  $entitie->getId();
            }

            return implode($this->delimiter,$entitiesIds);
        }
    }

    /**
     * @param $ids
     * @return array|object
     * @throws \Symfony\Component\Form\Exception\TransformationFailedException
     */
    public function reverseTransform($ids)
    {
        if(!$this->multiple) {
            if (is_null($ids) || $ids == '') {
                return null;
            }

            $entity = $this->om->getRepository($this->entityRepository)->find($ids);

            if (null === $entity) {
                throw new TransformationFailedException(sprintf(
                    'An entity with id "%s" does not exist!',
                    $ids
                ));
            }

            return $entity;
        } else {
            if (is_null($ids) || $ids == '') {
                return array();
            }

            $ids = explode($this->delimiter, $ids);
            if (is_null($ids) || !is_array($ids) || !count($ids)) {
                return array();
            }

            $entities = array();
            foreach($ids as $id) {
                $entity = $this->om->getRepository($this->entityRepository)->find($id);

                if (null === $entity) {
                    throw new TransformationFailedException(sprintf(
                        'An entity with id "%s" does not exist!',
                        $id
                    ));
                }

                $entities[] = $entity;
            }

            return $entities;
        }
    }

    /**
     * Set the repository in shorthand or FQN string
     * @param string $entityRepository
     */
    public function setEntityRepository($entityRepository)
    {
        $this->entityRepository = $entityRepository;
    }
}