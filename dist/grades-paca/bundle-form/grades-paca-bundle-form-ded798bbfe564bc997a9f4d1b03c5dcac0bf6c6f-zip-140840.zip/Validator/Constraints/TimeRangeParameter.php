<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 06/05/14
 */

namespace Oru\Bundle\FormBundle\Validator\Constraints;


use Symfony\Component\Validator\Constraints\Range;

class TimeRangeParameter extends TimeRange
{
    public function validatedBy()
    {
        return 'time_range_parameter';
    }
} 