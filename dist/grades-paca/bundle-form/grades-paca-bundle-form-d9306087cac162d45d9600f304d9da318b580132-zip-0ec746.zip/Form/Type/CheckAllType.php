<?php

namespace Oru\Bundle\FormBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class CheckAllType
 *
 * @package Oru\Bundle\FormBundle\Form\Type
 * @author Michaël VEROUX
 */
class CheckAllType extends AbstractType
{
    /**
     * @param OptionsResolver $resolver
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setRequired(array('type_class'));
        $resolver->setDefined('isChecked');
        $resolver->setDefault('mapped', false);
        $resolver->setDefault('is_checked', false);
        $resolver->setDefault('translation_domain', 'OruFormBundle');
        $resolver->setDefault('label', 'checkall');
    }

    /**
     * @param FormView      $view
     * @param FormInterface $form
     * @param array         $options
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        $view->vars['type_class'] = $options['type_class'];
        $view->vars['is_checked'] = $options['is_checked'] ? 'true' : 'false';
    }

    /**
     * {@inheritdoc}
     */
    public function getParent()
    {
        return 'checkbox';
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_checkall';
    }
}
