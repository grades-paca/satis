<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Validator\Constraints;


class PhoneNumber extends \Misd\PhoneNumberBundle\Validator\Constraints\PhoneNumber
{
    const SHORT_ACCEPT = 'short_accept';

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public function getType()
    {
        if (self::SHORT_ACCEPT === $this->type) {
            return $this->type;
        }

        return parent::getType();
    }
}