<?php
/**
 * Author: Michaël VEROUX
 * Date: 05/01/15
 * Time: 15:20
 */

namespace Oru\Bundle\FormBundle\Controller;

use Oru\Bundle\FormBundle\Entity\Recoverable;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class RecoverableController extends Controller
{

    public function recoverableAction(Request $request, $form, $id)
    {
        if('null' === $id)
        {
            $id = null;
        }

        $post = $request->request->all();
        if(isset($post[$form]))
        {
            $removes = array('_token', '_method');
            while($remove = array_shift($removes))
            {
                if(isset($post[$form][$remove]))
                {
                    unset($post[$form][$remove]);
                }
            }
        } else {
            throw new NotFoundHttpException();
        }

        $save = $this->getDoctrine()->getManager()->getRepository('OruFormBundle:Recoverable')->findOneBy(array(
            'professionnelId'       =>  $this->getUser()->getId(),
            'objectId'              =>  $id,
            'formName'              =>  $form,
        ));

        if(! $save instanceof Recoverable)
        {
            $save = new Recoverable();
            $save->setFormName($form);
            $save->setObjectId($id);
            $save->setProfessionnelId($this->getUser()->getId());
        }

        $save->setSerializedForm(http_build_query($post));

        $this->getDoctrine()->getManager()->persist($save);
        $this->getDoctrine()->getManager()->flush($save);

        $response = new Response();
        $response->headers->set('Content-Type', 'text/plain');

        return $response;
    }

    public function recoverableGetAction(Request $request)
    {
        $response = new Response();
        $response->headers->set('Content-Type', 'text/plain');

        if(! $request->query->get('data'))
        {
            throw new NotFoundHttpException();
        }

        $data = (array) json_decode(html_entity_decode($request->query->get('data')));

        if(! is_array($data))
        {
            return $response;
        }

        $dataPrototype = array(
            'professionnelId'       =>  null,
            'objectId'              =>  null,
            'formName'              =>  null,
        );

        $data = array_intersect_key($data, $dataPrototype);
        $data['professionnelId'] = $this->getUser()->getId(); // Sandbox

        if(3 !== count($data))
        {
            return $response;
        }

        $recover = $this->getDoctrine()->getManager()->getRepository('OruFormBundle:Recoverable')->findOneBy($data);

        if($recover instanceof Recoverable)
        {
            $response->setContent($recover->getSerializedForm());
        }

        return $response;
    }
} 