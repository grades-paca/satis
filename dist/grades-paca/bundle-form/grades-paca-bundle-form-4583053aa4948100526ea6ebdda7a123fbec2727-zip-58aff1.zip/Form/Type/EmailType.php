<?php

namespace Oru\Bundle\FormBundle\Form\Type;

use Oru\Bundle\FormBundle\Form\DataTransformer\EmailIdnTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;

/**
 * Class EmailType
 *
 * @package Oru\Bundle\FormBundle\Form\Type
 * @author Michaël VEROUX
 */
class EmailType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->addModelTransformer(new EmailIdnTransformer());
    }

    /**
     * @return string
     * @inheritdoc
     */
    public function getParent()
    {
        return 'email';
    }

    /**
     * @return string
     * @inheritdoc
     */
    public function getName()
    {
        return 'oru_email';
    }
}
