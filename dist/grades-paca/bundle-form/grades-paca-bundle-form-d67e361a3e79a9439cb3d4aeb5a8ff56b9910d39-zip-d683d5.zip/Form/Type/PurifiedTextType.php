<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 23/11/2016
 * Time: 16:52
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\DataTransformerInterface;

/**
 * Class PurifiedTextType
 * @package Oru\Bundle\FormBundle\Form\Type
 */
class PurifiedTextType extends AbstractType
{
    /**
     * @var DataTransformerInterface
     */
    private $purifierTransformer;
    
    /**
     * PurifiedTextType constructor.
     * @param DataTransformerInterface $purifierTransformer
     */
    public function __construct(DataTransformerInterface $purifierTransformer)
    {
        $this->purifierTransformer = $purifierTransformer;
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->addViewTransformer($this->purifierTransformer);
    }

    /**
     * @return string
     */
    public function getParent()
    {
        return 'textarea';
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'oru_purified_text';
    }
}