<?php
/**
 * Created by PhpStorm.
 * User: andre
 * Date: 29/01/14
 * Time: 16:08
 */

namespace Oru\Bundle\FormBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraints\Length;

/**
 * @Annotation
 */
class LengthParameter extends Length {
    public function validatedBy()
    {
        return 'length_parameter';
    }
}