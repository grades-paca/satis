<?php

namespace Oru\Bundle\FormBundle;

use Oru\Bundle\FormBundle\DependencyInjection\Compiler\FormPass;
use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class OruFormBundle extends OruBundle
{
    /**
     * @author Michaël VEROUX
     */
    public function __construct()
    {
        DynamicLoader::addYaml('@OruFormBundle/Resources/config/routing.yml');
    }

    /**
     * {@inheritdoc}
     */
    public function build(ContainerBuilder $container)
    {
        parent::build($container);
        $container->addCompilerPass(new FormPass());
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getFriendlyName()
    {
        return 'Formulaires divers';
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getDescription()
    {
        return 'Bundle qui fournit des widgets de form spécifiques à l\'ORU';
    }
}
