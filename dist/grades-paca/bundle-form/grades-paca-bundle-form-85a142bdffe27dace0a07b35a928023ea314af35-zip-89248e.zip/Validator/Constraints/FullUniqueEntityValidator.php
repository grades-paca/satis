<?php

namespace Oru\Bundle\FormBundle\Validator\Constraints;

use Doctrine\Common\Persistence\ManagerRegistry;
use Doctrine\ORM\EntityManager;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntityValidator;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\Exception\ConstraintDefinitionException;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;

/**
 * Class FullUniqueEntityValidator
 *
 * @package Oru\Bundle\FormBundle\Validator\Constraints
 * @author Michaël VEROUX
 */
class FullUniqueEntityValidator extends UniqueEntityValidator
{
    /**
     * @var ManagerRegistry
     */
    private $registry;

    /**
     * @param ManagerRegistry $registry
     */
    public function __construct(ManagerRegistry $registry)
    {
        $this->registry = $registry;

        parent::__construct($registry);
    }

    /**
     * @param object     $entity
     * @param Constraint $constraint
     *
     * @throws UnexpectedTypeException
     * @throws ConstraintDefinitionException
     */
    public function validate($entity, Constraint $constraint)
    {
        if ($constraint->em) {
            $em = $this->registry->getManager($constraint->em);

            if (!$em) {
                throw new ConstraintDefinitionException(sprintf('Object manager "%s" does not exist.', $constraint->em));
            }
        } else {
            $em = $this->registry->getManagerForClass(get_class($entity));

            if (!$em) {
                throw new ConstraintDefinitionException(sprintf('Unable to find the object manager associated with an entity of class "%s".', get_class($entity)));
            }
        }
        $this->disableSoftdeleteable($em);
        $this->disableIsValidate($em);

        parent::validate($entity, $constraint);

        $this->enableSoftdeleteable($em);
        $this->enableIsValidate($em);
    }

    /**
     * @param EntityManager $entityManager
     *
     * @author Michaël VEROUX
     */
    private function disableSoftdeleteable(EntityManager $entityManager)
    {
        if (array_key_exists('softdeleteable', $entityManager->getFilters()->getEnabledFilters())) {
            $entityManager->getFilters()->disable('softdeleteable');
        }
    }

    /**
     * @param EntityManager $entityManager
     *
     * @author Michaël VEROUX
     */
    private function enableSoftdeleteable(EntityManager $entityManager)
    {
        if ($entityManager->getFilters()->has('softdeleteable') && !$entityManager->getFilters()->isEnabled('softdeleteable')) {
            $entityManager->getFilters()->enable('softdeleteable');
        }
    }

    /**
     * @param EntityManager $entityManager
     *
     */
    private function disableIsValidate(EntityManager $entityManager)
    {
        if (array_key_exists('isValidate', $entityManager->getFilters()->getEnabledFilters())) {
            $entityManager->getFilters()->disable('isValidate');
        }
    }

    /**
     * @param EntityManager $entityManager
     *
     */
    private function enableIsValidate(EntityManager $entityManager)
    {
        if ($entityManager->getFilters()->has('isValidate') && !$entityManager->getFilters()->isEnabled('isValidate')) {
            $entityManager->getFilters()->enable('isValidate');
        }
    }
}
