<?php
/**
 * Author: Michaël VEROUX
 * Date: 05/01/15
 * Time: 15:04
 */

namespace Oru\Bundle\FormBundle\Entity;

class Recoverable
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var string
     */
    protected $serializedForm;

    /**
     * @var string
     */
    protected $formName;

    /**
     * @var int
     */
    protected $objectId;

    /**
     * @var int
     */
    protected $professionnelId;

    /**
     * @var \DateTime
     */
    protected $created;

    /**
     * @var \DateTime
     */
    protected $updated;

    /**
     * @param string $formName
     * @return $this
     */
    public function setFormName($formName)
    {
        $this->formName = $formName;

        return $this;
    }

    /**
     * @return string
     */
    public function getFormName()
    {
        return $this->formName;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $objectId
     * @return $this
     */
    public function setObjectId($objectId)
    {
        $this->objectId = $objectId;

        return $this;
    }

    /**
     * @return int
     */
    public function getObjectId()
    {
        return $this->objectId;
    }

    /**
     * @param int $professionnelId
     * @return $this
     */
    public function setProfessionnelId($professionnelId)
    {
        $this->professionnelId = $professionnelId;

        return $this;
    }

    /**
     * @return int
     */
    public function getProfessionnelId()
    {
        return $this->professionnelId;
    }

    /**
     * @param string $serializedForm
     * @return $this
     */
    public function setSerializedForm($serializedForm)
    {
        $this->serializedForm = $serializedForm;

        return $this;
    }

    /**
     * @return string
     */
    public function getSerializedForm()
    {
        return $this->serializedForm;
    }

    /**
     * @param \DateTime $created
     * @return $this
     */
    public function setCreated(\DateTime $created = null)
    {
        $this->created = $created;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param \DateTime $updated
     * @return $this
     */
    public function setUpdated(\DateTime $updated = null)
    {
        $this->updated = $updated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }
} 