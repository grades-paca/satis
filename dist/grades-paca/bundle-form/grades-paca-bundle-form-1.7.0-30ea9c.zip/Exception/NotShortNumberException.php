<?php

namespace Oru\Bundle\FormBundle\Exception;

/**
 * Class NotShortNumberException.
 *
 * @author Michaël VEROUX
 */
class NotShortNumberException extends \LengthException
{
}
