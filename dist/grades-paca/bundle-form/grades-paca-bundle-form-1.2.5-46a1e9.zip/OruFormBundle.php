<?php

namespace Oru\Bundle\FormBundle;

use Oru\Bundle\FormBundle\DependencyInjection\Compiler\FormPass;
use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class OruFormBundle extends OruBundle
{
    /**
     * {@inheritdoc}
     */
    public function build(ContainerBuilder $container)
    {
        parent::build($container);
        $container->addCompilerPass(new FormPass());
    }

    /**
     * @author Michaël VEROUX
     */
    public function boot()
    {
        $collection = $this
            ->container
            ->get('routing.loader')
            ->load(__DIR__.'/Resources/config/routing.yml')
        ;

        $this
            ->container
            ->get('router')
            ->getRouteCollection()
            ->addCollection($collection)
        ;
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getFriendlyName()
    {
        return 'Bundle Widgets Form ORU';
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    public static function getDescription()
    {
        return 'Bundle qui fournit des widgets de form spécifiques à l\'ORU';
    }
}
