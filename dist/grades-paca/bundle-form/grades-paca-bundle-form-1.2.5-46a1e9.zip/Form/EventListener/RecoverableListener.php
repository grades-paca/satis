<?php
/**
 * Author: Michaël VEROUX
 * Date: 06/01/15
 * Time: 10:03
 */

namespace Oru\Bundle\FormBundle\Form\EventListener;

use Oru\Bundle\FormBundle\Entity\Recoverable;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Doctrine\Common\Persistence\ObjectManager;

class RecoverableListener implements EventSubscriberInterface
{
    /**
     * @var TokenStorageInterface
     */
    protected $securityContext;

    /**
     * @var ObjectManager
     */
    protected $em;

    /**
     * @param TokenStorageInterface $securityContext
     * @param ObjectManager $em
     */
    public function __construct(TokenStorageInterface $securityContext, ObjectManager $em)
    {
        $this->securityContext = $securityContext;
        $this->em = $em;
    }

    public function preSetData(FormEvent $event)
    {
        $form = $event->getForm();
        $factory = $form->getConfig()->getFormFactory();
        $professionnelId = null;
        $objectId = null;
        $dataSerialized = '';

        if(
            is_object($this->securityContext->getToken())
            && is_object($this->securityContext->getToken()->getUser())
        )
        {
            $professionnelId = $this->securityContext->getToken()->getUser()->getId();
        }

        if(is_object($event->getData()) && method_exists($event->getData(), 'getId'))
        {
            $objectId = $event->getData()->getId();
        }

        if(null !== $professionnelId)
        {
            $criteria = array(
                'professionnelId'       =>  $professionnelId,
                'objectId'              =>  $objectId,
                'formName'              =>  $form->getName(),
            );

            $recover = $this->em->getRepository('OruFormBundle:Recoverable')->findOneBy($criteria);

            if($recover instanceof Recoverable)
            {
                $dataSerialized = htmlentities(json_encode($criteria));
            }
        }

        $form->add(
            $factory->createNamed('recoverable', 'oru_recoverable', null, array(
                    'auto_initialize'   => false,
                    'attr'  => array('data-prototype' => $dataSerialized),
                )
            )
        );
    }

    public static function getSubscribedEvents()
    {
        return array(
            FormEvents::PRE_SET_DATA => 'preSetData',
        );
    }
}