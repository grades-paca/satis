<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Symfony\Component\Form\AbstractType;

class EmailVerifyType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function getParent()
    {
        return EmailType::class;
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'oru_email_verify';
    }
}
