<?php
/**
 * Author: tdepreaumont
 * Date: 10/12/14
 * Time: 13:28
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Oru\Bundle\FormBundle\Form\DataTransformer\KeyValueArrayTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class PasswordStrengthType extends AbstractType
{
    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            array(
                'first_options' => array(
                    'label' => 'form.password',
                    'attr' => array('class' => 'password-strength', 'title', 'autocomplete' => 'off'),
                ),
                'second_options' => array(
                    'label' => 'form.password_confirmation',
                    'attr' => array('autocomplete' => 'off'),
                ),
                'type' => PasswordType::class,
            )
        );
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->addModelTransformer(new KeyValueArrayTransformer());
    }

    public function getParent()
    {
        return RepeatedType::class;
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_password_strength';
    }
}
