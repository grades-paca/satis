<?php

namespace Oru\Bundle\FormBundle\Tool;

use libphonenumber\PhoneNumber;
use Oru\Bundle\FormBundle\Exception\NotShortNumberException;

/**
 * Class ShortNumberTool.
 *
 * @author Michaël VEROUX
 */
class ShortNumberTool
{
    public static $short_2_3 = array(
        '15',
        '17',
        '18',
        '110',
        '112',
        '115',
        '119',
    );

    /**
     * @param PhoneNumber $phoneNumber
     *
     * @throws NotShortNumberException
     *
     * @return null|string
     *
     * @author Michaël VEROUX
     */
    public static function getShortNumber(PhoneNumber $phoneNumber)
    {
        if (self::isShort($phoneNumber->getNationalNumber())) {
            return $phoneNumber->getNationalNumber();
        }

        throw new NotShortNumberException('Number is not a short one!');
    }

    /**
     * @param string $string
     *
     * @throws NotShortNumberException
     *
     * @return PhoneNumber
     *
     * @author Michaël VEROUX
     */
    public static function getPhoneNumber($string)
    {
        $string = preg_replace('#[^0-9]#', '', $string);

        if (self::isShort($string)) {
            $phoneNumber = new PhoneNumber();
            $phoneNumber->setNationalNumber($string);

            return $phoneNumber;
        }

        throw new NotShortNumberException('Number is not a short one!');
    }

    /**
     * @param string $number
     *
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public static function isShort($number)
    {
        if (preg_match('/^([0-9]{2,5})$/', $number)) {
            if (3 >= strlen($number) && !in_array($number, self::$short_2_3, true)) {
                return false;
            }

            return true;
        }

        return false;
    }
}
