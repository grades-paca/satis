<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 31/07/14
 */

namespace Oru\Bundle\FormBundle\Form\Type;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

abstract class AutocompleteType extends AbstractType  {

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefined(array( 'results', 'infinite_scroll', 'minimum', 'allow_clear', 'placeholder'));
        $resolver->setDefaults(array('results' => 10, 'infinite_scroll' => true, 'minimum' => 3, 'placeholder' => 'Chercher'));
        $resolver->setRequired(array('class'));
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        parent::buildView($view, $form, $options);

        $view->vars['multiple'] = ($options['multiple']) ? true : false;
        $view->vars['allow_clear'] = ($options['required']) ? 'false' : 'true';
        $view->vars['results'] = $options['results'];
        $view->vars['infinite_scroll'] = ($options['infinite_scroll']) ? 'true' : 'false';
        $view->vars['minimum'] = $options['minimum'];
        $view->vars['placeholder'] = $options['placeholder'];
    }

    /**
     * @return string
     */
    public function getParent()
    {
        return 'oru_text_entities';
    }

} 