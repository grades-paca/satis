<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Validator\Constraints;


use Symfony\Component\Validator\Constraint;

class Siren extends Constraint
{
    public $message = "La chaîne {{ value }} n'est pas un SIREN valide.";
    public $charset = 'UTF-8';

    public function validatedBy()
    {
        return get_class($this).'Validator';
    }
}