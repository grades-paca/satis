<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 06/05/14
 */

namespace Oru\Bundle\FormBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\Constraints\TimeValidator;
use Symfony\Component\Validator\ConstraintValidator;

class TimeRangeValidator extends ConstraintValidator
{
    /**
     * {@inheritdoc}
     */
    public function validate($value, Constraint $constraint)
    {
        if (null === $value || '' === $value) {
            return;
        }

        if ($value instanceof \DateTime) {
            $value = $value->format('H:i:s');
        }

        if (
            $this->validateTime($value, $constraint->timeMessage)
            && $this->validateTime($constraint->min, $constraint->constraintMessage)
            && $this->validateTime($constraint->max, $constraint->constraintMessage)
        ) {
            if (null !== $constraint->max && $value > $constraint->max) {
                $this->context->addViolation($constraint->maxMessage, array(
                    '{{ value }}' => $value,
                    '{{ limit }}' => $constraint->max,
                ));

                return;
            }

            if (null !== $constraint->min && $value < $constraint->min) {
                $this->context->addViolation($constraint->minMessage, array(
                    '{{ value }}' => $value,
                    '{{ limit }}' => $constraint->min,
                ));
            }
        }
    }

    public function validateTime($value, $message)
    {
        if (null === $value || '' === $value || $value instanceof \DateTime) {
            return true;
        }

        if (!is_scalar($value) && !(is_object($value) && method_exists($value, '__toString'))) {
            throw new UnexpectedTypeException($value, 'string');
        }

        $value = (string) $value;

        if (!preg_match(TimeValidator::PATTERN, $value, $matches)) {
            $this->context->addViolation($message, array('{{ value }}' => $value));

            return false;
        }

        return true;
    }

    public function getTimeFromDateTime(\DateTime $dateTime)
    {
        $str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", '00:$1:$2', $dateTime);
        sscanf($str_time, '%d:%d:%d', $hours, $minutes, $seconds);

        return $hours * 3600 + $minutes * 60 + $seconds;
    }
}
