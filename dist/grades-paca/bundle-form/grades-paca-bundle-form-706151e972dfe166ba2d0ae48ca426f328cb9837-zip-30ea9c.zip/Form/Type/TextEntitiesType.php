<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 25/03/14
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class HiddenEntityType.
 *
 * Render an entity as a text field using the identifier field "id"
 * transformed using the Entity to Int transformer
 */
class TextEntitiesType extends AbstractType
{
    /**
     * @var ObjectManager
     */
    private $om;

    /**
     * @param ObjectManager $om
     */
    public function __construct(ObjectManager $om)
    {
        $this->om = $om;
    }

    /**
     * Add the data transformer to the field setting the entity repository.
     *
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $entityTransformer = new $options['transformer']($this->om, $options['multiple'], $options['delimiter']);
        $entityTransformer->setEntityRepository($options['class']);
        $builder->addViewTransformer($entityTransformer);
    }

    /**
     * Require the entity repository option to be set on the field.
     *
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => null,
            'transformer' => 'Oru\Bundle\FormBundle\Form\DataTransformer\EntitiesToIdentifierTransformer',
            'multiple' => false,
            'delimiter' => ',',
            'attr' => array('style' => 'visibility: hidden;'),
        ));
        $resolver->setRequired(
            array(
                'class',
            )
        );
        $resolver->setDefined(
            array(
                'multiple',
                'delimiter',
            )
        );
    }

    /**
     * Set the parent form type to hidden.
     *
     * @return string
     */
    public function getParent()
    {
        return TextType::class;
    }

    /**
     * @return string
     */
    public function getBlockPrefix()
    {
        return 'oru_text_entities';
    }
}
