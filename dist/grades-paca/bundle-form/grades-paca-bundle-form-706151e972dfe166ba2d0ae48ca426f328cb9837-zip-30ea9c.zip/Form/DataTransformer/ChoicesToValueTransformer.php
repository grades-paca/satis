<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 21/01/14
 * Time: 15:55
 */

namespace Oru\Bundle\FormBundle\Form\DataTransformer;

use Symfony\Component\Form\ChoiceList\ChoiceListInterface;
use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\Exception\TransformationFailedException;

class ChoicesToValueTransformer implements DataTransformerInterface
{
    private $choiceList;

    /**
     * Constructor.
     *
     * @param ChoiceListInterface $choiceList
     */
    public function __construct(ChoiceListInterface $choiceList)
    {
        $this->choiceList = $choiceList;
    }

    /**
     * @param string $array
     *
     * @throws TransformationFailedException if the given value is not an array
     *
     * @return array
     */
    public function transform($array)
    {
        if (null === $array) {
            return array();
        }

        if (!is_string($array)) {
            throw new TransformationFailedException('Expected a string.');
        }

        return $this->choiceList->getValuesForChoices(explode("\n", $array));
    }

    /**
     * @param array $array
     *
     * @throws TransformationFailedException if the given value is not an array
     *                                       or if no matching choice could be
     *                                       found for some given value
     *
     * @return array
     */
    public function reverseTransform($array)
    {
        if (null === $array) {
            return '';
        }

        if (!is_array($array)) {
            throw new TransformationFailedException('Expected an array.');
        }

        $choices = $this->choiceList->getChoicesForValues($array);

        if (count($choices) !== count($array)) {
            throw new TransformationFailedException('Could not find all matching choices for the given values');
        }

        return implode("\n", $choices);
    }
}
