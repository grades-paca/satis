<?php
/**
 * Author: tdepreau
 * Date: 10/12/14
 * Time: 15:34
 */

namespace Oru\Bundle\FormBundle\Form\DataTransformer;

use Oru\Bundle\FormBundle\Model\KeyValueArray;
use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\Exception\TransformationFailedException;

class KeyValueArrayTransformer implements DataTransformerInterface
{

    public function transform($value)
    {
        if(empty($value)) {
            return null;
        }
        if(is_array($value))
        {
            foreach($value as $k => &$v)
            {
                if(! $v instanceof KeyValueArray)
                    $v = new KeyValueArray($k, $v);
            }
        }
        else{
            return (array)$value;
        }
        return $value;
    }

    public function reverseTransform($value)
    {
        if('' === $value)
            return null;

        if(is_array($value))
        {
            if(empty($value)) {
                return null;
            }

            $expectedArray = array();
            foreach($value as $k => $v)
            {
                if($v instanceof KeyValueArray)
                    $expectedArray[$v->getKey()] = (string)$v;
                else
                    $expectedArray[] = (string)$v;
            }
            $value = $expectedArray;
        }

        return $value;
    }
}