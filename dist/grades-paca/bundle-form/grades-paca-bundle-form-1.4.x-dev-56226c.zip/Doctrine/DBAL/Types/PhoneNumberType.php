<?php

/*
 * André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\Doctrine\DBAL\Types;

use Doctrine\DBAL\Platforms\AbstractPlatform;
use Doctrine\DBAL\Types\ConversionException;
use libphonenumber\PhoneNumber;
use Oru\Bundle\FormBundle\Exception\NotShortNumberException;
use Oru\Bundle\FormBundle\Tool\ShortNumberTool;

/**
 * Phone number Doctrine mapping type.
 */
class PhoneNumberType extends \Misd\PhoneNumberBundle\Doctrine\DBAL\Types\PhoneNumberType
{
    /**
     * Phone number type name.
     */
    const NAME = 'phone_number';

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return self::NAME;
    }

    /**
     * {@inheritdoc}
     */
    public function getSQLDeclaration(array $fieldDeclaration, AbstractPlatform $platform)
    {
        return $platform->getVarcharTypeDeclarationSQL(array('length' => 35));
    }

    /**
     * {@inheritdoc}
     */
    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
        if (null === $value) {
            return null;
        } elseif (false === $value instanceof PhoneNumber) {
            throw new ConversionException('Expected \libphonenumber\PhoneNumber, got ' . gettype($value));
        }

        try {
            return ShortNumberTool::getShortNumber($value);
        } catch (NotShortNumberException $e) {
            // Is not a short one...
        }

        return parent::convertToDatabaseValue($value, $platform);
    }

    /**
     * {@inheritdoc}
     */
    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        if (null === $value) {
            return null;
        }

        try {
            return ShortNumberTool::getPhoneNumber($value);
        } catch (NotShortNumberException $e) {
            // Is not a short one...
        }

        return parent::convertToPHPValue($value, $platform);
    }

    /**
     * {@inheritdoc}
     */
    public function requiresSQLCommentHint(AbstractPlatform $platform)
    {
        return true;
    }
}
