<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 06/05/14
 */

namespace Oru\Bundle\FormBundle\Validator\Constraints;


use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\Validator\Constraint;

class TimeRangeValidatorParameter extends TimeRangeValidator
{
    private $container;

    public function setContainer(Container $container) {
        $this->container = $container;
    }

    /**
     * {@inheritDoc}
     */
    public function validate($value, Constraint $constraint)
    {
        if (null === $value) {
            return;
        }

        if($constraint->min != null && $constraint->min != '')
            $constraint->min = $this->container->getParameter($constraint->min);

        if($constraint->max != null && $constraint->max != '')
            $constraint->max = $this->container->getParameter($constraint->max);

        parent::validate($value, $constraint);
    }
} 