<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 26/06/2017
 * Time: 15:14
 */

namespace Oru\Bundle\FormBundle\Form\Dummy;

/**
 * Class DummyFormDescriptionBuilder.
 */
class DummyFormDescriptionBuilder extends DummyFormBuilder
{
    /**
     * @var array
     */
    private $deniedFields = array();

    /**
     * @param bool        $bool
     * @param string      $name
     * @param null|string $type
     * @param array       $options
     *
     * @return $this
     */
    public function addConditional($bool, $name, $type = null, $options = array())
    {
        if ($bool) {
            $this->add($name, $type, $options);
        } else {
            $this->deny($name);
        }

        return $this;
    }

    /**
     * @param string $name
     */
    public function deny($name)
    {
        if (!in_array($name, $this->deniedFields)) {
            $this->deniedFields[] = $name;
        }
    }

    /**
     * @return array
     */
    public function getDeniedFields()
    {
        return $this->deniedFields;
    }
}