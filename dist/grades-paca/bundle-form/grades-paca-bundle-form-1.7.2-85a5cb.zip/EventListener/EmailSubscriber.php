<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\FormBundle\EventListener;

use Doctrine\Common\EventArgs;
use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\OnFlushEventArgs;
use Doctrine\ORM\Event\PostFlushEventArgs;
use Oru\Bundle\FormBundle\Event\EmailVerifyEvent;
use Oru\Bundle\FormBundle\Event\OruFormEvents;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Security\Acl\Util\ClassUtils;

class EmailSubscriber implements EventSubscriber
{
    /**
     * @var ContainerInterface
     */
    private $container;

    /**
     * @var array
     */
    private $emails;

    /**
     * EmailSubscriber constructor.
     */
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
        $this->emails = array();
    }

    /**
     * Specifies the list of events to listen.
     *
     * @return array
     */
    public function getSubscribedEvents()
    {
        return array(
            'onFlush',
            'postFlush',
        );
    }

    /**
     * Looks for oru_email_verify fields being updated.
     *
     * @param EventArgs $args
     */
    public function onFlush(OnFlushEventArgs $args)
    {
        $em = $args->getEntityManager();
        $uow = $em->getUnitOfWork();
        $fields = $this->searchEmailFields($em);
        $dispatcher = $this->container->get('event_dispatcher');
        foreach ($fields as $field) {
            foreach ($uow->getScheduledEntityInsertions() as $entity) {
                $event = new EmailVerifyEvent($entity);
                $dispatcher->dispatch(OruFormEvents::EMAIL_CONFIRMATION_SEND, $event);
                if (!$event->isEnabled()) {
                    continue;
                }
                if (ClassUtils::getRealClass($entity) === $field['class']) {
                    $changes = $uow->getEntityChangeSet($entity);
                    if (isset($changes[$field['field']]) && isset($changes[$field['field']][1]) && strpos($changes[$field['field']][1], '@')) {
                        if (!in_array($changes[$field['field']], $this->emails, true)) {
                            $this->emails[] = $changes[$field['field']][1];
                        }
                    }
                }
            }
            foreach ($uow->getScheduledEntityUpdates() as $entity) {
                $event = new EmailVerifyEvent($entity);
                $dispatcher->dispatch(OruFormEvents::EMAIL_CONFIRMATION_SEND, $event);
                if (!$event->isEnabled()) {
                    continue;
                }
                if (ClassUtils::getRealClass($entity) === $field['class']) {
                    $changes = $uow->getEntityChangeSet($entity);
                    if (isset($changes[$field['field']]) && isset($changes[$field['field']][1]) && strpos($changes[$field['field']][1], '@')) {
                        if (!in_array($changes[$field['field']], $this->emails, true)) {
                            $this->emails[] = $changes[$field['field']][1];
                        }
                    }
                }
            }
        }
    }

    /**
     * Save emails notifications.
     *
     * @param PostFlushEventArgs $event
     */
    public function postFlush(PostFlushEventArgs $event)
    {
        if (!empty($this->emails)) {
            foreach ($this->emails as $email) {
                $this->container->get('oru_form.email.manager')->send($email);
            }

            $this->emails = array();
        }
    }

    /**
     * @param \Doctrine\ORM\EntityManager $em
     *
     * @return array
     */
    private function searchEmailFields(\Doctrine\ORM\EntityManager $em)
    {
        $fields = array();
        $uow = $em->getUnitOfWork();
        foreach ($uow->getScheduledEntityInsertions($uow) as $object) {
            $meta = $em->getClassMetadata(ClassUtils::getRealClass($object));
            foreach ($this->searchEmailFieldsMetadata($meta) as $field) {
                $fields[] = array('class' => ClassUtils::getRealClass($object), 'field' => $field);
            }
        }

        foreach ($uow->getScheduledEntityUpdates($uow) as $object) {
            $meta = $em->getClassMetadata(ClassUtils::getRealClass($object));
            foreach ($this->searchEmailFieldsMetadata($meta) as $field) {
                $fields[] = array('class' => ClassUtils::getRealClass($object), 'field' => $field);
            }
        }

        return array_map('unserialize', array_unique(array_map('serialize', $fields)));
    }

    /**
     * @param \Doctrine\ORM\Mapping\ClassMetadata $md
     *
     * @return array
     */
    private function searchEmailFieldsMetadata(\Doctrine\ORM\Mapping\ClassMetadata $md)
    {
        $fields = array();
        foreach ($md->getFieldNames() as $field) {
            $mapping = $md->getFieldMapping($field);
            if (isset($mapping['type']) && $mapping['type'] === 'oru_email_verify') {
                $fields[] = $field;
            }
        }

        return $fields;
    }
}
