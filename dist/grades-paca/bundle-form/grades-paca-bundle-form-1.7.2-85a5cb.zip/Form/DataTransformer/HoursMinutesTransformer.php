<?php

namespace Oru\Bundle\FormBundle\Form\DataTransformer;

use Symfony\Component\Form\DataTransformerInterface;

class HoursMinutesTransformer implements DataTransformerInterface
{
    /**
     * {@inheritdoc}
     */
    public function transform($value)
    {
        if (!$value) {
            return;
        } elseif ($value === 0) {
            return 0;
        }

        $hours = floor($value / 60);
        $minutes = ($value % 60);

        if ($hours < 10) {
            $hours = '0'.$hours;
        }
        if ($minutes < 10) {
            $minutes = '0'.$minutes;
        }

        return array('hours' => $hours, 'minutes' => $minutes);
    }

    /**
     * {@inheritdoc}
     */
    public function reverseTransform($array)
    {
        try {
            $minutes = (int) ($array['hours']) * 60 + (int) ($array['minutes']);

            return $minutes;
        } catch (\Exception $e) {
            return null;
        }
    }
}
