<?php
/**
 * Author: tdepreaumont
 * Date: 10/12/14
 * Time: 13:28
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use libphonenumber\PhoneNumberFormat;
use Oru\Bundle\FormBundle\Form\DataTransformer\PhoneNumberToArrayTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class TelType.
 */
class TelType extends AbstractType
{
    /**
     * @var
     */
    private $defaultIndicatif;

    /**
     * @var
     */
    private $phoneNumberFormat;

    /**
     * @param $defaultIndicatif
     * @param $setting
     */
    public function __construct($defaultIndicatif, $setting)
    {
        $this->defaultIndicatif = $defaultIndicatif;
        if ($setting->setting('tel_format', 'OruRorDesignBundle') === 'NATIONAL') {
            $this->phoneNumberFormat = PhoneNumberFormat::NATIONAL;
        } else {
            $this->phoneNumberFormat = PhoneNumberFormat::INTERNATIONAL;
        }
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $class = null;
        if (isset($options['attr']['class'])) {
            $class = $options['attr']['class'];
            unset($options['attr']['class']);
        }
        $builder->add('indicatif', TextType::class, array(
            'attr' => array_merge(array('class' => 'form_indicatif '.$class), $options['attr']), //Peut changer le comportement dans les fichiers show.js (plancBlanc/Bleu, cruqpc)
            'required' => true,
        ))
        ->add('phone', TextType::class, array(
            'error_bubbling' => false,
            'error_mapping' => true,
            'attr' => array_merge(array('class' => 'form_compound_tel phone_number '.$class), $options['attr']), //Peut changer le comportement dans les fichiers show.js (plancBlanc/Bleu, cruqpc)
            'required' => true,
        ));

        $builder->addViewTransformer(
            new PhoneNumberToArrayTransformer($options['default_region'], $options['format'])
        );
    }

    /**
     * {@inheritdoc}
     */
    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        $view->vars['type'] = 'phone';
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            array(
                'compound' => true,
                'default_region' => $this->defaultIndicatif,
                'format' => $this->phoneNumberFormat,
                //todo rajouter un service pour récupérer le paramètre
                'invalid_message' => 'Ce numéro de téléphone n\'est pas correct.',
            )
        );
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_tel';
    }
}
