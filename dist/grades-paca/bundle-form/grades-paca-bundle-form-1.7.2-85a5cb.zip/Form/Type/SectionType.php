<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 23/01/14
 * Time: 14:59
 */

namespace Oru\Bundle\FormBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\OptionsResolver\Options;
use Symfony\Component\OptionsResolver\OptionsResolver;

class SectionType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'mapped' => false,
            'attr' => function (Options $options, $previousValue) {
                $class = 'form_section';

                if (!isset($previousValue['class'])) {
                    $previousValue['class'] = $class;
                } else {
                    $previousValue['class'] .= ' '.$class;
                }

                return $previousValue;
            },
            'required' => false,
        ));
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getBlockPrefix()
    {
        return 'oru_section';
    }
}
