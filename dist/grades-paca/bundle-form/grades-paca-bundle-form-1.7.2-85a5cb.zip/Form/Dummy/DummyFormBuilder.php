<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 02/04/14
 */

namespace Oru\Bundle\FormBundle\Form\Dummy;

/**
 * Class DummyFormBuilder.
 */
class DummyFormBuilder
{
    /**
     * @var array
     */
    private $fields = array();

    /**
     * @param string $name
     * @param string $type
     * @param array  $options
     *
     * @return $this
     */
    public function add($name, $type = null, $options = array())
    {
        $this->fields[$name] = array('type' => $type, 'options' => $options);

        return $this;
    }

    /**
     * @return array
     */
    public function getFields()
    {
        return $this->fields;
    }

    /**
     * @param string $field
     *
     * @return bool
     */
    public function getField($field)
    {
        if ($this->has($field)) {
            return $this->fields[$field];
        }

        return false;
    }

    /**
     * @param string $field
     *
     * @return bool
     */
    public function has($field)
    {
        return array_key_exists($field, $this->fields) !== false;
    }

    /**
     * @param string $key
     */
    public function remove($key)
    {
        unset($this->fields[$key]);

        return $this;
    }
}
