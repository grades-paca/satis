<?php
/**
 * Author: Michaël VEROUX
 * Date: 28/05/14
 * Time: 15:22
 */

namespace Oru\Bundle\JqueryMaskBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruJqueryMaskBundle extends Bundle
{
}
