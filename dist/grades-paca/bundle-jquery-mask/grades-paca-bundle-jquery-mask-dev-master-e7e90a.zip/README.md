Bundle JqueryMaskBundle
=======================

Installation
------------

Dans le AppKernel.php, activer ce bundle

    $bundles[] = new Oru\Bundle\JqueryMaskBundle\OruJqueryMaskBundle();

Vider le cache de Symfony

Description
-----------

Ce bundle intègre la librairie JqueryMask dans Symfony. Pour son bon fonctionnement, il faut installer les assets à l'aide liens symboliques.
