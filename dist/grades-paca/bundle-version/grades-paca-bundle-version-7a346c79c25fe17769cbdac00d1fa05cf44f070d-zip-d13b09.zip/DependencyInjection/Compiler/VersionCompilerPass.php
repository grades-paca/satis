<?php
/**
 * Author: Michaël VEROUX
 * Date: 03/09/15
 * Time: 16:14
 */

namespace Oru\Bundle\VersionBundle\DependencyInjection\Compiler;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\KernelInterface;
use TQ\Git\Repository\Repository;

class VersionCompilerPass implements CompilerPassInterface
{
    /**
     * @var KernelInterface
     */
    protected $kernel;

    /**
     * VersionCompilerPass constructor.
     *
     * @param KernelInterface $kernel
     */
    public function __construct(KernelInterface $kernel)
    {
        $this->kernel = $kernel;
    }

    /**
     * You can modify the container here before it is dumped to PHP code.
     *
     * @param ContainerBuilder $container
     *
     * @api
     */
    public function process(ContainerBuilder $container)
    {
        try {
            $git = Repository::open($this->kernel->getRootDir());
            $describe = $git->getGit()->{'describe'}($git->getRepositoryPath(), array('--tags'));

            $container->setParameter('ror_version', $describe->getStdOut());

            if ($container->hasDefinition('assets._version__default')) {
                $assetDef = $container->getDefinition('assets._version__default');
                if ('dynamic' === $assetDef->getArgument(0)) {
                    $assetDef->replaceArgument(0, $container->getParameter('ror_version'));
                }
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }
}
