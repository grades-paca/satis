<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Entity;

class GitCommitBranch
{
    /**
     * @var string
     */
    private $commitId;

    /**
     * @var string
     */
    private $branch;

    /**
     * @var int
     */
    private $id;

    /**
     * Set commitId.
     *
     * @param string $commitId
     *
     * @return GitCommitBranch
     */
    public function setCommitId($commitId)
    {
        $this->commitId = $commitId;

        return $this;
    }

    /**
     * Get commitId.
     *
     * @return string
     */
    public function getCommitId()
    {
        return $this->commitId;
    }

    /**
     * Set branch.
     *
     * @param string $branch
     *
     * @return GitCommitBranch
     */
    public function setBranch($branch)
    {
        $this->branch = $branch;

        return $this;
    }

    /**
     * Get branch.
     *
     * @return string
     */
    public function getBranch()
    {
        return $this->branch;
    }

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }
}
