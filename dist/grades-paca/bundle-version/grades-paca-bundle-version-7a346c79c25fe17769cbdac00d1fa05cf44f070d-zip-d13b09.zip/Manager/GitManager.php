<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Manager;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\VersionBundle\Entity\GitCommitBranch;
use Symfony\Component\HttpKernel\Kernel;
use TQ\Git\Repository\Repository;

class GitManager
{
    const FIRST_VERSION = '2015-03-09 13:00:00';

    /**
     * @var Repository
     */
    private $git;

    /**
     * @var string
     */
    private $currentBranch;

    /**
     * @var string
     */
    private $currentVersion;

    /**
     * @var string
     */
    private $lastVersion;

    /**
     * @var array
     */
    private $branches;

    /**
     * @var EntityManager
     */
    private $em;

    /**
     * @var array
     */
    private $acceptedBranches = "/^[a-z]*-?[0-9]{1,3}\.[0-9]{1,3}\.?[0-9]{0,3}$/";

    /**
     * @param Kernel $kernel
     */
    public function __construct(Kernel $kernel, EntityManager $entityManager)
    {
        $this->git = Repository::open($kernel->getRootDir());
        $this->em = $entityManager;

        // versions
        $this->lastVersion = $this->getLastVersion();
        $this->currentVersion = $this->getCurrentVersion();

        // branches
        $this->branches = $this->getBranches();
        $this->currentBranch = $this->getCurrentBranch();
    }

    /**
     * Retourne la liste des commit par version et branche.
     *
     * @param null       $masterVersion
     * @param null|mixed $branch
     */
    public function getCommitsByBranchesVersions($branch = null)
    {
        $commits = $this->getLog();
        $currentVersion = array();
        $changementsVersion = $this->getChangementVersion();
        $commitsByVersion = array();

        foreach ($this->getFullLog() as $commit => $log) {
            // ce commit est-il lié à un nouveau tag
            $version = array_search($commit, $changementsVersion, true);
            if ($version !== false) {
                $currentVersion[$this->getBranchFromVersion($version)] = $version;
            }
            if (array_search($commit, array_keys($commits), true) !== false) {
                $tmp = $this->getCommitFirstBranch($commit);
                $firstBranch = ($tmp) ? $tmp : $this->currentBranch;
                if (!isset($commitsByVersion[$firstBranch])) {
                    $commitsByVersion[$firstBranch] = array();
                }

                if (!$branch || $branch === $firstBranch) {
                    if (!isset($currentVersion[$firstBranch])) {
                        $currentVersion[$firstBranch] = $this->getCurrentVersion($firstBranch);
                    }
                    $commitsByVersion[$firstBranch][$currentVersion[$firstBranch]][$commit] = $log;
                }
            }
        }

        krsort($commitsByVersion);

        return $commitsByVersion;
    }

    /**
     * Retourne la version courante du ROR : git describe.
     *
     * @param null|mixed $branch
     *
     * @return string Version courante
     */
    public function getCurrentVersion($branch = null)
    {
        if (!$branch) {
            $branch = $this->getBranchFromVersion($this->lastVersion);
        }
        $result = $this->git->getGit()->{'describe'}($this->git->getRepositoryPath(), array('--tags', '--match' => "$branch*"));

        return $result->getStdOut();
    }

    /**
     * Retourne la branche courante.
     *
     * @return string Branche courante
     */
    public function getCurrentBranch()
    {
        $result = $this->git->getGit()->{'rev-parse'}($this->git->getRepositoryPath(), array('HEAD'));
        $commit = $result->getStdOut();
        $branch = $this->getCommitFirstBranch($commit);

        return $this->translateBranches($branch);
    }

    /**
     * Purge le cache des commits en base.
     *
     * @throws \Doctrine\DBAL\ConnectionException
     * @throws \Doctrine\DBAL\DBALException
     */
    public function purge()
    {
        $cmd = $this->em->getClassMetadata('OruVersionBundle:GitCommitBranch');
        $connection = $this->em->getConnection();
        $connection->beginTransaction();
        $connection->query('DELETE FROM '.$cmd->getTableName());
        $connection->query('ALTER TABLE '.$cmd->getTableName().' AUTO_INCREMENT = 1');
        $connection->commit();
    }

    /**
     * Liste des commits en excluant les commits de merge.
     *
     * @return array
     */
    private function getLog()
    {
        $gitShortCommits = $gitCommitsByVersion = array();
        $results = $this->git->getGit()->{'log'}($this->git->getRepositoryPath(), array(
            '--pretty' => 'format:%h - %an, %ar : %s',
            '--since' => self::FIRST_VERSION,
            '--no-merges',
        ));

        foreach (explode("\n", $results->getStdOut()) as $oneLine) {
            if (preg_match('/^([a-z0-9]*) .*/i', $oneLine, $matches) !== false) {
                $gitShortCommits[$matches[1]] = $oneLine;
            }
        }

        return $gitShortCommits;
    }

    /**
     * Liste des commits.
     *
     * @return array
     */
    private function getFullLog()
    {
        $gitShortCommits = $gitCommitsByVersion = array();
        $results = $this->git->getGit()->{'log'}($this->git->getRepositoryPath(), array(
            '--pretty' => 'format:%h - %an, %ar : %s',
            '--since' => self::FIRST_VERSION,
        ));

        foreach (explode("\n", $results->getStdOut()) as $oneLine) {
            if (preg_match('/^([a-z0-9]*) .*/i', $oneLine, $matches) !== false) {
                $gitShortCommits[$matches[1]] = $oneLine;
            }
        }

        return $gitShortCommits;
    }

    /**
     * Liste des branches.
     *
     * @return array
     */
    private function getBranches()
    {
        $branches = array();
        $results = $this->git->getGit()->{'for-each-ref'}($this->git->getRepositoryPath(), array(
            '--format' => '%(refname:short)',
            'refs/tags/',
        ));

        foreach (explode("\n", $results->getStdOut()) as $oneLine) {
            if (preg_match($this->acceptedBranches, $oneLine)) {
                if (strpos($oneLine, '-') !== false) {
                    $list = preg_split('/-/', $oneLine);
                    if (isset($list[0]) && array_search("$list[0]", $branches, true) === false) {
                        $branches[] = "$list[0]";
                    }
                } else {
                    $list = preg_split('/\./', $oneLine);
                    if (isset($list[0]) && isset($list[1]) && array_search("$list[0].$list[1]", $branches, true) === false) {
                        $branches[] = "$list[0].$list[1]";
                    }
                }
            }
        }

        return $branches;
    }

    /**
     * Liste des commits correspondants à une nouvelle version.
     *
     * @return array
     */
    private function getChangementVersion()
    {
        $shortCommits = array();
        $results = $this->git->getGit()->{'for-each-ref'}($this->git->getRepositoryPath(), array(
            '--format' => '%(objectname:short) %(refname:short)',
            'refs/tags/',
        ));

        foreach (explode("\n", $results->getStdOut()) as $oneLine) {
            list($commit, $version) = preg_split('/ /', $oneLine);
            $shortCommits[$version] = $commit;
        }

        return $shortCommits;
    }

    /**
     * Récupère la branche d'origine d'un commit.
     *
     * @param $commit
     *
     * @return string
     */
    private function getCommitFirstBranch($commit)
    {
        $gitCommitBranch = $this->em->getRepository('OruVersionBundle:GitCommitBranch')->findOneByCommitId($commit);
        if ($gitCommitBranch) {
            return $gitCommitBranch->getBranch();
        }
        $branchesToCheck = $matches = array();
        $result = $this->git->getGit()->{'branch'}($this->git->getRepositoryPath(), array('-a', '--contains', "$commit"));
        $branches = explode("\n", $result->getStdOut());
        foreach ($branches as $key => $value) {
            if (preg_match("/[*\ ]*remotes\/origin\/([a-z0-9\-\.]*).*/", $value, $matches) !== false) {
                if (isset($matches[1])) {
                    $branchesToCheck[] = $this->translateBranches($matches[1]);
                }
            }
        }

        foreach ($this->branches as $version) {
            if (array_search($version, $branchesToCheck, true) !== false) {
                $gitCommitBranch = new GitCommitBranch();
                $gitCommitBranch->setCommitId($commit);
                $gitCommitBranch->setBranch($version);
                $this->em->persist($gitCommitBranch);
                $this->em->flush();

                return $version;
            }
        }

        return false;
    }

    /**
     * Retourne la branche d'une version.
     *
     * @param $version
     *
     * @return string
     */
    private function getBranchFromVersion($version)
    {
        if (strpos($version, '-') !== false) {
            $list = preg_split('/-/', $version);

            return "$list[0]";
        }
        $list = preg_split('/\./', $version);
        if (isset($list[0]) && isset($list[1])) {
            return "$list[0].$list[1]";
        }

        return false;
    }

    /**
     * Traduire les branches (pour l'instant master).
     *
     * @param $branch
     *
     * @return string
     */
    private function translateBranches($branch)
    {
        if ($branch === 'master' || !preg_match($this->acceptedBranches, $branch)) {
            return $this->getBranchFromVersion($this->currentVersion);
        }

        return $branch;
    }

    /**
     * Retourne la dernière version publiée sur la branche courante.
     */
    private function getLastVersion()
    {
        $results = $this->git->getGit()->{'for-each-ref'}($this->git->getRepositoryPath(), array(
            '--format' => '%(refname:short)',
            '--sort' => '-authordate',
            'refs/tags/',
        ));

        $tags = explode("\n", $results->getStdOut());
        foreach ($tags as $tag) {
            if ($this->getCurrentVersion($this->getBranchFromVersion($tag)) !== '') {
                return $tag;
            }
        }

        return false;
    }
}
