<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Command;

use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class CheckVersionCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this
            ->setName('oru:version:check')
            ->setDescription('Install current version')
        ;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $context = $this->getContainer()->get('router')->getContext();
        $context->setHost($this->getContainer()->getParameter('router.request_context.host'));
        $context->setScheme($this->getContainer()->getParameter('router.request_context.scheme'));
        $context->setBaseUrl($this->getContainer()->getParameter('router.request_context.base_url'));

        $this->getContainer()->get('oru_version.manager')->getLogs($this->getContainer()->get('oru_version.manager')->getCurrentMasterVersion());
        $output->writeln('Changelog mis à jour.');
        $version = $this->getContainer()->get('oru_version.manager')->updateCurrentVersion();
        if ($version) {
            $output->writeln("Nouvelle version {$version->getNumber()} installée.");
        }
    }

    /**
     * Doit renvoyer le nombre de secondes d'exécution acceptable avant que le gestionnaire de taches ne tue le processus
     * 0 si pas de limite
     * @return integer
     **/
    public function getMaxRunningTimeSec()
    {
        return 0;
    }

    /**
     * Doit renvoyer un booleen signalant si la tache accepte d'être exécutée en parallèle avec d'autres taches issus de la même commande
     * @return bool
     */
    public function isConcurentAllowed()
    {
        return false;
    }

    /**
     * Cette methode fait le lien entre un nom de parametre ou d'option, et le type de champ au sens "formulaire symfony"
     * Si elle est implémentée vide, tout sera considéré comme du texte.
     *
     * Fonctionnement:
     * En fonction du nom de l'argument ou de l'option spécifié par $name
     * il faut affecter les variables passées en référence $type et $options
     * Ces variables seront utilisées lors de la génération du formulaire symfony d'interface graphique pour gêrer l'exécution du script
     * et seront passées à la commande FormBuilder::add (voir options de cette commande pour plus de détail sur le contenu éventuel de $options)
     * @return mixed
     */
    public function getTypeFieldFromArgumentName($name, & $type = "text", & $options = [])
    {
        // TODO: Implement getTypeFieldFromArgumentName() method.
    }


}
