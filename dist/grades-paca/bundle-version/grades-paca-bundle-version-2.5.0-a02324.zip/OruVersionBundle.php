<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 18/08/14
 */

namespace Oru\Bundle\VersionBundle;

use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Oru\Bundle\SettingBundle\Bundle\OruBundle;
use Oru\Bundle\VersionBundle\DependencyInjection\Compiler\VersionCompilerPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\Bundle\Bundle;
use Symfony\Component\HttpKernel\KernelInterface;

class OruVersionBundle extends OruBundle
{
    /**
     * @var KernelInterface
     */
    protected $kernel;

    /**
     * OruVersionBundle constructor.
     *
     * @param KernelInterface $kernel
     */
    public function __construct(KernelInterface $kernel = null)
    {
        $this->kernel = $kernel;

        DynamicLoader::addYaml('@OruVersionBundle/Resources/config/routing.yml');
    }

    /**
     * Builds the bundle.
     *
     * It is only ever called once when the cache is empty.
     *
     * This method can be overridden to register compilation passes,
     * other extensions, ...
     *
     * @param ContainerBuilder $container A ContainerBuilder instance
     */
    public function build(ContainerBuilder $container)
    {
        parent::build($container);

        $container->addCompilerPass(new VersionCompilerPass($this->kernel));
    }

    public static function getFriendlyName()
    {
        return 'Feuille de route';
    }

    public static function getDescription()
    {
        return 'Bundle de gestion de la feuille de route';
    }
}
