<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Events;

use Oru\Bundle\VersionBundle\Entity\Version;
use Symfony\Component\EventDispatcher\Event;

class InstallNewVersionEvent extends Event
{

    /**
     * @var Version
     */
    protected $version;

    /**
     * @return mixed
     */
    public function getVersion()
    {
        return $this->version;
    }

    /**
     * @param mixed $version
     */
    public function setVersion(Version $version)
    {
        $this->version = $version;
    }
}
