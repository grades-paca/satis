<?php

namespace Oru\Bundle\VersionBundle\Entity;

use Doctrine\ORM\EntityRepository;

/**
 * Class VersionRepository.
 *
 * @author Michaël VEROUX
 */
class VersionRepository extends EntityRepository
{
    /**
     * @return Version|false
     *
     * @author Michaël VEROUX
     */
    public function findLastVersion()
    {
        $query = $this->createQueryBuilder('v');
        $query->orderBy('v.createdAt', 'DESC');
        $query->setMaxResults(1);

        $version = $query->getQuery()->getOneOrNullResult();

        return $version;
    }
}
