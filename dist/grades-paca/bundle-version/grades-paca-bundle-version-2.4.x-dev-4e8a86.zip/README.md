OruVersionBundle
============

Description
-----------

Ce bundle fournit un système permettant de créer une feuille de route en fonction des sources installées et des données disponibles au sein de Redmine.
Quand une nouvelle version est installée, la date de mise à jour est sauvegardée en base de données et un évènement est lancé.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/version":dev-master
```

Dans le AppKernel.php, activer ces bundles :

```php
$bundles[] = new Oru\Bundle\VersionBundle\OruVersionBundle();
```

Dans le config.yml, ajouter ce bundle au paramètre imports :

```yaml
imports:
    ...
    - { resource: @OruVersionBundle/Resources/config/config.yml }
```

Dans le routing.yml, ajouter la nouvelle route :

```yaml
oru_version:
    resource: "@OruVersionBundle/Resources/config/routing.yml"
```

### Liste des paramètres

Les paramètres install_* du fichier app/config/parameters.yml permettent d'activer et de définir la base Redmine de référence.
Documentation : https://redmine.orupaca.fr/projects/ror-3/wiki/Voir_la_documentation_de_parametersyml#Paramètres-utiles-à-linstallation

Utilisation
-----------

Quand une mise à jour est détectée, l'évènement 'install.new_version' est lancé. Cet évènement contient le numéro de version.