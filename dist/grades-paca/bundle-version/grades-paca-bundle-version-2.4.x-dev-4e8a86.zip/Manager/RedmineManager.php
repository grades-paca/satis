<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Manager;

use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Mapping\Entity;
use Oru\Bundle\SettingBundle\Setting\Setting;
use Oru\Bundle\VersionBundle\Entity\RedmineTicketDetails;
use Redmine\Client;

class RedmineManager
{
    const DEFAULT_TRACKER = "inconnu";

    /**
     * @var array
     */
    private $options;

    /**
     * @var Client
     */
    private $client;

    /**
     * @var integer
     */
    private $idCustomFieldTitle;

    /**
     * @var integer
     */
    private $idCustomFieldDescription;

    /**
     * @var integer
     */
    private $idCustomFieldActions;

    /**
     * @var integer
     */
    private $idCustomFieldPublish;

    /**
     * @var EntityManager
     */
    private $em;

    /**
     * @param $options
     */
    function __construct($options, Client $client, Setting $setting, EntityManager $entityManager)
    {
        $this->client = $client;
        $this->options = $options;
        $this->idCustomFieldTitle = $setting->setting('idCustomFieldTitle', 'OruVersionBundle');
        $this->idCustomFieldDescription = $setting->setting('idCustomFieldDescription', 'OruVersionBundle');
        $this->idCustomFieldActions = $setting->setting('idCustomFieldActions', 'OruVersionBundle');
        $this->idCustomFieldPublish = $setting->setting('idCustomFieldPublish', 'OruVersionBundle');
        $this->em = $entityManager;
    }

    /**
     * Retourne des logs triés par branche et version
     *
     * @param $branchesVersionsCommits
     * @return mixed
     */
    public function getLogs($branchesVersionsCommits)
    {
        $logs = array();
        foreach($branchesVersionsCommits as $branch => $versionsCommits) {
            $logs[$branch] = array();
            foreach($versionsCommits as $version => $commits) {
                foreach ($commits as $commit => $log) {
                    foreach ($this->getRedmineTickets($log) as $ticket) {
                        $details = $this->getRedmineDetails($ticket);
                        if ($details && $details->getVisible()) {
                            if ($details->getDescription()) {
                                $logs[$branch][$version][$ticket] = sprintf("%s %s %s<br />%s", $details->getTracker(), $details->getUrl(), $details->getTitle(), $details->getDescription());
                            } else {
                                $logs[$branch][$version][$ticket] = sprintf("%s %s %s", $details->getTracker(), $details->getUrl(), $details->getTitle());
                            }

                            $action = $details->getActions();
                            if ($action) {
                                if (!isset($logs[$branch][$version]['actions'])) {
                                    $logs[$branch][$version]['actions'] = array();
                                }
                                $logs[$branch][$version]['actions'][$ticket] = sprintf("%s %s %s<br />%s", $details->getTracker(), $details->getUrl(), $details->getTitle(), $details->getActions());
                            }
                        }
                    }
                }
            }
        }

        return $logs;
    }

    /**
     * Get redmine tickets from git log
     *
     * @param $gitShortCommit
     * @return array
     */
    private function getRedmineTickets($log)
    {
        if (preg_match_all("/#([0-9]{2,6})/", $log, $matches)) {
            return $matches[1];
        }

        return array();
    }

    /**
     * Get redmine tracker for issue
     *
     * @param $ticket
     * @return string
     */
    private function getRedmineTracker($details)
    {
        if ($details && isset($details['issue']) && isset($details['issue']['tracker'])) {
            return $details['issue']['tracker']['name'];
        }

        return self::DEFAULT_TRACKER;
    }

    /**
     * Get Redmine title for issue, fonctional else default
     *
     * @param $ticket
     * @return string|null
     */
    private function getRedmineTitle($details)
    {
        if ($details && isset($details['issue'])) {
            if (isset($details['issue']['custom_fields']) && count($details['issue']['custom_fields'])) {
                foreach ($details['issue']['custom_fields'] as $field) {
                    if (isset($field['id']) && $field['id'] == $this->idCustomFieldTitle && $field['value']) {
                        return $field['value'];
                    }
                }
            }
            if (isset($details['issue']['subject'])) {
                return $details['issue']['subject'];
            }
        }
        return 'Inconnu';
    }

    /**
     * Get Redmine description for issue
     *
     * @param $ticket
     * @return string|null
     */
    private function getRedmineDescription($details)
    {
        if ($details && isset($details['issue'])) {
            if (isset($details['issue']['custom_fields']) && count($details['issue']['custom_fields'])) {
                foreach ($details['issue']['custom_fields'] as $field) {
                    if (isset($field['id']) && $field['id'] == $this->idCustomFieldDescription && $field['value']) {
                        return $field['value'];
                    }
                }
            }
        }
        return null;
    }

    /**
     * Get Redmine may publish issue
     *
     * @param $ticket
     * @return string|null
     */
    private function getRedminePublish($details)
    {
        if ($details && isset($details['issue'])) {
            if (isset($details['issue']['custom_fields']) && count($details['issue']['custom_fields'])) {
                foreach ($details['issue']['custom_fields'] as $field) {
                    if (isset($field['id']) && $field['id'] == $this->idCustomFieldPublish && $field['value'] === '0') {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    /**
     * Get Redmine may publish issue
     *
     * @param $ticket
     * @return string|null
     */
    private function getRedmineActions($details)
    {
        if ($details && isset($details['issue'])) {
            if (isset($details['issue']['custom_fields']) && count($details['issue']['custom_fields'])) {
                foreach ($details['issue']['custom_fields'] as $field) {
                    if (isset($field['id']) && $field['id'] == $this->idCustomFieldActions && $field['value']) {
                        return $field['value'];
                    }
                }
            }
        }
        return null;
    }

    /**
     * Get Redmine details for issue
     *
     * @param $ticket
     * @return RedmineTicketDetails
     */
    private function getRedmineDetails($ticket)
    {
        $object = $this->em->getRepository('OruVersionBundle:RedmineTicketDetails')->findOneByTicket($ticket);
        if ($object) {
            $object->setUrl($this->getRedmineIssueUrl($ticket));
            return $object;
        }

        $redmineDetails = $this->client->api('issue')->show($ticket);
        if (is_array($redmineDetails)) {
            $object = new RedmineTicketDetails();
            $object->setTicket($ticket);
            $object->setTitle($this->getRedmineTitle($redmineDetails));
            $object->setDescription($this->getRedmineDescription($redmineDetails));
            $object->setActions($this->getRedmineActions($redmineDetails));
            $object->setTracker($this->getRedmineTracker($redmineDetails));
            $object->setVisible($this->getRedminePublish($redmineDetails));
            $object->setUrl($this->getRedmineIssueUrl($ticket));
            $this->em->persist($object);
            $this->em->flush();

            return $object;
        }

        return false;
    }

    public function updateRedmineDetails(RedmineTicketDetails $details)
    {
        $redmineDetails = $this->client->api('issue')->show($details->getTicket());
        if(is_array($redmineDetails)) {
            $details->setTitle($this->getRedmineTitle($redmineDetails));
            $details->setDescription($this->getRedmineDescription($redmineDetails));
            $details->setActions($this->getRedmineActions($redmineDetails));
            $details->setTracker($this->getRedmineTracker($redmineDetails));
            $details->setVisible($this->getRedminePublish($redmineDetails));
        }
    }

    /**
     * Get Redmine issue url
     *
     * @param $ticket
     * @return string
     */
    private function getRedmineIssueUrl($ticket)
    {
        return "<a href='{$this->options['redmine_url']}/issues/$ticket' target='_blank'>#$ticket</a>";
    }

    /**
     * Purge le cache des demandes en base
     *
     * @throws \Doctrine\DBAL\ConnectionException
     * @throws \Doctrine\DBAL\DBALException
     */
    public function purge()
    {
        $cmd = $this->em->getClassMetadata('OruVersionBundle:RedmineTicketDetails');
        $connection = $this->em->getConnection();
        $connection->beginTransaction();
        $connection->query('DELETE FROM '.$cmd->getTableName());
        $connection->query('ALTER TABLE '.$cmd->getTableName().' AUTO_INCREMENT = 1');
        $connection->commit();
    }
}