<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Manager;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\AppBundle\Cache\CacheManager;
use Oru\Bundle\VersionBundle\Entity\Version;
use Oru\Bundle\VersionBundle\Events\InstallEvents;
use Oru\Bundle\VersionBundle\Events\InstallNewVersionEvent;
use Symfony\Component\Config\ConfigCache;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\HttpKernel\Kernel;

class Manager
{
    /**
     * @var EntityManager
     */
    private $em;

    /**
     * @var GitManager
     */
    private $git;

    /**
     * @var EventDispatcherInterface
     */
    private $eventDispatcher;

    /**
     * @var RedmineManager
     */
    private $redmine;

    /**
     * @var CacheManager
     */
    private $cacheManager;

    /**
     * Manager constructor.
     *
     * @param EntityManager            $em
     * @param GitManager               $git
     * @param EventDispatcherInterface $eventDispatcher
     * @param RedmineManager           $redmine
     * @param CacheManager             $cacheManager
     */
    public function __construct(EntityManager $em, GitManager $git, EventDispatcherInterface $eventDispatcher, RedmineManager $redmine, CacheManager $cacheManager)
    {
        $this->em = $em;
        $this->git = $git;
        $this->eventDispatcher = $eventDispatcher;
        $this->redmine = $redmine;
        $this->cacheManager = $cacheManager;
    }

    /**
     * Renvoi un tableaux des logs indexés par branche et version.
     * Le tableau est mise en cache via la commande app/console oru:install:check.
     *
     * @return array Tableaux des logs indexés par version
     */
    public function getLogs($masterVersion = null, $force = false)
    {
        $this->cacheManager->setId('changelog'.$masterVersion);
        $branchesVersionsLogs = $this->cacheManager->read();
        if (!$branchesVersionsLogs || $force) {
            $branchesVersionsCommits = $this->git->getCommitsByBranchesVersions($masterVersion);
            $branchesVersionsLogs = $this->redmine->getLogs($branchesVersionsCommits);
            $this->cacheManager->write($branchesVersionsLogs);
        }

        return $branchesVersionsLogs;
    }

    /**
     * Publier une mise à jour
     *
     * Envoi un évenement InstallEvents::INSTALL_NEW_VERSION
     *
     */
    public function updateCurrentVersion()
    {
        $version = $this->em->getRepository('OruVersionBundle:Version')->findOneByNumber($this->getCurrentVersion());
        if (!$version) {
            $version = new Version();
            $version->setNumber($this->getCurrentVersion());
            $this->em->persist($version);
            $this->em->flush();

            // send listener
            $event = new InstallNewVersionEvent();
            $event->setVersion($version);
            $this->eventDispatcher->dispatch(InstallEvents::INSTALL_NEW_VERSION, $event);

            return $version;
        }

        return null;
    }

    /**
     * Version courante
     *
     * @return string
     */
    public function getCurrentVersion()
    {
        return $this->git->getCurrentVersion();
    }

    /**
     * Version courante
     *
     * @return string
     */
    public function getCurrentMasterVersion()
    {
        return $this->git->getCurrentBranch();
    }

    /**
     * Purge le cache de la version courante
     *
     * @param $version
     */
    public function purge($version)
    {
        $this->cacheManager->setId('changelog'.$version);
        unlink($this->cacheManager->getPath());
    }

}
