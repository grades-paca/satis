<?php
/**
 * Author: Michaël VEROUX
 * Date: 03/09/15
 * Time: 16:14
 */

namespace Oru\Bundle\VersionBundle\DependencyInjection\Compiler;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\KernelInterface;
use TQ\Git\Repository\Repository;

class VersionCompilerPass implements CompilerPassInterface
{
    /**
     * @var KernelInterface
     */
    protected $kernel;

    /**
     * VersionCompilerPass constructor.
     * @param KernelInterface $kernel
     */
    public function __construct(KernelInterface $kernel)
    {
        $this->kernel = $kernel;
    }

    /**
     * You can modify the container here before it is dumped to PHP code.
     *
     * @param ContainerBuilder $container
     *
     * @api
     */
    public function process(ContainerBuilder $container)
    {
        try {
            $git = Repository::open($this->kernel->getRootDir());
            $describe = $git->getGit()->{'describe'}($git->getRepositoryPath(), array("--tags"));

            $container->setParameter('ror_version', $describe->getStdOut());

            if($container->hasDefinition('templating.asset.default_package')) {
                $assetDef = $container->getDefinition('templating.asset.default_package');
                if('dynamic' === $assetDef->getArgument(1)) {
                    $assetDef->replaceArgument(1, $container->getParameter('ror_version'));
                }
            }
        } catch (\Exception $e) {
            // @Todo Log maybe?
        }
    }
}