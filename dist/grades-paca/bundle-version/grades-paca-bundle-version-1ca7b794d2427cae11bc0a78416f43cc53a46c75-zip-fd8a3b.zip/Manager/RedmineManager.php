<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Manager;


use Redmine\Client;

class RedmineManager
{
    const DEFAULT_TRACKER = "inconnu";

    /**
     * @var array
     */
    private $options;

    /**
     * @var Client
     */
    private $client;

    /**
     * @param $options
     */
    function __construct($options, $webClient)
    {
        $this->client = new Client(($options['redmine_url_locale']) ? $options['redmine_url_locale'] : $options['redmine_url'], $options['redmine_api_key']);
        $this->options = $options;
        $proxyHost = $proxyPort = $proxyLogin = $proxyPass = null;
        $webClient->getProxyParams($proxyHost, $proxyPort, $proxyLogin, $proxyPass);
        if($proxyHost) {
            $this->client->setCurlOption(CURLOPT_PROXY, "$proxyHost:$proxyPort");
            if ($proxyLogin) {
                $this->client->setCurlOption(CURLOPT_PROXYUSERPWD, "$proxyLogin:$proxyPass");
            }
        }
    }

    /**
     * Retourne des logs triés par branche et version
     *
     * @param $branchesVersionsCommits
     * @return mixed
     */
    public function getLogs($branchesVersionsCommits)
    {
        $logs = array();
        foreach($branchesVersionsCommits as $branch => $versionsCommits) {
            $logs[$branch] = array();
            foreach($versionsCommits as $version => $commits) {
                foreach ($commits as $commit => $log) {
                    foreach ($this->getRedmineTickets($log) as $ticket) {
                        if (is_array($this->getRedmineDetails($ticket))) {
                            $logs[$branch][$version][$ticket] = sprintf("%s %s %s", $this->getRedmineTracker($ticket), $this->getRedmineIssueUrl($ticket), $this->getRedmineTitle($ticket));
                        }
                    }
                }
            }
        }

        return $logs;
    }



    /**
     * Get redmine tickets from git log
     *
     * @param $gitShortCommit
     * @return array
     */
    private function getRedmineTickets($log)
    {
        if (preg_match_all("/#([0-9]{2,5})/", $log, $matches)) {
            return $matches[1];
        }

        return array();
    }

    /**
     * Get redmine tracker for issue
     *
     * @param $ticket
     * @return string
     */
    private function getRedmineTracker($ticket)
    {
        $details = $this->getRedmineDetails($ticket);
        if ($details && isset($details['issue']) && isset($details['issue']['tracker'])) {
            return $details['issue']['tracker']['name'];
        }

        return self::DEFAULT_TRACKER;
    }

    /**
     * Get Redmine title for issuer
     *
     * @param $ticket
     * @return string|null
     */
    private function getRedmineTitle($ticket)
    {
        $details = $this->getRedmineDetails($ticket);
        if ($details && isset($details['issue']) && isset($details['issue']['subject'])) {
            return $details['issue']['subject'];
        }

        return null;
    }

    /**
     * Get Redmine details for issue
     *
     * @param $ticket
     * @return mixed
     */
    private function getRedmineDetails($ticket)
    {
        if (isset($this->redmineDetails[$ticket])) {
            return $this->redmineDetails[$ticket];
        }
        $this->redmineDetails[$ticket] = $this->client->api('issue')->show($ticket);
        return $this->redmineDetails[$ticket];
    }

    /**
     * Get Redmine issue url
     *
     * @param $ticket
     * @return string
     */
    private function getRedmineIssueUrl($ticket)
    {
        return "<a href='{$this->options['redmine_url']}/issues/$ticket' target='_blank'>#$ticket</a>";
    }
}