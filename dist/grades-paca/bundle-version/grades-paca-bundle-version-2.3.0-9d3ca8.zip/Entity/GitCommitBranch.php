<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Entity;


class GitCommitBranch
{

    /**
     * @var string
     */
    private $commit;

    /**
     * @var string
     */
    private $branch;

    /**
     * @var integer
     */
    private $id;


    /**
     * Set commit
     *
     * @param string $commit
     *
     * @return GitCommitBranch
     */
    public function setCommit($commit)
    {
        $this->commit = $commit;

        return $this;
    }

    /**
     * Get commit
     *
     * @return string
     */
    public function getCommit()
    {
        return $this->commit;
    }

    /**
     * Set branch
     *
     * @param string $branch
     *
     * @return GitCommitBranch
     */
    public function setBranch($branch)
    {
        $this->branch = $branch;

        return $this;
    }

    /**
     * Get branch
     *
     * @return string
     */
    public function getBranch()
    {
        return $this->branch;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
}
