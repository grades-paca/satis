<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class DefaultController extends Controller
{

    public function indexAction(Request $request)
    {
        ini_set('set_time_limit', 0);
        $masterVersion = $request->query->get('masterVersion', $this->get('oru_version.manager')->getCurrentMasterVersion());
        return $this->render('@OruVersion/Default/index.html.twig', array(
            'logs'              => $this->get('oru_version.manager')->getLogs($masterVersion),
            'current'           => $this->get('oru_version.manager')->getCurrentVersion(),
            'installedVersions' => $this->getDoctrine()->getRepository('OruVersionBundle:Version')->findAll(),
            'masterVersion'     => $masterVersion
        ));
    }

    public function numberAction()
    {
        return $this->render('@OruVersion/Default/current.html.twig', array(
            'current' => $this->get('oru_version.manager')->getCurrentVersion()
        ));
    }

    public function allAction(Request $request)
    {
        ini_set('set_time_limit', 0);
        return $this->render('@OruVersion/Default/index.html.twig', array(
            'logs' => $this->get('oru_version.manager')->getLogs(),
            'current' => $this->get('oru_version.manager')->getCurrentVersion(),
            'installedVersions' => $this->getDoctrine()->getRepository('OruVersionBundle:Version')->findAll()
        ));
    }
}
