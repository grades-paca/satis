<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class CheckVersionCommand extends ContainerAwareCommand
{
    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this
            ->setName('oru:version:check')
            ->setDescription('Install current version')
        ;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int|null|void
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $context = $this->getContainer()->get('router')->getContext();
        $context->setHost($this->getContainer()->getParameter('router.request_context.host'));
        $context->setScheme($this->getContainer()->getParameter('router.request_context.scheme'));
        $context->setBaseUrl($this->getContainer()->getParameter('router.request_context.base_url'));

        $this->getContainer()->get('oru_version.manager')->getLogs($this->getContainer()->get('oru_version.manager')->getCurrentMasterVersion());
        $output->writeln('Changelog mis à jour.');
        $version = $this->getContainer()->get('oru_version.manager')->updateCurrentVersion();
        if ($version) {
            $output->writeln("Nouvelle version {$version->getNumber()} installée.");
        }
    }
}
