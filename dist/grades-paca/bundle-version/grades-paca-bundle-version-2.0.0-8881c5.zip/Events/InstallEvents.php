<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Events;

final class InstallEvents
{
    const INSTALL_NEW_VERSION = 'install.new_version';
}
