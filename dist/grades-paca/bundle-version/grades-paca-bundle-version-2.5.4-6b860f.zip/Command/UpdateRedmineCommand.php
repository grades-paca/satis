<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Command;

use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class UpdateRedmineCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    /**
     * Doit renvoyer le nombre de secondes d'exécution acceptable avant que le gestionnaire de taches ne tue le processus
     * 0 si pas de limite.
     *
     * @return int
     **/
    public function getMaxRunningTimeSec()
    {
        return 1500;
    }

    /**
     * Doit renvoyer un booleen signalant si la tache accepte d'être exécutée en parallèle avec d'autres taches issus de la même commande.
     *
     * @return bool
     */
    public function isConcurentAllowed()
    {
        return false;
    }

    /**
     * Cette methode fait le lien entre un nom de parametre ou d'option, et le type de champ au sens "formulaire symfony"
     * Si elle est implémentée vide, tout sera considéré comme du texte.
     *
     * Fonctionnement:
     * En fonction du nom de l'argument ou de l'option spécifié par $name
     * il faut affecter les variables passées en référence $type et $options
     * Ces variables seront utilisées lors de la génération du formulaire symfony d'interface graphique pour gêrer l'exécution du script
     * et seront passées à la commande FormBuilder::add (voir options de cette commande pour plus de détail sur le contenu éventuel de $options)
     *
     * @param mixed $name
     *
     * @return mixed
     */
    public function getTypeFieldFromArgumentName($name, &$type = TextType::class, &$options = array())
    {
        // TODO: Implement getTypeFieldFromArgumentName() method.
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this
            ->setName('oru:version:redmine-update')
            ->setDescription('Update details about redmine cached tickets')
            ->addOption('purge', 'p', InputOption::VALUE_NONE, 'Clear all Redmine data cached into database')
        ;
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $container = $this->getContainer();

        $context = $container->get('router')->getContext();
        $context->setHost($container->getParameter('router.request_context.host'));
        $context->setScheme($container->getParameter('router.request_context.scheme'));
        $context->setBaseUrl($container->getParameter('router.request_context.base_url'));

        if ($input->getOption('purge')) {
            $container->get('oru_version.redmine_manager')->purge();
        } else {
            $details = $container->get('doctrine.orm.entity_manager')->getRepository('OruVersionBundle:RedmineTicketDetails')->findAll();
            if (is_array($details)) {
                $progress = new ProgressBar($output, count($details));
                $progress->start();
                foreach ($details as $detail) {
                    $container->get('oru_version.redmine_manager')->updateRedmineDetails($detail);
                    $progress->advance();
                }
                $progress->finish();
                $container->get('doctrine.orm.entity_manager')->flush();
            }
        }

        $masterVersion = $container->get('oru_version.manager')->getCurrentMasterVersion();
        $container->get('oru_version.manager')->getLogs($masterVersion, true);
        $output->writeln('Changelog mis à jour.');
    }
}
