<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\VersionBundle\Manager;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\VersionBundle\Entity\Version;
use Oru\Bundle\VersionBundle\Events\InstallEvents;
use Oru\Bundle\VersionBundle\Events\InstallNewVersionEvent;
use Symfony\Component\Config\ConfigCache;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\HttpKernel\Kernel;

class Manager
{
    /**
     * @var EntityManager
     */
    private $em;

    /**
     * @var GitManager
     */
    private $git;

    /**
     * @var EventDispatcher
     */
    private $eventDispatcher;

    /**
     * @var RedmineManager
     */
    private $redmine;

    /**
     * @var array
     */
    private $options;

    /**
     * @param EntityManager $entityManager
     * @param Kernel $kernel
     * @param EventDispatcher $eventDispatcher
     * @param Mailer $mailer
     */
    public function __construct(EntityManager $entityManager, GitManager $gitManager, EventDispatcherInterface $eventDispatcher, RedmineManager $redmineManager, $options)
    {
        $this->em = $entityManager;
        $this->eventDispatcher = $eventDispatcher;
        $this->git = $gitManager;
        $this->redmine = $redmineManager;
        $this->options = $options;
    }

    /**
     * Renvoi un tableaux des logs indexés par branche et version.
     * Le tableau est mise en cache via la commande app/console oru:install:check.
     *
     * @return array Tableaux des logs indexés par version
     */
    public function getLogs($masterVersion = null)
    {
        $cache = new ConfigCache($this->options['cache_dir']."/changelog$masterVersion", false);
        if (!$cache->isFresh()) {
            $branchesVersionsCommits = $this->git->getCommitsByBranchesVersions($masterVersion);
            $branchesVersionsLogs = $this->redmine->getLogs($branchesVersionsCommits);
            $cache->write(serialize($branchesVersionsLogs));
        } else {
            $branchesVersionsLogs = unserialize(file_get_contents($cache));
        }

        return $branchesVersionsLogs;
    }

    /**
     * Publier une mise à jour
     *
     * Envoi un évenement InstallEvents::INSTALL_NEW_VERSION
     *
     */
    public function updateCurrentVersion()
    {
        $version = $this->em->getRepository('OruVersionBundle:Version')->findOneByNumber($this->getCurrentVersion());
        if (!$version) {
            $version = new Version();
            $version->setNumber($this->getCurrentVersion());
            $this->em->persist($version);
            $this->em->flush();

            // send listener
            $event = new InstallNewVersionEvent();
            $event->setVersion($version);
            $this->eventDispatcher->dispatch(InstallEvents::INSTALL_NEW_VERSION, $event);

            return $version;
        }

        return null;
    }

    /**
     * Version courante
     *
     * @return string
     */
    public function getCurrentVersion()
    {
        return $this->git->getCurrentVersion();
    }

    /**
     * Version courante
     *
     * @return string
     */
    public function getCurrentMasterVersion()
    {
        return $this->git->getCurrentBranch();
    }

}
