<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 07/01/14
 * Time: 11:18
 */

namespace Oru\Bundle\AttachmentBundle\Tests\Controller;

use Oru\Bundle\AttachmentBundle\Tests\Tool\TestFile;
use Oru\Bundle\TestBundle\Tests\ModelTestCase;

class AttachmentControllerTest extends ModelTestCase
{
    protected $client = null;

    public function testList()
    {
        $crawler = $this->getClient()->request('GET', '/tests/test-attachment');

        $this->assertTrue($crawler->filter('div:contains("test.txt")')->count() > 1);
    }

    public function testUploadMaxFilesize()
    {
        $crawler = $this->getClient()->request('GET', '/attachment_upload_max_filesize');

        $this->assertTrue(1 === preg_match('#Taille max\. de fichier#', $crawler->text()));
    }

    /**
     * @test
     */
    public function testGetDelete()
    {
        $this->getClient()->request('GET', '/attachment_delete/1');

        $this->assertSame(405, $this->getClient()->getResponse()->getStatusCode());

        $this->getClient()->request('POST', '/attachment_delete/1');

        $this->assertSame(405, $this->getClient()->getResponse()->getStatusCode());

        $this->getClient()->request('PUT', '/attachment_delete/1');

        $this->assertSame(405, $this->getClient()->getResponse()->getStatusCode());
    }

    public function testDownload()
    {
        TestFile::saveFile($this->get('service_container'));

        $em = $this->get('doctrine')->getManager();

        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findAll();

        $attachment = array_shift($attachments);

        $this->getClient()->request('GET', '/attachment_download/'.$attachment->getId());

        $this->assertTrue(1 === preg_match('#'.preg_quote($attachment->getFileType()).'#', $this->getClient()->getResponse()->headers->get('Content-Type')));

        $this->assertTrue($attachment->readData() === $this->getClient()->getResponse()->getContent());
    }

    public function testDelete()
    {
        TestFile::saveEntity($this->get('service_container'));

        $em = $this->get('doctrine')->getManager();

        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findAll();

        $attachment = array_shift($attachments);

        $this->getClient()->request('DELETE', '/attachment_delete/'.$attachment->getId());

        $this->assertTrue($this->getClient()->getResponse()->headers->contains('Content-Type', 'application/json'));

        $json_response = json_decode($this->getClient()->getResponse()->getContent());

        $this->assertTrue('success' === $json_response);
    }

    public function testNewForm()
    {
        $this->getClient()->request('GET', '/tests/test-attachment-new');

        $this->assertRegExp('/type="file"/', $this->getClient()->getResponse()->getContent());
    }

    public function testAjaxAdd()
    {
        $absolute_path = sprintf('%s/%s', TestFile::PATH, TestFile::NAME);

        $file = array(
            'tmp_name' => $absolute_path,
            'name' => TestFile::NAME,
            'type' => 'text/plain',
            'size' => filesize($absolute_path),
            'error' => UPLOAD_ERR_OK,
        );

        $crawler = $this->getClient()->request(
            'POST',
            '/attachment_add/',
            array(),
            array(
                'files' => array($file),
            ),
            array(
            'HTTP_X-Requested-With' => 'XMLHttpRequest',
            )
        );

        $this->assertRegExp('/<div id="file_/', $this->getClient()->getResponse()->getContent());
    }

    protected function getClient()
    {
        if (!$this->client) {
            $this->client = static::createClient();
        }

        return $this->client;
    }
}
