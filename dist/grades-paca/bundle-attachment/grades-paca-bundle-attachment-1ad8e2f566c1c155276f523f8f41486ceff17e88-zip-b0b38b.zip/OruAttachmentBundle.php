<?php

namespace Oru\Bundle\AttachmentBundle;

use Oru\Bundle\AttachmentBundle\DependencyInjection\Compiler\FormPass;
use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruAttachmentBundle extends Bundle
{
    public function build(ContainerBuilder $container)
    {
        parent::build($container);
        $container->addCompilerPass(new FormPass());
    }

    /**
     * @author André CARDOSO
     */
    public function boot()
    {
        DynamicLoader::addYaml('@OruAttachmentBundle/Resources/config/routing.yml');
    }
}
