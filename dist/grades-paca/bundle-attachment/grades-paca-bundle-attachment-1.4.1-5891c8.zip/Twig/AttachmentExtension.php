<?php

/*
 * This file is part of PHP CS Fixer.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *     Dariusz Rumiński <dariusz.ruminski@gmail.com>
 *
 * This source file is subject to the MIT license that is bundled
 * with this source code in the file LICENSE.
 */

namespace Oru\Bundle\AttachmentBundle\Twig;

use Oru\Bundle\AttachmentBundle\Attachment\AttachmentTool;

/**
 * Twig listing extension.
 *
 * Class ListingExtension
 */
class AttachmentExtension extends \Twig_Extension implements \Twig_Extension_InitRuntimeInterface
{
    /**
     * @var \Twig_Environment
     */
    protected $environment;

    /**
     * @var AttachmentTool
     */
    protected $attachmentTool;

    /**
     * AttachmentExtension constructor.
     *
     * @param AttachmentTool $attachmentTool
     */
    public function __construct(AttachmentTool $attachmentTool)
    {
        $this->attachmentTool = $attachmentTool;
    }

    /**
     * {@inheritdoc}
     */
    public function initRuntime(\Twig_Environment $environment)
    {
        $this->environment = $environment;
    }

    /**
     * {@inheritdoc}
     */
    public function getFunctions()
    {
        return array(
            'attachment_add' => new \Twig_SimpleFunction('attachment_add', array($this, 'attachment_add'), array('is_safe' => array('html'))),
            'attachment_add_js' => new \Twig_SimpleFunction('attachment_add_js', array($this, 'attachment_add_js'), array('is_safe' => array('html'))),
            'attachment_list' => new \Twig_SimpleFunction('attachment_list', array($this, 'attachment_list'), array('is_safe' => array('html'))),
            'attachment_show' => new \Twig_SimpleFunction('attachment_show', array($this, 'attachment_show'), array('is_safe' => array('html'))),
        );
    }

    public function getFilters()
    {
        return array(
            new \Twig_SimpleFilter('bytes2hr', array($this, 'bytes2hr')),
        );
    }

    /**
     * Fonction permettant d'afficher un bouton d'import de pièces jointes.
     *
     * @param array $attachments
     * @param mixed $controller
     * @param mixed $route
     *
     * @return string
     */
    public function attachment_add($attachments = array(), $controller = 'OruAttachmentBundle:Attachment:formOrphans', $route = 'oru_attachment_add')
    {
        return $this->environment->render(
            '@OruAttachment/Attachment/index.html.twig',
            array('attachments' => $attachments, 'controller' => $controller, 'route' => $route)
        );
    }

    /**
     * Fonction permettant d'afficher le javascript nécessaire à la fonction attachment_add.
     *
     * @see self::attachment_add
     *
     * @return string
     */
    public function attachment_add_js()
    {
        return $this->environment->render(
            '@OruAttachment/Attachment/index.javascript.twig'
        );
    }

    /**
     * Taille de la pièce jointe dans un format lisible.
     *
     * @param $size
     * @param string $unit
     *
     * @return string
     */
    public function bytes2hr($size, $unit = '')
    {
        if ((!$unit && $size >= 1 << 30) || $unit === 'GB') {
            return number_format($size / (1 << 30), 2).'GB';
        }
        if ((!$unit && $size >= 1 << 20) || $unit === 'MB') {
            return number_format($size / (1 << 20), 2).'MB';
        }
        if ((!$unit && $size >= 1 << 10) || $unit === 'KB') {
            return number_format($size / (1 << 10), 2).'KB';
        }

        return number_format($size).' bytes';
    }

    /**
     * Fonction permettant d'afficher toutes les pièces jointes liées à une entité.
     *
     * @param $entity
     * @param null $role_view
     *
     * @return string
     */
    public function attachment_list($entity, $role_view = null)
    {
        return $this->environment->render(
            '@OruAttachment/Attachment/list.html.twig',
            array('entity' => $entity, 'role_view' => $role_view)
        );
    }

    /**
     * Fonction permettant d'afficher une pièce jointe.
     *
     * @param $attachment
     * @param null $entity
     *
     * @return string
     */
    public function attachment_show($attachment, $entity = null)
    {
        if (!$entity) {
            $entity = $this->attachmentTool->getEntityForAttachment($attachment);
        }

        return $this->environment->render(
            '@OruAttachment/Attachment/attachment.html.twig',
            array('attachment' => $attachment, 'entity' => $entity)
        );
    }

    /**
     * {@inheritdoc}
     *
     * @return string
     */
    public function getName()
    {
        return 'attachment_extension';
    }
}
