<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\AttachmentBundle\Controller;

use Oru\Bundle\AttachmentBundle\Entity\Attachment;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\Security\Core\Util\ClassUtils;

class AttachmentController extends Controller
{
    /**
     * Ajouter une pièce jointe
     *
     * @param Request $request
     * @return Response
     */
    public function addAction(Request $request)
    {
        $files = $request->files->get('files');
        $attachments = array();
        if (!empty($files)) {
            foreach ($request->files->get('files') as $file) {
                if ($file instanceof UploadedFile) {
                    $attachment = $this->get('oru_attachment.context')->createAttachmentFromUploadedFile($file);

                    $em = $this->getDoctrine()->getManager();
                    $em->persist($attachment);
                    $em->flush();

                    $attachments[] = $attachment;
                }
            }
        }

        return
            $this->render('OruAttachmentBundle:Attachment:form_attachments.html.twig', array(
                'attachments' => $attachments
            ));
    }

    /**
     * Supprimer une pièce jointe
     *
     * @param Request $request
     * @param $id Identifiant de la pièce jointe à supprimer
     * @return Response
     */
    public function deleteAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();
        $attachment = $em->getRepository('OruAttachmentBundle:Attachment')->find($id);

        if (!$attachment) {
            throw $this->createNotFoundException("No attachment found for id : $id.");
        }

        if ($attachment->getRoleDelete() != '' && false === $this->get('security.authorization_checker')->isGranted($attachment->getRoleDelete(), $this->get('oru_attachment.context')->getEntityForAttachment($attachment))) {
            throw new AccessDeniedException('Unable to access this page!');
        }

        $em->remove($attachment);
        $em->flush();

        $response = new Response(json_encode('success'));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * Liste les pièces jointes associées à une entité
     *
     * @param Request $request
     * @param $entity
     * @param $role_view
     * @return Response
     */
    public function listAction(Request $request, $entity, $role_view)
    {
        if ($role_view != '' && false === $this->get('security.authorization_checker')->isGranted($role_view, $entity)) {
            throw new AccessDeniedException('Unable to access this page!');
        }

        $em = $this->getDoctrine()->getManager();
        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findByEntityIdAndEntityType($entity->getId(), ClassUtils::getRealClass(get_class($entity)));

        return
            $this->render('OruAttachmentBundle:Attachment:list_attachments.html.twig', array(
                'attachments' => $attachments,
                'entity' => $entity,
                'role_view' => $role_view
            ));
    }

    /**
     * Liste des pièces jointe non encore associées à une entité
     *
     * @param Request $request
     * @param $attachments
     * @return Response
     */
    public function formOrphansAction(Request $request, $attachments)
    {
        $em = $this->getDoctrine()->getManager();
        $attachments_entities = array();
        if (!empty($attachments)) {
            foreach ($attachments as $id => $details) {
                $attachment = $em->getRepository('OruAttachmentBundle:Attachment')->find($id);
                if ($attachment instanceof Attachment) {
                    $attachment->setDescription($details['description']);
                    $attachments_entities[] = $attachment;
                }
            }
        }

        return
            $this->render('OruAttachmentBundle:Attachment:form_attachments.html.twig', array(
                'attachments' => $attachments_entities
            ));
    }

    /**
     * Télécharger une pièce jointe
     *
     * @param Request $request
     * @param $id
     * @param bool|false $inline
     * @return Response
     */
    public function downloadAction(Request $request, $id, $inline = false)
    {
        $em = $this->getDoctrine()->getManager();
        $attachment = $em->getRepository('OruAttachmentBundle:Attachment')->find($id);

        if ($attachment->getRoleView() != '' && false === $this->get('security.authorization_checker')->isGranted($attachment->getRoleView(), $this->get('oru_attachment.context')->getEntityForAttachment($attachment))) {
            throw new AccessDeniedException('Unable to access this page!');
        }

        $attachment->setDownloads(((int) $attachment->getDownloads()) + 1);
        $em->flush();

        $response = new Response();
        $response->headers->set('Content-Type', $attachment->getFiletype());
        $response->headers->set('Content-Disposition', (($inline) ? 'inline' : 'attachment') . ';filename="'.$attachment->getFilename());
        $response->setContent($attachment->readData());

        return $response;
    }

    /**
     * Taille maximale de téléchargement
     *
     * @param Request $request
     * @return Response
     */
    public function uploadMaxFilesizeAction(Request $request)
    {
        return new Response($this->get('translator')->trans("attachment.upload_max_filesize", array('%max%' => ini_get('upload_max_filesize')), 'OruAttachmentBundle'));
    }

    /**
     * Affiche les pièces jointes associées à une entité sous forme de galerie
     *
     * @param Request $request
     * @param $id Identifiant de la pièce jointe pour récupérer l'entité
     * @return Response
     */
    public function galleryAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();
        $first = $em->getRepository('OruAttachmentBundle:Attachment')->find($id);
        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findByEntityIdAndEntityType($first->getEntityId(), $first->getEntityType());

        $tm = array(
            'image/jpeg',
            'image/pjpeg',
            'image/jpg',
            'image/png',
            'image/x-png',
            'image/x-citrix-png',
            'image/x-citrix-jpeg',
            'image/x-citrix-pjpeg'
        );
        $am = $this->get('oru_attachment.context');
        $sc = $this->get('security.authorization_checker');

        $displayables = array();
        foreach ($attachments as $att) {
            $entity = $em->getRepository('OruAttachmentBundle:Attachment')->find($att['id']);
            $view = $entity->getRoleView() == '' || $sc->isGranted($entity->getRoleView(), $am->getEntityForAttachment($entity));
            if (array_search($entity->getFiletype(), $tm) !== false && $view) {
                $displayables[] = $entity;
            }
        }

        return
            $this->render('OruAttachmentBundle:Attachment:gallery.html.twig', array(
                'attachments' => $displayables
            ));
    }

    /**
     * Affiche une galerie de vidéos
     *
     * @param Request $request
     * @param $id
     * @return Response
     */
    public function videoAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();
        $first = $em->getRepository('OruAttachmentBundle:Attachment')->findWithoutData($id);
        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findByEntityIdAndEntityType($first['entityId'], $first['entityType']);

        $tm = array(
            'video/ogg',
            'video/mp4',
            'video/webm',
            'video/quicktime'
        );
        $sc = $this->get('security.authorization_checker');

        $displayables = array();
        foreach ($attachments as $att) {
            $entity = $em->getRepository('OruAttachmentBundle:Attachment')->findWithoutData($att['id']);
            $linkedEntity = $em->getRepository($first['entityType'])->find($first['entityId']);
            $view = $entity['roleView'] == '' || $sc->isGranted($entity['roleView'], $linkedEntity);
            if (array_search($entity['filetype'], $tm) !== false && $view) {
                $entity['childrens'] = $em->getRepository('OruAttachmentBundle:Attachment')->findChildrensWithoutData($att['id'], $first['entityId'], $first['entityType']);
                $displayables[] = $entity;
            }
        }

        return
            $this->render('OruAttachmentBundle:Attachment:video.html.twig', array(
                'attachments' => $displayables
            ));
    }

    /**
     * Affiche une galerie de PDF
     *
     * @param Request $request
     * @param $id
     * @return Response
     */
    public function pdfAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();
        $first = $em->getRepository('OruAttachmentBundle:Attachment')->findWithoutData($id);
        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findByEntityIdAndEntityType($first['entityId'], $first['entityType']);

        $tm = array('application/pdf');
        $sc = $this->get('security.authorization_checker');

        $displayables = array();
        foreach ($attachments as $att) {
            $entity = $em->getRepository('OruAttachmentBundle:Attachment')->findWithoutData($att['id']);
            $linkedEntity = $em->getRepository($first['entityType'])->find($first['entityId']);
            $view = $entity['roleView'] == '' || $sc->isGranted($entity['roleView'], $linkedEntity);
            if (array_search($entity['filetype'], $tm) !== false && $view) {
                $displayables[] = $entity;
            }
        }


        if(count($displayables) == 1) {
            return $this->redirect('/bundles/oruattachment/js/pdf.js/web/viewer.html?file=' . $this->generateUrl('oru_attachment_inline', array('id' => $displayables[0]['id'])));
        }

        return
            $this->render('OruAttachmentBundle:Attachment:pdf.html.twig', array(
                'attachments' => $displayables
            ));
    }
}
