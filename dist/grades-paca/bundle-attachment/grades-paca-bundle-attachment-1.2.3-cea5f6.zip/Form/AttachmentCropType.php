<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\AttachmentBundle\Form;


use Oru\Bundle\AttachmentBundle\Attachment\AttachmentTool;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AttachmentCropType extends AbstractType
{

    private $attachmentTool;

    /**
     * @param AttachmentTool $attachmentTool
     */
    public function __construct(AttachmentTool $attachmentTool)
    {
        $this->attachmentTool = $attachmentTool;
    }

    /**
     * Add the data transformer to the field setting the entity repository
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $entityTransformer = new $options['transformer']($this->attachmentTool, $options['role_view'], $options['role_delete']);
        $builder->addViewTransformer($entityTransformer);
        $builder
            ->add('uploadedFile', 'file', array('label' => ' ', 'attr' => (isset($options['attr'])) ? $options['attr'] : array()))
            ->add('x', 'hidden')
            ->add('y', 'hidden')
            ->add('width', 'hidden')
            ->add('height', 'hidden')
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefined(array('role_view', 'role_delete', 'aspect_ratio'));
        $resolver->setDefaults(array(
            'role_view' => null,
            'role_delete' => null,
            'data_class' => 'Oru\Bundle\AttachmentBundle\Entity\Attachment',
            'transformer' => 'Oru\Bundle\AttachmentBundle\Form\DataTransformer\CropTransformer',
        ));
    }

    /**
     * @param FormView $view
     * @param FormInterface $form
     * @param array $options
     */
    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        $view->vars = array_replace($view->vars, array(
            'type' => 'file',
            'value' => '',
            'attachment' => $form->getViewData(),
            'entity' => $form->getParent()->getViewData(),
        ));

        if(isset($options['aspect_ratio'])) {
            $view->vars['aspect_ratio'] = $options['aspect_ratio'];
        }
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_attachment_crop';
    }

}