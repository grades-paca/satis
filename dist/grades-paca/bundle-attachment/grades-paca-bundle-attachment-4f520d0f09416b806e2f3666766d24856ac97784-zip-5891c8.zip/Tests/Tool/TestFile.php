<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 08/01/14
 * Time: 11:55
 */

namespace Oru\Bundle\AttachmentBundle\Tests\Tool;

use Oru\Bundle\TestBundle\Entity\ModelObject;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class TestFile
{
    const NAME = 'test.txt';
    const PATH = '/tmp';
    const CONTENT = 'Fichier test attachmentBundle';

    /**
     * @return \Oru\Bundle\AttachmentBundle\Entity\Attachment
     */
    public static function saveFile(Container $container)
    {
        $test_path_absolute = sprintf('%s/%s', self::PATH, self::NAME);
        file_put_contents($test_path_absolute, self::CONTENT);

        $uploadedFile = new UploadedFile($test_path_absolute, self::NAME, 'text/plain', filesize($test_path_absolute));

        $attachment = $container->get('oru_attachment.context')->createAttachmentFromUploadedFile($uploadedFile);

        $em = $container->get('doctrine')->getManager();

        $em->persist($attachment);
        $em->flush();

        return $attachment;
    }

    /**
     * @return ModelObject
     */
    public static function saveEntity(Container $container)
    {
        $modelObject = new ModelObject();

        $modelObject->setName('test');
        $modelObject->setDescription('description');
        $modelObject->setComment('commentaire');

        $em = $container->get('doctrine')->getManager();

        $em->persist($modelObject);
        $em->flush();

        return $modelObject;
    }
}
