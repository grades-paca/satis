<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 23/05/14
 */
namespace Oru\Bundle\AttachmentBundle\Command;

use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class CleanCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this
            ->setName('oru:attachment:clean')
            ->setDescription('Clean unused attachments.')
            ->addOption('since', null, InputOption::VALUE_OPTIONAL, 'Imported since (default to more than one day). See http://www.php.net/manual/fr/datetime.modify.php.', '-1 day')
        ;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int|null|void
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $em = $this->getContainer()->get('doctrine')->getManager();
        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findUnused($input->getOption('since'));
        $count = count($attachments);

        foreach ($attachments as $attachment) {
            $em->remove($attachment);
        }
        $em->flush();

        $output->writeln("{$count} attachments successfully removed.");
    }

    /**
     * {@inheritdoc}
     **/
    public function getMaxRunningTimeSec()
    {
        return 5;
    }

    /**
     * {@inheritdoc}
     */
    public function isConcurentAllowed()
    {
        return false;
    }

    /**
     * {@inheritdoc}
     */
    public function getTypeFieldFromArgumentName($name, & $type = "text", & $options = [])
    {
    }
}
