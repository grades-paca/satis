<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\AttachmentBundle\Command;

use Oru\Bundle\ScheduleBundle\Interfaces\OruSchedulableCommandInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class EncodeCommand extends ContainerAwareCommand implements OruSchedulableCommandInterface
{
    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this
            ->setName('oru:attachment:encode')
            ->setDescription('Encode video attachments.')
        ;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int|null|void
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $em = $this->getContainer()->get('doctrine')->getManager();
        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findOrphanVideos();

        $i = 0;
        if(count($attachments)) {
            foreach ($attachments as $attachmentData) {
                $attachment = $em->getRepository('OruAttachmentBundle:Attachment')->find($attachmentData['id']);
                $videos = $this->getContainer()->get('oru_attachment.manager')->encodeVideo($attachment);
                foreach($videos as $video) {
                    $i++;
                    $em->persist($video);
                    $em->flush($video);
                }
                if(!count($videos)) {
                    $attachment->setOrphan(true);
                }
                $em->flush();
            }
        }

        $output->writeln("{$i} attachments successfully encoded.");
    }

    /**
     * {@inheritdoc}
     **/
    public function getMaxRunningTimeSec()
    {
        return 900;
    }

    /**
     * {@inheritdoc}
     */
    public function isConcurentAllowed()
    {
        return false;
    }

    /**
     * {@inheritdoc}
     */
    public function getTypeFieldFromArgumentName($name, & $type = "text", & $options = [])
    {
    }
}
