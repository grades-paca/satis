<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\AttachmentBundle\Manager;

use Oru\Bundle\AttachmentBundle\Attachment\AttachmentTool;

class AttachmentManager extends AttachmentTool
{
}
