<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\AttachmentBundle\Form\DataTransformer;

use Oru\Bundle\AttachmentBundle\Attachment\AttachmentTool;
use Oru\Bundle\AttachmentBundle\Entity\Attachment;
use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\Exception\TransformationFailedException;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class UploadedFileToAttachmentTransformer implements DataTransformerInterface
{
    /**
     * @var AttachmentTool
     */
    private $attachmentTool;

    /**
     * @var string
     */
    private $role_view;

    /**
     * @var string
     */
    private $role_delete;

    /**
     * UploadedFileToAttachmentTransformer constructor.
     * @param AttachmentTool $attachmentTool
     * @param null $role_view
     * @param null $role_delete
     */
    public function __construct(AttachmentTool $attachmentTool, $role_view = null, $role_delete = null)
    {
        $this->attachmentTool = $attachmentTool;
        $this->role_view = $role_view;
        $this->role_delete = $role_delete;
    }

    /**
     * @inheritdoc
     */
    public function transform($value)
    {
        return $value;
    }

    /**
     * @inheritdoc
     */
    public function reverseTransform($value)
    {
        if ($value) {
            return $this->attachmentTool->createAttachmentFromUploadedFile($value, null, $this->role_view, $this->role_delete);
        }

        return $value;
    }
}
