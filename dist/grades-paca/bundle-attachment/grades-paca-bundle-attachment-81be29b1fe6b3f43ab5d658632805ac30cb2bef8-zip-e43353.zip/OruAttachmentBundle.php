<?php

/*
 * This file is part of PHP CS Fixer.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *     Dariusz Rumiński <dariusz.ruminski@gmail.com>
 *
 * This source file is subject to the MIT license that is bundled
 * with this source code in the file LICENSE.
 */

namespace Oru\Bundle\AttachmentBundle;

use Oru\Bundle\AttachmentBundle\DependencyInjection\Compiler\FormPass;
use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruAttachmentBundle extends Bundle
{
    /**
     * OruAttachmentBundle constructor.
     */
    public function __construct()
    {
        DynamicLoader::addYaml('@OruAttachmentBundle/Resources/config/routing.yml');
    }

    public function build(ContainerBuilder $container)
    {
        parent::build($container);
        $container->addCompilerPass(new FormPass());
    }
}
