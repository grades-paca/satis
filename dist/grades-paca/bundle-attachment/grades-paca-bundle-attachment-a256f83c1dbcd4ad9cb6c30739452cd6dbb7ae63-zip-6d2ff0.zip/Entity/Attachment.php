<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\AttachmentBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oru\Bundle\AttachmentBundle\Model\Crop;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * Attachment
 */
class Attachment implements \ArrayAccess
{
    use Crop;

    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $filename;

    /**
     * @var integer
     */
    private $filesize;

    /**
     * @var string
     */
    private $filetype;

    /**
     * @var string
     */
    private $data;

    /**
     * @var string
     */
    private $digest;

    /**
     * @var boolean
     */
    private $downloads;

    /**
     * @var string
     */
    private $description;

    /**
     * @var integer
     */
    private $entityId;

    /**
     * @var string
     */
    private $entityType;

    /**
     * @var DateTime
     */
    private $created;

    /**
     * @var string
     */
    private $roleView;

    /**
     * @var string
     */
    private $roleDelete;

    /**
     * @var binary
     */
    private $file;

    /**
     * @var Attachment
     */
    private $parent;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection();
     */
    private $childrens;

    /**
     * @var boolean
     */
    private $orphan;

    /**
     * Attachment constructor.
     * @param \Doctrine\Common\Collections\ArrayCollection $childrens
     */
    public function __construct()
    {
        $this->childrens = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set filename
     *
     * @param string $filename
     * @return Attachment
     */
    public function setFilename($filename)
    {
        $this->filename = $filename;
    
        return $this;
    }

    /**
     * Get filename
     *
     * @return string
     */
    public function getFilename()
    {
        return $this->filename;
    }

    /**
     * @return string
     */
    public function getFilenameASCII(){
        return mb_convert_encoding($this->filename, 'ASCII');
    }

    /**
     * Set filesize
     *
     * @param integer $filesize
     * @return Attachment
     */
    public function setFilesize($filesize)
    {
        $this->filesize = $filesize;
    
        return $this;
    }

    /**
     * Get filesize
     *
     * @return integer
     */
    public function getFilesize()
    {
        return $this->filesize;
    }

    /**
     * Set filetype
     *
     * @param string $filetype
     * @return Attachment
     */
    public function setFiletype($filetype)
    {
        $this->filetype = $filetype;
    
        return $this;
    }

    /**
     * Get filetype
     *
     * @return string
     */
    public function getFiletype()
    {
        return $this->filetype;
    }

    /**
     * Set data
     *
     * @param string $data
     * @return Attachment
     */
    public function setData($data)
    {
        $this->data = $data;
    
        return $this;
    }

    /**
     * Get data
     *
     * @return string
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * Set digest
     *
     * @param string $digest
     * @return Attachment
     */
    public function setDigest($digest)
    {
        $this->digest = $digest;
    
        return $this;
    }

    /**
     * Get digest
     *
     * @return string
     */
    public function getDigest()
    {
        return $this->digest;
    }

    /**
     * Set downloads
     *
     * @param boolean $downloads
     * @return Attachment
     */
    public function setDownloads($downloads)
    {
        $this->downloads = $downloads;
    
        return $this;
    }

    /**
     * Get downloads
     *
     * @return boolean
     */
    public function getDownloads()
    {
        return $this->downloads;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Attachment
     */
    public function setDescription($description)
    {
        $this->description = $description;
    
        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set entityId
     *
     * @param integer $entityId
     * @return Attachment
     */
    public function setEntityId($entityId)
    {
        $this->entityId = $entityId;
    
        return $this;
    }

    /**
     * Get entityId
     *
     * @return integer
     */
    public function getEntityId()
    {
        return $this->entityId;
    }

    /**
     * Set entityType
     *
     * @param string $entityType
     * @return Attachment
     */
    public function setEntityType($entityType)
    {
        $this->entityType = $entityType;
    
        return $this;
    }

    /**
     * Get entityType
     *
     * @return string
     */
    public function getEntityType()
    {
        return $this->entityType;
    }

    public function readData()
    {
        if (!is_resource($this->getData())) {
            return $this->getData();
        }

        $content = '';
        while (!feof($this->getData())) {
            $content.= fread($this->getData(), 1024);
        }
        rewind($this->getData());
        return $content;
    }

    /**
     * @param mixed $created
     */
    public function setCreated($created)
    {
        $this->created = $created;
    }

    /**
     * @return mixed
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * @param string $roleDelete
     */
    public function setRoleDelete($roleDelete)
    {
        $this->roleDelete = $roleDelete;
    }

    /**
     * @return string
     */
    public function getRoleDelete()
    {
        return $this->roleDelete;
    }

    /**
     * @param string $roleView
     */
    public function setRoleView($roleView)
    {
        $this->roleView = $roleView;
    }

    /**
     * @return string
     */
    public function getRoleView()
    {
        return $this->roleView;
    }

    public function __clone()
    {
        if ($this->id) {
            $this->id = null;
        }
    }

    public function offsetExists($offset)
    {
        return property_exists($this, $offset);
    }

    public function offsetGet($offset)
    {
        return $this->$offset;
    }

    public function offsetSet($offset, $value)
    {
        return false;
    }

    public function offsetUnset($offset)
    {
        return false;
    }

    public function base64_encode($height = null, $quality = null)
    {
        $data = $this->readData();
        if ($height) {
            $image = imagecreatefromstring($data);
            $x = imagesx($image);
            $y = imagesy($image);
            $newY = $height;
            $newX = $x*$newY/$y;
            $newImage = imagecreatetruecolor($newX, $newY);
            imagecopyresampled($newImage, $image, 0, 0, 0, 0, $newX, $newY, $x, $y);
            ob_start();
            imagejpeg($newImage, null, $quality);
            $data =  ob_get_contents();
            ob_end_clean();
            imagedestroy($image);
            imagedestroy($newImage);
        }
        return base64_encode($data);
    }

    /**
     * @return binary
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * @param binary $file
     */
    public function setFile($file)
    {
        $this->file = $file;
    }

    /**
     * @return Attachment
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * @param Attachment $parent
     */
    public function setParent(Attachment $parent)
    {
        $this->parent = $parent;
    }

    /**
     * Add children
     *
     * @param Attachment $attachment
     * @return Attachment
     */
    public function addChildren(Attachment $attachment)
    {
        $attachment->setParent($this);
        $this->childrens[] = $attachment;

        return $this;
    }

    /**
     * Remove children
     *
     * @param Attachment $attachment
     */
    public function removeChildren(Attachment $attachment)
    {
        $this->childrens->removeElement($attachment);
    }

    /**
     * Get avis
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getChildren()
    {
        return $this->childrens;
    }

    /**
     * @return boolean
     */
    public function getOrphan()
    {
        return $this->orphan;
    }

    /**
     * @param boolean $orphan
     */
    public function setOrphan($orphan)
    {
        $this->orphan = $orphan;
    }
}
