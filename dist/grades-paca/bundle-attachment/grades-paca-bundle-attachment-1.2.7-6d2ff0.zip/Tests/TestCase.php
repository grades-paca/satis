<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 03/01/14
 * Time: 16:04
 */

namespace Oru\Bundle\AttachmentBundle\Tests;

use Oru\Bundle\TestBundle\Tests\ModelTestCase;

class TestCase extends ModelTestCase
{
}
