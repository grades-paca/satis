<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\AttachmentBundle\Twig;

use Oru\Bundle\AttachmentBundle\Attachment\AttachmentInterface;
use Oru\Bundle\AttachmentBundle\Attachment\AttachmentTool;

/**
 * Twig listing extension
 *
 * Class ListingExtension
 * @package Oru\Bundle\ListingBundle\Twig
 */
class AttachmentExtension extends \Twig_Extension
{

    /**
     * @var \Twig_Environment
     */
    protected $environment;

    /**
     * @var AttachmentTool
     */
    protected $attachmentTool;

    /**
     * AttachmentExtension constructor.
     * @param AttachmentTool $attachmentTool
     */
    public function __construct(AttachmentTool $attachmentTool)
    {
        $this->attachmentTool = $attachmentTool;
    }


    /**
     * {@inheritDoc}
     */
    public function initRuntime(\Twig_Environment $environment)
    {
        $this->environment = $environment;
    }

    /**
     * {@inheritDoc}
     */
    public function getFunctions()
    {
        return array(
            'attachment_add'                        =>  new \Twig_Function_Method($this, 'attachment_add', array('is_safe' => array('html'))),
            'attachment_add_js'                     =>  new \Twig_Function_Method($this, 'attachment_add_js', array('is_safe' => array('html'))),
            'attachment_list'                       =>  new \Twig_Function_Method($this, 'attachment_list', array('is_safe' => array('html'))),
            'attachment_show'                       =>  new \Twig_Function_Method($this, 'attachment_show', array('is_safe' => array('html'))),
        );
    }

    public function getFilters()
    {
        return array(
            new \Twig_SimpleFilter('bytes2hr', array($this, 'bytes2hr')),
        );
    }

    /**
     * Fonction permettant d'afficher un bouton d'import de pièces jointes
     *
     * @param array $attachments
     * @return string
     */
    public function attachment_add($attachments = array(), $controller = 'OruAttachmentBundle:Attachment:formOrphans', $route = 'oru_attachment_add')
    {
        return $this->environment->render(
            'OruAttachmentBundle:Attachment:index.html.twig',
            array('attachments' => $attachments, 'controller' => $controller, 'route' => $route)
        );
    }

    /**
     * Fonction permettant d'afficher le javascript nécessaire à la fonction attachment_add.
     *
     * @link self::attachment_add
     *
     * @return string
     */
    public function attachment_add_js()
    {
        return $this->environment->render(
            'OruAttachmentBundle:Attachment:index.javascript.twig'
        );
    }

    /**
     * Taille de la pièce jointe dans un format lisible
     *
     * @param $size
     * @param string $unit
     * @return string
     */
    public function bytes2hr($size, $unit="")
    {
        if ((!$unit && $size >= 1<<30) || $unit == "GB") {
            return number_format($size/(1<<30), 2)."GB";
        }
        if ((!$unit && $size >= 1<<20) || $unit == "MB") {
            return number_format($size/(1<<20), 2)."MB";
        }
        if ((!$unit && $size >= 1<<10) || $unit == "KB") {
            return number_format($size/(1<<10), 2)."KB";
        }
        return number_format($size)." bytes";
    }

    /**
     * Fonction permettant d'afficher toutes les pièces jointes liées à une entité
     *
     * @param $entity
     * @param null $role_view
     * @return string
     */
    public function attachment_list($entity, $role_view = null)
    {
        return $this->environment->render(
            'OruAttachmentBundle:Attachment:list.html.twig',
            array('entity' => $entity, 'role_view' => $role_view)
        );
    }

    /**
     * Fonction permettant d'afficher une pièce jointe
     *
     * @param $attachment
     * @param null $entity
     * @return string
     */
    public function attachment_show($attachment, $entity = null)
    {
        if(!$entity) {
            $entity = $this->attachmentTool->getEntityForAttachment($attachment);
        }
        return $this->environment->render(
            'OruAttachmentBundle:Attachment:attachment.html.twig',
            array('attachment' => $attachment, 'entity' => $entity)
        );
    }

    /**
     * {@inheritDoc}
     * @return string
     */
    public function getName()
    {
        return 'attachment_extension';
    }
}
