<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\AttachmentBundle\Attachment;

use Doctrine\Common\Util\ClassUtils;
use Doctrine\ORM\EntityManager;
use Oru\Bundle\AttachmentBundle\Entity\Attachment;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class AttachmentTool
{

    public function __construct(EntityManager $manager)
    {
        $this->em = $manager;
    }

    public function linkEntities(array $attachments = null, $entity, $role_view = 'ROLE_USER', $role_delete = 'ROLE_ADMIN')
    {
        if (!empty($attachments) && method_exists($entity, 'getId')) {
            foreach ($attachments as $id => $details) {
                $attachment = $this->em->getRepository('OruAttachmentBundle:Attachment')->find($id);
                $attachment->setDescription($details['description']);
                $attachment->setEntityId($entity->getId());
                $attachment->setEntityType(ClassUtils::getRealClass(get_class($entity)));
                $attachment->setRoleView($role_view);
                $attachment->setRoleDelete($role_delete);
                $this->em->persist($attachment);
                $this->em->flush();
            }
        }
    }

    public function linkAttachementToEntity(Attachment $attachment, $entity)
    {
        if (method_exists($entity, 'getId')) {
            $attachment->setEntityId($entity->getId());
            $attachment->setEntityType(ClassUtils::getRealClass(get_class($entity)));
            $this->em->persist($attachment);
            $this->em->flush();
        }
    }

    /**
     * @param UploadedFile $file
     * @return Attachment
     */
    public function createAttachmentFromUploadedFile(UploadedFile $file, $description = null, $role_view = null, $role_delete = null)
    {
        $attachment = new Attachment();
        $attachment->setFilename($file->getClientOriginalName());
        $attachment->setFiletype($file->getClientMimeType());
        $attachment->setFilesize($file->getClientSize());
        $attachment->setData(file_get_contents($file->getPathname()));
        $attachment->setDigest(hash_file('md5', $file->getPathname()));
        $attachment->setDownloads(0);
        $attachment->setDescription($description);
        $attachment->setFile($file);
        $attachment->setRoleView($role_view);
        $attachment->setRoleDelete($role_delete);

        return $attachment;
    }


    /**
     * @param UploadedFile $file
     * @return Attachment
     */
    public function createAttachmentFromPath($path, $description = '', $role_view = null, $role_delete = null)
    {
        if ($this->url_exists($path)) {
            $size = $this->curl_get_file_size($path);
            if ($size > 0) {
                $data = file_get_contents($path);
                $attachment = new Attachment();
                $attachment->setFilename(basename($path));
                $attachment->setFiletype(pathinfo($path, PATHINFO_EXTENSION));
                $attachment->setFilesize($size);
                $attachment->setData($data);
                $attachment->setDigest(hash_file('md5', $data));
                $attachment->setDownloads(0);
                $attachment->setDescription($description);
                $attachment->setRoleView($role_view);
                $attachment->setRoleDelete($role_delete);

                return $attachment;
            }
        }

        return false;
    }

    /**
     * @param Attachment $attachment
     * @return object
     */
    public function getEntityForAttachment(Attachment $attachment)
    {
        if ($attachment->getEntityType()) {
            return $this->em->getRepository($attachment->getEntityType())->find($attachment->getEntityId());
        }
        return false;
    }

    /**
     * @param $url
     * @return int|string
     */
    private function curl_get_file_size($url)
    {
        // Assume failure.
        $result = -1;

        $curl = curl_init($url);

        // Issue a HEAD request and follow any redirects.
        curl_setopt($curl, CURLOPT_NOBODY, true);
        curl_setopt($curl, CURLOPT_HEADER, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);

        $data = curl_exec($curl);
        curl_close($curl);

        if ($data) {
            $content_length = "unknown";
            $status = "unknown";

            if (preg_match("/^HTTP\/1\.[01] (\d\d\d)/", $data, $matches)) {
                $status = (int)$matches[1];
            }

            if (preg_match("/Content-Length: (\d+)/", $data, $matches)) {
                $content_length = (int)$matches[1];
            }

            // http://en.wikipedia.org/wiki/List_of_HTTP_status_codes
            if ($status == 200 || ($status > 300 && $status <= 308)) {
                $result = $content_length;
            }
        }

        return $result;
    }

    /**
     * @param $url
     * @return bool|int
     */
    private function url_exists($url)
    {
        $hdrs = @get_headers($url);
        return is_array($hdrs) ? preg_match('/^HTTP\\/\\d+\\.\\d+\\s+2\\d\\d\\s+.*$/', $hdrs[0]) : false;
    }

    /**
     * @param $entity
     * @return array
     * @throws \Exception
     */
    public function getAttachmentsForEntity($entity)
    {
        if (!method_exists($entity, 'getId')) {
            throw new \Exception("$entity id not a valid entity for attachements");
        }

        return $this->em->getRepository('OruAttachmentBundle:Attachment')->findByEntityIdAndEntityType($entity->getId(), ClassUtils::getRealClass(get_class($entity)));
    }

    /**
     * @param $id
     * @return Attachment
     */
    public function getAttachmentById($id)
    {
        return $this->em->getRepository('OruAttachmentBundle:Attachment')->find($id);
    }
}
