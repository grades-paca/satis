<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\AttachmentBundle\Form;

use Oru\Bundle\AttachmentBundle\Attachment\AttachmentTool;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AttachmentType extends AbstractType
{

    private $attachmentTool;

    /**
     * @param AttachmentTool $attachmentTool
     */
    public function __construct(AttachmentTool $attachmentTool)
    {
        $this->attachmentTool = $attachmentTool;
    }

    /**
     * Add the data transformer to the field setting the entity repository
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $entityTransformer = new $options['transformer']($this->attachmentTool, $options['role_view'], $options['role_delete']);
        $builder->addViewTransformer($entityTransformer);
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefined(array('role_view', 'role_delete'));
        $resolver->setDefaults(array(
            'role_view' => null,
            'role_delete' => null,
            'data_class' => 'Oru\Bundle\AttachmentBundle\Entity\Attachment',
            'transformer' => 'Oru\Bundle\AttachmentBundle\Form\DataTransformer\UploadedFileToAttachmentTransformer',
        ));
    }

    /**
     * @param FormView $view
     * @param FormInterface $form
     * @param array $options
     */
    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        $view->vars = array_replace($view->vars, array(
            'type' => 'file',
            'value' => '',
            'attachment' => $form->getViewData(),
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_attachment';
    }

    /**
     * @return null|string|\Symfony\Component\Form\FormTypeInterface
     */
    public function getParent()
    {
        return 'file';
    }
}
