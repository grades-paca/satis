<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\AttachmentBundle\Validator\Constraints;

use Oru\Bundle\AttachmentBundle\Entity\Attachment;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\Constraints\ImageValidator;

class AttachmentImageValidator extends ImageValidator
{

    public function validate($value, Constraint $constraint)
    {
        if (null === $value || '' === $value) {
            return;
        }

        if ($value instanceof Attachment && $value->getFile()) {
            parent::validate($value->getFile(), $constraint);
        }
    }
}
