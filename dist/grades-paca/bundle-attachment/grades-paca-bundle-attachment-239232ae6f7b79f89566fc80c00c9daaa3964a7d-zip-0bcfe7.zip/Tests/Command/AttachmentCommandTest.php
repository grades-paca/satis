<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 23/05/14
 */

namespace Oru\Bundle\AttachmentBundle\Tests\Command;

use Oru\Bundle\AttachmentBundle\Command\CleanCommand;
use Oru\Bundle\TestBundle\Tests\ModelTestCase;
use Symfony\Component\Console\Tester\CommandTester;


class AttachmentCommandTest extends ModelTestCase
{

    public function testExecute()
    {
        $this->_application->add(new CleanCommand());

        $command = $this->_application->find('oru:attachment:clean');
        $commandTester = new CommandTester($command);
        $commandTester->execute(array('command' => $command->getName()));

        $this->assertRegExp('/attachments successfully removed/', $commandTester->getDisplay());
    }

    public function testSinceOneYear()
    {
        $this->_application->add(new CleanCommand());

        $command = $this->_application->find('oru:attachment:clean');
        $commandTester = new CommandTester($command);
        $commandTester->execute(array('command' => $command->getName(), '--since' => '-1 year'));
        $commandTester->getDisplay();

        $this->assertRegExp('/attachments successfully removed/', $commandTester->getDisplay());
    }

    public function testSinceInvalid()
    {
        $this->_application->add(new CleanCommand());
        $this->setExpectedException('InvalidArgumentException');

        $command = $this->_application->find('oru:attachment:clean');
        $commandTester = new CommandTester($command);
        $commandTester->execute(array('command' => $command->getName(), '--since' => 'a long time ago'));
        $commandTester->getDisplay();
    }
}
