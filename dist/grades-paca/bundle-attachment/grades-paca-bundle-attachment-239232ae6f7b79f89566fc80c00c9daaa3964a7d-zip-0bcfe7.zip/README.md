Bundle OruAttachmentBundle
==========================

Description
-----------

Ce bundle fournit une gestion de pièces jointes en ajax au sein d'un formulaire. Une ou plusieurs pièces jointes peuvent être téléchargées simultanément. Elles sont mises en attente de sauvegarde du formulaire pour être ensuite attachées à l'entité. De cette façon, les pièces jointes sont partie intégrante du formulaire et ne polluent pas celui-ci lors de sa sauvegarde, particulièrement en terme de taille de la requête. Néanmoins, si la personne ne sauvegarde pas le formulaire, les pièces jointes ne sont pas ajoutées, ce qui est cohérent. Ce bundle répond aux besoins qui existent aujourd'hui dans le ROR. Les pièces jointes sont pour l'instant stockées en base de données.
Il y a de nombreuses pistes d'améliorations. Par ordre de priorité :
* injecter automatiquement les pièces jointes dans toutes les réponses
* valider la taille et le type des pièces jointes côté client
* améliorer l'interface d'ajout de pièces jointes
* paramètres pour sauvegarde en base ou non
* rattacher des pièces jointes à plusieurs entités

Il manque le nettoyage des pièces jointes qui sont rattachées à aucune entité. Cette partie pourra être réalisée après la création du gestionnaire de tâches : #7300.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/attachment":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\AttachmentBundle\OruAttachmentBundle();
```

Dans le config.yml, importer la configuration de ce bundle :

```
imports:
    ...
    - { resource: @OruAttachmentBundle/Resources/config/config.yml }
    ...
```

Vider le cache de Symfony2

Utilisation
-----------

### Ajouter des pièces jointes

#### Pièce jointe spécifique (logo, plan...)

Utiliser le type de champ 'oru_attachment'.
Les validators associés sont Oru\Bundle\AttachmentBundle\Validator\Constraints\AttachmentFile ou Oru\Bundle\AttachmentBundle\Validator\Constraints\AttachmentImage
et reçoivent respectivement les mêmes paramètres que http://symfony.com/fr/doc/current/reference/constraints/File.html et http://symfony.com/fr/doc/current/reference/constraints/Image.html.

Voici un exemple d'utilisation :

``` php
$builder->add('logo', 'oru_attachment', array('label' => 'Etablissement.logo', 'translation_domain' => 'OruEtablissementBundle', 'role_view' => null, 'role_delete' => 'ORU_ROR_ETABLISSEMENT_EDIT'));
```

Voici un exemple de configuration doctrine associée :

``` xml
<one-to-one field="logo" target-entity="Oru\Bundle\AttachmentBundle\Entity\Attachment">
    <join-columns>
        <join-column name="logo" on-delete="SET NULL" />
    </join-columns>
    <cascade>
        <cascade-persist/>
        <cascade-remove/>
    </cascade>
</one-to-one>
```

L'affichage dans le template peut se faire de cette façon :

``` twig
{% if entity.logo %}
    <img src="data:{{ entity.logo.filetype }};base64,{{ entity.logo.base64_encode }}" class="logo img-responsive" />
{% endif %}
```

ou encore

``` twig
{{ attachment_show(attachment, entity) }}
```

#### Multiples pièces jointes liées à une entité

Deux fonctions twig "attachment_add" et "attachment_add_js" permettent l'ajout des pièces jointes dans votre formulaire :

``` twig
    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}
        {{ attachment_add(attachments) }}
        <input type="submit" name="Submit" />
    {{ form_end(edit_form) }}
```

``` twig
{% block body_js %}
    {{ parent() }}
    {{ attachment_add_js() }}
{% endblock %}
```

La fonction "attachment_add" attend en argument un tableau vide ou des précédentes pièces jointes sauvegardées.
Voici un exemple dans le controller pour un nouveau formulaire (new ou edit) :

``` php
return $this->render('...', array(
    ...
    'attachments'   => array()
));
```

Voici un exemple dans le controller pour un formulaire dont la sauvegarde n'a pas fonctionnée (create ou update) :

``` php
return $this->render('...', array(
    ...
    'attachments'   => $request->get('attachments')
));
```

Si la sauvergarde de l'entité a fonctionné, l'appel au service 'oru_attachment.context' permet de rattacher les pièces jointes à l'entité :

``` php
$this->get('oru_attachment.context')->linkEntities($request->get('attachments'), $entity, $role_view, $role_delete);
```

Ce service attend en paramètre une classe qui implémente la fonction "getId" puis les rôles qui permettrons respectivement de visualiser et supprimer cette pièce jointe. Par défaut, les rôles valent null.

La classe css "bar" permet de modifier l'affichage de la barre de progression.

### Lister les pièces jointes

La fonction twig "attachment_list" permet de lister les pièces jointes liées à une entité. Voici un exemple d'utilisation :

``` twig
{{ attachment_list(entity, role_view) }}
```

Cette fonction attend en paramètre une classe qui implémente la fonction "getId".
Un rôle peut-être transmis qui permettra de masquer les pièces jointes à certains utilisateurs. Par défaut, le rôle vaut null.

Pour toute question : acardoso@orupaca.fr