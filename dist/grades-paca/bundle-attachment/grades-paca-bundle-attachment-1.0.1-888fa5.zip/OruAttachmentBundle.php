<?php

namespace Oru\Bundle\AttachmentBundle;

use Oru\Bundle\AttachmentBundle\DependencyInjection\Compiler\FormPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruAttachmentBundle extends Bundle
{
    public function build(ContainerBuilder $container)
    {
        parent::build($container);
        $container->addCompilerPass(new FormPass());
    }

    /**
     * @author André CARDOSO
     */
    public function boot()
    {
        $collection = $this
            ->container
            ->get('routing.loader')
            ->load(__DIR__.'/Resources/config/routing.yml')
        ;

        $this
            ->container
            ->get('router')
            ->getRouteCollection()
            ->addCollection($collection)
        ;
    }
}
