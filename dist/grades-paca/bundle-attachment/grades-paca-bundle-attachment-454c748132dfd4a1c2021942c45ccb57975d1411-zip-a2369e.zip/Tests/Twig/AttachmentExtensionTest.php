<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 07/01/14
 * Time: 10:34
 */

namespace Oru\Bundle\AttachmentBundle\Tests\Twig;

use Oru\Bundle\AttachmentBundle\Tests\TestCase;
use Oru\Bundle\TestBundle\Entity\ModelObject;

class AttachmentExtensionTest extends TestCase
{

    /**
     * @test
     */
    public function getTemplate()
    {
        $attachmentExtension = $this->get('oru_attachment.twig.extension');

        $attachmentExtension->initRuntime($this->get('twig'));

        $this->assertEquals(array_keys($attachmentExtension->getFunctions()), array(
                'attachment_add',
                'attachment_list',
            )
        );

        $twig_filters_expected = array('bytes2hr');
        $twig_filters = $attachmentExtension->getFilters();

        foreach ($twig_filters as $twig_filter) {
            $this->assertTrue(in_array($twig_filter->getName(), $twig_filters_expected));
        }

//        $this->assertTrue(1 === preg_match('#^<index #', $attachmentExtension->attachment_add()));
//        $this->assertTrue(1 === preg_match('#^<div id="attachments">#', $attachmentExtension->attachment_list(TestFile::saveEntity($this->get('service_container')))));
        $this->assertEquals('1.00KB', $attachmentExtension->bytes2hr(1024));
        $this->assertEquals('1.22KB', $attachmentExtension->bytes2hr(1245));
        $this->assertEquals('1,000.00KB', $attachmentExtension->bytes2hr(1024000));
        $this->assertEquals('1.18MB', $attachmentExtension->bytes2hr(1240000));
        $this->assertEquals('1,000.00MB', $attachmentExtension->bytes2hr(1048576000));
        $this->assertEquals('1.15GB', $attachmentExtension->bytes2hr(1240000000));
        $this->assertEquals('30 bytes', $attachmentExtension->bytes2hr(30));
    }
}
