<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 03/01/14
 * Time: 16:43
 */

namespace Oru\Bundle\AttachmentBundle\Tests;

use Doctrine\Common\Util\ClassUtils;
use Oru\Bundle\AttachmentBundle\Tests\Tool\TestFile;

class OruAttachmentBundleTest extends TestCase
{
    /**
     * @test
     */
    public function serviceContext()
    {
        $attachmentTool = $this->getMockBuilder('Oru\Bundle\AttachmentBundle\Attachment\AttachmentTool')
            ->disableOriginalConstructor()
            ->getMock()
        ;

        $container = $this->createMock('Symfony\Component\DependencyInjection\ContainerInterface');

        $container
            ->expects($this->once())
            ->method('get')
            ->with('oru_attachment.context')
            ->will($this->returnValue($attachmentTool))
        ;

        $container->get('oru_attachment.context');
    }

    /**
     * @test
     */
    public function saveUploadedFile()
    {
        $attachment = TestFile::saveFile($this->get('service_container'));

        $this->assertTrue(strlen(TestFile::CONTENT) === $attachment->getFilesize());
    }

    /**
     * @test
     */
    public function attachToEntity()
    {
        $modelObject = TestFile::saveEntity($this->get('service_container'));

        $attachments = $this->linkEntities($modelObject);

        $this->assertTrue(count($attachments) > 0);

        /** @var \Oru\Bundle\AttachmentBundle\Entity\Attachment $attachment */
        foreach ($attachments as $attachment) {
            $this->assertTrue($modelObject->getId() === $attachment->getEntityId());
        }
    }

    /**
     * @test
     */
    public function integrityOfSavedAttachment()
    {
        $modelObject = TestFile::saveEntity($this->get('service_container'));

        $attachments = $this->linkEntities($modelObject);

        $test_path_absolute = sprintf('%s/%s', TestFile::PATH, TestFile::NAME);

        $this->assertTrue(count($attachments) > 0);

        foreach ($attachments as $attachment) {
            $this->assertSame(TestFile::NAME, $attachment->getFilename());
            $this->assertSame('text/plain', $attachment->getFiletype());
//            $this->assertEquals(STATIC::TEST_CONTENT, $attachment->getData());
            $this->assertSame(hash_file('md5', $test_path_absolute), $attachment->getDigest());
            $this->assertSame(0, $attachment->getDownloads());
            $this->assertSame('test', $attachment->getDescription());
            $this->assertSame(ClassUtils::getRealClass($modelObject), $attachment->getEntityType());
            $this->assertSame(TestFile::CONTENT, $attachment->readData());
        }
    }

    protected function linkEntities($modelObject)
    {
        TestFile::saveFile($this->get('service_container'));

        $em = $this->get('doctrine')->getManager();

        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findAll();

        $attachment_array = array();
        /** @var \Oru\Bundle\AttachmentBundle\Entity\Attachment $attachment */
        foreach ($attachments as $attachment) {
            $attachment_array[$attachment->getId()] = array('description' => 'test');
        }

        $this->get('oru_attachment.context')->linkEntities($attachment_array, $modelObject);

        return $attachments;
    }
}
