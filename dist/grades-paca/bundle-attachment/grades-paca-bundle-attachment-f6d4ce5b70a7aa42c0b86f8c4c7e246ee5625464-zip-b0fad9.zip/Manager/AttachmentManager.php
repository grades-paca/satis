<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\AttachmentBundle\Manager;

use Doctrine\ORM\EntityManager;
use Oru\Bundle\AttachmentBundle\Attachment\AttachmentTool;
use Oru\Bundle\AttachmentBundle\Entity\Attachment;

class AttachmentManager extends AttachmentTool
{
    private $cacheDir;

    public static $mimes_types_image = array(
        'image/jpeg',
        'image/pjpeg',
        'image/jpg',
        'image/png',
        'image/x-png',
        'image/x-citrix-png',
        'image/x-citrix-jpeg',
        'image/x-citrix-pjpeg'
    );

    public static $mimes_types_video = array(
        'video/ogg',
        'video/mp4',
        'video/webm',
        'video/quicktime',
        'video/avi',
        'video/x-msvideo'
    );

    /**
     * @param EntityManager $manager
     */
    public function __construct(EntityManager $manager)
    {
        $this->em = $manager;

    }

    /**
     * @param $cacheDir
     */
    public function setCacheDir($cacheDir)
    {
        $this->cacheDir = $cacheDir;
        if(!is_dir($this->cacheDir)) {
            mkdir($this->cacheDir);
        }
    }

    /**
     * @return string
     */
    public function getCacheDir()
    {
        return $this->cacheDir;
    }

    /**
     * @param Attachment $attachment
     * @return array
     */
    public function encodeVideo(Attachment $attachment)
    {
        $newAttachments = array();
        $fileIn = $this->cacheDir.'/' . $attachment->getFilename();
        file_put_contents($fileIn, $attachment->getData());

        // others
        $fileIn = $this->cacheDir.'/' . $attachment->getFilename();
        $fileOut = $this->cacheDir . '/' . preg_replace('/\\.[^.\\s]{3,4}$/', '', $attachment->getFilename()) . '_child.webm';

        $rotation = null;
        $result = shell_exec('which mediainfo');
        if(!empty($result)) {
            preg_match("/([0-9]+)/",shell_exec("mediainfo $fileIn |grep Rotation"), $matches);
            if(isset($matches[1]) && intval($matches[1])) {
                $rotation = intval($matches[1]);
                switch ($rotation) {
                    case '90' :
                    case '270' :
                        $rotation = '-vf "transpose=1"';
                        break;
                    case '180' :
                        $rotation = '-vf "transpose=2"';
                        break;

                    default:
                        $rotation = '';
                }
            }
        }

        $cmd = 'avconv -y -i "' . $fileIn . '" -vcodec libvpx -acodec libvorbis -b:v 1M ' . $rotation . ' "' . $fileOut . '"';
        echo "$cmd\n";
        exec($cmd);
        $newAttachment = $this->createAttachmentFromPath($fileOut, $attachment->getDescription(), $attachment->getRoleView(), $attachment->getRoleDelete());
        if($newAttachment) {
            $newAttachment->setParent($attachment);
            $newAttachment->setEntityId($attachment->getEntityId());
            $newAttachment->setEntityType($attachment->getEntityType());
            $newAttachments[] = $newAttachment;
        }
        if(file_exists($fileOut)) {
            unlink($fileOut);
        }

        // ie and safari
        $fileOut = $this->cacheDir . '/' . preg_replace('/\\.[^.\\s]{3,4}$/', '', $attachment->getFilename()) . '_child.mp4';
        $cmd = 'avconv -y -i "' . $fileIn . '" -c:v libx264 -profile:v baseline -strict experimental -ar 44100 ' . $rotation . ' "' . $fileOut . '"';
        echo "$cmd\n";
        exec($cmd);
        $newAttachment = $this->createAttachmentFromPath($fileOut, $attachment->getDescription(), $attachment->getRoleView(), $attachment->getRoleDelete());
        if($newAttachment) {
            $newAttachment->setParent($attachment);
            $newAttachment->setEntityId($attachment->getEntityId());
            $newAttachment->setEntityType($attachment->getEntityType());
            $newAttachments[] = $newAttachment;
        }
        if(file_exists($fileOut)) {
            unlink($fileOut);
        }

        if(file_exists($fileIn)) {
            unlink($fileIn);
        }

        return $newAttachments;
    }

    /**
     * @param $path
     * @param string $description
     * @param null $role_view
     * @param null $role_delete
     * @return bool|Attachment
     */
    public function createAttachmentFromPath($path, $description = '', $role_view = null, $role_delete = null)
    {
        if (file_exists($path)) {
            $size = filesize($path);
            if ($size > 0) {
                $data = file_get_contents($path);
                $attachment = new Attachment();
                $attachment->setFilename(basename($path));
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $attachment->setFiletype(finfo_file($finfo, $path));
                finfo_close($finfo);
                $attachment->setFilesize($size);
                $attachment->setData($data);
                $attachment->setDigest(hash('md5', $data));
                $attachment->setDownloads(0);
                $attachment->setDescription($description);
                $attachment->setRoleView($role_view);
                $attachment->setRoleDelete($role_delete);

                return $attachment;
            }
        }

        return false;
    }
}
