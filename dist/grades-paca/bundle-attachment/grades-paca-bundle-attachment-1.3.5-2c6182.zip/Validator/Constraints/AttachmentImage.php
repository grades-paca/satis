<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */
namespace Oru\Bundle\AttachmentBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraints\Image;

class AttachmentImage extends Image
{
}
