<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\AttachmentBundle\Controller;

use Oru\Bundle\AttachmentBundle\Entity\Attachment;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\Security\Core\Util\ClassUtils;

class AttachmentController extends Controller
{
    public function addAction(Request $request)
    {
        $files = $request->files->get('files');
        $attachments = array();
        if (!empty($files)) {
            foreach ($request->files->get('files') as $file) {
                if ($file instanceof UploadedFile) {
                    $attachment = $this->get('oru_attachment.context')->createAttachmentFromUploadedFile($file);

                    $em = $this->getDoctrine()->getManager();
                    $em->persist($attachment);
                    $em->flush();

                    $attachments[] = $attachment;
                }
            }
        }

        return
            $this->render('OruAttachmentBundle:Attachment:form_attachments.html.twig', array(
                'attachments' => $attachments
            ));
    }

    public function deleteAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();
        $attachment = $em->getRepository('OruAttachmentBundle:Attachment')->find($id);

        if (!$attachment) {
            throw $this->createNotFoundException("No attachment found for id : $id.");
        }

        if ($attachment->getRoleDelete() != '' && false === $this->get('security.authorization_checker')->isGranted($attachment->getRoleDelete(), $this->get('oru_attachment.context')->getEntityForAttachment($attachment))) {
            throw new AccessDeniedException('Unable to access this page!');
        }

        $em->remove($attachment);
        $em->flush();

        $response = new Response(json_encode('success'));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    public function listAction(Request $request, $entity, $role_view)
    {
        if ($role_view != '' && false === $this->get('security.authorization_checker')->isGranted($role_view, $entity)) {
            throw new AccessDeniedException('Unable to access this page!');
        }

        $em = $this->getDoctrine()->getManager();
        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findByEntityIdAndEntityType($entity->getId(), ClassUtils::getRealClass(get_class($entity)));

        return
            $this->render('OruAttachmentBundle:Attachment:list_attachments.html.twig', array(
                'attachments' => $attachments,
                'entity' => $entity,
                'role_view' => $role_view
            ));
    }

    public function formOrphansAction(Request $request, $attachments)
    {
        $em = $this->getDoctrine()->getManager();
        $attachments_entities = array();
        if (!empty($attachments)) {
            foreach ($attachments as $id => $details) {
                $attachment = $em->getRepository('OruAttachmentBundle:Attachment')->find($id);
                if ($attachment instanceof Attachment) {
                    $attachment->setDescription($details['description']);
                    $attachments_entities[] = $attachment;
                }
            }
        }

        return
            $this->render('OruAttachmentBundle:Attachment:form_attachments.html.twig', array(
                'attachments' => $attachments_entities
            ));
    }

    public function downloadAction(Request $request, $id, $inline = false)
    {
        $em = $this->getDoctrine()->getManager();
        $attachment = $em->getRepository('OruAttachmentBundle:Attachment')->find($id);

        if ($attachment->getRoleView() != '' && false === $this->get('security.authorization_checker')->isGranted($attachment->getRoleView(), $this->get('oru_attachment.context')->getEntityForAttachment($attachment))) {
            throw new AccessDeniedException('Unable to access this page!');
        }

        $attachment->setDownloads(((int) $attachment->getDownloads()) + 1);
        $em->flush();

        $response = new Response();
        $response->headers->set('Content-Type', $attachment->getFiletype());
        $response->headers->set('Content-Disposition', (($inline) ? 'inline' : 'attachment') . ';filename="'.$attachment->getFilename());
        $response->setContent($attachment->readData());

        return $response;
    }

    public function uploadMaxFilesizeAction(Request $request)
    {
        return new Response($this->get('translator')->trans("attachment.upload_max_filesize", array('%max%' => ini_get('upload_max_filesize')), 'OruAttachmentBundle'));
    }

    public function galleryAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();
        $first = $em->getRepository('OruAttachmentBundle:Attachment')->find($id);
        $attachments = $em->getRepository('OruAttachmentBundle:Attachment')->findByEntityIdAndEntityType($first->getEntityId(), $first->getEntityType());

        $tm = array(
            'image/jpeg',
            'image/pjpeg',
            'image/jpg',
            'image/png',
            'image/x-png',
            'image/x-citrix-png',
            'image/x-citrix-jpeg',
            'image/x-citrix-pjpeg'
        );
        $am = $this->get('oru_attachment.context');
        $sc = $this->get('security.authorization_checker');

        $displayables = array();
        foreach ($attachments as $att) {
            $entity = $em->getRepository('OruAttachmentBundle:Attachment')->find($att['id']);
            $view = $entity->getRoleView() == '' || $sc->isGranted($entity->getRoleView(), $am->getEntityForAttachment($entity));
            if (array_search($entity->getFiletype(), $tm) !== false && $view) {
                $displayables[] = $entity;
            }
        }

        return
            $this->render('OruAttachmentBundle:Attachment:gallery.html.twig', array(
                'attachments' => $displayables
            ));
    }
}
