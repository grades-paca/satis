<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 17/12/13
 * Time: 07:48
 */

namespace Oru\Bundle\ListingBundle\Tests;

class OruListingBundleTest extends TestCase
{
    /**
     * @test
     */
    public function serviceRegistry()
    {
        $listingRegistry = $this->getMockBuilder('Oru\Bundle\ListingBundle\Listing\ListingRegistry')
            ->disableOriginalConstructor()
            ->getMock()
        ;

        $container = $this->createMock('Symfony\Component\DependencyInjection\ContainerInterface');

        $container
            ->expects($this->once())
            ->method('get')
            ->with('listing.registry')
            ->will($this->returnValue($listingRegistry))
        ;

        $container->get('listing.registry');
    }

    /**
     * @test
     */
    public function serviceFactory()
    {
        $listingRegistry = $this->getMockBuilder('Oru\Bundle\ListingBundle\Listing\ListingFactory')
            ->disableOriginalConstructor()
            ->getMock()
        ;

        $container = $this->createMock('Symfony\Component\DependencyInjection\ContainerInterface');

        $container
            ->expects($this->once())
            ->method('get')
            ->with('listing.factory')
            ->will($this->returnValue($listingRegistry))
        ;

        $container->get('listing.factory');
    }
}
