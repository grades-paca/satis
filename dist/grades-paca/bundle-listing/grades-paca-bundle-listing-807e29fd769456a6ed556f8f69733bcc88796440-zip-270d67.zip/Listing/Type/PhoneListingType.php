<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing\Type;

use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class PhoneListingType.
 */
class PhoneListingType extends BaseAbstractListingType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $this->getOptionsResolver()->setDefined(array('attr', 'phone_type'));
        $resolver->setDefaults(array('template' => '@OruListing/Listing/Type/listing_phone_type.html.twig', 'phone_type' => 'NATIONAL'));
    }

    public function getPhoneType()
    {
        return (isset($this->options['phone_type'])) ? $this->options['phone_type'] : null;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'tel';
    }
}
