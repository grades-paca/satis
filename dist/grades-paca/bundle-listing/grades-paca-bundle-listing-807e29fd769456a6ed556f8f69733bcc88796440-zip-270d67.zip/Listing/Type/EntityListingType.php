<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing\Type;

use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class EntityListingType.
 */
class EntityListingType extends BaseAbstractListingType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setRequired(array('name', 'class', 'template'));
        $resolver->setDefined(array('label', 'multiple', 'em', 'important'));
        $resolver->setDefaults(array('template' => '@OruListing/Listing/Type/listing_text_type.html.twig'));
    }

    public function getTemplate()
    {
        if (isset($this->options['multiple']) && $this->options['multiple'] && $this->options['template'] === '@OruListing/Listing/Type/listing_text_type.html.twig') {
            return '@OruListing/Listing/Type/listing_collection_type.html.twig';
        }
        return $this->options['template'];
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        if (isset($this->options['multiple']) && $this->options['multiple']) {
            return 'collection';
        }
        return 'text';
    }
}
