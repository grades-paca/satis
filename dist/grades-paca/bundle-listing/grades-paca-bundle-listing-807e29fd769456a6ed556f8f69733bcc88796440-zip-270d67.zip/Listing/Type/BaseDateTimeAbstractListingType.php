<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing\Type;

use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Base class for date and time types.
 *
 * Class BaseDateTimeAbstractListingType
 */
class BaseDateTimeAbstractListingType extends BaseAbstractListingType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setRequired(array('format', 'name', 'template'));
        $resolver->setDefined(array('label', 'widget', 'date_widget', 'time_widget', 'important'));
        $resolver->setDefaults(array('template' => '@OruListing/Listing/Type/listing_datetime_type.html.twig'));
    }

    /**
     * The format of this DateTime field.
     *
     * @return string The format
     */
    public function getFormat()
    {
        return $this->options['format'];
    }
}
