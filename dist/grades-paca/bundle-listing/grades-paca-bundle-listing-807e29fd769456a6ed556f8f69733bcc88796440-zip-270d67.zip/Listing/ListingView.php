<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing;

use Symfony\Component\Form\Exception\BadMethodCallException;

class ListingView implements \ArrayAccess, \IteratorAggregate, \Countable, ListingViewInterface
{
    /**
     * @var array
     */
    public $children = array();

    /**
     * @var array
     */
    public $object_actions = array();

    /**
     * @var array
     */
    public $list_actions = array();

    /**
     * @var array
     */
    public $batch_actions = array();

    /**
     * @var ListingInterface
     */
    private $listing;

    /**
     * @var bool
     */
    private $locked = false;

    /**
     * @var array
     */
    private $columns = array();

    /**
     * Saves Listing for this ListingView.
     *
     * @param ListingInterface $config
     */
    public function __construct(ListingInterface $listing)
    {
        $this->listing = $listing;
    }

    /**
     * {@inheritdoc}
     */
    public function getIterator()
    {
        if ($this->locked) {
            return new \ArrayIterator($this->columns);
        }
        throw new BadMethodCallException('ListingView has not yet been built.');
    }

    /**
     * {@inheritdoc}
     */
    public function offsetExists($name)
    {
        if ($this->locked) {
            return isset($this->columns[$name]);
        }
        throw new BadMethodCallException('ListingView has not yet been built.');
    }

    /**
     * {@inheritdoc}
     */
    public function offsetGet($name)
    {
        if ($this->locked) {
            return $this->columns[$name];
        }
        throw new BadMethodCallException('ListingView has not yet been built.');
    }

    /**
     * {@inheritdoc}
     */
    public function offsetSet($offset, $value)
    {
        throw new BadMethodCallException('Not supported');
    }

    /**
     * {@inheritdoc}
     */
    public function offsetUnset($name)
    {
        if ($this->locked) {
            unset($this->columns[$name]);
        } else {
            throw new BadMethodCallException('ListingView has not yet been built.');
        }
    }

    /**
     * {@inheritdoc}
     */
    public function count()
    {
        if ($this->locked) {
            return count($this->columns);
        }
        throw new BadMethodCallException('ListingView has not yet been built.');
    }

    /**
     * {@inheritdoc}
     */
    public function buildView()
    {
        // count object actions
        foreach ($this->children as $name => $field) {
            switch ($field->getName()) {
                case 'list_action':
                    $this->list_actions[$name] = $field;
                    break;
                case 'batch_action':
                    $this->batch_actions[$name] = $field;
                    break;
                case 'object_action':
                    $this->object_actions[$name] = $field;

                default:
                    $this->columns[$name] = $field;
                    break;
            }
            unset($this->children[$name]);
        }

        $this->locked = true;
    }

    /**
     * {@inheritdoc}
     */
    public function getTemplate($name)
    {
        return $this->getListing()->getTemplate($name);
    }

    /**
     * {@inheritdoc}
     */
    public function getListing()
    {
        return $this->listing;
    }

    /**
     * {@inheritdoc}
     */
    public function countObjectActions()
    {
        return count($this->object_actions);
    }

    /**
     * {@inheritdoc}
     */
    public function countListActions()
    {
        return count($this->list_actions);
    }

    /**
     * {@inheritdoc}
     */
    public function countBatchActions()
    {
        return count($this->batch_actions);
    }
}
