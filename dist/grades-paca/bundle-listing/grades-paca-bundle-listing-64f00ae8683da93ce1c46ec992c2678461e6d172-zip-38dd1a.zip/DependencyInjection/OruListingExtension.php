<?php

namespace Oru\Bundle\ListingBundle\DependencyInjection;

use Symfony\Component\Config\Definition\Processor;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\HttpKernel\DependencyInjection\Extension;
use Symfony\Component\DependencyInjection\Loader;

/**
 * This is the class that loads and manages your bundle configuration
 *
 * To learn more see {@link http://symfony.com/doc/current/cookbook/bundles/extension.html}
 */
class OruListingExtension extends Extension
{
    /**
     * {@inheritDoc}
     */
    public function load(array $configs, ContainerBuilder $container)
    {
        $processor = new Processor();

        $loader = new Loader\XmlFileLoader($container, new FileLocator(__DIR__.'/../Resources/config'));
        $loader->load('services.xml');

        $configuration = new Configuration();
        $config = $processor->processConfiguration($configuration, $configs);

        $container->setParameter('oru_listing.template.listing', $config['template']['listing']);
        $container->setParameter('oru_listing.template.listing_header', $config['template']['listing_header']);
        $container->setParameter('oru_listing.template.listing_core', $config['template']['listing_core']);
        $container->setParameter('oru_listing.template.listing_table_header', $config['template']['listing_table_header']);
        $container->setParameter('oru_listing.template.listing_table_body', $config['template']['listing_table_body']);
        $container->setParameter('oru_listing.template.listing_table_footer', $config['template']['listing_table_footer']);
        $container->setParameter('oru_listing.template.listing_core_footer', $config['template']['listing_core_footer']);
        $container->setParameter('oru_listing.template.listing_footer', $config['template']['listing_footer']);
        $container->setParameter('oru_listing.template.listing_filter', $config['template']['listing_filter']);
        $container->setParameter('oru_listing.template.listing_and_filter', $config['template']['listing_and_filter']);
    }
}
