<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing;


interface ListingConfigInterface {

    /**
     * Resolve the unresolvedChildren's into the children's and empties unresolvedChildren.
     *
     */
    public function resolveChildren();

    /**
     * Clones and returns the current ListingConfig
     *
     * @return ListingConfigInterface
     */
    public function getListingConfig();

    /**
     * Returns the template associated to a twig list block, use the factory to resolve that.
     *
     * @param $name string      The alias of the template
     * @return string           The template
     */
    public function getTemplate($name);

    /**
     * Set the template associated to a twig list block in the factory.
     *
     * @param $name string      The alias of the template
     * @param $value string     The template
     */
    public function setTemplate($name, $value);

    /**
     * Get the listing class in the factory.
     *
     * @return string           The data class
     */
    public function getListingClass();

    /**
     * Returns the current data.
     *
     * @return array
     */
    public function getData();
} 