<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Oru\Bundle\ListingBundle\Listing\ListingInterface;
use Oru\Bundle\ListingBundle\Listing\ListingTypeInterface;
use Oru\Bundle\ListingBundle\Listing\ListingView;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Abstract type
 *
 * Class AbstractListingType
 * @package Oru\Bundle\ListingBundle\Listing
 */
abstract class AbstractListingType implements ListingTypeInterface
{
    /**
     * @var array
     */
    public $attributes = array();

    /**
     * @var array
     */
    protected $options = array();

    /**
     * @var OptionsResolver
     */
    private $optionsResolver = null;

    /**
     * Initialize options for this abstract type.
     *
     * @param array $options
     */
    public function __construct($options = array())
    {
        $this->configureOptions($this->getOptionsResolver());
        $this->options = $this->getOptionsResolver()->resolve($options);
    }

    /**
     * {@inheritdoc}
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function buildView(ListingView $view, ListingInterface $listing)
    {
        return $this;
    }
    /**
     * {@inheritdoc}
     */
    public function getOptionsResolver()
    {
        if($this->optionsResolver === null) {
            $this->optionsResolver = new OptionsResolver();
            $this->configureOptions($this->optionsResolver);
        }

        return $this->optionsResolver;
    }

    /**
     * {@inheritdoc}
     */
    abstract public function getName();

    /**
     * {@inheritdoc}
     */
    abstract public function configureOptions(OptionsResolver $resolver);
}