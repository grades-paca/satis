<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 16/12/13
 * Time: 14:25
 */

namespace Oru\Bundle\ListingBundle\Tests\Listing;

use Oru\Bundle\ListingBundle\Listing\ListingRegistryInterface;
use Oru\Bundle\ListingBundle\Tests\TestCase;
use Oru\Bundle\ListingBundle\Tests\Tool\TypeAvailable;

class ListingRegistryTest extends TestCase
{
    /**
     * @var \Oru\Bundle\ListingBundle\Tests\Tool\TypeAvailable
     */
    private $typeAvailable;

    public function setUp()
    {
        $this->typeAvailable = new TypeAvailable();

        parent::setUp();
    }

    /**
     * @test
     */
    public function createListingRegistry()
    {
        $listingRegistry = $this->container->get('listing.registry');

        $this->assertTrue($listingRegistry instanceof ListingRegistryInterface);

        $this->assertInstanceOf('Symfony\Component\Form\FormTypeGuesserInterface', $listingRegistry->getTypeGuesser());
    }

    /**
     * @test
     * @dataProvider provideImplementedTypes
     *
     * @param mixed $type
     * @param mixed $type_class
     */
    public function getImplementedTypes($type, $type_class)
    {
        $listingRegistry = $this->container->get('listing.registry');

        // Est-ce que le type est bien supporté
        $this->assertTrue($listingRegistry->hasType($type));

        // Est-ce que ce type retourne bien la classe attendue
        $this->assertInstanceOf(
            $type_class,
            $listingRegistry->getType(
                'test',
                $type,
                null,
                $this->typeAvailable->getOptionRequired($type)
            )
        );

        // Les classes ListingType doivent implémenter ListingTypeInterface
        $this->assertInstanceOf(
            'Oru\Bundle\ListingBundle\Listing\ListingTypeInterface',
            $listingRegistry->getType(
                'test',
                $type,
                null,
                $this->typeAvailable->getOptionRequired($type)
            )
        );
    }

    public function provideImplementedTypes()
    {
        $this->setUp();

        $return = array();
        foreach ($this->typeAvailable->getTypes() as $type) {
            $return[] = array($type, $this->typeAvailable->getTypeClass($type));
        }

        return $return;
    }

    /**
     * @test
     */
    public function getAnInvalidType()
    {
        $listingRegistry = $this->container->get('listing.registry');

        $listingRegistry->getType('test', 'string');
    }

    /**
     * @test
     * @dataProvider provideInvalidString
     *
     * @param mixed $invalidString
     */
    public function getNotStringType($invalidString)
    {
        $listingRegistry = $this->container->get('listing.registry');

        $listingRegistry->getType('test', $invalidString);
    }

    public function provideInvalidString()
    {
        return array(
            array(5),
            array(new \SplObjectStorage()),
            array(true),
            array(false),
            array(null),
            array(array()),
        );
    }
}
