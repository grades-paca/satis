OruListingBundle
================

Description
-----------

Ce bundle fournit une interface de gestion de tableaux d'entités, les entités sont pour l'instant basées sur Doctrine.
Il est possible de créer des actions par entité, des actions groupées sur plusieurs entités ou des actions globales.
Chaque information est affichée via des templates twig qu'il est possible de surcharger. Chaque colonne peut aussi avoir un template spécifique.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/listing":dev-master
```

Dans le AppKernel.php, activer ce bundle

``` php
$bundles[] = new Oru\Bundle\ListingBundle\OruListingBundle();
```

Vider le cache de Symfony2

Utilisation
-----------

### Le model

Ce bundle fournit une interface "ListingTypeInterface" qui permet de stocker les attributs d'une entité Doctrine qu'il faudra afficher sous forme de tableau.
Sur le même principe que les forms, l'appel à la fonction "buildListing" permet d'ajouter des champs au builder fourni en paramètre.
En plus des champs disponibles dans l'entité, il est possible d'ajouter :
    des actions par entité via le type "object_action",
    des actions groupées sur plusieurs entités via le type "batch_action",
    des actions globales via le type "list_action".

Liste des options disponibles par défaut (chaque type de champ peut proposer de nouvelles options) :


#### - important

```
Masque les colonnes en dessous d'une certaines largeur en utilisant les classes hidden-xs et hidden-sm.
```

#### - template

```
Template à utiliser pour afficher ce champ
```

#### - label et translation_domain

```
Libellé utilisé pour la colonne
```


Voici un exemple d'utilisation :

``` php
namespace Oru\Bundle\RepertoireBundle\Listing;

use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class DepartementListingType extends AbstractListingType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('no')
            ->add('libelle')
            ->add('mail')
            ->add('edit', 'object_action', array('route' => 'departement_edit', 'role' => 'ROLE_DEPARTEMENT_EDIT'))
            ->add('show', 'object_action', array('route' => 'departement_show'))
            ->add('new', 'list_action', array('route' => 'departement_new'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\RepertoireBundle\Entity\Departement',
            'role' => 'ROLE_DEPARTEMENT_VIEW',
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_repertoirebundle_departementlisting';
    }
}
```

### Le contrôleur

La création d'une liste est possible via le 'ListingFactory'. Ce factory peut être instancié via le service "listing.factory".
L'appel à la fonction create du factory en fournissant notre objet de type "ListingTypeInterface" et les données à afficher renvoie une liste à afficher, un objet implémentant "ListingInterface".
Voici un exemple d'utilisation dans un controller :

``` php
$listing = $this->container->get('listing.factory')->create(new DepartementListingType(), $entities, $options);
```

### Les templates

Cette liste (ou objet implémentant "ListingInterface") s'affiche dans un template en utilisant la fonction twig "listing".

Voici l'arborescence des templates utilisés par la fonction twig "listing" :

```
listing : defaultListingTemplate
    listing header : defaultListingHeaderTemplate
    listing core : defaultListingCoreTemplate
        table header : defaultListingTableHeaderTemplate
        table body : defaultListingTableBodyTemplate
        table footer : defaultListingTableFooterTemplate
        core footer : defaultListingCoreFooterTemplate
    listing footer : defaultListingFooterTemplate
```

Chaque template peut être redéfini en utilisant la fonction setTemplate de cette liste :

``` php
$listing->setTemplate('defaultListingTableHeaderTemplate', '@OruPaginator/listing_table_header.html.twig');
```

Il sera possible très facilement de compléter cette arborescence pour être plus exhaustif.

Pour chaque colonne à afficher, un template de base est utilisé. Tous les templates peuvent être surchargés directement lors de la construction du tableau, dans la fonction "buildListing" évoquée ci-dessus.
Voici comment surcharger le template de la colonne libelle d'une entité département :

``` php
public function buildListing(ListingBuilderInterface $builder)
{
    $builder
        ->add('no')
        ->add('libelle', null, array('template' => '@OruRepertoire/Departement/listing_departement_libelle.html.twig')
        ->add('mail')
        ->add('edit', 'object_action', array('route' => 'departement_edit'))
        ->add('show', 'object_action', array('route' => 'departement_show'))
        ->add('new', 'list_action', array('route' => 'departement_new'))
    ;
}
```

### Filtres et listing

La nouvelle fonction twig listing_and_filter(Listing, FormView, path=null, template=null) permet d'afficher une page responsive contenant la liste des élements et les filtres du formulaire.

### Divers

Des exemples d'utilisation de ce bundle sont disponibles dans les bundles OruPaginatorBundle et OruCrudBundle.
Certains types de champs Doctrine ne sont pas encore gérés par ce bundle. Il faudra les ajouter au cas par cas.
A terme, il sera pertinent de pouvoir surcharger la construction d'un type de champ, les classes situées dans ListingBundle/Listing/Type.


### Trier les listes

``` php
'sort' => 'identifiant.Field'
```

Exemple dans  Oru\Bundle\PdsEsBundle\Listing\PdsEsInstanceListingType :

``` php
            ->add('Etablissements', 'collection', array('sort' => 'e.nom', 'label' => 'PdsEs.etablissement', 'translation_domain' => 'OruPdsEsBundle'))
            ->add('PdsEsType', null, array('sort' => 't.libelle', 'label' => 'listing.PdsEsType', 'translation_domain' => 'OruPdsEsBundle'))
            ->add('PdsEsMode', null, array('sort' => 'm.libelle', 'label' => 'listing.PdsEsMode', 'translation_domain' => 'OruPdsEsBundle'))
            ->add('created', null, array('sort' => 'u.created', 'label' => 'listing.created', 'translation_domain' => 'OruPdsEsBundle'))
            ->add('updated', null, array('sort' => 'u.updated', 'label' => 'listing.updated', 'translation_domain' => 'OruPdsEsBundle'))
```

A savoir que les identifiants sont dans le repository (il faut ajouter une jointure pour certains cas) :

``` php
$builder = $this->createQueryBuilder("u");
        $builder
            ->innerJoin('u.PdsEs', 'p')
            ->innerJoin('p.Etablissement', 'e')
            ->innerJoin('p.PdsEsType', 't')
            ->innerJoin('u.PdsEsMode', 'm')
        ;
```

Attention, les order dans le repository sont à supprimer pour que ça fonctionne correctement.
A la place il faut rajouter dans le linstingType:

``` php
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\PdsEsBundle\Entity\PdsEsMode',
            'defaultSortFieldName' => 'u.rank'
        ));
    }
```
