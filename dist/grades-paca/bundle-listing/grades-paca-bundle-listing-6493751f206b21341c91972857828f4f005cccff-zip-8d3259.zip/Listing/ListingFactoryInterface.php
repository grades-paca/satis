<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing;

/**
 * Interface ListingFactoryInterface.
 */
interface ListingFactoryInterface
{
    /**
     * Returns a listing.
     *
     * @param string | AbstractListingType $type    The type of the list
     * @param mixed                        $data    The initial data
     * @param array                        $options The options
     *
     * @return ListingInterface the listing
     */
    public function create($type, $data = null, array $options = array());

    /**
     * Returns the options resolver.
     *
     * @return OptionsResolver
     */
    public function getOptionsResolver();

    /**
     * Returns a AbstractListingType associated to a field.
     *
     * @param string                     $name    The name of the field
     * @param string|AbstractListingType $type    The type of the field
     * @param mixed                      $data    The initial data
     * @param array                      $options The options
     *
     * @throws \Symfony\Component\OptionsResolver\Exception\UndefinedOptionsException if any given option is not applicable to the given type
     *
     * @return AbstractListingType the AbstractListingType associated to $name field
     */
    public function getType($name, $type, $data, $options);

    /**
     * Returns a AbstractListingType associated to a field using the registry guesser.
     *
     * @param string $class    The fully qualified class name (data_class)
     * @param string $property The name of the property to guess for
     * @param mixed  $data     The initial data
     * @param array  $options  The options for this field
     *
     * @return AbstractListingType the AbstractListingType associated to $name field
     */
    public function getTypeForProperty($class, $property, $data = null, array $options = array());

    /**
     * Returns the template associated to a listing twig block.
     *
     * @param string $name The alias of the template
     *
     * @throws \Oru\Bundle\ListingBundle\Listing\Exception\UnexpectedValueException if the template asked doesn't exists
     *
     * @return string The template associated
     */
    public function getTemplate($name);

    /**
     * Set the template associated to a twig list block in the factory.
     *
     * @param $name string                  The alias of the template
     * @param $value string                 The template
     */
    public function setTemplate($name, $value);

    /**
     * Get the listing class.
     *
     * @return string
     */
    public function getListingClass();
}
