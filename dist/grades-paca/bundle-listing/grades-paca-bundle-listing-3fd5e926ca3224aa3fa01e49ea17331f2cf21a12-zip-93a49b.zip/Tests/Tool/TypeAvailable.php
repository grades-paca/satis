<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 17/12/13
 * Time: 10:31
 */

namespace Oru\Bundle\ListingBundle\Tests\Tool;


class TypeAvailable
{
    private $types_class = array();
    private $options_required = array();
    private $types = array();

    public function __construct()
    {
        $this->types_class = array();
        $this->types_class['integer'] = 'Oru\Bundle\ListingBundle\Listing\Type\TextListingType';
        $this->types_class['text'] = 'Oru\Bundle\ListingBundle\Listing\Type\TextListingType';
        $this->types_class['email'] = 'Oru\Bundle\ListingBundle\Listing\Type\EmailListingType';
        $this->types_class['entity'] = 'Oru\Bundle\ListingBundle\Listing\Type\EntityListingType';
        $this->types_class['object_action'] = 'Oru\Bundle\ListingBundle\Listing\Type\ObjectActionListingType';
        $this->types_class['list_action'] = 'Oru\Bundle\ListingBundle\Listing\Type\ListActionListingType';
        $this->types_class['batch_action'] = 'Oru\Bundle\ListingBundle\Listing\Type\BatchActionListingType';
        $this->types_class['datetime'] = 'Oru\Bundle\ListingBundle\Listing\Type\DateTimeListingType';
        $this->types_class['time'] = 'Oru\Bundle\ListingBundle\Listing\Type\TimeListingType';
        $this->types_class['date'] = 'Oru\Bundle\ListingBundle\Listing\Type\DateListingType';
        $this->types_class['checkbox'] = 'Oru\Bundle\ListingBundle\Listing\Type\CheckboxListingType';

        $this->options_required = array(
            'date'              =>  array(
                'name'              =>  'test',
                'format'            =>  '',
            ),
            'time'              =>  array(
                'name'              =>  'test',
                'format'            =>  '',
            ),
            'datetime'          =>  array(
                'name'              =>  'test',
                'format'            =>  '',
            ),
            'entity'            =>  array(
                'name'              =>  'test',
                'class'             =>  'Test',
            ),
            'batch_action'      =>  array(
                'name'              =>  'test',
                'route'             =>  'test',
            ),
            'list_action'       =>  array(
                'name'              =>  'test',
                'route'             =>  'test',
            ),
            'object_action'     =>  array(
                'name'              =>  'test',
                'route'             =>  'test',
            ),
        );

        $this->types = array(
            'integer',
            'text',
            'email',
            'entity',
            'object_action',
            'list_action',
            'batch_action',
            'datetime',
            'time',
            'date',
            'checkbox',
        );
    }

    /**
     * @param $type
     * @return array
     */
    public function getOptionRequired($type)
    {
        return isset($this->options_required[$type]) ? $this->options_required[$type] : array();
    }

    /**
     * @return array
     */
    public function getTypes()
    {
        return $this->types;
    }

    /**
     * @param $type
     * @return string
     */
    public function getTypeClass($type)
    {
        return isset($this->types_class[$type]) ? $this->types_class[$type] : '';
    }
} 