<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 16/12/13
 * Time: 14:17
 */

namespace Oru\Bundle\ListingBundle\Tests;

use Oru\Bundle\TestBundle\Tests\ModelTestCase;

class TestCase extends ModelTestCase
{
    protected $container;

    public function setUp()
    {
        parent::setUp();

        $this->container = $this->getContainer();
    }
}