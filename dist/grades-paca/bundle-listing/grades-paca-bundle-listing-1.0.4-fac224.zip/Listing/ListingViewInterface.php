<?php
/**
 * Created by PhpStorm.
 * User: andre
 * Date: 26/11/13
 * Time: 14:17
 */

namespace Oru\Bundle\ListingBundle\Listing;


interface ListingViewInterface {


    /**
     * Build the view based on the children.
     * At the moment, in order to simplify the treatment, there is one variable per type of action.
     * Eventually, we will probably go through specific classes.
     * At the end, the ListView can be used.
     */
    public function buildView();

    /**
     * Returns the number of object actions
     *
     * @return integer
     */
    public function countObjectActions();

    /**
     * Returns the number of list actions
     *
     * @return integer
     */
    public function countListActions();

    /**
     * Returns the number of batch actions
     *
     * @return integer
     */
    public function countBatchActions();

    /**
     * Returns the template associated to a twig list block, use the factory to resolve that.
     *
     * @param $name string      The alias of the template
     * @return string           The template
     */
    public function getTemplate($name);

    /**
     * Returns the listing associated
     *
     * @return ListingInterface
     */
    public function getListing();
} 