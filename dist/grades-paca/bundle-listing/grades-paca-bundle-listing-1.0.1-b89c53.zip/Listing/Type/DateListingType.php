<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing\Type;

use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class DateListingType
 * @package Oru\Bundle\ListingBundle\Listing\Type
 */
class DateListingType extends BaseDateTimeAbstractListingType {

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array('format' => 'd/m/Y'));
    }

    /**
     * {@inheritdoc}
     */
    function getName() {
        return 'datetime';
    }
} 