<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing;


class Listing implements ListingInterface {

    /**
     * @var ListingConfigInterface
     */
    private $config;

    /**
     * @var ListingViewInterface
     */
    private $view;

    /**
     * Saves ListingConfig for this Listing.
     *
     * @param ListingConfigInterface $config
     */
    public function __construct(ListingConfigInterface $config)
    {
        $this->config = $config;
    }

    /**
     * {@inheritdoc}
     */
    public function add($child, $type = null, array $options = array())
    {
        if($type instanceof ListingTypeInterface)
            $this->children[$child] = $type;
        else
            $this->unresolvedChildren[$child] = array(
                'type'    => $type,
                'options' => $options,
            );

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getConfig()
    {
        return $this->config;
    }

    /**
     * {@inheritdoc}
     */
    public function createView()
    {
        $this->getConfig()->resolveChildren();

        $this->view = new ListingView($this);

        foreach($this->children as $name => $children)
        {
            $this->view->children[$name] = $children->buildView($this->view, $this);
        }

        $this->view->buildView();
    }

    /**
     * {@inheritdoc}
     */
    public function getView()
    {
        if(!$this->view)
            $this->createView();

        return $this->view;
    }

    /**
     * {@inheritdoc}
     */
    public function getTemplate($name)
    {
        return $this->getConfig()->getTemplate($name);
    }

    /**
     * {@inheritdoc}
     */
    public function setTemplate($name, $value)
    {
        return $this->getConfig()->setTemplate($name, $value);
    }

    /**
     * {@inheritdoc}
     */
    public function getData()
    {
        return $this->getConfig()->getData();
    }
}