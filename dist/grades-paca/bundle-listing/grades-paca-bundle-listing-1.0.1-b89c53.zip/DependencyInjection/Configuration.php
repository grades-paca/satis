<?php

namespace Oru\Bundle\ListingBundle\DependencyInjection;

use Symfony\Component\Config\Definition\Builder\TreeBuilder;
use Symfony\Component\Config\Definition\ConfigurationInterface;

/**
 * This is the class that validates and merges configuration from your app/config files
 *
 * To learn more see {@link http://symfony.com/doc/current/cookbook/bundles/extension.html#cookbook-bundles-extension-config-class}
 */
class Configuration implements ConfigurationInterface
{
    /**
     * {@inheritDoc}
     */
    public function getConfigTreeBuilder()
    {
        $treeBuilder = new TreeBuilder();

        $treeBuilder->root('oru_listing')
            ->addDefaultsIfNotSet()
            ->children()
                ->arrayNode('template')
                    ->addDefaultsIfNotSet()
                    ->children()
                        ->scalarNode('listing')
                        ->defaultValue('OruListingBundle:Listing:listing.html.twig')
                        ->end()
                        ->scalarNode('listing_header')
                        ->defaultValue('OruListingBundle:Listing:listing_header.html.twig')
                        ->end()
                        ->scalarNode('listing_core')
                        ->defaultValue('OruListingBundle:Listing:listing_core.html.twig')
                        ->end()
                        ->scalarNode('listing_table_header')
                        ->defaultValue('OruListingBundle:Listing:listing_table_header.html.twig')
                        ->end()
                        ->scalarNode('listing_table_body')
                        ->defaultValue('OruListingBundle:Listing:listing_table_body.html.twig')
                        ->end()
                        ->scalarNode('listing_table_footer')
                        ->defaultValue('OruListingBundle:Listing:listing_table_footer.html.twig')
                        ->end()
                        ->scalarNode('listing_core_footer')
                        ->defaultValue('OruListingBundle:Listing:listing_core_footer.html.twig')
                        ->end()
                        ->scalarNode('listing_footer')
                        ->defaultValue('OruListingBundle:Listing:listing_footer.html.twig')
                        ->end()
                        ->scalarNode('listing_filter')
                        ->defaultValue('OruListingBundle:Listing:listing_filter.html.twig')
                        ->end()
                        ->scalarNode('listing_and_filter')
                        ->defaultValue('OruListingBundle:Listing:listing_and_filter.html.twig')
                        ->end()
                    ->end()
                ->end()
            ->end()
        ;

        return $treeBuilder;
    }
}
