<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Twig;

use Oru\Bundle\ListingBundle\Listing\ListingInterface;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\Form\FormView;

/**
 * Twig listing extension
 *
 * Class ListingExtension
 * @package Oru\Bundle\ListingBundle\Twig
 */
class ListingExtension extends \Twig_Extension {

    /**
     * @var \Twig_Environment
     */
    protected $environment;

    /**
     * {@inheritDoc}
     */
    public function initRuntime(\Twig_Environment $environment)
    {
        $this->environment = $environment;
    }

    /**
     * {@inheritDoc}
     */
    public function getFunctions()
    {
        return array(
            'listing'                   =>  new \Twig_Function_Method($this, 'listing', array('is_safe' => array('html'))),
            'listing_header'            =>  new \Twig_Function_Method($this, 'listing_header', array('is_safe' => array('html'))),
            'listing_core'              =>  new \Twig_Function_Method($this, 'listing_core', array('is_safe' => array('html'))),
            'listing_table_header'      =>  new \Twig_Function_Method($this, 'listing_table_header', array('is_safe' => array('html'))),
            'listing_table_body'        =>  new \Twig_Function_Method($this, 'listing_table_body', array('is_safe' => array('html'))),
            'listing_table_footer'      =>  new \Twig_Function_Method($this, 'listing_table_footer', array('is_safe' => array('html'))),
            'listing_core_footer'       =>  new \Twig_Function_Method($this, 'listing_core_footer', array('is_safe' => array('html'))),
            'listing_footer'            =>  new \Twig_Function_Method($this, 'listing_footer', array('is_safe' => array('html'))),
            'listing_filter'            =>  new \Twig_Function_Method($this, 'listing_filter', array('is_safe' => array('html'))),
            'listing_and_filter'        =>  new \Twig_Function_Method($this, 'listing_and_filter', array('is_safe' => array('html')))
        );
    }

    /**
     * {@inheritDoc}
     */
    public function getFilters()
    {
        return array(
            'camelize' => new \Twig_Filter_Method($this, 'camelizeFilter'),
        );
    }

    /**
     * Twig listing function
     *
     * @param ListingInterface $listing
     * @param string|null $template
     * @return string
     */
    public function listing(ListingInterface $listing, $template = null)
    {
        return $this->environment->render(
            $template ? $template : $listing->getTemplate('defaultListingTemplate'),
            array('listing' => $listing)
        );
    }

    /**
     * Twig listing_header function
     *
     * @param ListingInterface $listing
     * @param string|null $template
     * @return string
     */
    public function listing_header(ListingInterface $listing, $template = null)
    {
        return $this->environment->render(
            $template ? $template : $listing->getTemplate('defaultListingHeaderTemplate'),
            array('listing' => $listing)
        );
    }

    /**
     * Twig listing_core function
     *
     * @param ListingInterface $listing
     * @param string|null $template
     * @return string
     */
    public function listing_core(ListingInterface $listing, $template = null)
    {
        return $this->environment->render(
            $template ? $template : $listing->getTemplate('defaultListingCoreTemplate'),
            array('listing' => $listing)
        );
    }

    /**
     * Twig listing_footer function
     *
     * @param ListingInterface $listing
     * @param string|null $template
     * @return string
     */
    public function listing_footer(ListingInterface $listing, $template = null)
    {
        return $this->environment->render(
            $template ? $template : $listing->getTemplate('defaultListingFooterTemplate'),
            array('listing' => $listing)
        );
    }

    /**
     * Twig listing_table_header function
     *
     * @param ListingInterface $listing
     * @param string|null $template
     * @return string
     */
    public function listing_table_header(ListingInterface $listing, $template = null)
    {
        return $this->environment->render(
            $template ? $template : $listing->getTemplate('defaultListingTableHeaderTemplate'),
            array('listing' => $listing)
        );
    }

    /**
     * Twig listing_table_body function
     *
     * @param ListingInterface $listing
     * @param string|null $template
     * @return string
     */
    public function listing_table_body(ListingInterface $listing, $template = null)
    {
        return $this->environment->render(
            $template ? $template : $listing->getTemplate('defaultListingTableBodyTemplate'),
            array('listing' => $listing)
        );
    }

    /**
     * Twig listing_table_footer function
     *
     * @param ListingInterface $listing
     * @param string|null $template
     * @return string
     */
    public function listing_table_footer(ListingInterface $listing, $template = null)
    {
        return $this->environment->render(
            $template ? $template : $listing->getTemplate('defaultListingTableFooterTemplate'),
            array('listing' => $listing)
        );
    }

    /**
     * Twig listing_core_footer function
     *
     * @param ListingInterface $listing
     * @param string|null $template
     * @return string
     */
    public function listing_core_footer(ListingInterface $listing, $template = null)
    {
        return $this->environment->render(
            $template ? $template : $listing->getTemplate('defaultListingCoreFooterTemplate'),
            array('listing' => $listing)
        );
    }

    /**
     * Twig listing function
     *
     * @param ListingInterface $listing
     * @param string|null $template
     * @return string
     */
    public function listing_filter(ListingInterface $listing, FormView $form, $path = null, $template = null)
    {
        return $this->environment->render(
            $template ? $template : $listing->getTemplate('defaultListingFilterTemplate'),
            array('listing' => $listing, 'form' => $form, 'path' => $path)
        );
    }

    /**
     * Twig listing function
     *
     * @param ListingInterface $listing
     * @param string|null $template
     * @return string
     */
    public function listing_and_filter(ListingInterface $listing, FormView $form, $path = null, $template = null)
    {
        return $this->environment->render(
            $template ? $template : $listing->getTemplate('defaultListingAndFilterTemplate'),
            array('listing' => $listing, 'form' => $form, 'path' => $path)
        );
    }

    /**
     * Camelize filter
     *
     * @param $value string to camelize
     * @return string camelized
     */
    public function camelizeFilter($value)
    {
        if(!is_string($value)) {
            return $value;
        }

        return Container::camelize($value);
    }

    /**
     * Returns the name of the extension.
     *
     * @return string The extension name
     */
    public function getName()
    {
        return 'listing_extension';
    }
}