<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing\Type;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ObjectActionListingType
 * @package Oru\Bundle\ListingBundle\Listing\Type
 */
class ObjectActionListingType extends BaseActionListingType {

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array('template' => 'OruListingBundle:Listing/Type:listing_object_action_type.html.twig'));
    }

    /**
     * {@inheritdoc}
     */
    function getName() {
        return 'object_action';
    }
}