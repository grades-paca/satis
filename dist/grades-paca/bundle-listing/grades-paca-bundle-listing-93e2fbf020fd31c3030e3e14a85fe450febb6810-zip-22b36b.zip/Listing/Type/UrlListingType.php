<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing\Type;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class TextListingType
 * @package Oru\Bundle\ListingBundle\Listing\Type
 */
class UrlListingType extends BaseAbstractListingType {

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array('template' => 'OruListingBundle:Listing/Type:listing_url_type.html.twig'));
    }

    /**
     * {@inheritdoc}
     */
    function getName() {
        return 'url';
    }
} 