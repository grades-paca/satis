<?php
/**
 * Created by PhpStorm.
 * User: andre
 * Date: 15/11/13
 * Time: 10:05
 */

namespace Oru\Bundle\ListingBundle\Listing;

use Doctrine\Common\Proxy\Exception\InvalidArgumentException;
use Oru\Bundle\ListingBundle\Listing\Exception\UnexpectedTypeException;
use Symfony\Component\Form\FormExtensionInterface;
use Symfony\Component\Form\FormTypeGuesserChain;

class ListingRegistry implements ListingRegistryInterface
{
    /**
     * Extensions.
     *
     * @var FormExtensionInterface[] An array of FormExtensionInterface
     */
    private $extensions = array();

    private $types = array();

    private $guesser = false;

    public function __construct(array $extensions)
    {
        foreach ($extensions as $extension) {
            if (!$extension instanceof FormExtensionInterface) {
                throw new UnexpectedTypeException($extension, 'Symfony\Component\Form\FormExtensionInterface');
            }
        }

        $this->extensions = $extensions;

        /* replace with dependency injection */
        $this->types['integer'] = 'Oru\Bundle\ListingBundle\Listing\Type\TextListingType';
        $this->types['text'] = 'Oru\Bundle\ListingBundle\Listing\Type\TextListingType';
        $this->types['tel'] = 'Oru\Bundle\ListingBundle\Listing\Type\PhoneListingType';
        $this->types['textarea'] = 'Oru\Bundle\ListingBundle\Listing\Type\TextListingType';
        $this->types['checkbox'] = 'Oru\Bundle\ListingBundle\Listing\Type\CheckboxListingType';
        $this->types['email'] = 'Oru\Bundle\ListingBundle\Listing\Type\EmailListingType';
        $this->types['entity'] = 'Oru\Bundle\ListingBundle\Listing\Type\EntityListingType';
        $this->types['object_action'] = 'Oru\Bundle\ListingBundle\Listing\Type\ObjectActionListingType';
        $this->types['list_action'] = 'Oru\Bundle\ListingBundle\Listing\Type\ListActionListingType';
        $this->types['batch_action'] = 'Oru\Bundle\ListingBundle\Listing\Type\BatchActionListingType';
        $this->types['datetime'] = 'Oru\Bundle\ListingBundle\Listing\Type\DateTimeListingType';
        $this->types['time'] = 'Oru\Bundle\ListingBundle\Listing\Type\TimeListingType';
        $this->types['date'] = 'Oru\Bundle\ListingBundle\Listing\Type\DateListingType';
        $this->types['collection'] = 'Oru\Bundle\ListingBundle\Listing\Type\CollectionListingType';
        $this->types['url'] = 'Oru\Bundle\ListingBundle\Listing\Type\UrlListingType';

        // compatibilité sf 3.0
        $this->types['Symfony\Component\Form\Extension\Core\Type\IntegerType'] = 'Oru\Bundle\ListingBundle\Listing\Type\TextListingType';
        $this->types['Symfony\Component\Form\Extension\Core\Type\TextType'] = 'Oru\Bundle\ListingBundle\Listing\Type\TextListingType';
        $this->types['Oru\Bundle\FormBundle\Form\Type\TelType'] = 'Oru\Bundle\ListingBundle\Listing\Type\PhoneListingType';
        $this->types['Symfony\Component\Form\Extension\Core\Type\TextareaType'] = 'Oru\Bundle\ListingBundle\Listing\Type\TextListingType';
        $this->types['Symfony\Component\Form\Extension\Core\Type\CheckboxType'] = 'Oru\Bundle\ListingBundle\Listing\Type\CheckboxListingType';
        $this->types['Oru\Bundle\FormBundle\Form\Type\EmailType'] = 'Oru\Bundle\ListingBundle\Listing\Type\EmailListingType';
        $this->types['Symfony\Component\Form\Extension\Core\Type\EmailType'] = 'Oru\Bundle\ListingBundle\Listing\Type\EmailListingType';
        $this->types['Symfony\Bridge\Doctrine\Form\Type\EntityType'] = 'Oru\Bundle\ListingBundle\Listing\Type\EntityListingType';
        $this->types['Symfony\Component\Form\Extension\Core\Type\DateTimeType'] = 'Oru\Bundle\ListingBundle\Listing\Type\DateTimeListingType';
        $this->types['Symfony\Component\Form\Extension\Core\Type\TimeType'] = 'Oru\Bundle\ListingBundle\Listing\Type\TimeListingType';
        $this->types['Symfony\Component\Form\Extension\Core\Type\DateType'] = 'Oru\Bundle\ListingBundle\Listing\Type\DateListingType';
        $this->types['Symfony\Component\Form\Extension\Core\Type\CollectionType'] = 'Oru\Bundle\ListingBundle\Listing\Type\CollectionListingType';
        $this->types['Symfony\Component\Form\Extension\Core\Type\UrlType'] = 'Oru\Bundle\ListingBundle\Listing\Type\UrlListingType';
    }

    public function getType($name, $type, $data = null, $options = array())
    {
        if (!is_string($type)) {
            throw new UnexpectedTypeException($type, 'string');
        }

        if (!isset($options['name'])) {
            $options['name'] = $name;
        }

        if (isset($this->types[$type])) {
            return new $this->types[$type]($options);
        }
        throw new InvalidArgumentException(sprintf('Could not load type "%s". This type has not yet been implemented !', $type));
    }

    public function hasType($type)
    {
        return isset($this->types[$type]);
    }

    public function getTypeGuesser()
    {
        if (false === $this->guesser) {
            $guessers = array();

            foreach ($this->extensions as $extension) {
                /* @var FormExtensionInterface $extension */
                $guesser = $extension->getTypeGuesser();

                if ($guesser) {
                    $guessers[] = $guesser;
                }
            }

            $this->guesser = !empty($guessers) ? new FormTypeGuesserChain($guessers) : null;
        }

        return $this->guesser;
    }
}
