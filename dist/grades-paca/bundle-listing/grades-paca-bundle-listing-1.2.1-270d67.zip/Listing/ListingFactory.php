<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing;

use Doctrine\ORM\AbstractQuery;
use Oru\Bundle\ListingBundle\Listing\Exception\UnexpectedValueException;
use Symfony\Component\EventDispatcher\EventDispatcher;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * The factory.
 *
 * Class ListingFactory
 */
class ListingFactory implements ListingFactoryInterface
{
    /**
     * @var ListingBuilderInterface The builder
     */
    private $builder;

    /**
     * @var OptionsResolver The master options resolver
     */
    private $optionsResolver;

    /**
     * @var ListingRegistryInterface The registry that links factory to AbstractListingTypes
     */
    private $registry;

    /**
     * @var array The templates used by this bundle
     */
    private $templates;

    /**
     * @var string The listing class
     */
    private $listing_class;

    /**
     * Default registry and templates.
     *
     * @param ListingRegistryInterface $registry
     * @param array                    $templates
     * @param mixed                    $listing_class
     */
    public function __construct(ListingRegistryInterface $registry, $listing_class, array $templates)
    {
        $this->registry = $registry;
        $this->templates = $templates;
        $this->listing_class = $listing_class;
        $this->listing_builder = $listing_class;
    }

    /**
     * {@inheritdoc}
     */
    public function create($type, $data = null, array $options = array())
    {
        $type->configureOptions($this->getOptionsResolver());
        $options = $this->getOptionsResolver()->resolve($options);

        $this->builder = new ListingBuilder(new EventDispatcher(), $this, $options);

        return $this->builder->create($type, $data)->getListing();
    }

    /**
     * {@inheritdoc}
     */
    public function getOptionsResolver()
    {
        if (null === $this->optionsResolver) {
            $this->optionsResolver = new OptionsResolver();
        }

        return $this->optionsResolver;
    }

    /**
     * {@inheritdoc}
     */
    public function getType($name, $type, $data, $options, AbstractQuery $query = null)
    {
        $new_type = $this->registry->getType($name, $type, $data, $options, $query);

        return $new_type;
    }

    /**
     * {@inheritdoc}
     */
    public function getTypeForProperty($class, $property, $data = null, array $options = array(), AbstractQuery $query = null)
    {
        if (null === $guesser = $this->registry->getTypeGuesser()) {
            return $this->getType($property, 'text', $data, $options, $query);
        }

        $typeGuess = $guesser->guessType($class, $property);

        $type = $typeGuess ? $typeGuess->getType() : 'text';

        // user options may override guessed options
        if ($typeGuess) {
            $options = array_merge($typeGuess->getOptions(), $options);
        }

        return $this->getType($property, $type, $data, $options, $query);
    }

    /**
     * {@inheritdoc}
     */
    public function getTemplate($name)
    {
        if (isset($this->templates[$name])) {
            return $this->templates[$name];
        }
        throw new UnexpectedValueException($name);
    }

    /**
     * {@inheritdoc}
     */
    public function setTemplate($name, $value)
    {
        $this->templates[$name] = $value;
    }

    /**
     * {@inheritdoc}
     */
    public function getListingClass()
    {
        return $this->listing_class;
    }
}
