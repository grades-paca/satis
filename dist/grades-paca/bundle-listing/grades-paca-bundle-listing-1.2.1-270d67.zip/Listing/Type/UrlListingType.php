<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing\Type;

use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class TextListingType.
 */
class UrlListingType extends BaseAbstractListingType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array('template' => '@OruListing/Listing/Type/listing_url_type.html.twig'));
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'url';
    }
}
