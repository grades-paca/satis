<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing\Exception;

/**
 * Class UnexpectedValueException.
 */
class UnexpectedValueException extends \InvalidArgumentException
{
    public function __construct($value)
    {
        parent::__construct(sprintf('Unexpected argument "%s".', $value));
    }
}
