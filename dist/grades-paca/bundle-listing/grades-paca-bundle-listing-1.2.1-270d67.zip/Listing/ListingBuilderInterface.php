<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing;

/**
 * Interface ListingBuilderInterface.
 */
interface ListingBuilderInterface
{
    /**
     * Creates and return the listing interface.
     *
     * @param AbstractListingType $type An AbstractListingType to build
     * @param array               $data Doctrine entities to display
     *
     * @throws \Symfony\Component\OptionsResolver\Exception\UndefinedOptionsException if any given option is not applicable to the given type
     *
     * @return ListingInterface The listing interface
     *
     * @todo $type = null and $data = mixed. This way you can display a working list without doctrine's connections.
     */
    public function create(AbstractListingType $type, array $data = null);

    /**
     * Adds a field to the listing builder.
     *
     * @param string $child   The name of the field (maybe the doctrine property)
     * @param string $type    The type of the column
     * @param array  $options The options
     *
     * @return ListingBuilderInterface $this       The builder
     */
    public function add($child, $type = null, array $options = array());

    /**
     * Returns the listing config without builder configuration.
     *
     * @return ListingConfigInterface The ListingConfig of the builder
     */
    public function getListingConfig();

    /**
     * Returns the listing.
     *
     * @return Listing The listing associated to this builder
     */
    public function getListing();

    /**
     * Return the options.
     *
     * @return array The options of this builder
     */
    public function getOptions();

    /**
     * Returns the options resolver.
     *
     * @return OptionsResolver
     */
    public function getOptionsResolver();
}
