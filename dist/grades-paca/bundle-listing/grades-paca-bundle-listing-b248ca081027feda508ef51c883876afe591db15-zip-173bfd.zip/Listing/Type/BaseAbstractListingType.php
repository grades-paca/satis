<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing\Type;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\Exception\UnexpectedValueException;
use Oru\Bundle\ListingBundle\Listing\ListingInterface;
use Oru\Bundle\ListingBundle\Listing\ListingView;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Base class for AbstractListingType
 *
 * Class BaseAbstractListingType
 * @package Oru\Bundle\ListingBundle\Listing\Type
 */
class BaseAbstractListingType extends AbstractListingType {

    public function __construct($options)
    {
        $this->getOptionsResolver()->setRequired(array('template', 'name'));
        $this->getOptionsResolver()->setDefined(array('sort', 'label', 'translation_domain', 'role', 'important'));
        parent::__construct($options);
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'template' => '@OruListing/Listing/Type/listing_text_type.html.twig',
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function buildView(ListingView $view, ListingInterface $listing)
    {
        $this->attributes['label'] = (isset($this->options['label'])) ? $this->options['label'] : $this->options['name'] ;
        $this->attributes['name'] = $this->options['name'];

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        throw new UnexpectedValueException('BaseAbstractListingType cannot be used as an instance of AbstractListingType');
    }

    /**
     * {@inheritdoc}
     */
    public function getTemplate()
    {
        return $this->options['template'];
    }

    /**
     * {@inheritdoc}
     */
    public function getImportant()
    {
        if(isset($this->options['important']))
            return (boolean) $this->options['important'];

        return true;
    }

    public function hasSort()
    {
        return isset($this->options['sort']);
    }

    public function getSort()
    {
        return $this->options['sort'];
    }

    public function getRole()
    {
        return isset($this->options['role']) ? $this->options['role'] : false;
    }

    public function getTranslationDomain()
    {
        if(isset($this->options['translation_domain']))
            return $this->options['translation_domain'];
        else return 'messages';
    }
}