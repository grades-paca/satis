<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 17/12/13
 * Time: 11:48
 */

namespace Oru\Bundle\ListingBundle\Tests\Tool;

use Oru\Bundle\ListingBundle\Listing\AbstractListingType;
use Oru\Bundle\ListingBundle\Listing\ListingBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ModelObjectListingType extends AbstractListingType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildListing(ListingBuilderInterface $builder)
    {
        $builder
            ->add('name', null, array('label' => 'ModelObject.libelle'))
            ->add('description', null, array('label' => 'ModelObject.email'))
            ->add('edit', 'object_action', array('route' => 'log', 'label' => 'listing.action.edit'))
            ->add('show', 'object_action', array('route' => 'log', 'label' => 'listing.action.show'))
            ->add('delete', 'batch_action', array('route' => 'log', 'label' => 'listing.batch_action.delete'))
            ->add('new', 'list_action', array('route' => 'log', 'label' => 'listing.action.new'))
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Oru\Bundle\TestBundle\Entity\ModelObject',
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'oru_bundle_test_testlisting';
    }
}
