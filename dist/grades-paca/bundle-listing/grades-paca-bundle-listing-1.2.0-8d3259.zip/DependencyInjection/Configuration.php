<?php

namespace Oru\Bundle\ListingBundle\DependencyInjection;

use Symfony\Component\Config\Definition\Builder\TreeBuilder;
use Symfony\Component\Config\Definition\ConfigurationInterface;

/**
 * This is the class that validates and merges configuration from your app/config files.
 *
 * To learn more see {@link http://symfony.com/doc/current/cookbook/bundles/extension.html#cookbook-bundles-extension-config-class}
 */
class Configuration implements ConfigurationInterface
{
    /**
     * {@inheritdoc}
     */
    public function getConfigTreeBuilder()
    {
        $treeBuilder = new TreeBuilder();

        $treeBuilder->root('oru_listing')
            ->addDefaultsIfNotSet()
            ->children()
                ->arrayNode('template')
                    ->addDefaultsIfNotSet()
                    ->children()
                        ->scalarNode('listing')
                        ->defaultValue('@OruListing/Listing/listing.html.twig')
                        ->end()
                        ->scalarNode('listing_header')
                        ->defaultValue('@OruListing/Listing/listing_header.html.twig')
                        ->end()
                        ->scalarNode('listing_core')
                        ->defaultValue('@OruListing/Listing/listing_core.html.twig')
                        ->end()
                        ->scalarNode('listing_table_header')
                        ->defaultValue('@OruListing/Listing/listing_table_header.html.twig')
                        ->end()
                        ->scalarNode('listing_table_body')
                        ->defaultValue('@OruListing/Listing/listing_table_body.html.twig')
                        ->end()
                        ->scalarNode('listing_table_footer')
                        ->defaultValue('@OruListing/Listing/listing_table_footer.html.twig')
                        ->end()
                        ->scalarNode('listing_core_footer')
                        ->defaultValue('@OruListing/Listing/listing_core_footer.html.twig')
                        ->end()
                        ->scalarNode('listing_footer')
                        ->defaultValue('@OruListing/Listing/listing_footer.html.twig')
                        ->end()
                        ->scalarNode('listing_filter')
                        ->defaultValue('@OruListing/Listing/listing_filter.html.twig')
                        ->end()
                        ->scalarNode('listing_and_filter')
                        ->defaultValue('@OruListing/Listing/listing_and_filter.html.twig')
                        ->end()
                    ->end()
                ->end()
            ->end()
        ;

        return $treeBuilder;
    }
}
