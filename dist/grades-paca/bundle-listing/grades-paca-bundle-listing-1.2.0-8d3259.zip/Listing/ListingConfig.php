<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing;

/**
 * Class config to share parameters between listing and builder.
 *
 * Class ListingConfig
 */
class ListingConfig implements ListingConfigInterface
{
    /**
     * @var EventDispatcherInterface
     */
    protected $dispatcher;

    /**
     * @var ListingFactoryInterface
     */
    protected $listingFactory;

    /**
     * @var string
     */
    protected $dataClass = null;

    /**
     * @var array
     */
    protected $data = array();

    /**
     * @var array
     */
    protected $options = array();

    /**
     * @var array
     */
    protected $children = array();

    /**
     * @var array
     */
    protected $unresolvedChildren = array();

    /**
     * @var string|null
     */
    protected $role;

    /**
     * {@inheritdoc}
     */
    public function resolveChildren()
    {
        foreach ($this->unresolvedChildren as $name => $info) {
            if ($info['type'] === null) {
                $this->children[$name] = $this->listingFactory->getTypeForProperty($this->dataClass, $name, $this->data, $info['options']);
            } else {
                $this->children[$name] = $this->listingFactory->getType($name, $info['type'], $this->data, $info['options']);
            }
        }

        $this->unresolvedChildren = array();
    }

    /**
     * {@inheritdoc}
     */
    public function getListingConfig()
    {
        $config = clone $this;

        return $config;
    }

    /**
     * {@inheritdoc}
     */
    public function getTemplate($name)
    {
        return $this->listingFactory->getTemplate($name);
    }

    /**
     * {@inheritdoc}
     */
    public function setTemplate($name, $value)
    {
        return $this->listingFactory->setTemplate($name, $value);
    }

    /**
     * {@inheritdoc}
     */
    public function getListingClass()
    {
        return $this->listingFactory->getListingClass();
    }

    /**
     * {@inheritdoc}
     */
    public function getData()
    {
        return $this->data;
    }
}
