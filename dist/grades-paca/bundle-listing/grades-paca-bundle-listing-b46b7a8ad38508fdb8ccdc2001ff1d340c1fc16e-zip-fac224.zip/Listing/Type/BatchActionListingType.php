<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing\Type;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class BatchActionListingType
 * @package Oru\Bundle\ListingBundle\Listing\Type
 */
class BatchActionListingType extends BaseActionListingType {

    /**
     * {@inheritdoc}
     */
    function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array('template' => 'OruListingBundle:Listing/Type:listing_batch_action_type.html.twig'));
    }

    /**
     * {@inheritdoc}
     */
    function getName() {
        return 'batch_action';
    }
}