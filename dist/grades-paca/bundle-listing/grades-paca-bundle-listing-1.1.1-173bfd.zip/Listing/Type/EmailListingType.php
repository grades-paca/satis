<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing\Type;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class EmailListingType
 * @package Oru\Bundle\ListingBundle\Listing\Type
 */
class EmailListingType extends BaseAbstractListingType {

    /**
     * {@inheritdoc}
     */
    function configureOptions(OptionsResolver $resolver)
    {
        parent::configureOptions($resolver);
        $resolver->setDefaults(array('template' => '@OruListing/Listing/Type/listing_email_type.html.twig'));
    }

    /**
     * {@inheritdoc}
     */
    function getName() {
        return 'email';
    }
}