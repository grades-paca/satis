<?php
/**
 * Created by PhpStorm.
 * User: andre
 * Date: 15/11/13
 * Time: 10:15
 */

namespace Oru\Bundle\ListingBundle\Listing;

interface ListingRegistryInterface
{
    public function getType($name, $type, $data = null, $options = array());

    public function hasType($name);

    public function getTypeGuesser();
}
