<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing;

interface ListingInterface
{
    /**
     * Adds a field to the listing.
     *
     * @param string                      $child   The name of the child
     * @param null | ListingTypeInterface $type    The type of the column
     * @param array                       $options The options
     *
     * @return ListingInterface $this       The listing
     */
    public function add($child, $type = null, array $options = array());

    /**
     * Returns the current config.
     *
     * @return ListingConfigInterface
     */
    public function getConfig();

    /**
     * Creates the listing view associated to this listing.
     *
     * @return ListingViewInterface
     */
    public function createView();

    /**
     * Returns the template associated to a twig list block, use the factory to resolve that.
     *
     * @param $name string      The alias of the template
     *
     * @return string The template
     */
    public function getTemplate($name);

    /**
     * Set the template associated to a twig list block in the factory.
     *
     * @param $name string      The alias of the template
     * @param $value string     The template
     */
    public function setTemplate($name, $value);

    /**
     * Returns the current data.
     *
     * @return array
     */
    public function getData();

    /**
     * Returns the listing view associated to this listing.
     *
     * @return ListingViewInterface
     */
    public function getView();
}
