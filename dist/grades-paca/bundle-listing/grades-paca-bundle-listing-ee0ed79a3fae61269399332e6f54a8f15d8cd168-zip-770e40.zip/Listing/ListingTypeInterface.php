<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing;

use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Type interface.
 *
 * Interface ListingTypeInterface
 */
interface ListingTypeInterface
{
    /**
     * Build type from options.
     *
     * @param ListingBuilderInterface $builder
     *
     * @return ListingTypeInterface
     */
    public function buildListing(ListingBuilderInterface $builder);

    /**
     * Build view.
     *
     * @param ListingView      $view
     * @param ListingInterface $listing
     *
     * @return ListingTypeInterface
     */
    public function buildView(ListingView $view, ListingInterface $form);

    /**
     * Set default options for this type.
     *
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver);

    /**
     * Get name of this type.
     *
     * @return mixed
     */
    public function getName();
}
