<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\ListingBundle\Listing;

use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * The builder
 *
 * Class ListingBuilder
 * @package Oru\Bundle\ListingBundle\Listing
 */
class ListingBuilder extends ListingConfig implements \IteratorAggregate, ListingBuilderInterface {

    /**
     * @var OptionsResolver
     */
    protected $optionsResolver = null;

    /**
     * Constructs the builder.
     *
     * @param EventDispatcherInterface $dispatcher      The event dispatcher (not used for the moment)
     * @param ListingFactoryInterface $listingFactory   The listing factory
     * @param array $options                            The options
     */
    public function __construct(EventDispatcherInterface $dispatcher, ListingFactoryInterface $listingFactory, array $options = array())
    {
        $this->dispatcher = $dispatcher;
        $this->listingFactory = $listingFactory;
        $this->dataClass = $options['data_class'];
        $this->role = isset($options['role']) ? $options['role'] : null;
    }

    /**
     * {@inheritdoc}
     */
    public function create(AbstractListingType $type, Array $data = null, array $options = array()) {
        $this->options = $this->getOptionsResolver()->resolve($options);
        if($type instanceof ListingTypeInterface)
            $type->buildListing($this, $this->options);

        $this->data = $data;

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function add($child, $type = null, array $options = array())
    {
        $this->unresolvedChildren[$child] = array(
            'type'    => $type,
            'options' => $options,
        );

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getIterator()
    {
        return new \ArrayIterator($this->children);
    }

    /**
     * {@inheritdoc}
     */
    public function getListingConfig()
    {
        $config = parent::getListingConfig();

        $config->children = array();
        $config->unresolvedChildren = array();

        return $config;
    }

    /**
     * {@inheritdoc}
     */
    public function getListing() {
        $this->resolveChildren();

        // You cannot return to ListingBuilder in Listing. ListingBuilder is just an intermediate class.
        $data_class = $this->getListingClass();
        $listing = new $data_class($this->getListingConfig());

        foreach ($this->children as $name => $child) {
            // Automatic initialization is only supported on root forms
            $listing->add($name,$child);
        }

        return $listing;
    }

    /**
     * {@inheritdoc}
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * {@inheritdoc}
     */
    public function getOptionsResolver()
    {
        if (null === $this->optionsResolver) {
            $this->optionsResolver = new OptionsResolver();
            $this->optionsResolver->isRequired('data_class');
        }

        return $this->optionsResolver;
    }

    public function getRole()
    {
        return $this->role;
    }
}