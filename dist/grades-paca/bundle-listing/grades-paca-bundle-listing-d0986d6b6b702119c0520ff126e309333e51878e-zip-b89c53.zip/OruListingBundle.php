<?php

namespace Oru\Bundle\ListingBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruListingBundle extends Bundle
{
}
