<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 17/12/13
 * Time: 10:30
 */

namespace Oru\Bundle\ListingBundle\Tests\Listing;


use Oru\Bundle\ListingBundle\Tests\TestCase;
use Oru\Bundle\ListingBundle\Tests\Tool\ModelObjectListingType;

class ListingFactoryTest extends TestCase
{
    private function buildListing()
    {
        $listingFactory = $this->container->get('listing.factory');

        return $listingFactory->create(
            new ModelObjectListingType()
        );
    }

    /**
     * @test
     */
    public function getCreateTypes()
    {
        // L'objet retourné doit implémenter ListingInterface
        $this->assertInstanceOf(
            'Oru\Bundle\ListingBundle\Listing\ListingInterface',
            $this->buildListing()
        );
    }

    /**
     * @test
     */
    public function getView()
    {
        $listing = $this->buildListing();

        $view = $listing->getView();

        // L'objet retourné doit implémenter ListingViewInterface
        $this->assertInstanceOf(
            'Oru\Bundle\ListingBundle\Listing\ListingViewInterface',
            $view
        );

        $this->assertTrue($listing === $view->getListing());

        $this->assertTrue($view->count() > 1);

        $this->assertTrue($view->countObjectActions() === 2);

        $this->assertTrue($view->countListActions() === 1);

        $this->assertTrue($view->countBatchActions() === 1);

        $this->assertTrue(isset($view['description']));

        $this->assertInstanceOf(
            'Oru\Bundle\ListingBundle\Listing\ListingTypeInterface',
            $view['description']
        );

        unset($view['description']);

        $this->assertTrue(! isset($view['description']));
    }

    /**
     * @test
     * @dataProvider provideTemplates
     */
    public function getTemplate($key, $value)
    {
        $this->assertTrue($this->buildListing()->getTemplate($key) === $value);

        $this->assertTrue($this->buildListing()->getView()->getTemplate($key) === $value);
    }

    public function provideTemplates()
    {
        $this->setUp();

        $return = array();
        foreach($this->container->getParameter('listing.template.collection') as $key => $value)
        {
            $return[] = array($key,$value);
        }

        return $return;
    }

    /**
     * @test
     */
    public function addTemplate()
    {
        $listing = $this->buildListing();

        $listing->setTemplate('test','TestBundle::test.html.twig');

        $this->assertTrue($this->buildListing()->getTemplate('test') === 'TestBundle::test.html.twig');
    }

    /**
     * @test
     * @expectedException \Oru\Bundle\ListingBundle\Listing\Exception\UnexpectedValueException
     */
    public function unexpectedTemplate()
    {
        $this->buildListing()->getTemplate('farfelu');
    }

    /**
     * @test
     * @expectedException \Symfony\Component\Form\Exception\BadMethodCallException
     */
    public function unexpectedAddToViewAfterBuild()
    {
        $view = $this->buildListing()->getView();

        $view['test'] = 1;
    }


    /**
     * @test
     * @dataProvider provideColumnView
     */
    public function getColumnsOfView($listingType)
    {
        $this->assertInstanceOf(
            'Oru\Bundle\ListingBundle\Listing\ListingTypeInterface',
            $listingType
        );
    }

    public function provideColumnView()
    {
        $this->setUp();

        $return = array();

        $iterator = $this->buildListing()->getView()->getIterator();

        while($iterator->valid())
        {
            $return[] = array($iterator->current());
            $iterator->next();
        }

        return $return;
    }
} 