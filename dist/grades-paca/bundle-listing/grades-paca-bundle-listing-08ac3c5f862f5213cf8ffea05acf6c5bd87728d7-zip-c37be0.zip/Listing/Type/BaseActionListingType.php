<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */


namespace Oru\Bundle\ListingBundle\Listing\Type;


use Oru\Bundle\ListingBundle\Listing\ListingInterface;
use Oru\Bundle\ListingBundle\Listing\ListingView;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Base class for action's types
 *
 * Class BaseActionListingType
 * @package Oru\Bundle\ListingBundle\Listing\Type
 */
class BaseActionListingType extends BaseAbstractListingType {

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setRequired(array('route', 'name'));
        $resolver->setDefined(array('label', 'route_parameters', 'attr', 'deleted'));
    }

    /**
     * {@inheritdoc}
     */
    function getName() {
        return 'list_action';
    }

    /**
     * {@inheritdoc}
     */
    public function buildView(ListingView $view, ListingInterface $listing)
    {
        parent::buildView($view, $listing);
        $this->attributes['alt'] = $this->getName() . ((isset($this->options['name'])) ? '_'.$this->options['name'] : '');
        $this->attributes['deleted'] = (isset($this->options['deleted'])) ? $this->options['deleted'] : false;

        return $this;
    }

    /**
     * The route associated to this field type
     *
     * @return string
     */
    public function getRoute() {
        return $this->options['route'];
    }

    /**
     * The parameters associated to the route
     *
     * @return array
     */
    public function getRouteParameters() {
        return (isset($this->options['route_parameters'])) ? $this->options['route_parameters'] : array();
    }

    public function getAttributes()
    {
        if(isset($this->options['attr']))
            return $this->options['attr'];
        return array();
    }

    public function getDeleted() {
        return (isset($this->options['deleted'])) ? $this->options['deleted'] : false;
    }
}