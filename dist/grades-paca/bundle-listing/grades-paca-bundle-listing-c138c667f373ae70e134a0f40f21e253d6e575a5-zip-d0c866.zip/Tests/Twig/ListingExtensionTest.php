<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 02/01/14
 * Time: 17:25
 */

namespace Oru\Bundle\ListingBundle\Tests\Twig;


use Oru\Bundle\ListingBundle\Tests\TestCase;
use Oru\Bundle\ListingBundle\Tests\Tool\ModelObjectListingType;
use Oru\Bundle\ListingBundle\Twig\ListingExtension;

class ListingExtensionTest extends TestCase
{
    private function buildListing()
    {
        $listingFactory = $this->container->get('listing.factory');

        return $listingFactory->create(
            new ModelObjectListingType()
        );
    }

    /**
     * @test
     */
    public function getTemplate()
    {
        $listing = $this->buildListing();

        $listingExtension = $this->container->get('oru.twig.listing_extension');

        $listingExtension->initRuntime($this->container->get('twig'));

        $this->assertEquals(array_keys($listingExtension->getFunctions()), array(
            'listing',
            'listing_header',
            'listing_core',
            'listing_table_header',
            'listing_table_body',
            'listing_table_footer',
            'listing_core_footer',
            'listing_footer')
        );

        $this->assertTrue('' === $listingExtension->listing_header($listing));
        $this->assertTrue(1 === preg_match('#^\s+<form action=#', $listingExtension->listing_core($listing)));
        $this->assertTrue('' === $listingExtension->listing_footer($listing));
        $this->assertTrue(1 === preg_match('#^\s+<tr>#', $listingExtension->listing_table_header($listing)));
        $this->assertTrue('' === $listingExtension->listing_table_body($listing));
        $this->assertTrue('' === $listingExtension->listing_table_footer($listing));
        $this->assertTrue(1 === preg_match('#^\s+<select #', $listingExtension->listing_core_footer($listing)));
        $this->assertTrue(1 === preg_match('#^\s+<div #', $listingExtension->listing($listing)));
    }
} 