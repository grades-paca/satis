OruDeniedFieldBundle
====================

Ce bundle permet de gérer des droits au niveau des propriétés des entités.
Il recueille des interdictions pour les propriétés. Ces interdictions sont fournies par des subscribers.
Les interdictions gérées sont VIEW, EDIT, OWNER et ADMIN, nous les nommerons autorisations dans le document.

Créer un subscriber qui fournit des interdictions
-------------------------------------------------

**Exemple**

DeniedSubscriber.php

```php

namespace Your\Namespace;

use Oru\Bundle\DeniedFieldBundle\Event\DeniedFieldsEvent;
use Oru\Bundle\DeniedFieldBundle\Event\Events;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Class DeniedSubscriber.
 */
class DeniedSubscriber implements EventSubscriberInterface
{
    /**
     * @param DeniedFieldsEvent $event
     */
    public function deniedFields(DeniedFieldsEvent $event)
    {
        $entity = $event->getEntity();

        if (!$entity instanceof TheEntityYouWant) {
            return;
        }

        // Your logic to deny fields. See the doc below.
   }

    /**
     * Returns an array of event names this subscriber wants to listen to.
     *
     * The array keys are event names and the value can be:
     *
     *  * The method name to call (priority defaults to 0)
     *  * An array composed of the method name to call and the priority
     *  * An array of arrays composed of the method names to call and respective
     *    priorities, or 0 if unset
     *
     * For instance:
     *
     *  * array('eventName' => 'methodName')
     *  * array('eventName' => array('methodName', $priority))
     *  * array('eventName' => array(array('methodName1', $priority), array('methodName2')))
     *
     * @return array The event names to listen to
     */
    public static function getSubscribedEvents()
    {
        $listen = array(
            Events::DENIED_FIELDS => array('deniedFields', 0),
        );

        return $listen;
    }
}
```

services.xml

```xml
<services>
    <service id="denied_subscriber" class="Your\Namespace\DeniedSubscriber">
        <tag name="kernel.event_subscriber" />
    </service>
</services>
```

L'Objet DeniedFields
--------------------

Il est l'objet qui recense toutes les interdictions de propriétés pour une entité donnée.
Il y a 2 manières de le récupérer :

- Dans les subscribers dans l'objet DeniedFieldsEvent :

```php
$deniedFields = $event->getDeniedFields();
```

- Via le service `oru_denied_field.denied_field_manager` :

```php
$deniedFields = $deniedFieldManager->getDeniedFields($entity);
```

**Attention d'utiliser toujours le même ojbet récupéré via le manager (il n'y a pas de système de cache)**

Interdir un field (propriété)
-----------------------------

- La méthode `addHardDeniedNoTrueCondition` :

```php
$deniedFields->addHardDeniedNoTrueCondition('yourField', array($isCeci, $isCela));
```

Si aucune des conditions passées en 2ème argument n'est vraie, le field sera denied.
Il sera denied pour toutes les autorisations, par défaut, View Edit Owner et Admin.

Pour n'interdire que View, par exemple, il faudra le préciser en 3ème paramètre :
```php
use Oru\Bundle\DeniedFieldBundle\DeniedField\DeniedFields;

$deniedFields->addHardDeniedNoTrueCondition('yourField', array($isCeci, $isCela), DeniedFields::View);
```

Il convient de bien choisir dans quel ordre nous interdisons lorsque les autorisations sont découplées.

**NB**: Il est possible de fournir en 2ème argument des Closures, ce qui entraîne des gains de performances dans certains cas. En effet, si une autorisation est déjà interdite, le code ne sera pas exécuté.
Par ailleurs, les variables fournies en second paramètre sont testées dans l'ordre ce qui fait que dès qu'une est à true, on ne teste pas les autres.

- La méthode `addHardDeniedOn` :

La méthode précédente ayant ses limites dans certains cas d'usage, il existe celle-ci qui interdit si une condition est vraie.

```php
$deniedFields->addHardDeniedOn('yourField', array($isCeci, $isCela));
```

Hormis cette particularité, elle fonctionne comme la précédente pour les autorisations qui peuvent être passées en 3ème argument.

Changer le professionnel pour lequel sont calculés les droits
-------------------------------------------------------------

Par défaut les droits sont calculés pour l'utilisateur courant.
Pour calculer les droits pour un autre utilisateur, il faut le changer dans le manager avant de récupérer l'objet DeniedFields.

- En lui fournissant un TokenStorage :

```php
$deniedFieldManager->setTokenStorage($tokenStorage);
$deniedFields = $deniedFieldManager->getDeniedFields($entity);
```

- En lui fournissant un Professionnel :

```php
$deniedFieldManager->setProfessionnel($professionnel);
$deniedFields = $deniedFieldManager->getDeniedFields($entity);
```

**Attention aux éventuels effets non désirés avec ce professionnel remplacé dans le manager qui restera celui-ci jusqu'à ce qu'on en change à nouveau de manière délibérée.**

Notion de denied et hardDenied
------------------------------

J'ai créé cette notion pour pouvoir reprendre une permission (denied) si nécessaire en fonction d'un autre écouteur.
Ce cas d'usage ne s'étant pas présenté, elle ne sert à rien pour l'instant. Il n'y a que des hardDenied (interdit définitif).

Tester l'autoraisation d'un champ
---------------------------------

Prérequis : Il faut un objet DeniedFields (voir ci-dessus).

```php

// Par défaut c'est le droit EDIT qui est testé
$deniedFields->isDenied('yourField');
// Ou l'équivalent
$deniedFields->isDenied('yourField', DeniedFields::EDIT);

// Pour les autres droits
$deniedFields->isDenied('yourField', DeniedFields::VIEW);
$deniedFields->isDenied('yourField', DeniedFields::OWNER);
$deniedFields->isDenied('yourField', DeniedFields::ADMIN);

// Les combinaisons sont possibles :
$deniedFields->isDenied('yourField', DeniedFields::EDIT | DeniedField::OWNER); // EDIT et OWNER
$deniedFields->isDenied('yourField', ~DeniedFields::VIEW & ~DeniedField::EDIT); // Tous les droits sauf VIEW et EDIT
```

Il est possible de tester les mêmes autorisations sur plusieurs champs.

- Est-ce qu'un des champs est autorisé :

```php
$deniedFields->isSomeNotDenied(array('yourField1', 'yourField2', '...'), DeniedFields::VIEW);
```

- Est-ce qu'un des champs est interdit :

```php
$deniedFields->isSomeDenied(array('yourField1', 'yourField2', '...'), DeniedFields::VIEW);
```
