<?php

namespace Oru\Bundle\DeniedFieldBundle\Debug;

use Doctrine\Common\Util\ClassUtils;

/**
 * Class SubscriberLog.
 *
 * @author Michaël VEROUX
 */
class SubscriberLog
{
    /**
     * @var array
     */
    public $deniedFields;

    /**
     * @var string|null
     */
    private $currentSubscriber;

    /**
     * @var object|null
     */
    private $currentEntity;

    /**
     * @param string $field
     * @param int    $mask
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function add($field, $mask)
    {
        if (!$this->currentSubscriber) {
            $this->currentSubscriber = 'unknown';
        }

        if (!isset($this->deniedFields[$this->currentSubscriber])) {
            $this->deniedFields[$this->currentSubscriber] = array();
        }

        $entityClass = ClassUtils::getRealClass($this->currentEntity);
        $classNamePos = strrpos($entityClass, '\\');
        $entityName = substr($entityClass, $classNamePos);

        $this->deniedFields[$this->currentSubscriber][] = array(
            sprintf('[%s] %s', $entityName, $field) => $mask,
        );

        return $this;
    }

    /**
     * @param null|string $currentSubscriber
     *
     * @return $this
     */
    public function setCurrentSubscriber($currentSubscriber)
    {
        $this->currentSubscriber = $currentSubscriber;

        return $this;
    }

    /**
     * @param null|object $currentEntity
     *
     * @return $this
     */
    public function setCurrentEntity($currentEntity)
    {
        $this->currentEntity = $currentEntity;

        return $this;
    }

    /**
     * @return array
     */
    public function getDeniedFields()
    {
        return $this->deniedFields;
    }
}
