<?php

namespace Oru\Bundle\DeniedFieldBundle\DeniedField;

/**
 * Interface DeniedFieldsInterface.
 *
 * @author Michaël VEROUX
 */
interface DeniedFieldsInterface
{
    const VIEW = 0x01;
    const EDIT = 0x02;
    const OWNER = 0x04;
    const ADMIN = 0x08;

    const EDIT_ADMIN = self::EDIT | self::ADMIN;
    const ALL = self::VIEW | self::EDIT | self::OWNER |self::ADMIN;
    const ALL_EXCEPT_VIEW = self::ALL & ~self::VIEW;

    /**
     * @param string $field
     * @param int    $attribute
     *
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isDenied($field, $attribute = self::EDIT);
}
