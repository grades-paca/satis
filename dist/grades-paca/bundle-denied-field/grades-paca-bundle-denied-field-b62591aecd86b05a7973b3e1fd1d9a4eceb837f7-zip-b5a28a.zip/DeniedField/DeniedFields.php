<?php

namespace Oru\Bundle\DeniedFieldBundle\DeniedField;

/**
 * Class DeniedFields.
 *
 * @author Michaël VEROUX
 */
class DeniedFields implements DeniedFieldsInterface
{
    /**
     * @var array
     */
    protected $hardDenied = array();

    /**
     * @var array
     */
    protected $denied = array();

    /**
     * @param string $field
     * @param int    $attributes
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function addHardDenied($field, $attributes = null)
    {
        if (null === $attributes) {
            $attributes = self::VIEW | self::EDIT | self::OWNER | self::ADMIN;
        }

        if (isset($this->hardDenied[$field])) {
            $attributes |= $this->hardDenied[$field];
        }

        $this->hardDenied[$field] = $attributes;

        return $this;
    }

    /**
     * @param string $field
     * @param int    $attribute
     *
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isHardDenied($field, $attribute = self::EDIT)
    {
        if (!in_array($field, array_keys($this->hardDenied))) {
            return false;
        }

        $attributes = $this->hardDenied[$field];

        if ($attributes === ($attributes | $attribute)) {
            return true;
        }

        return false;
    }

    /**
     * @param string $field
     * @param int    $attributes
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function addDenied($field, $attributes = null)
    {
        if (null === $attributes) {
            $attributes = self::VIEW | self::EDIT;
        }

        if (isset($this->denied[$field])) {
            $attributes |= $this->denied[$field];
        }

        $this->denied[$field] = $attributes;

        return $this;
    }

    /**
     * @param string $field
     * @param int    $attribute
     *
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isDenied($field, $attribute = self::EDIT)
    {
        if (!in_array($field, array_keys($this->denied))) {
            return $this->isHardDenied($field, $attribute);
        }

        $attributes = $this->denied[$field];

        if ($attribute === ($attributes | $attribute)) {
            return true;
        }

        return $this->isHardDenied($field, $attribute);
    }

    /**
     * @param array $fields
     * @param int   $attribute
     *
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isSomeDenied($fields, $attribute = self::EDIT)
    {
        foreach ($fields as $field) {
            if ($this->isDenied($field, $attribute)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array $fields
     * @param int   $attribute
     *
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function isSomeNotDenied($fields, $attribute = self::EDIT)
    {
        foreach ($fields as $field) {
            if (!$this->isDenied($field, $attribute)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Add hard denied if one of conditions is true
     *
     * @param string $field
     * @param array  $conditions
     * @param int    $attributes
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function addHardDeniedNoTrueCondition($field, $conditions, $attributes = null)
    {
        if (null === $attributes) {
            $attributes = self::VIEW | self::EDIT| self::OWNER | self::ADMIN;
        }

        if ($this->isHardDenied($field, $attributes)) {
            return $this;
        }

        foreach ($conditions as $condition) {
            if (is_callable($condition)) {
                $condition = call_user_func($condition);
            }

            if ($condition) {
                return $this;
            }
        }

        $this->addHardDenied($field, $attributes);

        return $this;
    }

    /**
     * Add hard denied if all of conditions are true
     *
     * @param string $field
     * @param array  $conditions
     * @param int    $attributes
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function addHardDeniedOn($field, $conditions, $attributes = null)
    {
        if (null === $attributes) {
            $attributes = self::VIEW | self::EDIT | self::OWNER | self::ADMIN;
        }

        if ($this->isHardDenied($field, $attributes)) {
            return $this;
        }

        foreach ($conditions as $condition) {
            if (is_callable($condition)) {
                $condition = call_user_func($condition);
            }

            if (!$condition) {
                return $this;
            }
        }

        $this->addHardDenied($field, $attributes);

        return $this;
    }
}
