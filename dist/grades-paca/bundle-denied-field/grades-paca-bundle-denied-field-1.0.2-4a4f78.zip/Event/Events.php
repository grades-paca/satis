<?php

namespace Oru\Bundle\DeniedFieldBundle\Event;

/**
 * Class Events.
 *
 * @author Michaël VEROUX
 */
final class Events
{
    const DENIED_FIELDS = 'oru.denied_fields';
}
