<?php

namespace Oru\Bundle\DeniedFieldBundle\Manager;

use Oru\Bundle\DeniedFieldBundle\DeniedField\DeniedFields;
use Oru\Bundle\DeniedFieldBundle\Event\DeniedFieldsEvent;
use Oru\Bundle\DeniedFieldBundle\Event\Events;
use Oru\Bundle\DeniedFieldBundle\User\DeniedFieldUser;
use Oru\Bundle\ProfessionnelBundle\Entity\Professionnel;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

/**
 * Class DeniedFieldManager.
 *
 * @author Michaël VEROUX
 */
class DeniedFieldManager implements DeniedFieldManagerInterface
{
    /**
     * @var EventDispatcherInterface
     */
    protected $eventDispatcher;

    /**
     * @var DeniedFieldUser
     */
    protected $deniedFieldUser;

    /**
     * DeniedFieldManager constructor.
     *
     * @param EventDispatcherInterface $eventDispatcher
     * @param DeniedFieldUser          $deniedFieldUser
     */
    public function __construct(EventDispatcherInterface $eventDispatcher, DeniedFieldUser $deniedFieldUser)
    {
        $this->eventDispatcher = $eventDispatcher;
        $this->deniedFieldUser = $deniedFieldUser;
    }

    /**
     * @param Professionnel $professionnel
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function setProfessionnelInitiator(Professionnel $professionnel)
    {
        $this->deniedFieldUser->setProfessionnel($professionnel);

        return $this;
    }

    /**
     * @param TokenStorageInterface $tokenStorage
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function setTokenStorage(TokenStorageInterface $tokenStorage)
    {
        $this->deniedFieldUser->setTokenStorage($tokenStorage);

        return $this;
    }

    /**
     * @param object $entity
     *
     * @return DeniedFields
     *
     * @author Michaël VEROUX
     */
    public function getDeniedFields($entity)
    {
        $event = new DeniedFieldsEvent($entity);

        $this->eventDispatcher->dispatch(Events::DENIED_FIELDS, $event);

        $deniedFields = $event->getDeniedFields();

        return $deniedFields;
    }
}
