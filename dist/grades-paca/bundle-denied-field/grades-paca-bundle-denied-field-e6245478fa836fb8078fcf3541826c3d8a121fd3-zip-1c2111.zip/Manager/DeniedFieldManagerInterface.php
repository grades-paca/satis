<?php

namespace Oru\Bundle\DeniedFieldBundle\Manager;

use Oru\Bundle\DeniedFieldBundle\DeniedField\DeniedFieldsInterface;
use Oru\Bundle\ProfessionnelBundle\Entity\Professionnel;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

/**
 * Interface DeniedFieldManagerInterface.
 *
 * @author Michaël VEROUX
 */
interface DeniedFieldManagerInterface
{
    /**
     * @param Professionnel $professionnel
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function setProfessionnelInitiator(Professionnel $professionnel);

    /**
     * @param TokenStorageInterface $tokenStorage
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function setTokenStorage(TokenStorageInterface $tokenStorage);

    /**
     * @param object $entity
     *
     * @return DeniedFieldsInterface
     *
     * @author Michaël VEROUX
     */
    public function getDeniedFields($entity);
}
