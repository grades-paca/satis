<?php

namespace Oru\Bundle\DeniedFieldBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class OruDeniedFieldBundle.
 *
 * @author Michaël VEROUX
 */
class OruDeniedFieldBundle extends Bundle
{
}
