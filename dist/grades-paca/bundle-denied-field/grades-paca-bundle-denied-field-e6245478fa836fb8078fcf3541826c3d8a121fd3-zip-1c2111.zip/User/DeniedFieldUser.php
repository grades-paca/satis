<?php

namespace Oru\Bundle\DeniedFieldBundle\User;

use Oru\Bundle\ProfessionnelBundle\Entity\Professionnel;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken;

/**
 * Class DeniedFieldUser.
 *
 * @author Michaël VEROUX
 */
class DeniedFieldUser
{
    /**
     * @var Professionnel
     */
    private $professionnel;

    /**
     * @var TokenStorageInterface
     */
    private $tokenStorage;

    /**
     * @var TokenInterface
     */
    private $token;

    /**
     * DeniedFieldUser constructor.
     *
     * @param TokenStorageInterface $tokenStorage
     */
    public function __construct(TokenStorageInterface $tokenStorage)
    {
        $this->tokenStorage = $tokenStorage;
    }

    /**
     * @return null|Professionnel
     *
     * @author Michaël VEROUX
     */
    public function getProfessionnel()
    {
        if (!$this->professionnel instanceof Professionnel) {
            $token = $this->tokenStorage->getToken();
            if ($token) {
                $this->professionnel = $token->getUser();
            }
        }

        return $this->professionnel;
    }

    /**
     * @return TokenInterface|UsernamePasswordToken
     *
     * @author Michaël VEROUX
     */
    public function getToken()
    {
        if (!$this->token instanceof TokenInterface) {
            $this->token = new UsernamePasswordToken($this->getProfessionnel(), 'none', 'none', $this->getProfessionnel()->getRoles());
        }

        return $this->token;
    }

    /**
     * @param Professionnel $professionnel
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function setProfessionnel(Professionnel $professionnel)
    {
        $this->token = null;
        $this->professionnel = $professionnel;

        return $this;
    }

    /**
     * @param TokenStorageInterface $tokenStorage
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function setTokenStorage(TokenStorageInterface $tokenStorage)
    {
        $this->professionnel = null;
        $this->tokenStorage = $tokenStorage;

        return $this;
    }
}
