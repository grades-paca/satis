<?php

namespace Oru\Bundle\DeniedFieldBundle\Debug;

use Oru\Bundle\DeniedFieldBundle\DeniedField\DeniedFields;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\DataCollector\DataCollectorInterface;

/**
 * Class ProfilerDataCollector.
 *
 * @author Michaël VEROUX
 */
class ProfilerDataCollector implements DataCollectorInterface
{
    /**
     * @var SubscriberLog
     */
    protected $subscriberLog;

    /**
     * @var array
     */
    protected $data = array();

    /**
     * @var array
     */
    protected $out = array();

    /**
     * @var int
     */
    protected $count = 0;

    /**
     * ProfilerDataCollector constructor.
     *
     * @param SubscriberLog $subscriberLog
     */
    public function __construct(SubscriberLog $subscriberLog)
    {
        $this->subscriberLog = $subscriberLog;
    }

    /**
     * Collects data for the given Request and Response.
     */
    public function collect(Request $request, Response $response, \Exception $exception = null)
    {
        $this->data = $this->subscriberLog->getDeniedFields();
    }

    /**
     * Returns the name of the collector.
     *
     * @return string The collector name
     */
    public function getName()
    {
        return 'denied_field_collector';
    }

    /**
     * @return int
     *
     * @author Michaël VEROUX
     */
    public function getDeniedCount()
    {
        if (!$this->isProcessed()) {
            $this->processData();
        }

        return $this->count;
    }

    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function getData()
    {
        if (!$this->isProcessed()) {
            $this->processData();
        }

        return $this->out;
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    private function isProcessed()
    {
        $isIt = count($this->out) || !count($this->data);

        return $isIt;
    }

    /**
     * @author Michaël VEROUX
     */
    private function processData()
    {
        $this->out = array();
        $this->count = 0;
        foreach ($this->data as $subscriber => $datas) {
            $this->out[$subscriber] = array();
            foreach ($datas as $denieds) {
                foreach ($denieds as $index => $mask) {
                    $line = array_fill(0, 4, '');
                    if ($mask === ($mask | DeniedFields::VIEW)) {
                        $line[0] = 'VIEW ';
                    }
                    if ($mask === ($mask | DeniedFields::EDIT)) {
                        $line[1] = 'EDIT ';
                    }
                    if ($mask === ($mask | DeniedFields::OWNER)) {
                        $line[2] = 'OWNER ';
                    }
                    if ($mask === ($mask | DeniedFields::ADMIN)) {
                        $line[3] = 'ADMIN ';
                    }

                    $this->out[$subscriber][] = array($index => $line);
                    ++$this->count;
                }
            }
        }
    }
}
