<?php

namespace Oru\Bundle\DeniedFieldBundle\Event;

use Oru\Bundle\DeniedFieldBundle\Debug\SubscriberLog;
use Oru\Bundle\DeniedFieldBundle\DeniedField\DeniedFields;
use Symfony\Component\EventDispatcher\Event;

/**
 * Class DeniedFieldsEvent.
 *
 * @author Michaël VEROUX
 */
class DeniedFieldsEvent extends Event
{
    /**
     * @var object
     */
    protected $entity;

    /**
     * @var DeniedFields
     */
    protected $deniedFields;

    /**
     * @var bool
     */
    protected $debug = false;

    /**
     * PHP 5 allows developers to declare constructor methods for classes.
     * Classes which have a constructor method call this method on each newly-created object,
     * so it is suitable for any initialization that the object may need before it is used.
     *
     * Note: Parent constructors are not called implicitly if the child class defines a constructor.
     * In order to run a parent constructor, a call to parent::__construct() within the child constructor is required.
     *
     * param [ mixed $args [, $... ]]
     * @param object $entity
     *
     * @link http://php.net/manual/en/language.oop5.decon.php
     */
    public function __construct($entity)
    {
        $this->entity = $entity;
        $this->deniedFields = new DeniedFields();
    }

    /**
     * @return object
     */
    public function getEntity()
    {
        return $this->entity;
    }

    /**
     * @param object $entity
     *
     * @return $this
     */
    public function setEntity($entity)
    {
        $this->entity = $entity;

        return $this;
    }

    /**
     * @param null|SubscriberLog $subscriberLog
     *
     * @return $this
     */
    public function setSubscriberLog(SubscriberLog $subscriberLog = null)
    {
        if (null !== $subscriberLog) {
            $this->debug = true;
            $subscriberLog->setCurrentEntity($this->entity);
        }

        $this->deniedFields->setSubscriberLog($subscriberLog);

        return $this;
    }

    /**
     * @return DeniedFields
     *
     * @author Michaël VEROUX
     */
    public function getDeniedFields()
    {
        if ($this->debug) {
            $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);
            $caller = $trace[1];

            if (isset($caller['class'])) {
                $subscriberClass = $caller['class'];

                $this->deniedFields->setCurrentSubscriber($subscriberClass);
            }
        }

        return $this->deniedFields;
    }
}
