<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\InstallBundle\Command;


use Lexik\Bundle\MaintenanceBundle\Command\DriverUnlockCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class MaintenanceUnlockCommand extends DriverUnlockCommand
{
    protected function configure()
    {
        parent::configure();
        $this->setName('oru:maintenance:unlock');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        try {
            parent::execute($input, $output);
        } catch(\Exception $e) {
        }
    }

}