<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 18/08/14
 */
namespace Oru\Bundle\InstallBundle;

use Oru\Bundle\InstallBundle\Routing\DynamicLoader;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruInstallBundle extends Bundle {

    /**
     *
     */
    public function __construct()
    {
        DynamicLoader::addYaml('@OruInstallBundle/Resources/config/routing.yml');
    }

    public function getParent() {
        return "CoreSphereConsoleBundle";
    }
}