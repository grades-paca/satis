<?php

namespace Oru\Bundle\InstallBundle\Routing;

use Symfony\Component\Config\Exception\FileLoaderLoadException;
use Symfony\Component\Config\Loader\Loader;
use Symfony\Component\Routing\RouteCollection;
use Psr\Log\LoggerInterface;

/**
 * Class DynamicLoader
 *
 * @package Oru\Bundle\InstallBundle\Routing
 * @author Michaël VEROUX
 */
class DynamicLoader extends Loader
{
    /**
     * @var array
     */
    static protected $yamls = array();

    /**
     * @var array
     */
    static protected $xmls = array();

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var array
     */
    protected $disabledBundles = array();

    /**
     * DynamicLoader constructor.
     *
     * @param LoggerInterface $logger
     */
    public function __construct(LoggerInterface $logger, $disabledBundles)
    {
        $this->logger = $logger;
        $this->disabledBundles = $disabledBundles;
    }

    /**
     * @param string $resource
     *
     * @return void
     * @author Michaël VEROUX
     */
    static public function addYaml($resource)
    {
        if (!in_array($resource, self::$yamls)) {
            self::$yamls[] = $resource;
        }
    }

    /**
     * @param string $resource
     *
     * @return void
     * @author Michaël VEROUX
     */
    static public function addXml($resource)
    {
        if (!in_array($resource, self::$xmls)) {
            self::$xmls[] = $resource;
        }
    }

    /**
     * Loads a resource.
     *
     * @param mixed       $resource The resource
     * @param string|null $type The resource type or null if unknown
     *
     * @return RouteCollection
     *
     * @throws \Exception If something went wrong
     */
    public function load($resource, $type = null)
    {
        $collection = new RouteCollection();

        foreach (self::$yamls as $yml) {
            if ($this->isDisabledBundle($yml)) {
                continue;
            }
            try {
                $importedRoutes = $this->import($yml, 'yaml');

                $collection->addCollection($importedRoutes);
            } catch (FileLoaderLoadException $e) {
                $this->logger->error($e->getMessage());
            }
        }

        foreach (self::$xmls as $xml) {
            if ($this->isDisabledBundle($xml)) {
                continue;
            }
            try {
                $importedRoutes = $this->import($xml, 'xml');

                $collection->addCollection($importedRoutes);
            } catch (FileLoaderLoadException $e) {
                $this->logger->error($e->getMessage());
            }
        }

        return $collection;
    }

    /**
     * Returns whether this class supports the given resource.
     *
     * @param mixed       $resource A resource
     * @param string|null $type The resource type or null if unknown
     *
     * @return bool True if this class supports the given resource, false otherwise
     */
    public function supports($resource, $type = null)
    {
        return 'oru_dynamic' === $type;
    }

    private function isDisabledBundle($resource)
    {
        if (preg_match('#^@([^/]+)/#', $resource, $match)) {
            $bundleName = $match[1];
            if (in_array($bundleName, $this->disabledBundles)) {
                return true;
            }

            return false;
        }

        $this->logger->warning('Can not determine bundle from resource '.$resource);

        return false;
    }
}
