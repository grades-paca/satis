<?php
/**
 * User: André Cardoso <acardoso@orupaca.fr>
 * Date: 18/08/14
 */
namespace Oru\Bundle\InstallBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OruInstallBundle extends Bundle {

}