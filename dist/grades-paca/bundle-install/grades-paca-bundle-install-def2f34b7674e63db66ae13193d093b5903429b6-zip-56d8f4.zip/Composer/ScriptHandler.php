<?php
/**
 * User: André CARDOSO
 * Date: 18/09/14
 * Time: 17:30
 */

namespace Oru\Bundle\InstallBundle\Composer;

use Composer\IO\IOInterface;
use Composer\Script\Event;
use Symfony\Component\Process\Process;
use Symfony\Component\Yaml\Parser;
use TQ\Git\Repository\Repository;

class ScriptHandler extends \Sensio\Bundle\DistributionBundle\Composer\ScriptHandler
{
    public static function checkUser(Event $event)
    {
        if (!self::checkUnixUser($event->getIO())) {
            if (!$event->getIO()->askConfirmation('<question>Voulez-vous continuer ? [y/N]</question>', false)) {
                die;
            }
        }
    }

    public static function updateGit(Event $event)
    {
        self::checkUser($event);

        if(!$event->getIO()->askConfirmation('<question>Do you want to update sources (we assume that you have a permanent authentication to Git)? [y/N]</question>', false)) {
            return;
        }

        $git = Repository::open('.');

        $event->getIO()->write('<info>Updating sources</info>', true);
        $result = $git->getGit()->{'fetch'}($git->getRepositoryPath());
        $result->assertSuccess(sprintf('Cannot fetch repository.'));
        if($event->getIO()->isVerbose()) {
            $event->getIO()->write("<info>Applying command : 'git fetch'.</info>", true);
        }

        $branch = 'origin/master';
        $config = $event->getComposer()->getPackage()->getExtra();
        if(is_array($config) && isset($config['incenteev-parameters']) && isset($config['incenteev-parameters']['file']))
        {
            $yamlParser = new Parser();
            $params = $yamlParser->parse(file_get_contents($config['incenteev-parameters']['file']));
            if(is_array($params) && isset($params['parameters']) && isset($params['parameters']['install_branch']))
            {
                $branch = $params['parameters']['install_branch'];
            }
        }
        $branch = $event->getIO()->ask(sprintf('<question>What branch do you want to use (default: "%s") ? </question>', $branch), $branch);

        $stashFlag = false;
        if($git->isDirty()) {
            $status = $git->getStatus();
            $event->getIO()->write('Your index contains uncommitted changes : ');
            foreach($status as $file) {
                $event->getIO()->write(" - {$file['file']}", true);
            }
            if(!$stashFlag = $event->getIO()->askConfirmation('<question>Uncommitted changes will be stashed. Do you want to continue updating sources? [y/N]</question>', false)) {
                return;
            }

            $date = 'Update ROR on ' . date('d/m/Y H:i:s');
            $result = $git->getGit()->{'stash'}($git->getRepositoryPath(), array(
                'save',
                $date
            ));
            if($event->getIO()->isVerbose()) {
                $event->getIO()->write("<info>Applying command : 'git stash save \"$date\"'.</info>", true);
            }
            $result->assertSuccess(sprintf('Cannot stash uncommitted changes.'));
        }

        do {
            $response = $event->getIO()->ask(sprintf("<question>Do you want to 'rebase' on %s or 'checkout' %s (default: checkout) ? </question>", $branch, $branch), 'checkout');
        } while ($response != 'rebase' && $response != 'checkout');

        $result = $git->getGit()->{$response}($git->getRepositoryPath(), array(
            $branch
        ));
        if($event->getIO()->isVerbose()) {
            $event->getIO()->write("<info>Applying command : 'git $response $branch'.</info>", true);
        }
        $result->assertSuccess(sprintf('Cannot "%s" "%s"', $response, 'origin/master'));

        if($stashFlag) {
            if($event->getIO()->askConfirmation('<question>Do you want to apply stashed changes? [y/N]</question>', false)) {
                $result = $git->getGit()->{'stash'}($git->getRepositoryPath(), array(
                    'apply'
                ));
                if($event->getIO()->isVerbose()) {
                    $event->getIO()->write("<info>Applying command : 'git stash apply'.</info>", true);
                }
                $result->assertSuccess(sprintf('Cannot apply stash', $response, 'origin/master'));
            }
        }
        $event->getIO()->write('<info>Successful end of sources update</info>', true);
    }

    public static function updateDatabase(Event $event)
    {
        $options = self::getOptions($event);
        $appDir = $options['symfony-app-dir'];

        $process = static::executeCommand($event, $appDir, 'doctrine:schema:update --dump-sql');
        if(!preg_match('/Nothing to update/i',(string)$process->getOutput()))
        {
            if($event->getIO()->askConfirmation('<question>Do you want to update database? [Y/n]</question>', true)) {
                static::executeCommand($event, $appDir, 'doctrine:schema:update --force');
            }
        }
    }

    public static function createDatabase(Event $event)
    {
        $options = self::getOptions($event);
        $appDir = $options['symfony-app-dir'];

        $php = escapeshellarg(self::getPhp());
        $console = escapeshellarg($appDir.'/console');
        if ($event->getIO()->isDecorated()) {
            $console .= ' --ansi';
        }

        $process = new Process($php.' '.$console.' doctrine:database:create', null, null, null, 300);
        $process->run();
        if($process->isSuccessful()) {
            echo $process->getOutput();
        }
        elseif (!$process->isSuccessful() && preg_match('/database exists/i',$process->getOutput())) {
            $event->getIO()->write('<info>Seems that database already exists.</info>', true);
        }
        else {
            throw new \RuntimeException($process->getOutput());

        }
    }

    public static function clearProdCache(Event $event)
    {
        $options = self::getOptions($event);
        $appDir = $options['symfony-app-dir'];

        static::executeCommand($event, $appDir, 'cache:clear -e prod --no-debug');
        static::executeCommand($event, $appDir, 'cache:warmup -e prod');
    }

    public static function installProdAssetic(Event $event)
    {
        $options = self::getOptions($event);
        $appDir = $options['symfony-app-dir'];

        static::executeCommand($event, $appDir, 'assetic:dump -e prod');
    }

    public static function installDevAssetic(Event $event)
    {
        $options = self::getOptions($event);
        $appDir = $options['symfony-app-dir'];

        static::executeCommand($event, $appDir, 'assetic:dump -e dev');
    }

    protected static function executeCommand(Event $event, $appDir, $cmd, $timeout = 300)
    {
        $php = escapeshellarg(self::getPhp());
        $console = escapeshellarg($appDir.'/console');
        if ($event->getIO()->isDecorated()) {
            $console .= ' --ansi';
        }

        $process = new Process($php.' '.$console.' '.$cmd, null, null, null, $timeout);
        $process->run(function ($type, $buffer) { echo $buffer; });
        if (!$process->isSuccessful()) {
            throw new \RuntimeException(sprintf('An error occurred when executing the "%s" command.', escapeshellarg($cmd)));
        }

        return $process;
    }

    /**
     * @param IOInterface $io
     *
     * @return bool
     * @author Michaël VEROUX
     */
    private static function checkUnixUser(IOInterface $io)
    {
        $out = array();
        exec('whoami', $out);
        $currentUser = $out[0];

        $out = array();
        $absolutePath = sprintf('%s/../../../../../../../app/logs', __DIR__);
        $cmd = sprintf('getfacl %s 2> /dev/null', $absolutePath);
        exec($cmd, $out);

        $users = array();
        foreach ($out as $stdout) {
            if (preg_match('#^user:([^:]+):#', $stdout, $match)) {
                $users[] = $match[1];
            }
        }

        if (count($users) && !in_array($currentUser, $users)) {
            if ('root' == $currentUser) {
                $io->writeError('<error>Mise à jour en tant que superutilisateur du système !</error>');
            }
            $io->writeError(sprintf('<error>L\'utilisateur "%s" ne semble pas être correct pour effectuer cette tâche.</error>', $currentUser));

            return false;
        }

        return true;
    }
} 