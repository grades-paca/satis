OruInstallBundle
================

Description
-----------

Ce bundle ajoute des fonctionnalités utiles en environnement de développement et pour le déploiement de l'application :
- des scripts handlers à composer,
- la console symfony via la debug bar,
- le support de Xhprof.

Installation
------------

Importer le paquet via composer

```
./composer.phar require "oru/install":dev-master
```

Dans le AppKernel.php, activer ces bundles en environnement de dev :

``` php
$bundles[] = new Jns\Bundle\XhprofBundle\JnsXhprofBundle();
```

Dans le AppKernel.php, activer ces bundles en environnement de prod :

``` php
$bundles[] = new Oru\Bundle\InstallBundle\OruInstallBundle();
$bundles[] = new CoreSphere\ConsoleBundle\CoreSphereConsoleBundle();
```

Dans le config.yml, ajouter ce bundle aux paramètres imports :

```
imports:
    ...
    - { resource: @OruInstallBundle/Resources/config/config.yml }
```

Dans le config_dev.yml, ajouter ce bundle aux paramètres imports :

```
imports:
    ...
    - { resource: @OruInstallBundle/Resources/config/config_dev.yml }
```

Ajouter les paramètres xhprof_enable (booléen) et xhprof_gui_url (string - url) dans le fichier parameters.yml.

Vider le cache de Symfony2

Utilisation
-----------

### Scripts Handlers

- clearProdCache : Vider le cache en environnement de production
- createDatabase : Créer la base de données
- installDevAssetic : Installer les assetics pour l'environnement de dev
- installProdAssetic : Installer les assetics pour l'environnement de production
- updateDatabase : Mettre à jour la base de données
- updateGit : Mettre à jour les sources via GIT

### Console Symfony via l'interface

Se référer à la documentation de https://github.com/CoreSphere/ConsoleBundle.

### Xhprof
    
Se référer à la documentation de https://github.com/jonaswouters/XhprofBundle.
Les paramètres xhprof_enable et xhprof_gui_url permettent respectivement d'activer le log xhprof dans la table 'details'
et de générer un lien dans la debug bar vers l'application de consultation des logs via XHGui.