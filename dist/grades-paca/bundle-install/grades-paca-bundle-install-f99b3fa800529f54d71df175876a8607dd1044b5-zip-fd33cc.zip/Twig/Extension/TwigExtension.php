<?php
/**
 * @author André Cardoso <acardoso@orupaca.fr>
 */

namespace Oru\Bundle\InstallBundle\Twig\Extension;


use Lexik\Bundle\MaintenanceBundle\Drivers\DriverFactory;

class TwigExtension extends \Twig_Extension
{
    /**
     * @param DriverFactory $lexikFactory
     */
    private $lexikFactory;

    public function setDriverFactory(DriverFactory $lexikFactory)
    {
        $this->lexikFactory = $lexikFactory;
    }

    /**
     * Return the functions registered as twig extensions
     *
     * @return array
     */
    public function getFunctions()
    {
        return array(
            'maintenance' => new \Twig_SimpleFunction('maintenance', array($this, 'maintenance2'))
        );
    }

    /**
     * Is in maintenance mode ?
     *
     * @return mixed
     * @throws \ErrorException
     */
    public function maintenance2()
    {
        return $this->lexikFactory->getDriver()->isExists();
    }

    /**
     * Returns the name of the extension.
     *
     * @return string The extension name
     */
    public function getName()
    {
        return 'oru_install.twig_extension';
    }
}