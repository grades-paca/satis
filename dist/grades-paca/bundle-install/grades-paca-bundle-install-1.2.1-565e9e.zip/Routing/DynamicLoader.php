<?php

namespace Oru\Bundle\InstallBundle\Routing;

use Psr\Log\LoggerInterface;
use Symfony\Component\Config\Exception\FileLoaderLoadException;
use Symfony\Component\Config\Loader\Loader;
use Symfony\Component\Routing\RouteCollection;

/**
 * Class DynamicLoader.
 *
 * @author Michaël VEROUX
 */
class DynamicLoader extends Loader
{
    /**
     * @var array
     */
    protected static $yamls = array();

    /**
     * @var array
     */
    protected static $xmls = array();

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var array
     */
    protected $disabledBundles = array();

    /**
     * DynamicLoader constructor.
     *
     * @param LoggerInterface $logger
     * @param mixed           $disabledBundles
     */
    public function __construct(LoggerInterface $logger, $disabledBundles)
    {
        $this->logger = $logger;
        $this->disabledBundles = $disabledBundles;
    }

    /**
     * @param string $resource
     *
     * @author Michaël VEROUX
     */
    public static function addYaml($resource)
    {
        if (!in_array($resource, self::$yamls, true)) {
            self::$yamls[] = $resource;
        }
    }

    /**
     * @param string $resource
     *
     * @author Michaël VEROUX
     */
    public static function addXml($resource)
    {
        if (!in_array($resource, self::$xmls, true)) {
            self::$xmls[] = $resource;
        }
    }

    /**
     * Loads a resource.
     *
     * @param mixed       $resource The resource
     * @param string|null $type     The resource type or null if unknown
     *
     * @throws \Exception If something went wrong
     *
     * @return RouteCollection
     */
    public function load($resource, $type = null)
    {
        $collection = new RouteCollection();

        foreach (self::$yamls as $yml) {
            if ($this->isDisabledBundle($yml)) {
                continue;
            }
            try {
                $importedRoutes = $this->import($yml, 'yaml');

                $collection->addCollection($importedRoutes);
            } catch (FileLoaderLoadException $e) {
                $this->logger->error($e->getMessage());
            }
        }

        foreach (self::$xmls as $xml) {
            if ($this->isDisabledBundle($xml)) {
                continue;
            }
            try {
                $importedRoutes = $this->import($xml, 'xml');

                $collection->addCollection($importedRoutes);
            } catch (FileLoaderLoadException $e) {
                $this->logger->error($e->getMessage());
            }
        }

        return $collection;
    }

    /**
     * Returns whether this class supports the given resource.
     *
     * @param mixed       $resource A resource
     * @param string|null $type     The resource type or null if unknown
     *
     * @return bool True if this class supports the given resource, false otherwise
     */
    public function supports($resource, $type = null)
    {
        return 'oru_dynamic' === $type;
    }

    private function isDisabledBundle($resource)
    {
        if (preg_match('#^@([^/]+)/#', $resource, $match)) {
            $bundleName = $match[1];
            if (in_array($bundleName, $this->disabledBundles, true)) {
                return true;
            }

            return false;
        }

        $this->logger->warning('Can not determine bundle from resource '.$resource);

        return false;
    }
}
