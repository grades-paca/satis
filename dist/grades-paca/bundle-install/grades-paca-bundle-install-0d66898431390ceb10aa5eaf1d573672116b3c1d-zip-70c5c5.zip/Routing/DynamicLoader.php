<?php

namespace Oru\Bundle\InstallBundle\Routing;

use Symfony\Component\Config\Loader\Loader;
use Symfony\Component\Routing\RouteCollection;

/**
 * Class DynamicLoader
 *
 * @package Oru\Bundle\InstallBundle\Routing
 * @author Michaël VEROUX
 */
class DynamicLoader extends Loader
{
    /**
     * @var array
     */
    static protected $yamls = array();

    /**
     * @var array
     */
    static protected $xmls = array();

    /**
     * @param string $resource
     *
     * @return void
     * @author Michaël VEROUX
     */
    static public function addYaml($resource)
    {
        if (in_array($resource, self::$yamls)) {
            self::$yamls[] = $resource;
        }
    }

    /**
     * @param string $resource
     *
     * @return void
     * @author Michaël VEROUX
     */
    static public function addXml($resource)
    {
        if (in_array($resource, self::$xmls)) {
            self::$xmls[] = $resource;
        }
    }

    /**
     * Loads a resource.
     *
     * @param mixed       $resource The resource
     * @param string|null $type The resource type or null if unknown
     *
     * @return RouteCollection
     *
     * @throws \Exception If something went wrong
     */
    public function load($resource, $type = null)
    {
        $collection = new RouteCollection();

        foreach (self::$yamls as $yml) {
            $importedRoutes = $this->import($yml, 'yaml');

            $collection->addCollection($importedRoutes);
        }

        foreach (self::$xmls as $xml) {
            $importedRoutes = $this->import($xml, 'xml');

            $collection->addCollection($importedRoutes);
        }


        return $collection;
    }

    /**
     * Returns whether this class supports the given resource.
     *
     * @param mixed       $resource A resource
     * @param string|null $type The resource type or null if unknown
     *
     * @return bool True if this class supports the given resource, false otherwise
     */
    public function supports($resource, $type = null)
    {
        return 'oru_dynamic' === $type;
    }
}
