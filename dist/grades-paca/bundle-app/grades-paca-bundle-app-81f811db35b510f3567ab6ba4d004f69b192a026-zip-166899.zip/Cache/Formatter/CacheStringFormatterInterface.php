<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

/**
 * Interface CacheStringFormatterInterface
 *
 * @package Oru\Bundle\AppBundle\Cache\Formatter
 * @author Michaël VEROUX
 */
interface CacheStringFormatterInterface extends CacheFormatterInterface
{
    /**
     * @param object|string|array|mixed $mixed
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function format($mixed);
}
