<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

/**
 * Class CacheShFormatter
 *
 * @package Oru\Bundle\AppBundle\Formatter
 * @author Michaël VEROUX
 */
class CacheBashFormatter extends CacheStringFormatter
{
    /**
     * @param string|array $mixed
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function format($mixed)
    {
        $string = parent::format($mixed);

        $bash = sprintf('#!/bin/bash%s%s', PHP_EOL, $string);

        return $bash;
    }
}
