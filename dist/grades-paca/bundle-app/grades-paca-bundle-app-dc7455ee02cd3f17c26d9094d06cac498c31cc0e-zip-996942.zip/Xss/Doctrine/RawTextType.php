<?php

namespace Oru\Bundle\AppBundle\Xss\Doctrine;

use Doctrine\DBAL\Types\TextType;

/**
 * Class RawTextType
 *
 * @package Oru\Bundle\AppBundle\Xss\Doctrine
 * @author Michaël VEROUX
 */
class RawTextType extends TextType
{
    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'text_raw';
    }
}
