<?php

namespace Oru\Bundle\RorAppBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class OruRorAppBundle
 *
 * @package Oru\Bundle\RorAppBundle
 * @author Michaël VEROUX
 */
class OruAppBundle extends Bundle
{

}
