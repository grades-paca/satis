<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

use Oru\Bundle\AppBundle\Exception\RuntimeException;

/**
 * Class AbstractFilenameRawCreator
 *
 * @package Oru\Bundle\AppBundle\Cache\Formatter
 * @author Michaël VEROUX
 */
abstract class AbstractFilenameRawCreator implements FilenameCreatorInterface
{
    /**
     * @param mixed $mixed
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function generate($mixed)
    {
        if (!is_string($mixed)) {
            throw new RuntimeException('String expected in '.__CLASS__);
        }

        $string = strtolower($mixed);
        $string = preg_replace('#[^a-z0-9_\.-]#', '-', $string);

        return $string;
    }
}
