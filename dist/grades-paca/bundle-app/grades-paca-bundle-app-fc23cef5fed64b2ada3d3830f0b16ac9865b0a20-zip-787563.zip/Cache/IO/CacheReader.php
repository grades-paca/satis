<?php

namespace Oru\Bundle\AppBundle\Cache\IO;

/**
 * Class CacheReader
 *
 * @package Oru\Bundle\AppBundle\Cache\IO
 * @author Michaël VEROUX
 */
class CacheReader extends AbstractFileCache
{
    /**
     * @return bool
     * @author Michaël VEROUX
     */
    public function exists()
    {
        return $this->filesystem->exists($this->getPath());
    }

    /**
     * @return bool|mixed
     * @author Michaël VEROUX
     */
    public function read()
    {
        if (!$this->exists()) {
            return false;
        }

        if ('.php' === substr($this->getPath(), -4)) {
            return include $this->getPath();
        }

        return file_get_contents($this->getPath());
    }
}
