<?php

namespace Oru\Bundle\AppBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class OruAppBundle.
 *
 * @author Michaël VEROUX
 */
class OruAppBundle extends Bundle
{
}
