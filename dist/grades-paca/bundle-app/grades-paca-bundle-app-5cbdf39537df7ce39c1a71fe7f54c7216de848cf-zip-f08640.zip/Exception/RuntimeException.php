<?php

namespace Oru\Bundle\AppBundle\Exception;

/**
 * Class RuntimeException.
 *
 * @author Michaël VEROUX
 */
class RuntimeException extends \RuntimeException
{
}
