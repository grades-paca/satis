<?php

namespace Oru\Bundle\AppBundle\Xss\Doctrine;

use Doctrine\DBAL\Platforms\AbstractPlatform;
use Doctrine\DBAL\Types\TextType;
use Oru\Bundle\AppBundle\Xss\Filter\StringFilter;

/**
 * Class XssTextType.
 *
 * @author Michaël VEROUX
 */
class XssTextType extends TextType
{
    /**
     * Converts a value from its PHP representation to its database representation
     * of this type.
     *
     * @param mixed                                     $value    the value to convert
     * @param \Doctrine\DBAL\Platforms\AbstractPlatform $platform the currently used database platform
     *
     * @return mixed the database representation of the value
     */
    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
        $value = StringFilter::xssTagRemove($value);

        return parent::convertToDatabaseValue($value, $platform);
    }

    /**
     * {@inheritdoc}
     */
    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        $value = parent::convertToPHPValue($value, $platform);
        $value = StringFilter::xssTagRemove($value);

        return $value;
    }
}
