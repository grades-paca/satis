<?php

namespace Oru\Bundle\AppBundle\Xss\Doctrine;

use Doctrine\DBAL\Types\TextType;

/**
 * Class RawTextType.
 *
 * @author Michaël VEROUX
 */
class RawTextType extends TextType
{
    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'text_raw';
    }
}
