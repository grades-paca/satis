<?php

namespace Oru\Bundle\AppBundle\Xss\Doctrine;

use Doctrine\DBAL\Types\StringType;

/**
 * Class RawStringType.
 *
 * @author Michaël VEROUX
 */
class RawStringType extends StringType
{
    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'string_raw';
    }
}
