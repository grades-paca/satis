<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

/**
 * Class FilenameClassCreator.
 *
 * @author Michaël VEROUX
 */
class FilenameClassCreator implements FilenameCreatorInterface
{
    /**
     * @param string $class
     *
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function generate($class)
    {
        return strtr($class, '\\', '-').'.cache.php';
    }
}
