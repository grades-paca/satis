<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

/**
 * Interface FilenameCreatorInterface.
 *
 * @author Michaël VEROUX
 */
interface FilenameCreatorInterface
{
    /**
     * @param mixed $mixed
     *
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function generate($mixed);
}
