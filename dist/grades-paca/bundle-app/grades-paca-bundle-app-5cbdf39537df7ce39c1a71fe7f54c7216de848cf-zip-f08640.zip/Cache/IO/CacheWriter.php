<?php

namespace Oru\Bundle\AppBundle\Cache\IO;

/**
 * Class CacheWriter.
 *
 * @author Michaël VEROUX
 */
class CacheWriter extends AbstractFileCache
{
    /**
     * @param string $string
     *
     * @author Michaël VEROUX
     */
    public function write($string)
    {
        $this->replace($string);
    }

    /**
     * @param string $path
     *
     * @author Michaël VEROUX
     */
    public function move($path)
    {
        if ($this->filesystem->exists($path)) {
            $this->filesystem->remove($path);
        }
        $this->filesystem->rename($this->getPath(), $path);
    }

    /**
     * @param string $string
     *
     * @author Michaël VEROUX
     */
    private function replace($string)
    {
        $this->filesystem->dumpFile($this->getPath(), $string);
        $this->filesystem->chmod(array($this->getPath()), 0750);
    }
}
