<?php

namespace Oru\Bundle\AppBundle\Cache\IO;

use Oru\Bundle\AppBundle\Exception\RuntimeException;
use Symfony\Component\Filesystem\Filesystem;

/**
 * Class AbstractFileCache.
 *
 * @author Michaël VEROUX
 */
abstract class AbstractFileCache
{
    /**
     * @var string
     */
    protected $path;

    /**
     * @var Filesystem
     */
    protected $filesystem;

    /**
     * AbstractFileCache constructor.
     */
    public function __construct()
    {
        $this->init();
    }

    /**
     * @author Michaël VEROUX
     */
    public function init()
    {
        if (!$this->filesystem instanceof Filesystem) {
            $this->filesystem = new Filesystem();
        }
    }

    /**
     * @param string $path
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function setPath($path)
    {
        $this->path = $path;

        return $this;
    }

    /**
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function getPath()
    {
        if (!$this->path) {
            throw new RuntimeException('path must not be null!');
        }

        return $this->path;
    }
}
