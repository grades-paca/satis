<?php

namespace Oru\Bundle\AppBundle\Cache;

use Oru\Bundle\AppBundle\Cache\Formatter\CacheBinaryFormatterInterface;
use Oru\Bundle\AppBundle\Cache\Formatter\CacheFormatterInterface;
use Oru\Bundle\AppBundle\Cache\Formatter\CacheStringFormatterInterface;
use Oru\Bundle\AppBundle\Cache\Formatter\FilenameCreatorInterface;
use Oru\Bundle\AppBundle\Cache\IO\CacheReader;
use Oru\Bundle\AppBundle\Cache\IO\CacheWriter;
use Oru\Bundle\AppBundle\Exception\RuntimeException;

/**
 * Class CacheManager.
 *
 * @author Michaël VEROUX
 */
class CacheManager
{
    /**
     * @var CacheWriter
     */
    protected $cacheWriter;

    /**
     * @var CacheReader
     */
    protected $cacheReader;

    /**
     * @var CacheFormatterInterface
     */
    protected $formatter;

    /**
     * @var FilenameCreatorInterface
     */
    protected $filenameCreator;

    /**
     * @var string
     */
    protected $cacheDirectory;

    /**
     * @var string
     */
    protected $filename;

    /**
     * @var string
     */
    protected $path;

    /**
     * CacheManager constructor.
     *
     * @param CacheWriter              $cacheWriter
     * @param CacheReader              $cacheReader
     * @param CacheFormatterInterface  $formatter
     * @param FilenameCreatorInterface $filenameCreator
     * @param string                   $cacheDirectory
     */
    public function __construct(CacheWriter $cacheWriter, CacheReader $cacheReader, CacheFormatterInterface $formatter, FilenameCreatorInterface $filenameCreator, $cacheDirectory)
    {
        $this->cacheWriter = $cacheWriter;
        $this->cacheReader = $cacheReader;
        $this->formatter = $formatter;
        $this->filenameCreator = $filenameCreator;
        $this->cacheDirectory = $cacheDirectory;
    }

    /**
     * @param mixed $mixed
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function setId($mixed)
    {
        $this->filename = $this->filenameCreator->generate($mixed);
        $this->setInternalId($this->filename);

        return $this;
    }

    /**
     * @param CacheFormatterInterface $formatter
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function setFormatter(CacheFormatterInterface $formatter)
    {
        $this->formatter = $formatter;

        return $this;
    }

    /**
     * @return bool
     *
     * @author Michaël VEROUX
     */
    public function exists()
    {
        return $this->cacheReader->exists();
    }

    /**
     * @return string
     */
    public function getPath()
    {
        return $this->path;
    }

    /**
     * @return bool|mixed
     *
     * @author Michaël VEROUX
     */
    public function read()
    {
        return $this->cacheReader->read();
    }

    /**
     * @param mixed $mixed
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function write($mixed)
    {
        if (!$this->formatter instanceof CacheStringFormatterInterface) {
            throw new RuntimeException('Bad formatter for this method!');
        }
        $string = $this->formatter->format($mixed);

        $this->cacheWriter->write($string);

        return $this;
    }

    /**
     * @param mixed $mixed
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    public function writeBinary($mixed)
    {
        if (!$this->formatter instanceof CacheBinaryFormatterInterface) {
            throw new RuntimeException('Bad formatter for this method!');
        }

        $filename = $this->filename;
        $filenameTmp = $filename.'.tmp';
        $path = $this->cacheWriter->getPath();
        $this->setInternalId($filenameTmp);
        $this->cacheWriter->write('');
        $this->formatter->writeFile($this->cacheWriter->getPath(), $mixed);

        $this->cacheWriter->move($path);
        $this->setInternalId($filename);

        return $this;
    }

    /**
     * @param string $filename
     *
     * @return $this
     *
     * @author Michaël VEROUX
     */
    private function setInternalId($filename)
    {
        $this->path = sprintf('%s/%s', $this->cacheDirectory, $filename);

        $this->cacheReader->setPath($this->path);
        $this->cacheWriter->setPath($this->path);

        return $this;
    }
}
