<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 14/03/2017
 * Time: 15:17
 */

namespace Oru\Bundle\AppBundle\Command;

use Doctrine\Bundle\MigrationsBundle\Command\DoctrineCommand;
use Doctrine\Bundle\MigrationsBundle\Command\Helper\DoctrineCommandHelper;
use Doctrine\DBAL\Migrations\Tools\Console\Command\MigrateCommand;
use Oru\Bundle\AppBundle\Migration\MigrationConfiguration;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class MigrationMigrateCommand.
 */
class MigrationMigrateCommand extends MigrateCommand implements ContainerAwareInterface
{
    /**
     * @var ContainerInterface
     */
    protected $container;

    /**
     * @param ContainerInterface|null $container
     */
    public function setContainer(ContainerInterface $container = null)
    {
        $this->container = $container;
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     */
    public function execute(InputInterface $input, OutputInterface $output)
    {
        // EM and DB options cannot be set at same time
        if (null !== $input->getOption('em') && null !== $input->getOption('db')) {
            throw new \InvalidArgumentException('Cannot set both "em" and "db" for command execution.');
        }

        DoctrineCommandHelper::setApplicationHelper($this->getApplication(), $input);

        $configuration = $this->getMigrationConfiguration($input, $output);
        DoctrineCommand::configureMigrations($this->getApplication()->getKernel()->getContainer(), $configuration);

        //Préparation de la migration OruApp
        $config = new MigrationConfiguration();
        $config
            ->setInput($input)
            ->setOutput($output)
            ->setVersions($configuration->getMigrations())
            ->setTableName($this->container->getParameter('doctrine_migrations.table_name'))
        ;
        $this->container->get('oru_app.migration')
            ->configure($config)
            ->migrate()
        ;
    }

    protected function configure()
    {
        parent::configure();
        $this
            ->setName('oru:migrations:migrate')
            ->addOption('db', null, InputOption::VALUE_REQUIRED, 'The database connection to use for this command.')
            ->addOption('em', null, InputOption::VALUE_REQUIRED, 'The entity manager to use for this command.')
            ->addOption('shard', null, InputOption::VALUE_REQUIRED, 'The shard connection to use for this command.')
        ;
    }
}
