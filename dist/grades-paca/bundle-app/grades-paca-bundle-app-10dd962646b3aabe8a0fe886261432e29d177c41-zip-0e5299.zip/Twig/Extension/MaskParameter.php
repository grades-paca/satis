<?php

namespace Oru\Bundle\AppBundle\Twig\Extension;

use Oru\Bundle\AppBundle\Util\ParameterVisibility;

class MaskParameter extends \Twig_Extension
{
    /**
     * @var ParameterVisibility
     */
    protected $parameterVisibility;

    /**
     * MaskParameter constructor.
     *
     * @param ParameterVisibility $parameterVisibility
     */
    public function __construct(ParameterVisibility $parameterVisibility)
    {
        $this->parameterVisibility = $parameterVisibility;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'mask_parameter';
    }

    /**
     * {@inheritdoc}
     */
    public function getFilters()
    {
        $filters = array(
            new \Twig_SimpleFilter('mask_parameter', array($this, 'maskParameter'), array('is_safe' => array('html'))),
        );

        return $filters;
    }

    /**
     * @param string $string
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function maskParameter($string)
    {
        $masked = $this->parameterVisibility->maskSensibleParameters($string);

        return $masked;
    }
}
