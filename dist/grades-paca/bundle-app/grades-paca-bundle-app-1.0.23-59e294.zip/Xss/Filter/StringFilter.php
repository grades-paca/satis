<?php

namespace Oru\Bundle\AppBundle\Xss\Filter;

use Oru\Bundle\AppBundle\Exception\RuntimeException;

/**
 * Class StringFilter
 *
 * @package Oru\Bundle\AppBundle\Xss\Filter
 * @author Michaël VEROUX
 */
class StringFilter
{
    const PATTERN = '#<%1$s\s?[^>]*>.+</%1$s>#i';

    /**
     * @var array
     */
    static private $htmlTags = array(
        'script',
        'embed',
        'object',
        'iframe',
    );

    /**
     * @var array
     */
    static private $removed = array();

    /**
     * @param string $string
     *
     * @return string|mixed
     * @author Michaël VEROUX
     */
    static public function xssTagRemove($string)
    {
        if (!is_string($string)) {
            return $string;
        }

        $isSerialized = self::isSerialized($string);

        $matches = array();
        $htmlTags = implode('|', self::$htmlTags);
        $htmlTags = sprintf('(%s)', $htmlTags);
        if (count(self::matching($string, $htmlTags, $matches)) && $isSerialized) {
            throw new RuntimeException('Serialized string contains XSS vulnerability.');
        }
        $presentHtmlTags = array();
        if (isset($matches[1])) {
            $presentHtmlTags = array_unique($matches[1]);
        }

        foreach ($presentHtmlTags as $htmlTag) {
            self::logRemoved($string, $htmlTag);
            $string = preg_replace(sprintf(self::PATTERN, $htmlTag), '', $string);
        }

        return $string;
    }

    /**
     * Tests if an input is valid PHP serialized string.
     *
     * Checks if a string is serialized using quick string manipulation
     * to throw out obviously incorrect strings. Unserialize is then run
     * on the string to perform the final verification.
     *
     * Valid serialized forms are the following:
     * <ul>
     * <li>boolean: <code>b:1;</code></li>
     * <li>integer: <code>i:1;</code></li>
     * <li>double: <code>d:0.2;</code></li>
     * <li>string: <code>s:4:"test";</code></li>
     * <li>array: <code>a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}</code></li>
     * <li>object: <code>O:8:"stdClass":0:{}</code></li>
     * <li>null: <code>N;</code></li>
     * </ul>
     *
     * @author		Chris Smith <code+php@chris.cs278.org>
     * @author      Michael Veroux
     * @copyright	Copyright (c) 2009 Chris Smith (http://www.cs278.org/)
     * @license		http://sam.zoy.org/wtfpl/ WTFPL
     * @param		string	$value	Value to test for serialized form
     * @return		boolean			True if $value is serialized data, otherwise false
     */
    static public function isSerialized($value)
    {
        // Bit of a give away this one
        if (!is_string($value))
        {
            return false;
        }
        // Serialized false, return true. unserialize() returns false on an
        // invalid string or it could return false if the string is serialized
        // false, eliminate that possibility.
        if ($value === 'b:0;')
        {
            return true;
        }
        $length	= strlen($value);
        if (0 === $length) {
            return false;
        }
        $end	= '';
        switch ($value[0])
        {
            case 's':
                if (!isset($value[$length - 2]) || $value[$length - 2] !== '"')
                {
                    return false;
                }
            case 'b':
            case 'i':
            case 'd':
                // This looks odd but it is quicker than isset()ing
                $end .= ';';
            case 'a':
            case 'O':
                $end .= '}';
                if (!isset($value[1]) || $value[1] !== ':')
                {
                    return false;
                }
                if (!isset($value[2])) {
                    return false;
                }
                switch ($value[2])
                {
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                        break;
                    default:

                        return false;
                }
            case 'N':
                $end .= ';';
                if ($value[$length - 1] !== $end[0])
                {
                    return false;
                }
                break;
            default:

                return false;
        }
        if (@unserialize($value) === false)
        {
            return false;
        }

        return true;
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    static public function getRemoved()
    {
        return self::$removed;
    }

    /**
     * @param string $string
     * @param string $htmlTag
     *
     * @return void
     * @author Michaël VEROUX
     */
    static private function logRemoved($string, $htmlTag)
    {
        $matches = self::matching($string, $htmlTag);
        if (isset($matches[0])) {
            self::$removed = array_merge(self::$removed, $matches[0]);
        }
    }

    /**
     * @param string $string
     * @param string $htmlTag
     * @param array  $matches
     *
     * @return array
     * @author Michaël VEROUX
     */
    static private function matching($string, $htmlTag, &$matches = array())
    {
        preg_match_all(sprintf(self::PATTERN, $htmlTag), $string, $matches);
        if (isset($matches[0]) && is_array($matches[0]) && !count($matches[0])) {
            return array();
        }

        return $matches;
    }
}
