<?php

namespace Oru\Bundle\AppBundle\Exception;

/**
 * Class RuntimeException
 *
 * @package Oru\Bundle\AppBundle\Exception
 * @author Michaël VEROUX
 */
class RuntimeException extends \RuntimeException
{

}
