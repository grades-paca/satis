Bundle OruAppBundle
=================

Description
-----------

Ce bundle regroupe des fonctionnalités qui sont partageables à l'ensemble des application développées en Symfony à l'ORU.

Installation du Bundle
------------

Importer le paquet via composer

    ./composer.phar require "oru/app":dev-master

Dans le AppKernel.php, activer ce bundle

    $bundles[] = new Oru\Bundle\AppBundle\OruAppBundle();

Dans le config_prod.yml, ajouter ce bundle aux paramètres imports :

    imports:
    ...
    - { resource: @OruAppBundle/Resources/config/config_prod.yml }

Vider le cache de Symfony

Utilisations
------------

### Gestion du cache fichier

#### Créer un service pour gérer un cache fichier

```xml
<service id="cache_string_manager" class="Oru\Bundle\AppBundle\Cache\CacheManager">
    <factory class="Oru\Bundle\AppBundle\Cache\CacheFactory" method="createCacheManager" />
    <argument>%kernel.cache_dir%/bundlenameorwhatyouwantunique</argument>
    <argument>Oru\Bundle\AppBundle\Cache\Formatter\CacheStringFormatter</argument> <!-- Format d'écriture -->
    <argument>Oru\Bundle\AppBundle\Cache\Formatter\FilenameCreator</argument> <!-- Format du nom de fichier -->
</service>
```

*Les différents formats disponibles sont décris ci-dessous.*

#### Utilisation du service

```php
// Écriture
$cache = $this->get('cache_string_manager');
$cache->setId(array('example', 'txt'));
$cache->write('Your text to put in cache file');
```

```php
// Lecture
$cache = $this->get('cache_string_manager');
$cache->setId(array('example', 'txt'));
$yourText = $cache->read(); // $yourText selon vos formatter et la façon de mettre en cache peut être de n'importe quel type...
```
Voir les exemples d'utilisation dans les bundles du ROR pour des usages plus avancés.

#### Formats d'écriture disponibles

- **Bash** Oru\Bundle\AppBundle\Cache\Formatter\CacheBashFormatter

Génère un fichier avec une entête #!/bin/bash et écrit le flux à l'intérieur.

- **String** Oru\Bundle\AppBundle\Cache\Formatter\CacheStringFormatter

Génère un fichier texte et écrit la chaîne de caractère à l'intérieur (si c'est un tableau qui est fourni, les valeurs sont concaténées à l'aide de retours à la ligne)

- **Php** Oru\Bundle\AppBundle\Cache\Formatter\PhpFormatter

Génère un fichier avec une entête <?php et écrit le flux à l'intérieur.

- **Serialized** Oru\Bundle\AppBundle\Cache\Formatter\SerializedFormatter

Génère un fichier avec une entête <?php et écrit le flux sérialisé dans la fonction PHP unserialize

#### Formats de fichiers disponibles

- **Basic** Oru\Bundle\AppBundle\Cache\Formatte\FilenameCreator

Il faudra fournir un nom de fichier et éventuellement une extension

- **Raw** / **Php** Oru\Bundle\AppBundle\Cache\Formatte\FilenameRawCreator

Une extension .php sera ajoutée à la fin du nom du fichier

- **Class** Oru\Bundle\AppBundle\Cache\Formatte\FilenameClassCreator

Une extension .cache.php sera ajoutée à la fin du nom de fichier, le nom de la classe fourni comme nom de fichier est converti en nom de fichier exploitable

#### Ajout de formats supportés

S'ils sont génériques, il est opportun de les ajouter à ce bundle. Quoiqu'il en soit ils doivent implémenter l'interface adéquat. S'inspirer des classes existantes pour en créer une.


