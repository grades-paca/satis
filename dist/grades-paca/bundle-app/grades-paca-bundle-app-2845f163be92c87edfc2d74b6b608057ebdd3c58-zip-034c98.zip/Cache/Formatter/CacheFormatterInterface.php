<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

/**
 * Interface CacheFormatterInterface.
 *
 * @author Michaël VEROUX
 */
interface CacheFormatterInterface
{
}
