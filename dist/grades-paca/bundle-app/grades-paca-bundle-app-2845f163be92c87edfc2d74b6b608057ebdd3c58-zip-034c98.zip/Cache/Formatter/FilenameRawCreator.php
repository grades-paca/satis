<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

/**
 * Class FilenameRawCreator.
 *
 * @author Michaël VEROUX
 */
class FilenameRawCreator extends AbstractFilenameRawCreator
{
    /**
     * @param mixed $mixed
     *
     * @return string
     *
     * @author Michaël VEROUX
     */
    public function generate($mixed)
    {
        $string = parent::generate($mixed);

        return $string.'.php';
    }
}
