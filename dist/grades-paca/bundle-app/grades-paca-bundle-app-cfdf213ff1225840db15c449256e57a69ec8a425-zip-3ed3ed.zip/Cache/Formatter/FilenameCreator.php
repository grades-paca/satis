<?php

namespace Oru\Bundle\AppBundle\Formatter;

use Oru\Bundle\AppBundle\Cache\Formatter\AbstractFilenameRawCreator;
use Oru\Bundle\AppBundle\Exception\RuntimeException;

/**
 * Class FilenameCreator
 *
 * @package Oru\Bundle\AppBundle\Formatter
 * @author Michaël VEROUX
 */
class FilenameCreator extends AbstractFilenameRawCreator
{
    /**
     * @param array $mixed ex: array('filename','ext')
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function generate($mixed)
    {
        if (!is_array($mixed)) {
            throw new RuntimeException('$mixed must be an array!');
        }
        if (1 !== count($mixed) && 2 !== count($mixed)) {
            throw new RuntimeException('$mixed must contains 1 element for file without extension, 2 otherwise!');
        }

        $filename = (string)array_shift($mixed);
        if (count($mixed)) {
            $ext = array_shift($mixed);
        }

        $filenameFinal = parent::generate($filename);
        if (isset($ext) && $ext) {
            $filenameFinal = sprintf('%s.%s', $filenameFinal, $ext);
        }

        return $filenameFinal;
    }

}
