<?php

namespace Oru\Bundle\AppBundle\Cache\IO;

/**
 * Class CacheWriter
 *
 * @package Oru\Bundle\AppBundle\Cache\IO
 * @author Michaël VEROUX
 */
class CacheWriter extends AbstractFileCache
{
    /**
     * @param string $string
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function write($string)
    {
        $this->replace($string);
    }

    /**
     * @param string $path
     *
     * @return void
     * @author Michaël VEROUX
     */
    public function move($path)
    {
        if ($this->filesystem->exists($path)) {
            $this->filesystem->remove($path);
        }
        $this->filesystem->rename($this->getPath(), $path);
    }

    /**
     * @param string $string
     *
     * @return void
     * @author Michaël VEROUX
     */
    private function replace($string)
    {
        $this->filesystem->dumpFile($this->getPath(), $string);
        $this->filesystem->chmod([$this->getPath()], 0750);
    }

}
