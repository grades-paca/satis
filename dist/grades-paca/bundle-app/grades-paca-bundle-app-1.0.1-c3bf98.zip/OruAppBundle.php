<?php

namespace Oru\Bundle\AppBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class OruAppBundle
 *
 * @package Oru\Bundle\AppBundle
 * @author Michaël VEROUX
 */
class OruAppBundle extends Bundle
{

}
