<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

use Oru\Bundle\AppBundle\Exception\RuntimeException;

/**
 * Class CacheStringFormatter
 *
 * @package Oru\Bundle\AppBundle\Formatter
 * @author Michaël VEROUX
 */
class CacheStringFormatter implements CacheStringFormatterInterface
{
    /**
     * @param object|string|array|mixed $mixed
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function format($mixed)
    {
        $string = $mixed;
        if (is_array($string)) {
            $string = implode(PHP_EOL, $string);
        }
        if (!is_string($string)) {
            throw new RuntimeException(sprintf('%s does not support this $mixed format to be tansformed to string!'));
        }

        return $string;
    }
}
