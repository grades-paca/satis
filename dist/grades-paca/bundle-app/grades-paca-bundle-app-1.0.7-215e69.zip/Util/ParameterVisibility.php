<?php

namespace Oru\Bundle\AppBundle\Util;

use Symfony\Component\DependencyInjection\ParameterBag\ParameterBag;

/**
 * Class ParameterVisibility
 *
 * @package Oru\Bundle\AppBundle\Util
 * @author Michaël VEROUX
 */
class ParameterVisibility
{
    /**
     * @var ParameterBag
     */
    protected $parameterBag;

    /**
     * ParameterVisibility constructor.
     *
     * @param ParameterBag $parameterBag
     */
    public function __construct(ParameterBag $parameterBag)
    {
        $this->parameterBag = $parameterBag;
    }

    /**
     * @param string $string
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function maskSensibleParameters($string)
    {
        $parameters = $this->toString10Parameters();
        foreach ($parameters as $parameter) {
            $pattern = sprintf('#([\'=])%s[^;,\)\']+([;,\)\'])#', preg_quote($parameter, '#'));
            $string = preg_replace($pattern, '$1--removed--$2', $string);
        }

        return $string;
    }

    /**
     * @param mixed $mixed
     *
     * @return bool
     * @author Michaël VEROUX
     */
    private function filterStringSensibility($mixed)
    {
        if (!is_string($mixed)) {
            return false;
        }

        return true;
    }

    /**
     * @param string $string
     *
     * @return string
     * @author Michaël VEROUX
     */
    private function toLength10($string)
    {
        return substr($string, 0, 10);
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    private function toString10Parameters()
    {
        $parameters = array_filter($this->parameterBag->all(), array($this, 'filterStringSensibility'));
        $parameters = array_map(array($this, 'toLength10'), $parameters);
        $parameters = array_unique($parameters);

        return $parameters;
    }
}
