<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

/**
 * Interface CacheBinaryFormatterInterface
 *
 * @package Oru\Bundle\AppBundle\Cache\Formatter
 * @author Michaël VEROUX
 */
interface CacheBinaryFormatterInterface extends CacheFormatterInterface
{
    /**
     * @param string $path
     * @param mixed  $mixed
     *
     * @return mixed
     * @author Michaël VEROUX
     */
    public function writeFile($path, $mixed);
}
