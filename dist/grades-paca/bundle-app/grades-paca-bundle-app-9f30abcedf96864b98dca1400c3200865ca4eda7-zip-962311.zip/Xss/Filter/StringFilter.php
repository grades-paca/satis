<?php

namespace Oru\Bundle\AppBundle\Xss\Filter;

use Oru\Bundle\AppBundle\Exception\RuntimeException;

/**
 * Class StringFilter
 *
 * @package Oru\Bundle\AppBundle\Xss\Filter
 * @author Michaël VEROUX
 */
class StringFilter
{
    const PATTERN = '#<%1$s\s?[^>]*>.+</%1$s>#i';

    /**
     * @var array
     */
    static private $htmlTags = array(
        'script',
        'embed',
        'object',
        'iframe',
    );

    /**
     * @var array
     */
    static private $removed = array();

    /**
     * @param string $string
     *
     * @return string
     * @author Michaël VEROUX
     */
    static public function xssTagRemove($string)
    {
        $isSerialized = @unserialize($string);
        if ('b:0;' === $string) {
            $isSerialized = true;
        }
        
        foreach (self::$htmlTags as $htmlTag) {
            if ($isSerialized && count(self::matching($string, $htmlTag))) {
                throw new RuntimeException('Serialized string contains XSS vulnerability.');
            }
            self::logRemoved($string, $htmlTag);
            $string = preg_replace(sprintf(self::PATTERN, $htmlTag), '', $string);
        }

        return $string;
    }

    /**
     * @return array
     * @author Michaël VEROUX
     */
    static public function getRemoved()
    {
        return self::$removed;
    }

    /**
     * @param string $string
     * @param string $htmlTag
     *
     * @return void
     * @author Michaël VEROUX
     */
    static private function logRemoved($string, $htmlTag)
    {
        $matches = self::matching($string, $htmlTag);
        if (isset($matches[0])) {
            self::$removed = array_merge(self::$removed, $matches[0]);
        }
    }

    /**
     * @param string $string
     * @param string $htmlTag
     *
     * @return array
     * @author Michaël VEROUX
     */
    static private function matching($string, $htmlTag)
    {
        $matches = array();
        preg_match_all(sprintf(self::PATTERN, $htmlTag), $string, $matches);
        if (isset($matches[0]) && is_array($matches[0]) && !count($matches[0])) {
            return array();
        }

        return $matches;
    }
}
