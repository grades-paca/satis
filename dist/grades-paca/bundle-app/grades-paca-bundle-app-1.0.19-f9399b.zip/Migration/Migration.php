<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 13/03/2017
 * Time: 13:31
 */

namespace Oru\Bundle\AppBundle\Migration;

use Doctrine\DBAL\Migrations\Version;
use Doctrine\ORM\EntityManager;
use Symfony\Bundle\FrameworkBundle\Console\Application;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\HttpKernel\Kernel;

/**
 * Class Migration
 * @package Oru\Bundle\AppBundle\Migration
 */
class Migration
{
    /**
     * @var Kernel
     */
    protected $kernel;

    /**
     * @var EntityManager
     */
    protected $em;

    /**
     * @var MigrationConfiguration
     */
    protected $configuration;

    /**
     * Migration constructor.
     * @param Kernel $kernel
     */
    public function __construct(Kernel $kernel, EntityManager $em)
    {
        $this->kernel = $kernel;
        $this->em = $em;
    }

    /**
     * @param MigrationConfiguration $configuration
     */
    public function configure(MigrationConfiguration $configuration){
        $this->configuration = $configuration;

        return $this;
    }

    /**
     * @throws \Exception
     */
    public function revert(){

        $config = $this->configuration;
        $input = $config->getInput();
        $output = $config->getOutput();

        //Console UI => Init
        $io = new SymfonyStyle($config->getInput(), $config->getOutput());
        $io->title("Revert migrations");

        $start = microtime(true);
        $computed = array();
        
        foreach($this->getDownMigrationsArrayFromConfig() as $version){
            if($this->isVersionExistsInDatabase($version)){

                $application = new Application($this->kernel);
                $application->setAutoExit(false);

                $newInput = new ArrayInput(array(
                    'command'   => 'doctrine:migrations:execute',
                    'version' => $version,
                    '--down' => true,
                    '--no-interaction' => true,
                ));

                $application->run($newInput, $output);
                $computed[] = $version;
            }
        }

        //Console UI => Time
        if(count($computed)){
            $end = microtime(true);
            $total = $end - $start;
            $io->block('++ Terminé en '.$total.' s');
        }else{
            $io->note("Aucune migration à annuler");
        }
    }

    /**
     * @param Version[] $versions
     * @throws \Exception
     */
    public function migrate(){

        $config = $this->configuration;
        $input = $config->getInput();
        $output = $config->getOutput();

        //Console UI => Init
        $io = new SymfonyStyle($config->getInput(), $config->getOutput());
        $io->title("Application migrations");

        $start = microtime(true);
        $computed = array();

        /** @var Version $version */
        foreach($config->getVersions() as $version){
            if(!$this->isVersionExistsInDatabase($version->getVersion()) &&
               !in_array($version->getVersion(), $this->getDownMigrationsArrayFromConfig())
            ){
                $application = new Application($this->kernel);
                $application->setAutoExit(false);

                $newInput = new ArrayInput(array(
                    'command' => 'doctrine:migrations:execute',
                    'version' => $version->getVersion(),
                    '--up' => true,
                    '--no-interaction' => true,
                ));

                $application->run($newInput, $output);
                $computed[] = $version;
            }
        }

        //Console UI => Time
        if(count($computed)){
            $end = microtime(true);
            $total = $end - $start;
            $io->block('++ Terminé en '.$total.' s');
        }else{
            $io->note("Aucune migration à exécuter");
        }
    }

    protected function isVersionExistsInDatabase($version){
        return (bool) $this->em->getConnection()->fetchAll("SELECT * FROM ".$this->configuration->getTableName()." WHERE version='".$version."'");
    }

    protected function getDownMigrationsArrayFromConfig(){
        $downMigrations = array();
        if($this->config && array_key_exists('migrations_down', $this->config)){
            $downMigrations = $this->config['migrations_down'];
        }
        return $downMigrations;
    }
}