<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

/**
 * Interface CacheFormatterInterface
 *
 * @package Oru\Bundle\AppBundle\Cache\Formatter
 * @author Michaël VEROUX
 */
interface CacheFormatterInterface
{
    /**
     * @param object|string|array|mixed $mixed
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function format($mixed);
}
