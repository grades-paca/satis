<?php

namespace Oru\Bundle\AppBundle\Cache;

/**
 * Class CacheFactory
 *
 * @package Oru\Bundle\AppBundle\Cache
 * @author Michaël VEROUX
 */
class CacheFactory
{
    /**
     * @param string $cacheDirectory
     * @param string $classWriterName
     * @param string $classReaderName
     * @param string $formatterName
     * @param string $filenameCreatorName
     *
     * @return CacheManager
     * @author Michaël VEROUX
     */
    public function createCacheManager($cacheDirectory, $formatterName, $filenameCreatorName, $classWriterName = 'Oru\Bundle\AppBundle\Cache\IO\CacheWriter', $classReaderName = 'Oru\Bundle\AppBundle\Cache\IO\CacheReader')
    {
        $writer = new $classWriterName();
        $reader = new $classReaderName();
        $formatter = new $formatterName();
        $filenameCreator = new $filenameCreatorName();

        $cacheManager = new CacheManager($writer, $reader, $formatter, $filenameCreator, $cacheDirectory);

        return $cacheManager;
    }
}
