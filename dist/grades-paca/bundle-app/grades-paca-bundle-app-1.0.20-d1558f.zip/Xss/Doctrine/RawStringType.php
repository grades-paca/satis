<?php

namespace Oru\Bundle\AppBundle\Xss\Doctrine;

use Doctrine\DBAL\Types\StringType;

/**
 * Class RawStringType
 *
 * @package Oru\Bundle\AppBundle\Xss\Doctrine
 * @author Michaël VEROUX
 */
class RawStringType extends StringType
{
    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'string_raw';
    }
}
