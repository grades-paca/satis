<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

/**
 * Class SerializedFormatter
 *
 * @package Oru\Bundle\AppBundle\Cache\Formatter
 * @author Michaël VEROUX
 */
class SerializedFormatter implements CacheFormatterInterface
{
    /**
     * @param object|string|array|mixed $mixed
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function format($mixed)
    {
        $pattern = '<?php return unserialize(%s);';
        $string = sprintf($pattern, var_export(serialize($mixed), true));

        return $string;
    }
}
