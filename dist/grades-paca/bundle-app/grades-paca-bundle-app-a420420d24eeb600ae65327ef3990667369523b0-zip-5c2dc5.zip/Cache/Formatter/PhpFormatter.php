<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

/**
 * Class PhpFormatter
 *
 * @package Oru\Bundle\AppBundle\Cache\Formatter
 * @author Michaël VEROUX
 */
class PhpFormatter implements CacheFormatterInterface
{
    /**
     * @param array|string $mixed Array of php instructions
     *
     * @return string
     * @author Michaël VEROUX
     */
    public function format($mixed)
    {
        if (!is_array($mixed)) {
            $mixed = array($mixed);
        }
        $php = implode(PHP_EOL, $mixed);
        $string = '<?php'.PHP_EOL.$php.PHP_EOL;

        return $string;
    }
}
