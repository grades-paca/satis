<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 13/03/2017
 * Time: 15:01
 */

namespace Oru\Bundle\AppBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Oru\Bundle\AppBundle\Migration\MigrationConfiguration;

/**
 * Class MigrationRevertCommand
 * @package Oru\Bundle\AppBundle\Command
 */
class MigrationRevertCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('oru:migrations:revert')
            ->setDescription('Industrialisation des DoctrineMigration dans le contexte OruApp: exécution des méthodes DOWN')
        ;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        //Préparation de la migration OruApp
        $config = new MigrationConfiguration();
        $config
            ->setInput($input)
            ->setOutput($output)
            ->setTableName($this->getContainer()->getParameter('doctrine_migrations.table_name'))
        ;
        $this->getContainer()->get('oru_app.migration')
            ->configure($config)
            ->revert()
        ;
    }
}