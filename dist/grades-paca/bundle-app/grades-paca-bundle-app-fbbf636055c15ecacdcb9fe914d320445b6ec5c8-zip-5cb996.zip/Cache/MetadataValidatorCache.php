<?php

namespace Oru\Bundle\AppBundle\Cache;

use Symfony\Component\Validator\Mapping\Cache\CacheInterface;
use Symfony\Component\Validator\Mapping\ClassMetadata;

/**
 * Class MetadataValidatorCache
 *
 * @package Oru\Bundle\AppBundle\Cache
 * @author Michaël VEROUX
 */
class MetadataValidatorCache implements CacheInterface
{
    /**
     * @var CacheManager
     */
    protected $cacheManager;

    /**
     * MetadataValidatorCache constructor.
     *
     * @param CacheManager $cacheManager
     */
    public function __construct(CacheManager $cacheManager)
    {
        $this->cacheManager = $cacheManager;
    }

    /**
     * Returns whether metadata for the given class exists in the cache.
     *
     * @param string $class
     *
     * @return bool
     */
    public function has($class)
    {
        $this->configure($class);

        return $this->cacheManager->exists();
    }

    /**
     * Returns the metadata for the given class from the cache.
     *
     * @param string $class Class Name
     *
     * @return ClassMetadata|false A ClassMetadata instance or false on miss
     */
    public function read($class)
    {
        $this->configure($class);

        return $this->cacheManager->read();
    }

    /**
     * Stores a class metadata in the cache.
     *
     * @param ClassMetadata $metadata A Class Metadata
     */
    public function write(ClassMetadata $metadata)
    {
        $this->configure($metadata->getClassName());

        $this->cacheManager->write($metadata);
    }

    /**
     * @param string $class
     *
     * @return void
     * @author Michaël VEROUX
     */
    private function configure($class)
    {
        $this->cacheManager->setId($class);
    }
}
