<?php

namespace Oru\Bundle\AppBundle\Cache\Formatter;

/**
 * Interface CacheFormatterInterface
 *
 * @package Oru\Bundle\AppBundle\Cache\Formatter
 * @author Michaël VEROUX
 */
interface CacheFormatterInterface
{

}
