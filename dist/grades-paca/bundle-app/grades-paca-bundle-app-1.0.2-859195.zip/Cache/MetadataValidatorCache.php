<?php

namespace Oru\Bundle\AppBundle\Cache;

use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Validator\Mapping\Cache\CacheInterface;
use Symfony\Component\Validator\Mapping\ClassMetadata;

/**
 * Class MetadataValidatorCache
 *
 * @package Oru\Bundle\AppBundle\Cache
 * @author Michaël VEROUX
 */
class MetadataValidatorCache implements CacheInterface
{
    /**
     * @var string
     */
    protected $cacheDirectory;

    /**
     * MetadataValidatorCache constructor.
     *
     * @param string $cacheDirectory
     */
    public function __construct($cacheDirectory)
    {
        $this->cacheDirectory = $cacheDirectory;
    }

    /**
     * Returns whether metadata for the given class exists in the cache.
     *
     * @param string $class
     *
     * @return bool
     */
    public function has($class)
    {
        $path = $this->getPath($class);
        $filesystem = new Filesystem();
        if (!$filesystem->exists($path)) {
            return false;
        }

        return true;
    }

    /**
     * Returns the metadata for the given class from the cache.
     *
     * @param string $class Class Name
     *
     * @return ClassMetadata|false A ClassMetadata instance or false on miss
     */
    public function read($class)
    {
        if (!$this->has($class)) {
            return false;
        }

        $path = $this->getPath($class);

        return include $path;
    }

    /**
     * Stores a class metadata in the cache.
     *
     * @param ClassMetadata $metadata A Class Metadata
     */
    public function write(ClassMetadata $metadata)
    {
        $path = $this->getPath($metadata->getClassName());

        file_put_contents($path, '<?php return unserialize('.var_export(serialize($metadata), true).');');
    }

    /**
     * @param string $class
     *
     * @return string
     * @author Michaël VEROUX
     */
    private function getPath($class)
    {
        $path = $this->getCacheDirectory().'/'.strtr($class, '\\', '-').'.cache.php';

        return $path;
    }

    /**
     * @return string
     * @author Michaël VEROUX
     */
    private function getCacheDirectory()
    {
        $filesystem = new Filesystem();
        if (!$filesystem->exists($this->cacheDirectory)) {
            $filesystem->mkdir($this->cacheDirectory);
        }

        return $this->cacheDirectory;
    }
}
