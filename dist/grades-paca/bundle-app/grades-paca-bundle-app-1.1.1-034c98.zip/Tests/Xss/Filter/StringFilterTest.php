<?php

namespace Oru\Bundle\AppBundle\Tests\Xss\Filter;

use Oru\Bundle\AppBundle\Xss\Filter\StringFilter;

/**
 * Class StringFilterTest.
 *
 * @author Michaël VEROUX
 */
class StringFilterTest extends \PHPUnit_Framework_TestCase
{
    /**
     * @author Michaël VEROUX
     */
    public function testIsSerialized()
    {
        $test = serialize(array());
        $this->assertTrue(StringFilter::isSerialized($test));

        $test = serialize(null);
        $this->assertTrue(StringFilter::isSerialized($test));

        $test = serialize(false);
        $this->assertTrue(StringFilter::isSerialized($test));

        $test = serialize(true);
        $this->assertTrue(StringFilter::isSerialized($test));

        $test = serialize(new \stdClass());
        $this->assertTrue(StringFilter::isSerialized($test));

        $test = serialize('test');
        $this->assertTrue(StringFilter::isSerialized($test));

        $test = serialize(1);
        $this->assertTrue(StringFilter::isSerialized($test));

        $test = serialize(0);
        $this->assertTrue(StringFilter::isSerialized($test));

        $test = serialize('');
        $this->assertTrue(StringFilter::isSerialized($test));

        $test = array();
        $this->assertFalse(StringFilter::isSerialized($test));

        $test = null;
        $this->assertFalse(StringFilter::isSerialized($test));

        $test = false;
        $this->assertFalse(StringFilter::isSerialized($test));

        $test = true;
        $this->assertFalse(StringFilter::isSerialized($test));

        $test = new \stdClass();
        $this->assertFalse(StringFilter::isSerialized($test));

        $test = 'test';
        $this->assertFalse(StringFilter::isSerialized($test));

        $test = 1;
        $this->assertFalse(StringFilter::isSerialized($test));

        $test = 0;
        $this->assertFalse(StringFilter::isSerialized($test));

        $test = '';
        $this->assertFalse(StringFilter::isSerialized($test));
    }

    /**
     * @dataProvider stringProvider
     *
     * @author Michaël VEROUX
     *
     * @param mixed $input
     * @param mixed $expected
     */
    public function testXssTagRemove($input, $expected)
    {
        $this->assertSame($expected, StringFilter::xssTagRemove($input));
    }

    /**
     * @return array
     *
     * @author Michaël VEROUX
     */
    public function stringProvider()
    {
        return array(
            array('<script type="text/javascript">alert("stop")</script><p>salut !</p>', '<p>salut !</p>'),
            array(sprintf('<input type="text" name="test" /><script type="text/javascript">alert("stop")</script>%s<p>salut !</p>', PHP_EOL), sprintf('<input type="text" name="test" />%s<p>salut !</p>', PHP_EOL)),
        );
    }
}
