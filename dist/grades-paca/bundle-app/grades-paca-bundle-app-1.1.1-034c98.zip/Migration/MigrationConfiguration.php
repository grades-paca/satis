<?php
/**
 * Created by PhpStorm.
 * User: MGONZALEZ
 * Date: 15/03/2017
 * Time: 14:31
 */

namespace Oru\Bundle\AppBundle\Migration;

use Doctrine\DBAL\Migrations\Version;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class MigrationConfiguration
{
    /**
     * @var InputInterface
     */
    protected $input;

    /**
     * @var OutputInterface
     */
    protected $output;

    /**
     * @var Version[]
     */
    protected $versions;

    /**
     * @var string
     */
    protected $tableName;

    /**
     * @return InputInterface
     */
    public function getInput()
    {
        return $this->input;
    }

    /**
     * @param InputInterface $input
     */
    public function setInput($input)
    {
        $this->input = $input;

        return $this;
    }

    /**
     * @return OutputInterface
     */
    public function getOutput()
    {
        return $this->output;
    }

    /**
     * @param OutputInterface $output
     */
    public function setOutput($output)
    {
        $this->output = $output;

        return $this;
    }

    /**
     * @return \Doctrine\DBAL\Migrations\Version[]
     */
    public function getVersions()
    {
        return $this->versions;
    }

    /**
     * @param \Doctrine\DBAL\Migrations\Version[] $versions
     */
    public function setVersions($versions)
    {
        $this->versions = $versions;

        return $this;
    }

    /**
     * @return string
     */
    public function getTableName()
    {
        return $this->tableName;
    }

    /**
     * @param string $tableName
     */
    public function setTableName($tableName)
    {
        $this->tableName = $tableName;
    }
}
